angular.module("mainApp",["ngRoute"])
		.directive("itemDirective",function(){
			return{
				restrict:"E",
				templateUrl:"item.html",
				controller:function($scope){
					$scope.val="Welcome folks";
				}
			};
		})
		.controller("itemController",function($scope){
			$scope.emp=[{"name":"Soumik","id":100906},{"name":"Sourav","id":100907},{"name":"Mamun","id":100904}];
			
		})
		.config(["$routeProvider",function($routeProvider){
			$routeProvider
				.when("/item1",{
					templateUrl:"show.htm"
				});
		}]);