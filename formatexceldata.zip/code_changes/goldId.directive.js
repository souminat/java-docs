angular.module('app.components.goldId.directive', ['app.config','app.services.goldId','app.services.company'])

.directive('mytrsGoldId', function (config) {
	return {
		restrict: 'E',
		scope: {
			ngModel: '=',
			name: '@',
			ngRequired: '=',
			componentCodes: '=',
			//param parameter added for blocking company codes import
			param: '='
		},
		templateUrl: config.templateBasePath + 'app/components/goldId/goldId.directive.html',
		controller:function($scope, goldIdManager,companyManager) {
			$scope.goldIdSelected = ($scope.ngModel.leCode)?$scope.ngModel.leCode+' - '+$scope.ngModel.leName:null;
			$scope.noResults = false;
			$scope.showSearchIcon=true;
			
			$scope.getFilteredGoldIds = function(searchTerm){
				var result = [];
					$scope.goldIds = goldIdManager.getGoldIdsList(searchTerm);					
					return $scope.goldIds.then(function(mdmData){
							result = mdmData.$resolved? mdmData.responseData.data: []; 
							result = _.reject(result, function(val){ return _.contains(config.rejLe, val.PRIMRY_ALT_CODE); });
							if(result.length === 0) {
								$scope.noResults = true;
							}
							else {
								$scope.noResults = false;
							}
							return  result; 	
					});		
	
			
			}
			$scope.onSelect = function () {
				console.log($scope.param);
				console.log($scope.name);
				if(!_.isUndefined($scope.param) && $scope.param == "filter"){
					$scope.ngModel.leName=	$scope.goldIdSelected.PARTY_NM;
					$scope.ngModel.leVersion=	$scope.goldIdSelected.VERSION_NUM;
					$scope.ngModel.leCode=	$scope.goldIdSelected.PRIMRY_ALT_CODE;
					$scope.ngModel.accountTitle	=$scope.goldIdSelected.PARTY_NM;
					$scope.ngModel.componentCode = null;
					$scope.showSearchIcon=false;
					$scope.componentCodes = $scope.goldIdSelected.ComponentCodeList;
				}else{
					$scope.ngModel.leName=	$scope.goldIdSelected.PARTY_NM;
					$scope.ngModel.leVersion=	$scope.goldIdSelected.VERSION_NUM;
					$scope.ngModel.leCode=	$scope.goldIdSelected.PRIMRY_ALT_CODE;
					$scope.ngModel.accountTitle	=$scope.goldIdSelected.PARTY_NM;
					$scope.ngModel.componentCode = null;
					$scope.showSearchIcon=false;
					$scope.componentCodes = $scope.goldIdSelected.ComponentCodeList;
					$scope.ngModel.companyCodeList=null;
		    		$scope.ngModel.companyCode=null;
					$scope.companyCodeList=companyManager.getCompanyCodes($scope.ngModel.leCode);
					$scope.companyCodeList.then(function(mdmData){
						$scope.ngModel.companyCodeList = mdmData;
						console.log(mdmData);
					});
				}
				
        	};
        	
       

		}
	};
}).directive('resetGoldidValues', function () {
	  return {
		    require: 'ngModel',
		    link: function (scope, element, attr, ngModel) {
		      //when user deletes the last character in the search box, reset the values to null
		      element.bind('keyup', function () {
		    	  if(ngModel.$viewValue==""){
		    		  scope.ngModel.leName=	null;
		    		  scope.ngModel.leVersion=	null;
		    		  scope.ngModel.leCode=	null;
		    		  scope.componentCodes = [];
		    		  scope.ngModel.componentCode = null;
		    		  scope.ngModel.companyCodeList=null;
		    		  scope.ngModel.companyCode=null;
		    	  }
		      });
		    }
		  };
		});