package com.ge.treasury.mybank.web.controllers.fileupload;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.beanio.BeanReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadActivityService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadService;
import com.ge.treasury.mybank.config.CacheService;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.BulkUploadError;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.MDMDetails;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.validations.BulkUploadFileValidator;
import com.ge.treasury.mybank.util.web.CSVFileReader;
import com.ge.treasury.mybank.web.controllers.BaseController;


@Controller
@RequestMapping(BulkApprovalConstants.API)
public class BulkUploadController extends BaseController implements BulkApprovalConstants {

	@Value("${mybank.url.openRequest}")
	private String openTemplate;

	@Value("${mybank.url.modifyRequest}")
	private String modifyTemplate;

	@Value("${mybank.url.closeRequest}")
	private String closeTemplate;

	@Value("${mybank.url.signerRequest}")
	private String signerTemplate;

	@Value("${mybank.url.faq}")
	private String faq;
	
	@Value("${mybank.gelib.applicationId}")
    private String applicationId;
    @Value("${mybank.gelib.app.userId}")
    private String defaultUserId;
    @Value("${mybank.gelib.app.password}")
    private String applicationPassword;
    @Value("${mybank.gelib.localDirectory}")
    private String localDirectory;

	CSVFileReader fileReader = new CSVFileReader();

	@Autowired
	BulkUploadService bulkUploadService;

	@Autowired
	FileUploadActivityService fileUploadActivityService;
	
	@Autowired
	BulkUploadFileValidator bulkUploadFileValidator;
	
	@Autowired
	CacheService cacheService;

	@Autowired
	BulkApprovalService bulkApprovalService;
	
	@Autowired
    FileUploadService fileUploadService;
	
	 
	@RequestMapping(value = "/checkCache", method = RequestMethod.GET)
		public void checkCache(HttpServletRequest request){
		MDMDetails a = cacheService.fetchMDMDataForValidation();
	 }
	
	
	/**
	 * Save raw file to DB
	 * 
	 * @param request
	 * @param file
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/bulkUpload", method = RequestMethod.POST)
	public @ResponseBody FileUpload postFileUpload(HttpServletRequest request,
			@RequestParam("file") final MultipartFile file,
			@RequestParam("uploadType") String fileUploadType) throws Exception {
		User user = (User) request.getSession().getAttribute("User");
		Set<String> tcodeSet = new HashSet<String>();
		Set<String> accountNumbersSet=new HashSet<String>();
		Map<String,Set<String>> duplicateCheckMap=new HashMap<String,Set<String>>();
		duplicateCheckMap.put("tCode", tcodeSet);
		duplicateCheckMap.put("openAccountValidation", accountNumbersSet);
		String userId = user.getSso();
		String transactionId = MyBankLogger.getTransactionId();
		long startTime = System.currentTimeMillis();

		MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);

		FileUpload fileUpload = new FileUpload();
		MDMDetails mdmData = cacheService.fetchMDMDataForValidation();
		
		// Load Required MDM Details
		//bulkUploadService.loadMDMDetails(mdmData);
		//BufferedOutputStream stream=null;
		String name = file.getOriginalFilename();
		if (name == null || name.matches(ValidationConstants.CSV_REGEX)) {
			if (!file.isEmpty()) {
				try {
					byte[] bytes = file.getBytes();
					file.getInputStream();
					File serverFile = new File(name);

					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(bytes);
					stream.close();
					
					List<BulkApprovalRequest> accountList = new ArrayList<BulkApprovalRequest>();
					List<BulkUploadError> errorList = new ArrayList<BulkUploadError>();
					List<BulkAccountSigner> bulkSigners=new ArrayList<BulkAccountSigner>(); 
					if ( BULK_UPLOAD_OPEN.equals(fileUploadType)) {
						fileUpload.setUpldTypeCode(BULK_UPLOAD_FILE_TYPE_OPEN);
					} else if (BULK_UPLOAD_CLOSE.equals(fileUploadType)) {
						fileUpload.setUpldTypeCode(BULK_UPLOAD_FILE_TYPE_CLOSE);
					} else if (BULK_UPLOAD_MODIFY.equals(fileUploadType)) {
						fileUpload.setUpldTypeCode(BULK_UPLOAD_FILE_TYPE_MODIFY);
					} else if (BULK_UPLOAD_SIGNER.equals(fileUploadType)) {
						fileUpload.setUpldTypeCode(BULK_UPLOAD_FILE_TYPE_SIGNER);
					}
					
					BeanReader reader = CSVFileReader.readCSVFromStream(file.getInputStream(), fileUpload.getUpldTypeCode());
					Object record = null;
					int recordCount = 2;
					while ((record = reader.read()) != null) {
						if (BULK_UPLOAD_OPEN_TEMPLATE.equals(reader.getRecordName())) {
							BulkApprovalRequest account = (BulkApprovalRequest) record;
							bulkUploadFileValidator.validateMDMData(duplicateCheckMap, account, fileUpload, mdmData, errorList,
									recordCount);
							accountList.add(account);
						}
						if (BULK_UPLOAD_CLOSE_TEMPLATE.equals(reader.getRecordName())) {
							BulkApprovalRequest account = (BulkApprovalRequest) record;
							bulkUploadFileValidator.validateMDMData(duplicateCheckMap, account, fileUpload, mdmData, errorList,
									recordCount);
							accountList.add(account);
						}
						if(BULK_UPLOAD_MODIFY_TEMPLATE.equals(reader.getRecordName())) {
							BulkApprovalRequest account = (BulkApprovalRequest) record;
							bulkUploadFileValidator.validateMDMData(duplicateCheckMap, account, fileUpload, mdmData, errorList,
									recordCount);
							accountList.add(account);
						}
						if(BULK_UPLOAD_SIGNER_TEMPLATE.equals(reader.getRecordName())) {
							BulkAccountSigner account = (BulkAccountSigner) record;
							bulkUploadFileValidator.validateSignerData(duplicateCheckMap, account, fileUpload, mdmData, errorList,
									recordCount);
							bulkSigners.add(account);
						}
						recordCount++;
					}
					if(BULK_UPLOAD_FILE_TYPE_SIGNER.equals(fileUpload.getUpldTypeCode())){
						fileUpload.setTotalCount((long) bulkSigners.size());
					}else{
					fileUpload.setTotalCount((long) accountList.size());
					}
					
					if (fileUpload.getBulkUploadError().size() < 1) {
						bulkUploadService.createFileUpload(fileUpload, serverFile, user);
						MyBankLogger.logDebug(this, "Successfully uploaded file => " + name);
						FileUploadActivity fileUploadActivity = 
								createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_SUBMITTED);
						
						MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
						fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
					}
				} catch (IOException e) {
					MyBankLogger.logError(this, "Failed to upload " + name + " => " + e.getMessage());
					throw new BusinessException("Failed to upload " + name + " => " + e.getMessage());
				}
			} else {
				MyBankLogger.logError(this, "Failed to upload " + name + " because the file was empty.");
				throw new BusinessException("Failed to upload " + name + " because the file was empty.");
			}
		} else {
			throw new BusinessException("Extension type of file " + name + " is not the correct one.");
		}

		if (fileUpload != null) {
			MyBankLogger.logPerf(this, userId, transactionId,
					"File upload id " + fileUpload.getFileUpldId() + " created",
					System.currentTimeMillis() - startTime);
		}

		return fileUpload;
	}


	/**
	 * Obtain File Upload Record(s), The request can contain the following
	 * parameters.
	 * 
	 * @param request
	 * @param columnName
	 * @param orderBy
	 * @return - FileUpload Records
	 */
	@RequestMapping(value = "/bulkUpload", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK) // 200
	public @ResponseBody List<FileUpload> getFileUpload(HttpServletRequest request,
			@RequestParam("columnName") String columnName, @RequestParam("orderBy") String orderBy) throws DBException {

		List<FileUpload> fileUploadResponseSort = null;
		try {

			fileUploadResponseSort = bulkUploadService.loadProcessingQueueSortBy(columnName, orderBy);
			MyBankLogger.logDebug(this, "Processing queue loaded successfully ");
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException(dbe.getMessage());
		}

		return fileUploadResponseSort;
	}
//changes made for download file validation for exponential value
	/**
	 * Download the bulk upload Templates, The request can contain the following
	 * parameters. To do search: File upload.
	 * 
	 * @param request
	 */
	@RequestMapping(value = "/bulkDownload", method = RequestMethod.GET)
	public @ResponseBody void downloadUploadedFile(@RequestParam("fileId") String fileId, HttpServletRequest request,
			HttpServletResponse response) throws DBException, BusinessException {
		String fileName = null;
		ByteArrayInputStream bis = null;
		String headerValue = null;
		String headerKey = "Content-Disposition";
		int len;
		FileUpload fileUpload = bulkUploadService.downLoadFile(Long.parseLong(fileId));
		MyBankLogger.logDebug(this, "After calling downloadFile=> ");
		fileName = fileUpload.getFileName();
		response.setContentType("application/text");
		headerValue = String.format("attachment; filename=\"%s\"", fileName);
		
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet(headerValue);
		
		response.setHeader(headerKey, headerValue);
		
		byte[] fileData = fileUpload.getUploadedFile().getBytes();
		StringBuilder str = new StringBuilder();
		
		String strArray[] = null;
		
		
		
		//int index = 0;
		
		byte[] buf = new byte[1024];
		try {
			for(byte b:fileData){
				str.append((char)b);
				//System.out.println((char)b);
			}
			String str2 = new String();
			//System.out.println(str);
			
			//str2 += str;
			String[] headerArray = new String[100];
			String[] valueArray = new String[100];
			String [][] fileContent = new String[100][100];
			String[] tempArray = new String[100];
			strArray = str.toString().split("\n");
		
			
			headerArray = strArray[0].split(",");
			
			
			
			/*for(String tempStr : strArray){
				System.out.println(tempStr);
			}*/
			
			
			//int headerLength = 22;
			
			
			int i;
			
			System.out.println("printing headers");
			for(i = 0 ; i < headerArray.length ; ++i){
				fileContent [0][i] = headerArray[i];
				//System.out.println(fileContent[0][i]);
			}
		/*	
			System.out.println("Printing file content");
			for(int l = 23;l < strArray.length; ++l){
				
				valueArray[l] = strArray[l];
				System.out.println(valueArray[l]);
				
			}*/
			
			int k = 0;
			int m = 0;
			int j = 1;
			int contentLength = strArray.length - 1;
			
			//System.out.println(contentLength);
			
			//System.out.println("printing content");
			
			for(int l = 1;l <= contentLength; ++l){
				tempArray = strArray[l].split(",");
				for(k = 0;k < tempArray.length; ++k){
					//System.out.println("inside k loop");
					fileContent[j][k] = tempArray[k];
					//System.out.println(fileContent[j][k]);
				}
					++j;
			}
			
			
			Object[][] excelContent = new Object[100][100];
			
			for(int index = 0;index < fileContent.length; ++index){
				for(int index1 = 0;index1 < fileContent[index].length;++index1){
					excelContent[index][index1] = (Object)fileContent[index][index1];
				}
			}
			
			 int rowNum = 0;
			
			for (int index = 0;index < excelContent.length; ++index){
	            Row row = sheet.createRow(rowNum++);
	            int colNum = 0;
	            for (int index1 = 0; index1 < excelContent[index].length; ++index1) {
	                Cell cell = row.createCell(colNum++);
	                //if((excelContent[index][index1].toString()).contains("E+")){
	                	//cell.setCellValue((Integer)excelContent[index][index1]);
	                	/*Double num = Double.parseDouble(excelContent[index][index1].toString());
	                	NumberFormat formatter = new DecimalFormat("#.#############");*/
	                	//cell.setCellType(Cell.CELL_TYPE_STRING);
	                	/*DataFormat format = workbook.createDataFormat();
	                	CellStyle cellStyle = workbook.createCellStyle();
	                	cellStyle.setDataFormat(format.getFormat("#.000"));
	                	cell.setCellStyle(cellStyle);*/
	                	//cell.setCellValue((Integer)excelContent[index][index1]);
	                //}else{
	                try{
	                	if((excelContent[index][index1]).toString()!=null && (excelContent[index][index1]).toString().contains("E+")){
	                		Double num = Double.parseDouble(excelContent[index][index1].toString());
		                	NumberFormat formatter = new DecimalFormat("#.#############");
		                	System.out.println(formatter.format(num));
	                		cell.setCellValue((formatter.format(num)));
		                	//cell.setCellType(Cell.CELL_TYPE_NUMERIC);
		                	
	                	}else{
	                		cell.setCellValue(excelContent[index][index1].toString());
	                	}
	                
	                }catch(Exception e){
	                	//System.out.println(e.getMessage());
	                }
	                //}
	                	
	            }
	        }
			
			
			workbook.write(response.getOutputStream());
			workbook.close();
			
		} catch (IOException e) {
			throw new BusinessException("Failed to download the file " + fileName + " => " + e.getMessage());
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException(dbe.getMessage());
		} finally {
			try {
				bis.close();
			} catch (IOException e) {
				throw new BusinessException("Failed to download the file " + fileName + " => " + e.getMessage());
			}

			try {
				response.getOutputStream().flush();
			} catch (IOException e) {
				throw new BusinessException("Failed to download the file " + fileName + " => " + e.getMessage());
			}
		}
	}

	@RequestMapping(value = "/bulkDownloadTemplate", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody void downloadTemplate(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("type") String type, @RequestParam("url") String url) throws BusinessException, ParserConfigurationException, SAXException,
			UnsupportedEncodingException, MalformedURLException {
		String templateUrl = null;
		//String fileName = null;

		switch (type) {
		case BULK_UPLOAD_OPEN:
			templateUrl = openTemplate;
			//fileName = "MyBank Bulk Upload Open Template.xlsx";
			break;
		case BULK_UPLOAD_MODIFY:
			templateUrl = modifyTemplate;
			//fileName = "MyBank Bulk Upload Modify Template.xlsx";
			break;
		case BULK_UPLOAD_CLOSE:
			templateUrl = closeTemplate;
			//fileName = "MyBank Bulk Upload Close Template.xlsx";
			break;
		case BULK_UPLOAD_SIGNER:
			templateUrl = signerTemplate;
			//fileName = "MyBank Bulk Upload Signer Template.xlsx";
			break;
		case BULK_UPLOAD_FAQ:
			templateUrl = faq;
			//fileName = "Upload FAQ.pdf";
			break;
		case BULK_UPLOAD_HELP_FAQ:
			templateUrl = url;
			//fileName = "FAQ.docx";
			break;
		case BULK_UPLOAD_HELP_REPORTS:
			templateUrl = url;
			//fileName = "Reports.docx";
			break;
		case BULK_UPLOAD_HELP_CONTACTS:
			templateUrl = url;
			//fileName = "Bank Admin Contacts.pptx";
			break;
		default:
			break;
		}
		
		Map<String, String> map;
		String fileId = "";
		map = StringHelper.splitQuery(new URL(templateUrl));

		if (map.containsKey(BulkApprovalConstants.FILE_ID)) {
			fileId = map.get(BulkApprovalConstants.FILE_ID);
		}
		Boolean isAccountDocumentDownloaded;
		String fileNameFrmMetaData = "";
		try {
			AccountDocument accountDocument = bulkApprovalService.getMetadataForFile(fileId);
			fileNameFrmMetaData = accountDocument.getDocName();
			isAccountDocumentDownloaded = fileUploadService.downloadFileById(fileId, fileNameFrmMetaData, localDirectory,
					defaultUserId, applicationId, applicationPassword);
			if (!isAccountDocumentDownloaded) {
				throw new BusinessException(FileUploadConstants.UNABLE_DOWNLOAD + fileNameFrmMetaData);
			} else {
				fileUploadService.downloadFileByOutputStream(response, fileNameFrmMetaData, localDirectory);
			}
			File file = new File(localDirectory + fileNameFrmMetaData);
			boolean isFileDeleted = fileUploadService.deleteLocalFile(file);
			if (isFileDeleted)
				MyBankLogger.logInfo(this, FileUploadConstants.FILE_DELETED_SUCCESS);
			else
				MyBankLogger.logInfo(this, FileUploadConstants.UNABLE_DELETE);
		} catch (IOException e) {
			throw new BusinessException(FileUploadConstants.UNABLE_DOWNLOAD + fileNameFrmMetaData, e);
		}
	}
	
	@RequestMapping(value = "/fetchTemplateDetails", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody Map<String, String> fetchTemplateDetails() {
		Map<String,String> templateMap = new HashMap<String,String>();
		AccountDocument document = null;

		document = fetchTempMetaData(openTemplate);
		templateMap.put("OPEN", document.getModifiedOn());

		document = fetchTempMetaData(modifyTemplate);
		templateMap.put("MODIFY", document.getModifiedOn());

		document = fetchTempMetaData(closeTemplate);
		templateMap.put("CLOSE", document.getModifiedOn());

		document = fetchTempMetaData(signerTemplate);
		templateMap.put("SIGNER", document.getModifiedOn());

		return templateMap;
	}

	private AccountDocument fetchTempMetaData(String url) {
		String fileId = "";
		AccountDocument document = null;
		if (!url.isEmpty()) {
			Map<String, String> map;
			try {
				map = StringHelper.splitQuery(new URL(url));
				if (map.containsKey(BulkApprovalConstants.FILE_ID)) {
					fileId = map.get(BulkApprovalConstants.FILE_ID);
				}
				document = bulkApprovalService.getMetadataForFile(fileId);

			} catch (UnsupportedEncodingException | MalformedURLException e) {
				MyBankLogger.logError(this, "Error in Decoding the Document URL" + e.getMessage(), e);
				throw new SystemException(e);
			}
		}
		return document;
	}
}
