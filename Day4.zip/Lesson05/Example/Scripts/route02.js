var app = angular.module('routeApp',['ngRoute']);
app.config(function($routeProvider){
	/*	$routeProvider
		.when('/',                            
		{
			template:'<h1>Please select a service</h1>'
		})
		.when('/view1',{
				controller:'AccController',
				templateUrl:'partials/createAcc.html'
		})
		.when('/view2',{
				controller: 'MainController',
				templateUrl: 'partials/viewDetails.html'
		})
		.when('/view3',{
				controller: 'AccController',
				templateUrl: 'partials/Success.html'
		})
		.otherwise({
			redirectTo:'/'
		})*/
});

app.controller("AccController",function($scope){
	$scope.rate = "8.5";
	$scope.name = "";
	$scope.address = "";
	$scope.phNo = "";
});

app.controller("MainController",function($scope,){
	$scope.accounts = "[
	{"accId":"101","custName":"Kunal","balance":"89788"},
	{"accId":"102","custName":"Akash","balance":"1212"},
	{"accId":"103","custName":"Ronald","balance":"23233"},
	{"accId":"106","custName":"Allen","balance":"52346"},
	]";
	
});


