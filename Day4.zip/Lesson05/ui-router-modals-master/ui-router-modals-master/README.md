ui-router-modals
================

Repo for my SitePoint article here <link pending>

Easy to get up and running in a unix environment.
Just clone the repo and then run a simple file server in the directory:

e.g

```
git clone git@github.com:Haizyfox/ui-router-modals.git

cd ui-router-modals

python -m SimpleHTTPServer 2723
```

You should now have a working example at `http://localhost:2723`
