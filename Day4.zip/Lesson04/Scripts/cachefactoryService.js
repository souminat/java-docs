var app = angular.module("serviceApp",[]);


app.factory("customCache",function($cacheFactory){
	//return $cacheFactory('customCache')
	//Cache eviction policy is Least recently used
	return $cacheFactory('customCache',{capacity:3})
})

app.factory("cgCache",function($cacheFactory){
	//return $cacheFactory('customCache')
	//Cache eviction policy is Least recently used
	return $cacheFactory('customCache',{capacity:3})
})

