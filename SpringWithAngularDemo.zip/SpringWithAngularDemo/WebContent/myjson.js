/**
 * 
 */

var webService = angular.module("webService",[]);

webService.controller('ServiceController',function($scope,$http){
	refreshPageData();
	
	function refershPageData(){
		$http({
			method:'GET',
			url:'http://localhost:8080/SpringWithAngularDemo/rest/products.json'
		}).success(function(data){
				$scope.posts = data;//response data
		});
	}
	
	$scope.form = {
			productId:'',
			productName:'',
			productPrice:''
			};	
	$scope.add = function(){
		$http({
			method:'POST',
			url:'http://localhost:8080/rest/products/create' +$scope.form.productId+'/'+$scope.form.productName+'/'+$scope.form.productPrice
		}).success(function(data){
				alert("DATA Added");
				refreshPageData();
		});
	}
	$scope.remove = function(data){
		$http({
			method:'DELETE',
			url:'http://localhost:8080/rest/products/delete' +data
		}).success(function(data){
				alert("Data Removed");
				refreshPageData();
		});
		
		
	}
});