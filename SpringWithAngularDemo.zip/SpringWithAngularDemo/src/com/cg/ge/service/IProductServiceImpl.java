package com.cg.ge.service;

import java.util.List;

import com.cg.ge.dao.IProductDao;
import com.cg.ge.dao.ProductDaoImpl;
import com.cg.ge.dto.Product;

public class IProductServiceImpl implements IProductService {
	IProductDao productDao = new ProductDaoImpl();
	@Override
	public void addProduct(Product product) {
		productDao.addProduct(product);

	}

	@Override
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

	@Override
	public List<Product> deleteProduct(String id) {
		return productDao.deleteProduct(id);
	}

}
