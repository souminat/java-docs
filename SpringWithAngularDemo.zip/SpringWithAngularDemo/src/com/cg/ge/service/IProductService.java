package com.cg.ge.service;

import java.util.List;

import com.cg.ge.dto.Product;

public interface IProductService {
	public void addProduct(Product product);
	public List<Product> getAllProducts();
	public List<Product> deleteProduct(String id);
}
