package com.cg.ge.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.ge.dto.Product;

public class ProductDb {
	private static List<Product> productList = new ArrayList<Product>();
	
	static{
		productList.add(new Product("101","Mobile","11000"));
		productList.add(new Product("102","Laptop","40000"));
		productList.add(new Product("103","Mouse","200"));
		productList.add(new Product("104","Keyboard","350"));
		productList.add(new Product("105","Hard Disk","4000"));
	}

public static List<Product> getProductList(){
	return productList;
}

public static void setProductList(List<Product> productList){
	ProductDb.setProductList(productList);	
}

}


