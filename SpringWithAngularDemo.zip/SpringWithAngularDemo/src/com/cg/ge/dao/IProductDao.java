package com.cg.ge.dao;

import java.util.List;
import org.springframework.http.HttpHeaders;


import com.cg.ge.dto.Product;

public interface IProductDao {
	public void addProduct(Product product);
	public List<Product> getAllProducts();
	public Product deleteProduct(String id);
}
