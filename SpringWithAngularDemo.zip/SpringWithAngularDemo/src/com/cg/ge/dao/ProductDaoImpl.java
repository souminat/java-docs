package com.cg.ge.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ge.dto.Product;
import com.cg.ge.staticdb.ProductDb;

public class ProductDaoImpl implements IProductDao {
	List<Product> productList = new ArrayList<Product>();
	
	@Override
	public void addProduct(Product product) {
		productList = ProductDb.getProductList();
		productList.add(product);
		ProductDb.setProductList(productList);
		}

	@Override
	public List<Product> getAllProducts() {
		return ProductDb.getProductList();
	}

	@Override
	public List<Product> deleteProduct(String id) {
		productList = ProductDb.getProductList();
		productList.remove(id);
		ProductDb.setProductList(productList);
		
		return ProductDb.getProductList();
	}

}
