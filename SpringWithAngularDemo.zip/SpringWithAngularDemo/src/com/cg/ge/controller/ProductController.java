package com.cg.ge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ge.dto.Product;
import com.cg.ge.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService productService;
	
	@RequestMapping(value="/products",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@RequestMapping(value="/products/create/{productId}/{rproductName}/{productPrice}",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Product> createProduct(@PathVariable String id,@PathVariable String name,@PathVariable String price){
		Product product = new Product(id,name,price);
		
		productService.addProduct(product);
		
		return productService.getAllProducts();
	}
	
	@RequestMapping(value="/products/delete/{productId}",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Product> deleteProduct(@PathVariable String id){
		productService.deleteProduct(id);
		return productService.getAllProducts();
	}
}
