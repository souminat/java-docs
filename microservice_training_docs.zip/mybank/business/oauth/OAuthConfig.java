/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.oauth;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;

/**
 * Configuration class for Spring OAuth Security
 * 
 * @author MyBank Dev Team
 * 
 */
@EnableOAuth2Client
@Configuration
public class OAuthConfig {

    @Value("${audit.ms.scope}")
    private String msAuditScope;
    
	@Value("${finegrainauth.ms.scope}")
    private String msFineGrainAuthScope;
	
	@Value("${mybank.finegrain.oauth.clientId}")
	private String msFineGrainClientId;
    
	@Value("${mybank.finegrain.oauth.clientSecret}")
	private String msFineGrainSecret;
	
	@Value("${hrApi.oauth.scope}")
    private String hrApiScope;

    @Value("${mybank.oauth.accessTokenUri}")
    private String accessTokenUri;

    @Value("${mybank.oauth.clientId}")
    private String clientId;

    @Value("${mybank.oauth.clientSecret}")
    private String clientSecret;

    @Value("${mybank.oauth.grantType}")
    private String grantType;
    
    @Value("${mdm.ms.scope}")
    private String mdmServiceScope;
    
    @Value("${mdm.ms.clientId}")
    private String mdmServiceClientId;

    @Value("${mdm.ms.clientSecret}")
    private String mdmServiceClientSecret;
    
    @Value("${mdm.ms.bankacctcentralize.client_id}")
    private String mdmBankCentralizeServiceClientID;
    
    @Value("${mdm.ms.bankacctcentralize.clientSecret}")
    private String mdmBankCentralizeServiceClientSecret;
    
    @Value("${mdm.ms.bankacctcentralize.scope}")
    private String mdmBankCentralizeServiceScope;
    
    @Bean
    protected OAuth2ProtectedResourceDetails resource() {
        ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();

        ArrayList<String> scope = new ArrayList<String>();
        scope.add(hrApiScope);

        resource.setAccessTokenUri(accessTokenUri);
        resource.setClientId(clientId);
        resource.setClientSecret(clientSecret);
        resource.setScope(scope);
        resource.setGrantType(grantType);

        return resource;
    }

    @Bean
    public OAuth2RestOperations myBankRestTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(resource(), oauth2ClientContext);
    }
    
    @Bean
    protected OAuth2ProtectedResourceDetails msauditresource() {
        ClientCredentialsResourceDetails msauditresource = new ClientCredentialsResourceDetails();

        ArrayList<String> msAuditScopeArr = new ArrayList<String>();
        msAuditScopeArr.add(msAuditScope);

        msauditresource.setAccessTokenUri(accessTokenUri);
        msauditresource.setClientId(msFineGrainClientId);
        msauditresource.setClientSecret(msFineGrainSecret);
        msauditresource.setScope(msAuditScopeArr);
        msauditresource.setGrantType(grantType);

        return msauditresource;
    }

    @Bean
    public OAuth2RestOperations msAuditRestTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(msauditresource(), oauth2ClientContext);
    }
    
    @Bean
    public OAuth2RestOperations mdmBankCentralizeTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(bankCentralizeResourceTemplate(), oauth2ClientContext);
    }
    
    @Bean
    protected OAuth2ProtectedResourceDetails bankCentralizeResourceTemplate() {
        ClientCredentialsResourceDetails bankCentralizeResource = new ClientCredentialsResourceDetails();
        ArrayList<String> bankCentralizeResourceScopeArr = new ArrayList<String>();
        bankCentralizeResourceScopeArr.add(mdmBankCentralizeServiceScope);
        bankCentralizeResource.setAccessTokenUri(accessTokenUri);
        bankCentralizeResource.setClientId(mdmBankCentralizeServiceClientID);
        bankCentralizeResource.setClientSecret(mdmBankCentralizeServiceClientSecret);
        bankCentralizeResource.setScope(bankCentralizeResourceScopeArr);
        bankCentralizeResource.setGrantType(grantType);
        return bankCentralizeResource;
    }
    
    @Bean
    protected OAuth2ProtectedResourceDetails msfinegrainauthresource() {
        ClientCredentialsResourceDetails msfinegrainauthresource = new ClientCredentialsResourceDetails();

        ArrayList<String> msFineGrainScope = new ArrayList<String>();
        msFineGrainScope.add(msFineGrainAuthScope);

        msfinegrainauthresource.setAccessTokenUri(accessTokenUri);
        msfinegrainauthresource.setClientId(msFineGrainClientId);
        msfinegrainauthresource.setClientSecret(msFineGrainSecret);
        msfinegrainauthresource.setScope(msFineGrainScope);
        msfinegrainauthresource.setGrantType(grantType);

        return msfinegrainauthresource;
    }

    @Bean
    public OAuth2RestOperations msFineGrainAuthRestTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(msfinegrainauthresource(), oauth2ClientContext);
    }
    
    @Bean
    protected OAuth2ProtectedResourceDetails mdmServiceResource() {
        ClientCredentialsResourceDetails mdmServiceResource = new ClientCredentialsResourceDetails();

        ArrayList<String> mdmServiceScopeArr = new ArrayList<String>();
        mdmServiceScopeArr.add(mdmServiceScope);

        mdmServiceResource.setAccessTokenUri(accessTokenUri);
        mdmServiceResource.setClientId(mdmServiceClientId);
        mdmServiceResource.setClientSecret(mdmServiceClientSecret);
        mdmServiceResource.setScope(mdmServiceScopeArr);
        mdmServiceResource.setGrantType(grantType);

        return mdmServiceResource;
    }

    @Bean
    public OAuth2RestOperations mdmServiceRestTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(mdmServiceResource(), oauth2ClientContext);
    }
    
    @Bean
    protected OAuth2ProtectedResourceDetails newMdmServiceResource() {
        ClientCredentialsResourceDetails newMdmServiceResource = new ClientCredentialsResourceDetails();

        ArrayList<String> mdmServiceScopeArr = new ArrayList<String>();
        mdmServiceScopeArr.add(mdmServiceScope);

        newMdmServiceResource.setAccessTokenUri(accessTokenUri);
        newMdmServiceResource.setClientId(mdmServiceClientId);
        newMdmServiceResource.setClientSecret(mdmServiceClientSecret);
        
        newMdmServiceResource.setScope(mdmServiceScopeArr);
        newMdmServiceResource.setGrantType(grantType);

        return newMdmServiceResource;
    }
    
    @Bean
    public OAuth2RestOperations newMdmServiceRestTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(newMdmServiceResource(), oauth2ClientContext);
    }
    
    @Bean
	protected OAuth2ProtectedResourceDetails newMdmServiceMyPayResource() {
		ClientCredentialsResourceDetails newMdmServiceResource = new ClientCredentialsResourceDetails();

		ArrayList<String> mdmServiceScopeArr = new ArrayList<String>();
		mdmServiceScopeArr.add(mdmServiceScope);

		newMdmServiceResource.setAccessTokenUri(accessTokenUri);

		newMdmServiceResource.setClientId(mdmServiceClientId);
		newMdmServiceResource.setClientSecret(mdmServiceClientSecret);

		newMdmServiceResource.setScope(mdmServiceScopeArr);
		newMdmServiceResource.setGrantType(grantType);

		return newMdmServiceResource;
	}
    
    @Bean
    public OAuth2RestOperations newMdmServiceMyPayRestTemplate() {
        OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();
        return new OAuth2RestTemplate(newMdmServiceMyPayResource(), oauth2ClientContext);
    }
}
