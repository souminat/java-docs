/**
 * 
 */
package com.ge.treasury.mybank.business.mdm.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;

import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;

/**
 * @author MyBank Dev Team
 * 
 */
public class MDMUtil {

	 private static final Map<String, String> NETWORK_TYPE_MAP = new HashMap<String, String>();
	        
	 	static{
	        	NETWORK_TYPE_MAP.put("NETWORKTYPE_PREFERRED", "Preferred");
	        	NETWORK_TYPE_MAP.put("NETWORKTYPE_NONPREFERRED", "Non-Preferred");
	        	NETWORK_TYPE_MAP.put("NETWORKTYPE_SPECIALPURPOSE_BNK", "Special Purpose Bank");
	        }
	    
	    
	    
	    private static final Map<String, String> NETWORK_TYPE_MAP_BACKUP = new HashMap<String, String>();
	        static{
	        	NETWORK_TYPE_MAP_BACKUP.put("Preferred", "NETWORKTYPE_PREFERRED");
	        	NETWORK_TYPE_MAP_BACKUP.put("Non-Preferred", "NETWORKTYPE_NONPREFERRED");
	        	NETWORK_TYPE_MAP_BACKUP.put("Special Purpose Bank", "NETWORKTYPE_SPECIALPURPOSE_BNK");
	        }
	   
	
    private MDMUtil() {
    }
    /**
     * @param obj
     * @return String json format object
     * @throws SystemException
     */
    public static String constructJsonString(Object obj) throws SystemException {
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();

        try {
            return ow.writeValueAsString(obj);
        } catch (IOException e) {
            MyBankLogger.logError(new MDMUtil(), e.getMessage(), e);
            throw new SystemException("SystemException " + e.getMessage());
        }

    }
    public static String trimToBlank(String value){
    	
    	if(value!=null){
    		return value.trim();
    	}
    	else {
    		return "";
    	}
    }
    
    public static String trimToBlankForSelect(String value){
    	
    	if(value!=null && !"Select".equalsIgnoreCase(value.trim())){
    		return value.trim();
    	}
    	else {
    		return "";
    	}
    }
    
    public static String fetchNetworkTypeDesc(String code){
    	
    	String desc =  NETWORK_TYPE_MAP.get(code);
    	String returnValue = "";
    	if(null==StringUtils.trimToNull(desc)){
    		boolean isKeyRight = NETWORK_TYPE_MAP_BACKUP.containsKey(code);
    		if(isKeyRight){
    			returnValue = code;
    		}
    	}else{
    		returnValue = desc;
    	}
    	
    	return returnValue;
    }

}
