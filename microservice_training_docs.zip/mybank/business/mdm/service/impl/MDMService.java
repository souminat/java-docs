/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.mdm.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.springframework.http.HttpMethod;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Service;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.mdm.MDMAccount;
import com.ge.treasury.mybank.domain.mdm.MDMSearchAccounts;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;

/**
 * Calling MDM Microservice Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
@Service
public interface MDMService {

    /**
     * Once status changed to COMPLETE, need to construct that MDM JSON and call
     * MDM service
     * 
     * @param accRequest
     * @return
     * @throws DBException
     * @throws BusinessException
     * @throws SystemException
     */
    public AccountRequest sendToMDM(AccountRequest accRequest)
            throws SystemException, ValidationFailedException;

    /**
     * Verify if the account is open using Tcode as a search parameter
     * 
     * @param tCode
     * @return true if open, false if otherwise
     * @throws SystemException
     * @throws Exception 
     * @throws BusinessException
     */
    public boolean isAccountOpen(String tCode) throws SystemException;
    
    public boolean isAccountValid(String tCode) throws UnsupportedEncodingException;
    
    public List<UserRole> isBusinessSubBusinessOpen(List<UserRole> search) throws SystemException;

    public JSONArray getMDMRouteDetails(AccountRequest accRequest) throws SystemException;

    public JSONArray getMDMLEDetails(AccountRequest accRequest);

    public JSONArray getMDMBankDetails(AccountRequest accRequest) throws SystemException;

    public String callMDM(String jsonString, String url, OAuth2RestOperations mdmRestTemplate);

    public MDMAccount constructMDMAccount(AccountRequest accRequest, String mdmAcctStatusInprocess);

    public Object callMDMBankAccountCentralize(MDMAccount mdmAcct) throws SystemException, ValidationFailedException;

	public String callMDMDenodo(Map<String, String> params, String url,
			HttpMethod method, boolean validateResponse);
			
	public String searchMDMAccounts(MDMSearchAccounts mdmSearchAccounts,User user) throws UnsupportedEncodingException;
	
	/**
	 * This method will perform below steps.
	 * 1) get the list of child gold ids for the given gold id.
	 * 2) get the list of company codes based on gold ids retrieved in step1
	 * 
	 * @param user
	 * @param goldId
	 * @param companyCode
	 * @param requireActive 
	 * @return
	 */
	public String getFilterCompanyCodes(User user,String goldId,String companyCode, boolean requireActive);
	
	/**
	 * This method will perform below steps.
	 * 1) get bu code from frontend.
	 * 2) set the bu code in the filter to derive business/sub-business
	 * 
	 * @param bu code
	 * @param filter
	 * @return
	 */
	public String getBusinessFromBu(String buCode, boolean requireActive);
	
	/**
	 * This method will perform below steps.
	 * 1) get either bu code or business/sub-business from frontend.
	 * 2) set the bu code or the business/sub-business in the filter to derive business/sub-business
	 * @param requireActive 
	 * 
	 * @param code(bu code/business/sub-business)
	 * @param filter
	 * @return
	 */
	public Map<String, String> setMDMBusinessParams(String code, boolean requireActive);
	
	public String getBuHierUrl();
	
	public Map<String, String> setLeFilterParams(boolean isWildSearch, String goldId);
	
	public boolean validateBankBranchStatus(String bankBranchID, String countryCode, String type);
    public boolean validateCountryCodeStatus(AccountRequest accountRequest);
    public boolean validateCurrencyCodeStatus(AccountRequest accountRequest);
    public boolean validateMeCodeStatus(AccountRequest accountRequest);
    public boolean validateAccountTypeStatus(AccountRequest accountRequest);
    public boolean validateComponentCode(AccountRequest accountRequest);

}
