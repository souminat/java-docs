/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.mdm.service.impl;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.AND_STRING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ACCOUNT_PURPOSE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ACCOUNT_TYPE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_COMPANY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_COUNTRY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_CURRENCY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_GOLD_LE_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_IBAN;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ME_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_NATIONAL_BANK_ACCOUNT_NUMBER;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_REQUEST_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ROUTE_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_BUSINESS_NAME;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_SUB_BUSINESS_NAME;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_T_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BUSINESS_BUSINESS_ACCOUNT_GROUP;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BUSINESS_SUBBUSINESS_ACCOUNT_GROUP;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.CONTACT_ATTRIBUTES;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.CORE_ATTRIBUTES;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.DOCUMENT_ATTRIBUTES;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ENTITY_NAME_BANK_ACCOUNT_CENTRALIZE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ENTITY_NAME_BANK_BRANCH;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ENTITY_NAME_BUSINESS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.FILTER_CONST;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PARTY_NM;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PARTY_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PRIMARY_ALT_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PRIMRY_SCOURCE_SYSTEM;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.MY_BANK;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_AND;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_EQUALS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_LIKE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_OR;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ORDER_ASCENDING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ORDER_DESCENDING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.S0;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.SELECT;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.SIGNATORY_ATTRIBUTES;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.TOTAL_COUNT_REQUIRED;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_2;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_LIKE;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.mdm.MDMAccount;
import com.ge.treasury.mybank.domain.mdm.MDMAccountDocument;
import com.ge.treasury.mybank.domain.mdm.MDMAccountSigner;
import com.ge.treasury.mybank.domain.mdm.MDMBaseAccount;
import com.ge.treasury.mybank.domain.mdm.MDMSearchAccounts;
import com.ge.treasury.mybank.domain.mdm.MdmSearchCriteria;
import com.ge.treasury.mybank.domain.mdm.MdmSearchCriteriaRule;
import com.ge.treasury.mybank.domain.mdm.ResponseObjects;
import com.ge.treasury.mybank.domain.mdm.SearchCriteria;
import com.ge.treasury.mybank.domain.mdm.SearchCriteriaList;
import com.ge.treasury.mybank.domain.mdm.Sort;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.validations.AccountValidationUtils;

/**
 * Contains the implementation of MDMService methods Implementation - calling
 * MDM Microservice
 * 
 * @author MyBank Dev Team
 * 
 */
@Service
public class MDMServiceImpl implements MDMService, ValidationConstants {

    @Value("${mdm.ms.bankacctcentralize.url}")
    private String independentbankacctcentralizeUrl;

    @Value("${mdm.ms.account}")
    private String accountUrl;
    
    @Value("${mdm.ms.buhierarchy}")
    private String businessHier;

	@Value("${mdm.ms.accountCore}")
	private String accountCoreUrl;
    
    @Value("${mdm.ms.bank}")
    private String bankUrl;
    
    @Value("${mdm.ms.business}")
    private String businessUrl;
    
    @Value("${mdm.ms.routeCode}")
    private String routeCodeUrl;
    
    @Value("${mdm.ms.security}")
    private String mdmSecurity;
    
    @Value("${mdm.ms.le}")
    private String leV2Url;
    
    @Value("${mdm.ms.me}")
    private String meUrl;
    
    @Value("${mdm.ms.accountType}")
    private String accountTypeUrl;

    @Value("${mdm.ms.country}")
    private String countryUrl;

    @Value("${mdm.ms.currency}")
    private String currencyUrl;
    
    @Value("${mdm.ms.companyCode}")
    private String companyCodeUrl;
    
    @Autowired
    private OAuth2RestOperations mdmBankCentralizeTemplate;
    
    @Autowired
    private MyBankLookupService lookupService;
    
    @Autowired
    private OAuth2RestOperations newMdmServiceRestTemplate;
    
    @Autowired
    private AccountRequestService accountService;
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.business.mdm.service.impl.MDMService#sendToMDM
     * (com.ge.treasury.mybank.domain.accountrequest.AccountRequest)
     */
    @Override
    public AccountRequest sendToMDM(AccountRequest accRequest)
            throws SystemException, ValidationFailedException {
        
		String status = StringUtils.trimToEmpty(accRequest.getRequestType());
        
        if(!StringUtils.isEmpty(status) && AccountValidationUtils.getRequestTypeMDMMap().containsKey(status.trim().toUpperCase())){
            status = AccountValidationUtils.getRequestTypeMDMMap().get(status.trim().toUpperCase());
        }

        MDMAccount mdmAcct = constructMDMAccount(accRequest, status);

        // Do the MDM Microservice Call
        callMDMBankAccountCentralize(mdmAcct);

        return accRequest;
    }

    /**
     * @param accRequest
     * @param status
     * @return
     */
    @Transactional
    @Override
    public MDMAccount constructMDMAccount(AccountRequest accRequest,
            String status) {
        MDMAccount mc = new MDMAccount();

        mc.settCode(StringUtils.defaultString(accRequest.gettCode()));
        mc.setAcctReqID(accRequest.getAcctReqID().toString());
        mc.setAcctNumber(StringUtils.defaultString(accRequest.getAcctNumber()));
        
        mc.setAccountStatus(status);
        mc.setBuCode(accRequest.getBuCode());

        mc.setBusName(accRequest.getBussName());
        mc.setSubBusName(accRequest.getSubBusName());

        mc.setAccountType(StringUtils.defaultString(accRequest.getAccountType()));
        mc.setLeCode(StringUtils.defaultString(accRequest.getLeCode()));
        mc.setAcctTitle(StringUtils.defaultString(accRequest.getAccountTitle()));        
        mc.setLeVersion(StringUtils.defaultString(accRequest.getLeVersion()));
        mc.setCountry(StringUtils.defaultString(accRequest.getCountry()));
        mc.setCurrency(StringUtils.defaultString(accRequest.getCurrency()));
        mc.setBankId(StringUtils.defaultString(accRequest.getBankId()));
        mc.setIban(StringUtils.defaultString(accRequest.getIban()));
        mc.setCashpoolTCode(StringUtils.defaultString(accRequest.getCashpoolTCode()));
        mc.setCashPoolGoldCode(StringUtils.defaultString(accRequest.getCashpoolLeCode()));
        mc.setRouteCode(StringUtils.defaultString(accRequest.getRouteCode()));
        mc.setRouteCodeType(StringUtils.defaultString(accRequest.getRouteCodeType()));
        mc.setBranchId(StringUtils.defaultString(accRequest.getBranchMDMID()));
        mc.setComponentCode(StringUtils.defaultString(accRequest.getComponentCode()));
        mc.setProjectName(StringUtils.defaultString(accRequest.getProjectName()));
        if(StringUtils.splitByWholeSeparator(StringUtils.defaultString(accRequest.getCashPoolRejectReason()), " : ").length > 1){
            mc.setCashPoolRejectReason(StringUtils.splitByWholeSeparator(StringUtils.defaultString(accRequest.getCashPoolRejectReason()), " : ")[1]);
        }else{
            mc.setCashPoolRejectReason(StringUtils.defaultString(accRequest.getCashPoolRejectReason()));
        }
        mc.setCocodeNotUseReason(MDMUtil.trimToBlankForSelect(accRequest.getCoCodeRejectReason()));
        
        if (accRequest.getSigners() != null
                && !accRequest.getSigners().isEmpty()) {
            Iterator<AccountSigner> iterator = accRequest.getSigners()
                    .iterator();
            List<MDMAccountSigner> acSigns = new ArrayList<MDMAccountSigner>();
            while (iterator.hasNext()) {
                AccountSigner accountSigner = iterator.next();
                MDMAccountSigner mdmAccountSigner = new MDMAccountSigner();

                if (accountSigner.getSignerId() != null)
                    mdmAccountSigner.setSignerId(accountSigner.getSignerId());

                mdmAccountSigner.setSsoId(StringUtils.defaultString(accountSigner.getSsoId()));

                mdmAccountSigner.setSignerName(StringUtils.defaultString(accountSigner
                        .getSignerName()));
                mdmAccountSigner.setDocName(StringUtils.defaultString(accountSigner.getDocName()));


                if (accountSigner.getFileId() != null)
                    mdmAccountSigner.setFileId(accountSigner.getFileId());
                else
                    mdmAccountSigner.setFileId(BigInteger.valueOf(0));

                if (accountSigner.getFolderId() != null)
                    mdmAccountSigner.setFolderId(accountSigner.getFolderId());
                else
                    mdmAccountSigner.setFolderId(BigInteger.valueOf(0));

                mdmAccountSigner.setDocURL(StringUtils.defaultString(accountSigner.getDocURL()));


                if (accountSigner.getSignerStartDate() != null)
                    mdmAccountSigner.setSignerStartDate(accountSigner
                            .getSignerStartDate());

                if (accountSigner.getSignerEndDate() != null)
                    mdmAccountSigner.setSignerEndDate(accountSigner
                            .getSignerEndDate());

                // Calling lookup service to get DisplayName based on lookupCode
                String code = accountSigner.getSignerType().toString();
                String signerDispName = null;
                try {
                    signerDispName = lookupService.getDisplayName(code);
                } catch (DBException e) {
                    MyBankLogger.logError(this, e.getMessage(), e);
                }
                mdmAccountSigner.setSignerType(signerDispName);

                acSigns.add(mdmAccountSigner);
            }
            mc.setSigners(acSigns);
        } else {
            mc.setSigners(new ArrayList<MDMAccountSigner>());
        }

        if (accRequest.getDocuments() != null
                && !accRequest.getDocuments().isEmpty()) {
            Iterator<AccountDocument> iterator = accRequest.getDocuments()
                    .iterator();
            List<MDMAccountDocument> acDocs = new ArrayList<MDMAccountDocument>();
            List<AccountDocument> docsFromMDM = new ArrayList<AccountDocument> ();
            try {
            	docsFromMDM = setDocsFromMDM(accRequest);
            } catch (Exception e) {
				 MyBankLogger.logError(this, ExceptionUtils.getFullStackTrace(e));
			}
            
            while (iterator.hasNext()) {
                AccountDocument accountDoc = iterator.next();
                MDMAccountDocument mdmAccountDoc = new MDMAccountDocument();

                mdmAccountDoc.setDocName(StringUtils.defaultString(accountDoc.getDocName()));
                mdmAccountDoc.setDocType(StringUtils.defaultString(accountDoc.getDocType()));
                mdmAccountDoc.setDocURL(StringUtils.defaultString(accountDoc.getDocURL()));

                if (accountDoc.getFileId() != null)
                    mdmAccountDoc.setFileId(accountDoc.getFileId().longValue());
                else
                    mdmAccountDoc.setFileId(0L);

                if (accountDoc.getFolderId() != null)
                    mdmAccountDoc.setFolderId(accountDoc.getFolderId()
                            .longValue());
                else
                    mdmAccountDoc.setFolderId(0L);
                
                boolean matchFound = false;
                matchFound = isDocInMDM(accountDoc, docsFromMDM, matchFound);
               
                if(!matchFound){
                	acDocs.add(mdmAccountDoc);
                }
                
            }
            mc.setDocuments(acDocs);
        } else {
            mc.setDocuments(new ArrayList<MDMAccountDocument>());
        }
        mc.setMeCode(MDMUtil.trimToBlank(accRequest.getMeCode()));
       
        //trim companycode description and grab only companycode
        String companyCode = MDMUtil.trimToBlank(accRequest.getCompanyCode());
        if(StringUtils.indexOf(companyCode, " - ") != -1){
        	accRequest.setCompanyCode(StringUtils.split(companyCode," - ")[0]);
        }
        
        mc.setCompanyCode(MDMUtil.trimToBlank(accRequest.getCompanyCode()));
        mc.setAccountPurpose(MDMUtil.trimToBlankForSelect(accRequest.getAccountPurpose()));
        mc.setNetworkType(MDMUtil.fetchNetworkTypeDesc(accRequest.getBankClassification()));

        if(null!=StringUtils.trimToNull(accRequest.getAcctOpenDate())){
            mc.setAcctOpenDate(accRequest.getAcctOpenDate());
        }
        
        if(null!=StringUtils.trimToNull(accRequest.getAcctClosedDate())){
            mc.setAcctClosedDate(accRequest.getAcctClosedDate());
        }
       
        return mc;
    }

    private List<AccountDocument> setDocsFromMDM(AccountRequest accRequest){
    	List<AccountDocument> docs = new ArrayList<AccountDocument>();
    	if(null!=StringUtils.trimToNull(accRequest.gettCode())){
			AccountRequest accReqMDM = accountService.findAccountFromMDM(accRequest.gettCode(),accountUrl,true);
			if(null!=accReqMDM && !CollectionUtils.isEmpty(accReqMDM.getDocuments())){
				docs = accReqMDM.getDocuments();
				MyBankLogger.logDebug(this, "docsFromMDM ->  " + docs.size());
			}
    	}
		return docs;
    }
    
    private boolean isDocInMDM(AccountDocument accountDoc,List<AccountDocument> docsFromMDM,boolean matchFound){
    	boolean docMatched = matchFound;
    	 if(!docsFromMDM.isEmpty()){
         	for(AccountDocument mdmDoc : docsFromMDM){
         		if(mdmDoc.equals(accountDoc)){
         			MyBankLogger.logDebug(this, "Match Found for Document " + accountDoc.toString());
         			docMatched = true;
         			break;
         		}
         	}
         }
		return docMatched;
    }
    /**
     * @param mdmAcct
     * @return
     * @throws BusinessException
     * @throws SystemException
     * @throws ValidationFailedException 
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Object callMDMBankAccountCentralize(MDMAccount mdmAcct)
            throws SystemException, ValidationFailedException {
        
        MDMBaseAccount baseAccount = new MDMBaseAccount();
        Object tCodeStr = null;
        baseAccount.setEntityName(MYBANK_MDM_ENTITY_BNKACCTCENTRALIZE);
        baseAccount.setRequestor(MYBANK_MDM_REQUESTOR);

        baseAccount.setBankAccountInformation(mdmAcct);

        JSONArray dataList = new JSONArray();

        String jsonString = MDMUtil.constructJsonString(baseAccount);

        MyBankLogger.logInfo(this, "Request To MDM - > " + jsonString);

        String responseBody = callMDM(jsonString, independentbankacctcentralizeUrl, mdmBankCentralizeTemplate);

        MyBankLogger.logInfo(this, "Response From MDM - > " + responseBody);
        
        JSONObject jsonObject = new JSONObject(responseBody);
        JSONObject responseData = (JSONObject) jsonObject
                .get(JSON_GET_RESPONSEDATA);
        if(null != responseData){
        	dataList = responseData.getJSONArray(JSON_GET_DATA);
        }

        if (dataList != null && dataList.length() != 0) {

            Iterator<Object> iterator = dataList.iterator();
            while (iterator.hasNext()) {
                JSONObject tCode = (JSONObject) iterator.next();
                if(null != tCode){
                	tCodeStr = tCode.get(JSON_GET_TCODE);
                	MyBankLogger.logDebug(this, "TCode: " + tCodeStr);
                }
            }
            MyBankLogger.logDebug(this,
                    "Account Request sent successfully to MDM");
        } else {
            BindingResult errors = new BeanPropertyBindingResult(mdmAcct,
                    "accountRequest");
            if(null != errors){
            	errors.reject("tcode.generate.failed", responseData.getString("Message"));
            }
            throw new ValidationFailedException(errors);
        }
        return tCodeStr;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.business.mdm.service.impl.MDMService#isAccountOpen
     * (java.lang.String)
     */
    @Override
    public boolean isAccountOpen(String tCode) throws SystemException{

        boolean isOpen = false;

        HashMap<String, String> params = new HashMap<>();
        final StringBuilder filter = new StringBuilder();
  
        filter.append("(");
        filter.append("UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + ") = UPPER('" + "Open" + "')");
        filter.append(" and ");
        try {
			filter.append("UPPER(" + BANK_ACCOUNT_CENTRALIZE_T_CODE + ") = UPPER('"
			        + URLDecoder.decode(tCode, "UTF-8") + "')");
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in isAccountOpen "+ e);
		}
        filter.append(")");
        params.put(FILTER_CONST, filter.toString());
        params.put(TOTAL_COUNT_REQUIRED, "true");
        params.put("$start_index", String.valueOf("0"));
        String response = callMDMDenodo(params, accountCoreUrl, HttpMethod.GET, true);

        JSONObject responseJson = new JSONObject(response);
        int count = responseJson.getInt("totalcount");
        isOpen = count!=0;  
        MyBankLogger.logDebug(this, "Is open?: " + isOpen);

        return isOpen;
    }

    /**
     * @param jsonString
     * @param url
     * @return String response from MDM service
     * @throws SystemException
     */
    @Override
    public String callMDM(String jsonString, String url, OAuth2RestOperations mdmRestTemplate) throws SystemException {

        ResponseEntity<String> response = new ResponseEntity<String>(null);
        
        RestTemplate rt = new RestTemplate();
        
        Object message = new Object();
        Object mdmStatus = new Object();

        try {

            HttpHeaders headers = new HttpHeaders();
            headers.set("Accept", MediaType.APPLICATION_JSON_VALUE+";charset=utf-8");
            MediaType mediaType = new MediaType("application", "json", StandardCharsets.UTF_8);
            headers.setContentType(mediaType);

            UriComponentsBuilder builder = null;
           
            
            HttpEntity<String> entity = null;

            if (url.contains("bankacctcentralize")) {

                MyBankLogger.logDebug(this,
                        "MDM Bank Centralize Request: " + jsonString.toString());
                
                entity = new HttpEntity<String>(jsonString.toString(), headers);

                if ("true".equalsIgnoreCase(mdmSecurity)) {
                    response = mdmRestTemplate.exchange(url, HttpMethod.POST,
                            entity, String.class);
                } else {
                    response = rt.exchange(url, HttpMethod.POST, entity,
                            String.class);
                }

            } else {

                entity = new HttpEntity<String>(headers);
                builder = UriComponentsBuilder.fromHttpUrl(url).queryParam(
                        MDM_QUERY_PARAM, jsonString);

                // Retrieve object by doing a GET/POST on the specified URL
                
                if ("true".equalsIgnoreCase(mdmSecurity)) {
                    response = mdmRestTemplate.exchange(builder.build()
                            .encode().toUri(), HttpMethod.GET, entity,
                            String.class);
                } else {
                    response = rt.exchange(builder.build().encode().toUri(),
                            HttpMethod.GET, entity, String.class);
                }
            }


            if (response.getStatusCode() == HttpStatus.OK) {
                MyBankLogger.logDebug(this,
                        "MDM Response: " + response.getBody());

                JSONObject jsonObject = new JSONObject(response.getBody());
                JSONObject responseData = (JSONObject) jsonObject
                        .get(JSON_GET_RESPONSEDATA);

                message = responseData.get(JSON_GET_MESSAGE);
                mdmStatus = responseData.get(JSON_GET_STATUS);
                if ("Bad request 400".equals(mdmStatus)) {
                    throw new SystemException("MDM ERROR: "
                            + message.toString());
                }
            } else {
                throw new SystemException("MDM ERROR: " + message.toString());
            }

        } catch (Exception e) {
            MyBankLogger.logError(this, e.getMessage(), e);
            throw new SystemException("MDM ERROR: " + e.getMessage().toString());
        }

        return response.getBody();
    }

    /**
     * Method used calling Reserve Bank Account
     * 
     * @param accRequest
     * @return
     * @throws SystemException
     */
    @Override
    public JSONArray getMDMBankDetails(AccountRequest accRequest)
            throws SystemException{
        String url = bankUrl;
        String code = accRequest.getBankId();

        SearchCriteria sc = new SearchCriteria();
        sc.setEntityName(ENTITY_NAME_BANK_BRANCH);
        sc.setRequestor(MY_BANK);

        List<SearchCriteriaList> scList = new ArrayList<SearchCriteriaList>();

        SearchCriteriaList mdmIdCriteria = new SearchCriteriaList();
        mdmIdCriteria.setAttribute(BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID);
        mdmIdCriteria.setSetName(S0);
        mdmIdCriteria.setOperator(OPERATOR_LIKE);
        mdmIdCriteria.setValue(code);
        scList.add(mdmIdCriteria);

        sc.setSearchRule("(S0)");

        List<Sort> sortList = new ArrayList<Sort>();
        Sort sort = new Sort();
        sort.setAttribute(BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID);
        sort.setOrder(ORDER_ASCENDING);
        sortList.add(sort);
        sc.setSort(sortList);

        ResponseObjects ro = new ResponseObjects();
        ro.setResponseList(CONTACT_ATTRIBUTES);
        sc.setResponseObjects(ro);
        sc.setSearchCriteriaList(scList);

        MyBankLogger.logDebug(this, "jsonString --- > " + MDMUtil.constructJsonString(sc));

        StringBuilder filter = new StringBuilder();
        filter.append("(");
        if (null!=StringUtils.trimToNull(code)) {
            try {
				filter.append("UPPER(" + "MDM_ID" + ") like UPPER('%"
				        + URLDecoder.decode(code, "UTF-8") + "%')");
			} catch (UnsupportedEncodingException e) {
				MyBankLogger.logError(this, "Error while decoding" + e);
				throw new BusinessException("Error while decoding : "+e.getMessage());
			}
        }
        filter.append(")");
        HashMap<String, String> params = new HashMap<>();
        params.put(FILTER_CONST, filter.toString());
        params.put(TOTAL_COUNT_REQUIRED, "true");
        params.put("$start_index", "0");
        
        String response = callMDMDenodo(params, url,HttpMethod.GET, true);
        
        JSONObject jsonObject = new JSONObject(response);
        
        JSONArray data = jsonObject.getJSONArray("elements");

        return data;
    }
    @Override
    public JSONArray getMDMLEDetails(AccountRequest accRequest)
            throws SystemException {
        
        String code = accRequest.getLeCode();

        String responseBody = callMDMDenodo(setLeFilterParams(false, code), leV2Url, HttpMethod.GET, true);;

        JSONObject jsonObject = new JSONObject(responseBody);
        JSONArray data = jsonObject.getJSONArray("elements");
        return data;
    }
    
    @Override
    public JSONArray getMDMRouteDetails(AccountRequest accRequest)
            throws SystemException{
    String url = routeCodeUrl;
    String code = accRequest.getRouteCode();
    String bankId = accRequest.getBankId();
    
    final StringBuilder filter = new StringBuilder();
    
    filter.append("(");
    filter.append("UPPER(" + "PARENT_MDM_ID" + ") = UPPER('" + bankId + "')");
    filter.append(" and ");
    filter.append("(");
    try {
		filter.append("UPPER(" + "RTE_CODE" + ") = UPPER('"
		        + URLDecoder.decode(code, "UTF-8") + "')");
		filter.append(" or ");
		filter.append("UPPER(" + "RTE_CODE_TYPE" + ") = UPPER('"
		        + URLDecoder.decode(code, "UTF-8") + "')");
	} catch (UnsupportedEncodingException e) {
		MyBankLogger.logError(this, "Error while decoding" + e);
		throw new BusinessException("Error while decoding : "+e.getMessage());
	}
    filter.append(")");
    filter.append(")");
    HashMap<String, String> params = new HashMap<>();
    params.put(FILTER_CONST, filter.toString());
    params.put(TOTAL_COUNT_REQUIRED, "true");
    params.put("$start_index", String.valueOf(0));
    String response = this.callMDMDenodo(params, url, HttpMethod.GET, true);
    JSONObject obj =  new JSONObject(response);
    int totalCount = obj.getInt("totalcount");
    if(totalCount <= 0){
        return null;
    }else{
        JSONArray a =  obj.getJSONArray("elements");
        return a;
    }
    }
    
    @Override
    public List<UserRole> isBusinessSubBusinessOpen(List<UserRole> search)
            throws SystemException{
        
        String url = businessUrl;

        MdmSearchCriteria searchCriteria = new MdmSearchCriteria();
        searchCriteria.setEntityName(ENTITY_NAME_BUSINESS);
        searchCriteria.setRequestor(MY_BANK);
        searchCriteria.setPageStart(0);
        searchCriteria.setPageIncrement(Integer.MAX_VALUE);
        
        searchCriteria.setResponseAttributes(CORE_ATTRIBUTES);
        
        List<Sort> sortList = new ArrayList<Sort>();
        Sort sort = new Sort();
        sort.setAttribute(BUSINESS_SUBBUSINESS_ACCOUNT_GROUP);
        sort.setOrder(ORDER_DESCENDING);
        sortList.add(sort);
        searchCriteria.setSort(sortList);
        
        List<MdmSearchCriteriaRule> rules = new ArrayList<MdmSearchCriteriaRule>();
        Map<String, UserRole> rolesMap = new HashMap<String, UserRole>();
        
        List<String> subBussRuleValues = new ArrayList<String>();
        List<String> bussRuleValues = new ArrayList<String>();
        
        for (UserRole role : search) {
            bussRuleValues.add("'"+role.getBusiness()+"'");
            subBussRuleValues.add("'"+role.getSubBusiness()+"'");
            
            rolesMap.put(role.getBusiness() + role.getSubBusiness(), role);
        }
        MdmSearchCriteriaRule subBussRule = new MdmSearchCriteriaRule();
        subBussRule.setAttribute(BUSINESS_SUBBUSINESS_ACCOUNT_GROUP);
        subBussRule.setOperator("IN");
        subBussRule.setValue(subBussRuleValues);
        rules.add(subBussRule);
        
        MdmSearchCriteriaRule bussRule = new MdmSearchCriteriaRule();
        bussRule.setAttribute(BUSINESS_BUSINESS_ACCOUNT_GROUP);
        bussRule.setOperator("IN");
        bussRule.setValue(bussRuleValues);
        rules.add(bussRule);
        
        MdmSearchCriteriaRule activeBusCriteria = new MdmSearchCriteriaRule();
        List<String> activeBusValues = new ArrayList<String>();
        activeBusCriteria.setAttribute("BUS_ACCT_GRP_STATUS");
        activeBusCriteria.setOperator(OPERATOR_EQUALS);
        activeBusValues.add(ACTIVE);
        activeBusCriteria.setValue(activeBusValues);
        rules.add(activeBusCriteria);

        MdmSearchCriteriaRule activeBusRelCriteria = new MdmSearchCriteriaRule();
        List<String> activeBusRelValues = new ArrayList<String>();
        activeBusRelCriteria.setAttribute("BUS_SBUS_REL_STATUS");
        activeBusRelCriteria.setOperator(OPERATOR_EQUALS);
        activeBusRelValues.add(ACTIVE);
        activeBusRelCriteria.setValue(activeBusRelValues);
        rules.add(activeBusRelCriteria);
        
        MdmSearchCriteriaRule activeSubBusCriteria = new MdmSearchCriteriaRule();
        List<String> activeSubBusValues = new ArrayList<String>();
        activeSubBusCriteria.setAttribute("SUB_BUS_ACCT_GRP_STATUS");
        activeSubBusCriteria.setOperator(OPERATOR_EQUALS);
        activeSubBusValues.add(ACTIVE);
        activeSubBusCriteria.setValue(activeSubBusValues);
        rules.add(activeSubBusCriteria);
        
        searchCriteria.setSearchCriteriaList(rules);
        
        HashMap<String, String> params = new HashMap<>();
        
       
        String subBussRuleValuesStr = subBussRuleValues.toString().replace("[","");
        subBussRuleValuesStr= subBussRuleValuesStr.replace("]","");
        
        String bussRuleValuesStr = bussRuleValues.toString().replace("[","");
        bussRuleValuesStr =bussRuleValuesStr.replace("]","");
        
        final StringBuilder filter = new StringBuilder();
        filter.append("(");
        filter.append("(");
        try {
			filter.append("sub_bus_acct_grp" +  " IN ("
			        + URLDecoder.decode(subBussRuleValuesStr, "UTF-8") + ")");
		 
			filter.append(" and ");
			filter.append("bus_acct_grp" + " IN  ("
                + URLDecoder.decode(bussRuleValuesStr, "UTF-8")+ ")");
        }catch (UnsupportedEncodingException e) {
        	MyBankLogger.logError(this, "Error while decoding" + e);
			throw new BusinessException("Error while decoding : "+e.getMessage());
		}
        filter.append(")");
        
        filter.append(" and ");
        filter.append("(");
        filter.append("(UPPER(" + "BUS_ACCT_GRP_STATUS" + UPPER_1
                + ACTIVE+ "'))");
        filter.append(" and ");
        filter.append("(UPPER(" + "BUS_SBUS_REL_STATUS" + UPPER_1
                + ACTIVE+ "'))");
        filter.append(" and ");
        filter.append("(UPPER(" + "SUB_BUS_ACCT_GRP_STATUS" + UPPER_1
                + ACTIVE+ "'))");
        filter.append(")");     
        filter.append(")");

        params.put(FILTER_CONST, filter.toString());
        params.put(TOTAL_COUNT_REQUIRED, "false");
        params.put("$start_index", String.valueOf("0"));
        String jsonResponse =this.callMDMDenodo(params, url, HttpMethod.GET, true);
        JSONObject jsonObject = new JSONObject(jsonResponse);
        
        JSONArray data = jsonObject.getJSONArray("elements");
        
        search.clear();
        Iterator<Object> itr = data.iterator();
        
        while (itr.hasNext()) {
            JSONObject obj = (JSONObject) itr.next();
            if (rolesMap.containsKey(obj.getString("bus_acct_grp") + obj.getString("sub_bus_acct_grp"))) {
                search.add(rolesMap.get(obj.getString("bus_acct_grp") + obj.getString("sub_bus_acct_grp")));
            }
        }
        
        return search;
    }
    /**
     * @param url
     * @param method
     * @param validateResponse
     * @param template
     *
     * @return String response from MDM service
     */
    @Override
    public String callMDMDenodo(Map<String, String> params, final String url, final HttpMethod method,
            final boolean validateResponse) {

        final HttpEntity<String> entity;
        final HttpHeaders headers = new HttpHeaders();
        final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        for (String paramName : params.keySet()) {
            builder.queryParam(paramName, params.get(paramName));
        }

        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        entity = new HttpEntity<String>(headers);
        return executeCall(this.newMdmServiceRestTemplate, builder, method, entity, validateResponse);

    }

    /**
     * Helper method to execute the RestOperation for the microservices calls
     *
     * @param ro
     * @param builder
     * @param method
     * @param entity
     * @param validateResponse
     *
     * @return
     */
    public String executeCall(final RestOperations ro, final UriComponentsBuilder builder, final HttpMethod method,
            final HttpEntity<String> entity, final boolean validateResponse) {
        try {
            final ResponseEntity<String> response = ro.exchange(builder.build().encode().toUri(), method, entity,
                    String.class);
            MyBankLogger.logInfo(this,"Request to MDM for Execute Call ->"+builder.build().encode().toUri().toString());
            final String responseBody;
            if (response.getStatusCode() == HttpStatus.OK) {
                responseBody = response.getBody();
                MyBankLogger.logInfo(this,"Response from MDM - Execute Call -> " + responseBody);
                if (validateResponse) {
                    validateJSONResponse(responseBody);
                }
            } else {
                throw new SystemException(
                        ControllersConstants.MDM_ERROR + "ResponseStatusCode: " + response.getStatusCode());
            }

            return responseBody;
        } catch (final RestClientException e) {
            throw new SystemException(ControllersConstants.MDM_ERROR + "Error when connecting to the MDM Microservice",
                    e);
        }
    }

    /**
     * Validate the responseBoby by checking the Status
     *
     * @param responseBody
     */
    public void validateJSONResponse(final String responseBody) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(responseBody);
            JsonNode messageNode = rootNode.path(ValidationConstants.JSON_GET_MESSAGE);
            JsonNode statusMessageNode = rootNode.path(ValidationConstants.JSON_GET_STATUS_MESSAGE);
            JsonNode statusNode = rootNode.path(ValidationConstants.JSON_GET_STATUS);

            if (null != statusNode && ("Bad request 400".equalsIgnoreCase(statusNode.asText())
                    || "failure".equalsIgnoreCase(statusNode.asText()))) {
                if (null == StringUtils.trimToNull(messageNode.asText())) {
                    throw new SystemException(ControllersConstants.MDM_ERROR + statusMessageNode.asText());
                } else {
                    throw new SystemException(ControllersConstants.MDM_ERROR + messageNode.asText());
                }
            }
        } catch (final IOException e) {
        	MyBankLogger.logError(this, "MDMServiceImpl.validateJSONResponse: " + e.getMessage(), e);
        }
    }

	@Override
	public boolean isAccountValid(String tCode) throws UnsupportedEncodingException
			{
		  boolean isAccountValid = false;

	        HashMap<String, String> params = new HashMap<>();
	        final StringBuilder filter = new StringBuilder();
	  
	        filter.append("(");

			filter.append(
					UPPER_2 + BANK_ACCOUNT_CENTRALIZE_T_CODE + UPPER_1 + URLDecoder.decode(tCode, "UTF-8") + "')");
			filter.append(AND_STRING);

			filter.append(
					UPPER_2 + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + ") NOT IN ('CLOSED')");

			filter.append(")");
	        params.put(FILTER_CONST, filter.toString());
	        params.put(TOTAL_COUNT_REQUIRED, "true");
	        params.put("$start_index", String.valueOf("0"));
	        String response = callMDMDenodo(params, accountCoreUrl, HttpMethod.GET, true);

	        JSONObject responseJson = new JSONObject(response);
	        int count = responseJson.getInt("totalcount");
	        isAccountValid = count!=0;  
	        MyBankLogger.logInfo(this,"-------------------------------->isAccountValid : " + isAccountValid);
	        MyBankLogger.logDebug(this, "Is open?: " + isAccountValid);

	        return isAccountValid;
	}
	
	@Override
    public String searchMDMAccounts(MDMSearchAccounts mdmSearchAccounts, User user) throws UnsupportedEncodingException {
        
        String url = (mdmSearchAccounts.getIsCore() == true) ? accountCoreUrl : accountUrl;
        
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MdmSearchCriteria searchCriteria = new MdmSearchCriteria();
        searchCriteria.setEntityName(ENTITY_NAME_BANK_ACCOUNT_CENTRALIZE);
        searchCriteria.setRequestor(MY_BANK);
        searchCriteria.setPageStart(mdmSearchAccounts.getStart());
        searchCriteria.setPageIncrement(mdmSearchAccounts.getLimit());

        List<Sort> sortList = new ArrayList<Sort>();
        Sort sort = new Sort();
        sort.setAttribute(BANK_ACCOUNT_CENTRALIZE_REQUEST_ID);
        sort.setOrder(ORDER_DESCENDING);
        sortList.add(sort);
        searchCriteria.setSort(sortList);

        List<MdmSearchCriteriaRule> rules = new ArrayList<MdmSearchCriteriaRule>();

        boolean isCustomSearchFlag = updateSearchCriteria(rules,searchCriteria,user,mdmSearchAccounts);

        MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
        List<String> ruleValues = new ArrayList<String>();
        rule.setAttribute("SRCE_SYS_NM");
        rule.setOperator(OPERATOR_EQUALS);
        ruleValues.add("MDM");
        ruleValues.add(mdmSearchAccounts.getAccountStatus());
        rule.setValue(ruleValues);
        rules.add(rule);

        searchCriteria.setSearchCriteriaList(rules);
        

        MyBankLogger.logPerf(this, userId, transactionId, "Searched MDM for accounts",
                System.currentTimeMillis() - startTime);

        String requestStr = MDMUtil.constructJsonString(searchCriteria);
        
        MyBankLogger.logDebug(this, "Json construct applied is --->".concat(String.valueOf(requestStr)));

        StringBuilder filter = new StringBuilder();
        StringBuilder subFilterSB = new StringBuilder();
        filter.append("(");
        
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.gettCode())) {
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            if(mdmSearchAccounts.isForTCode()){
                subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_T_CODE + ") like UPPER('%" + URLDecoder.decode(mdmSearchAccounts.gettCode(), "UTF-8") + "%'))");
            }else{
                subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_T_CODE + UPPER_1 + URLDecoder.decode(mdmSearchAccounts.gettCode(), "UTF-8") + "'))");             
            }
        }
        
        if (StringUtils.isEmpty(mdmSearchAccounts.getSubBusName())) {
            ruleValues = new ArrayList<String>();
            Set<String> business = new HashSet<String>();
            for (UserRole role : user.getUserProfile().getRoles()) {
                if (role.getMyBankRole().matches(ControllersConstants.IS_BUSINIESS_LEVEL_ROLE_REGEX) && !ruleValues.contains(role.getSubBusiness())) {
                        ruleValues.add("'"+role.getSubBusiness()+"'");
                }else if(ValidationConstants.ACCT_REQUEST_USER_TREASURY_DIVESTED.equalsIgnoreCase(role.getMyBankRole())){
                    business.add(role.getBusiness());
                }
                
            }
            if (!ruleValues.isEmpty()) {
                if(subFilterSB.length() > 1){
                    subFilterSB.append(" and ");
                }
                String ruleValuesStr = ruleValues.toString().replace("[", "");
                 ruleValuesStr = ruleValuesStr.replace("]", "");
                subFilterSB.append("TRIM(" + BANK_ACCOUNT_CENTRALIZE_SUB_BUSINESS_NAME + ") IN  (" + URLDecoder.decode(ruleValuesStr, "UTF-8") + ")");
                
            }
            if (!business.isEmpty()) {
                if(subFilterSB.length() > 1){
                    subFilterSB.append(" and ");
                }
                subFilterSB.append("TRIM(" + BANK_ACCOUNT_CENTRALIZE_BUSINESS_NAME + ") IN  ('" + URLDecoder.decode(StringUtils.join(business,"','"), "UTF-8") + "')");
                
            }
        } else {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("TRIM(" + BANK_ACCOUNT_CENTRALIZE_SUB_BUSINESS_NAME + ") =  TRIM('" + mdmSearchAccounts.getSubBusName() + "')");
            
            subFilterSB.append(" and ");
            subFilterSB.append("TRIM(" + BANK_ACCOUNT_CENTRALIZE_BUSINESS_NAME + ") =  TRIM('" + mdmSearchAccounts.getBussName() + "')");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getBuCode())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(bu_code" + UPPER_1 + mdmSearchAccounts.getBuCode() + "'))");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getAccountStatus())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + UPPER_1 + lookupService.getDisplayName(mdmSearchAccounts.getAccountStatus()) + "'))");
        }
        
        
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getBankId())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID + UPPER_1 + mdmSearchAccounts.getBankId() + "'))");
            
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getIban())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_IBAN + UPPER_1 + mdmSearchAccounts.getIban() + "'))");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getCountry())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_COUNTRY_CODE + UPPER_1 + mdmSearchAccounts.getCountry() + "'))");
        }
        
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getCurrency())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_CURRENCY_CODE + UPPER_1 + mdmSearchAccounts.getCurrency() + "'))");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getLeCode())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_GOLD_LE_CODE + UPPER_1 + mdmSearchAccounts.getLeCode() + "'))");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getRouteCode())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ROUTE_CODE + UPPER_1 + mdmSearchAccounts.getRouteCode() + "'))");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getAccountType())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_TYPE + UPPER_1 + mdmSearchAccounts.getAccountType() + "'))");
        }
        
        if (!StringUtils.isEmpty(mdmSearchAccounts.getAcctNumber())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_NATIONAL_BANK_ACCOUNT_NUMBER + UPPER_1 + mdmSearchAccounts.getAcctNumber() + "'))");
        }
        if (!StringUtils.isEmpty(mdmSearchAccounts.getCompanyCode())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_COMPANY_CODE + UPPER_1 + mdmSearchAccounts.getCompanyCode() + "'))");
                        
        }
        if (!StringUtils.isEmpty(mdmSearchAccounts.getMeCode())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ME_CODE + UPPER_1 + mdmSearchAccounts.getMeCode() + "'))");
        
        }
        if (!StringUtils.isEmpty(mdmSearchAccounts.getAccountPurpose())) {
            isCustomSearchFlag = true;
            if(subFilterSB.length() > 1){
                subFilterSB.append(" and ");
            }
            subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_PURPOSE + UPPER_LIKE + lookupService.getDisplayName(mdmSearchAccounts.getAccountPurpose()) + "%'))");
        }
        if(subFilterSB.length() > 1){
            filter.append(subFilterSB);
            filter.append(" and ");
        }
        if(!isCustomSearchFlag) {
            filter.append("(");
            filter.append("UPPER(" + "ACCOUNT_STATUS" + ") =  UPPER("+ "'OPEN'" +")");
            filter.append(" and ");
        }
        filter.append(UPPER_2 + "SRCE_SYS_NM" + ") ").append(OPERATOR_EQUALS).append(MDMConstants.UPPER_4  + "MDM" + "')");
        if(!isCustomSearchFlag) {
            filter.append(")");
        }
        filter.append(")");

        HashMap<String, String> params = new HashMap<>();
        
        if(null == mdmSearchAccounts.getStart() || mdmSearchAccounts.getStart() == 1){
            mdmSearchAccounts.setStart(0);
        }
        
        params.put(FILTER_CONST, filter.toString());
        params.put(TOTAL_COUNT_REQUIRED, "true");
        params.put("$start_index", String.valueOf(mdmSearchAccounts.getStart()));
        params.put("$count", String.valueOf(mdmSearchAccounts.getLimit()));
        params.put("$orderby", "rqst_id" + " "+ORDER_DESCENDING);
        
        return this.callMDMDenodo(params, url, HttpMethod.GET, true);
    }

    private boolean updateSearchCriteria(List<MdmSearchCriteriaRule> rules, MdmSearchCriteria searchCriteria, User user,
            MDMSearchAccounts mdmSearchAccounts) {
        boolean isCustomSearchFlag = false;
        if (StringUtils.isEmpty(mdmSearchAccounts.getSubBusName())) {
            List<String> ruleValues = new ArrayList<String>();
            List<String> business = new ArrayList<String>();
            for (UserRole role : user.getUserProfile().getRoles()) {
                if (role.getMyBankRole().matches(ControllersConstants.IS_BUSINIESS_LEVEL_ROLE_REGEX) && !ruleValues.contains(role.getSubBusiness())) {
                        ruleValues.add(role.getSubBusiness());
                }else if(ValidationConstants.ACCT_REQUEST_USER_TREASURY_DIVESTED.equalsIgnoreCase(role.getMyBankRole()) && !business.contains(role.getBusiness())){
                    business.add(role.getBusiness());
                }
            }
            if (!ruleValues.isEmpty()) {
                MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
                rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_SUB_BUSINESS_NAME);
                rule.setOperator("IN");
                rule.setValue(ruleValues);
                rules.add(rule);
            }
            if (!business.isEmpty()) {
                MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
                rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_BUSINESS_NAME);
                rule.setOperator("IN");
                rule.setValue(business);
                rules.add(rule);
            }
        } else {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_SUB_BUSINESS_NAME);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getSubBusName());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
            
            MdmSearchCriteriaRule ruleBus = new MdmSearchCriteriaRule();
            List<String> ruleValuesBus = new ArrayList<String>();
            ruleBus.setAttribute(BANK_ACCOUNT_CENTRALIZE_BUSINESS_NAME);
            ruleBus.setOperator(OPERATOR_EQUALS);
            ruleValuesBus.add(mdmSearchAccounts.getBussName());
            ruleBus.setValue(ruleValuesBus);
            rules.add(rule);
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getAccountStatus())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(lookupService.getDisplayName(mdmSearchAccounts.getAccountStatus()));
            ruleValues.add(mdmSearchAccounts.getAccountStatus());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.gettCode())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_T_CODE);
            if (mdmSearchAccounts.isForTCode()) {
                List<Sort> newSortList = new ArrayList<Sort>();
                newSortList.add(new Sort(BANK_ACCOUNT_CENTRALIZE_T_CODE, ORDER_ASCENDING));
                searchCriteria.setSort(newSortList);

                rule.setOperator(OPERATOR_LIKE);
                searchCriteria.setResponseAttributes(CORE_ATTRIBUTES);
            } else {
                rule.setOperator(OPERATOR_EQUALS);
                searchCriteria.setResponseAttributes(
                        String.format("%s, %s, %s", CORE_ATTRIBUTES, DOCUMENT_ATTRIBUTES, SIGNATORY_ATTRIBUTES));
                isCustomSearchFlag = true;
            }
            ruleValues.add(mdmSearchAccounts.gettCode());
            rule.setValue(ruleValues);
            rules.add(rule);

        } else {
            searchCriteria.setResponseAttributes(CORE_ATTRIBUTES);
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getBankId())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getBankId());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getIban())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_IBAN);
            rule.setOperator(OPERATOR_LIKE);
            rule.setValue(ruleValues);
            ruleValues.add(mdmSearchAccounts.getIban());
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getCountry())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_COUNTRY_CODE);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getCountry());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getCurrency())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_CURRENCY_CODE);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getCurrency());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getLeCode())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_GOLD_LE_CODE);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getLeCode());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getRouteCode())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ROUTE_CODE);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getRouteCode());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getAccountType())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ACCOUNT_TYPE);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(mdmSearchAccounts.getAccountType());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }

        if (!StringUtils.isEmpty(mdmSearchAccounts.getAcctNumber())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_NATIONAL_BANK_ACCOUNT_NUMBER);
            rule.setOperator(OPERATOR_LIKE);
            ruleValues.add(mdmSearchAccounts.getAcctNumber());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }
        if (!StringUtils.isEmpty(mdmSearchAccounts.getCompanyCode())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_COMPANY_CODE);
            rule.setOperator(OPERATOR_LIKE);
            ruleValues.add(mdmSearchAccounts.getCompanyCode());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }
        if (!StringUtils.isEmpty(mdmSearchAccounts.getMeCode())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ME_CODE);
            rule.setOperator(OPERATOR_LIKE);
            ruleValues.add(mdmSearchAccounts.getMeCode());
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }
        if (!StringUtils.isEmpty(mdmSearchAccounts.getAccountPurpose())) {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ACCOUNT_PURPOSE);
            rule.setOperator(OPERATOR_LIKE);
            ruleValues.add(lookupService.getDisplayName(mdmSearchAccounts.getAccountPurpose()));
            rule.setValue(ruleValues);
            rules.add(rule);
            isCustomSearchFlag = true;
        }
        if (!rules.isEmpty()) {
            if (!isCustomSearchFlag) {
                MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
                List<String> ruleValues = new ArrayList<String>();
                rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS);
                rule.setOperator(OPERATOR_EQUALS);
                ruleValues.add(lookupService.getDisplayName("MDMACCTSTATUS_OPEN"));
                ruleValues.add(mdmSearchAccounts.getAccountStatus());
                rule.setValue(ruleValues);
                rules.add(rule);
            }
        } else {
            MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
            List<String> ruleValues = new ArrayList<String>();
            rule.setAttribute(BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS);
            rule.setOperator(OPERATOR_EQUALS);
            ruleValues.add(lookupService.getDisplayName("MDMACCTSTATUS_OPEN"));
            ruleValues.add(mdmSearchAccounts.getAccountStatus());
            rule.setValue(ruleValues);
            rules.add(rule);
        }
        return isCustomSearchFlag;
    }

    @Override
    public String getFilterCompanyCodes(User user, String goldId, String companyCode,boolean requireActive) {
        StringBuilder filter = new StringBuilder();
        HashMap<String, String> params = new HashMap<>();

        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        Instant startTime = Instant.now();

        String associatedLes = "'" + StringUtils.join(getChildGoldIds(goldId), "','") + "'";

        MyBankLogger.logPerf(this, StringUtils.defaultString(userId), transactionId, "get child gold ids Complete",
                Duration.between(startTime, Instant.now()).toMillis());
        startTime = Instant.now();
        try {
            filter.append("(");

            filter.append(UPPER_2 + "associated_le) IN (" + associatedLes + ")");

            filter.append(MDMConstants.OPERATOR_SPACE.concat(OPERATOR_AND).concat(MDMConstants.OPERATOR_SPACE));

            filter.append(UPPER_2 + "company_code" + UPPER_LIKE + URLDecoder.decode(companyCode, "UTF-8") + "%')");
            
            if(requireActive){
                filter.append(MDMConstants.OPERATOR_SPACE+OPERATOR_AND+MDMConstants.OPERATOR_SPACE+UPPER_2 + "enabled" + UPPER_1 + "True" + "')");
            }
            filter.append(")");

        } catch (Exception e) {
            MyBankLogger.logError(this, "Error in Decoding :: getCompanyCodes ", e);
        }

        params.put(FILTER_CONST, filter.toString());

        String jsonOutput = callMDMDenodo(params, companyCodeUrl, HttpMethod.GET, false);

        MyBankLogger.logPerf(this, StringUtils.defaultString(userId), transactionId, "get Company Code list Completed",
                Duration.between(startTime, Instant.now()).toMillis());

        return jsonOutput;
    }

    private Set<String> getChildGoldIds(String goldId) {
        String leService = null;
        StringBuilder filter = new StringBuilder();
        HashMap<String, String> params = new HashMap<>();
        try {
            filter.append("(");

            filter.append("(UPPER(" + "PARENT_CODE" + ") ").append(OPERATOR_LIKE)
                    .append(" UPPER('%" + URLDecoder.decode(goldId, "UTF-8") + "%'))");
            filter.append(" " + OPERATOR_AND + " ");
            filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS)
                    .append(MDMConstants.UPPER_4 + "GOLD" + "')");
            filter.append(" " + OPERATOR_AND + " ");
            filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(MDMConstants.UPPER_4 + ACTIVE + "')");
            filter.append(" " + OPERATOR_AND + " ")
            				.append(MDMConstants.ACTIVE_FLAG)
            						.append(OPERATOR_EQUALS).append("'Y'");            
            filter.append(")");

            params.put(FILTER_CONST, filter.toString());
            params.put(SELECT, LE_PRIMARY_ALT_CODE.toLowerCase());
            leService = callMDMDenodo(params, leV2Url, HttpMethod.GET, true);

        } catch (Exception e) {
            MyBankLogger.logError(this, "Error while fetching GoldLe ", e);
        }

        Set<String> setList = new HashSet<String>();
        if (null != leService) {
            JSONObject jsonObject = new JSONObject(leService);
            JSONArray data = jsonObject.getJSONArray("elements");
            Iterator<Object> itr = data.iterator();
            while (itr.hasNext()) {
                JSONObject obj = (JSONObject) itr.next();
                setList.add(String.valueOf(obj.get(LE_PRIMARY_ALT_CODE.toLowerCase())));
            }
        }

        setList.add(goldId);

        return setList;
    }

	@Override
	public String getBusinessFromBu(String buCode,boolean requireActive) {
		
		StringBuilder filter = new StringBuilder();
		HashMap<String, String> params = new HashMap<>();
		try {
			filter.append("(");
			filter.append(UPPER_2  + MDMConstants.BU_CODE + UPPER_1 + URLDecoder.decode(buCode, "UTF-8")
								+ "')");
			if(requireActive) {
				filter.append(MDMConstants.OPERATOR_SPACE + OPERATOR_AND + MDMConstants.OPERATOR_SPACE);
				filter.append(UPPER_2 + MDMConstants.BU_ENABLED + UPPER_1 + ACTIVE + "')");
			}
			filter.append(")");
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in decodeing MDM Bank code : " + e);
			throw new SystemException("Error in decoding MDM Bank code : " + e.getMessage());
		}
		
		params.put(FILTER_CONST, filter.toString());
		
		params.put(MDMConstants.SELECT, StringUtils.join(Arrays.asList(MDMConstants.BU_CODE,
															MDMConstants.RPTLEVEL1__BU_DESCRIPTION,MDMConstants.RPTLEVEL2__BU_DESCRIPTION,MDMConstants.BU_ENABLED.toLowerCase()), 
																MDMConstants.OPERATOR_COMMA));
		
		return this.callMDMDenodo(params, businessHier, HttpMethod.GET, true);
		
	}
	
	@Override
	public Map<String, String> setMDMBusinessParams(String code,boolean requireActive){
		HashMap<String, String> params = new HashMap<>();
		
		try {
			final StringBuilder filter = new StringBuilder();
			filter.append("(");
			filter.append("(");
		
			filter.append(UPPER_2 + MDMConstants.RPTLEVEL1__BU_DESCRIPTION + MDMConstants.UPPER_3 
						+ URLDecoder.decode(code, "UTF-8") + "%')");
			filter.append(MDMConstants.OPERATOR_SPACE + OPERATOR_OR + MDMConstants.OPERATOR_SPACE);
			filter.append(UPPER_2 + MDMConstants.RPTLEVEL2__BU_DESCRIPTION + MDMConstants.UPPER_3 
					+ URLDecoder.decode(code, "UTF-8") + "%')");
            filter.append(MDMConstants.OPERATOR_SPACE + OPERATOR_OR + MDMConstants.OPERATOR_SPACE);
            filter.append(UPPER_2 + MDMConstants.BU_CODE + MDMConstants.UPPER_3 
                    + URLDecoder.decode(code, "UTF-8") + "%')");
            filter.append(")");
            if (requireActive) {
                filter.append(MDMConstants.OPERATOR_SPACE + MDMConstants.AND_STRING + MDMConstants.OPERATOR_SPACE);
                filter.append(UPPER_2 + MDMConstants.BU_ENABLED + UPPER_1 + ACTIVE + "')");
            }
			filter.append(MDMConstants.OPERATOR_SPACE + MDMConstants.AND_STRING + MDMConstants.OPERATOR_SPACE);
			filter.append(MDMConstants.RPTLEVEL1__BU_DESCRIPTION + MDMConstants.IS_NOT_NULL + MDMConstants.OPERATOR_SPACE 
								+ MDMConstants.OPERATOR_AND + MDMConstants.OPERATOR_SPACE 
									+ MDMConstants.RPTLEVEL2__BU_DESCRIPTION + MDMConstants.IS_NOT_NULL);
			filter.append(")");
			
			params.put(FILTER_CONST, filter.toString());
			params.put(MDMConstants.START_INDEX, "0");
			params.put(MDMConstants.COUNT, "20");
			
			params.put(MDMConstants.SELECT, StringUtils.join(Arrays.asList(MDMConstants.BU_CODE,
																		   	MDMConstants.RPTLEVEL1__BU_DESCRIPTION,MDMConstants.RPTLEVEL2__BU_DESCRIPTION),
																				MDMConstants.OPERATOR_COMMA));

		} catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
		}
		
		return params;
	}
	@Override
	public String getBuHierUrl() {
		return this.businessHier;
	}

	@Override
	public Map<String, String> setLeFilterParams(boolean isWildSearch, String goldId) {
		
		StringBuilder filter = new StringBuilder();;
		Map<String,String> params = new HashMap<>();
		
		try {
			
			filter.append("(");
			if(isWildSearch) {
				filter.append(UPPER_2 + LE_PRIMARY_ALT_CODE + ") ").append(OPERATOR_LIKE)
				.append(" UPPER('%" + URLDecoder.decode(goldId, "UTF-8") + "%')");
			}else {
				filter.append(UPPER_2 + LE_PRIMARY_ALT_CODE + ") ").append(OPERATOR_EQUALS)
				.append("UPPER('" + URLDecoder.decode(goldId, "UTF-8") + "')");
			}
			filter.append(" " + OPERATOR_AND + " ");
			filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS)
					.append(" UPPER('" + "GOLD" + "')");
			filter.append(" " + OPERATOR_AND + " ");
			filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");
			filter.append(" " + OPERATOR_AND + " ")
			.append(MDMConstants.ACTIVE_FLAG)
					.append(OPERATOR_EQUALS).append("'Y'");      
			filter.append(")");
			
			params.put(FILTER_CONST, filter.toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return params;
	}
	
	 @Override
	public boolean validateBankBranchStatus(String bankBranchID, String countrycode, String type){
	    	
			StringBuilder filter = new StringBuilder();
			
			try {
				filter.append("(");
				if (null != StringUtils.trimToNull(bankBranchID)) {
					filter.append("(");
					filter.append(
							UPPER_2 + MDMConstants.BANK_BANK_LEGAL_NAME + ") like UPPER('%" + URLDecoder.decode(bankBranchID, MDMConstants.UTF_8) + "%')");

					filter.append(" or ");

					filter.append(UPPER_2 + MDMConstants.BANK_MDM_ID + ") like UPPER('%" + URLDecoder.decode(bankBranchID, MDMConstants.UTF_8) + "%')");
					filter.append(")");

				}

				if (null != StringUtils.trimToNull(countrycode)) {

					filter.append(" and  ");

					filter.append(
							UPPER_2 + MDMConstants.BANK_BANK_COUNTRY_CODE + ") = UPPER('" + URLDecoder.decode(countrycode, MDMConstants.UTF_8) + "')");

				}

				filter.append(" and  ");

				
				filter.append(UPPER_2 + MDMConstants.BANK_BANK_TYPE + ") = UPPER('" + URLDecoder.decode(type, MDMConstants.UTF_8) + "')");

				filter.append(" and  ");

				filter.append(
						UPPER_2 + MDMConstants.BANK_BANK_STATUS + ") = UPPER('" + URLDecoder.decode("Active", MDMConstants.UTF_8) + "')");

				filter.append(")");
			} catch (UnsupportedEncodingException e) {
				MyBankLogger.logError(this, "Error in decodeing MDM Bank code : " + e);
				throw new SystemException("Error in decoding MDM Bank code : " + e.getMessage());
			}

			HashMap<String, String> params = new HashMap<>();
			params.put(FILTER_CONST, filter.toString());
			params.put("$totalCountRequired", "true");
			params.put("$start_index", "0");

			String responseBody = callMDMDenodo(params, bankUrl, HttpMethod.GET, true);
			JSONObject responseJson = new JSONObject(responseBody);
	        int totalCount = responseJson.getInt("totalcount");
	    	if(totalCount > 0)
	    	return true;
	    	else return false;
	    }
	
	 	@Override
	    public boolean validateCurrencyCodeStatus(AccountRequest accountRequest){
	    	
	    	final StringBuilder filter = new StringBuilder();

			filter.append("(");

			filter.append(UPPER_2 + MDMConstants.CURRENCY_CURRENCY_STATUS + ") = UPPER('" + ACTIVE + "')");
			filter.append(" AND ");
			filter.append(UPPER_2 + "curr_code" + ") = UPPER('" + accountRequest.getCurrency() + "')");

			filter.append(")");

			HashMap<String, String> params = new HashMap<>();
			params.put(FILTER_CONST, filter.toString());
			params.put("$totalCountRequired", "true");
			params.put("$start_index", "0");

			String responseBody = callMDMDenodo(params, currencyUrl, HttpMethod.GET, true);
			JSONObject responseJson = new JSONObject(responseBody);
	        int totalCount = responseJson.getInt("totalcount");
	    	if(totalCount > 0)
	    	return true;
	    	else return false;
	    }
	    
	    @Override
	    public boolean validateCountryCodeStatus(AccountRequest accountRequest){
			final StringBuilder filter = new StringBuilder();

			filter.append("(");

			filter.append(UPPER_2 + "CNTRY_STATUS" + ") = UPPER('" + ACTIVE + "')");
			filter.append(" AND ");
			filter.append(UPPER_2 + "mdm_id" + ") = UPPER('" + accountRequest.getCountry() + "')");

			filter.append(")");
			HashMap<String, String> params = new HashMap<>();
			params.put(FILTER_CONST, filter.toString());
			params.put("$totalCountRequired", "true");
			params.put("$start_index", "0");
			String responseBody = callMDMDenodo(params, countryUrl, HttpMethod.GET, true);
			JSONObject responseJson = new JSONObject(responseBody);
	        int totalCount = responseJson.getInt("totalcount");
	    	if(totalCount > 0)
	    	return true;
	    	else return false;
	    }
	    
	    @Override
	    public boolean validateAccountTypeStatus(AccountRequest accountRequest){
	    	HashMap<String, String> params = new HashMap<>();
	    	params.put("$status", "A");
	    	params.put("$acct_type", accountRequest.getAccountType());
			params.put("$totalCountRequired", "true");
			String url = accountTypeUrl;
	    	
	    	String responseBody = callMDMDenodo(params, url, HttpMethod.GET, true);
			JSONObject responseJson = new JSONObject(responseBody);
	        int totalCount = responseJson.getInt("totalcount");
	    	if(totalCount > 0)
	    	return true;
	    	else return false;
	    }
	    
	    @Override
	    public boolean validateMeCodeStatus(AccountRequest accountRequest){
			final StringBuilder filter = new StringBuilder();
			try {
				
				
				filter.append("(");
				filter.append("(");
				filter.append(UPPER_2 + LE_PARTY_NM + UPPER_LIKE + URLDecoder.decode(accountRequest.getMeCode(), MDMConstants.UTF_8) + "%')");
				filter.append(" " +OPERATOR_OR + " ");
				filter.append(UPPER_2 + LE_PRIMARY_ALT_CODE +  UPPER_LIKE + URLDecoder.decode(accountRequest.getMeCode(), MDMConstants.UTF_8)+"%')");
				filter.append(")");
				filter.append(" " + OPERATOR_AND + " ");
	            filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");
	        	filter.append(" " + OPERATOR_AND + " ");
	            filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + MDMConstants.MDM_MARS + "')");
				filter.append(")");


			} catch (Exception e) {
				MyBankLogger.logError(this, "Error in Decoding :: fetchMEDetails ", e);
			}

			HashMap<String, String> params = new HashMap<>();

			params.put(FILTER_CONST, filter.toString());
			params.put("$totalCountRequired", "true");
			params.put("$start_index", "0");
			String responseBody = callMDMDenodo(params, meUrl, HttpMethod.GET, false);
			JSONObject responseJson = new JSONObject(responseBody);
	        int totalCount = responseJson.getInt("totalcount");
	    	if(totalCount > 0)
	    	return true;
	    	else return false;
	    }
	    
	    @Override
		public boolean validateComponentCode(AccountRequest acct)
	    {
	    	return getChildGoldIds(acct.getLeCode()).contains(acct.getComponentCode());
	    }
}