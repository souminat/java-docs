package com.ge.treasury.mybank.business.security.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.business.user.service.impl.UserProfileService;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.SecurityConstants;

/**
 * @author MyBank Dev Team This class get the roles for particular SSO from IDM
 *         Microservice database and set only matching roles in userdetails
 *         object.
 */
@Component
public class MyBankUserDetailService implements UserDetailsService {

    @Autowired
    private UserProfileService userService;

    private static final char PASSWORD[] = {'p','a','s','s','w','o','r','d'};
    
    @SuppressWarnings("unchecked")
    @Override
    public UserDetails loadUserByUsername(String sso)
            throws UsernameNotFoundException {
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "Method loadUserByUsername"
                + "SSO Received :: " + sso);

        List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
        UserProfile userRolesList = null;
        Exception exception = null;
        try {
            // call FineGrain Microservice
            userRolesList = userService.getUserBySSODomain(sso);
            if (userRolesList != null) {

                for (UserRole role : userRolesList.getRoles()) {
                    GrantedAuthority grantedauthrole = new SimpleGrantedAuthority(
                            role.getMyBankRole().replaceAll("\\s+", ""));
                    grantedAuthorities.add(grantedauthrole);
                }
            } else {
                throw new UsernameNotFoundException("User not found");
            }

        } catch (Exception ex) {
            exception = ex;
        }
        CustomUserDetails userdetails = new CustomUserDetails(sso,
        		String.valueOf(PASSWORD), SecurityConstants.ENABLED,
                SecurityConstants.ACCOUNTNONEXPIRED,
                SecurityConstants.CREDENTIALSNONEXPIRED,
                SecurityConstants.ACCOUNTNONLOCKED, grantedAuthorities,
                exception, userRolesList);

        userdetails.setUserProfile(userRolesList);
        MyBankLogger.logEnd(
                this,
                "loadUserByUsername, time spent: "
                        + (System.currentTimeMillis() - startTime));
        MyBankLogger.logInfo(this, "userdetails " + userdetails);
        return userdetails;
    }

}
