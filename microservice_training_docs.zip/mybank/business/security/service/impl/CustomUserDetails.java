package com.ge.treasury.mybank.business.security.service.impl;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.ge.treasury.mybank.domain.user.UserProfile;

public class CustomUserDetails extends User {

    /**
     * Author : MyBank Dev Team This class extends
     * org.springframework.security.core.userdetails.User and adds the exception
     * to it
     */
    private static final long serialVersionUID = 1L;

    private Exception exception;
    private UserProfile userProfile;

    public CustomUserDetails(String username, String password, boolean enabled,
            boolean accountNonExpired, boolean credentialsNonExpired,
            boolean accountNonLocked,
            Collection<? extends GrantedAuthority> authorities,
            Exception exception, UserProfile userprofile) {
        super(username, password, enabled, accountNonExpired,
                credentialsNonExpired, accountNonLocked, authorities);
        this.exception = exception;
        this.userProfile = userprofile;
    }

    public Exception getException() {
        return exception;
    }

    public void setException(Exception exception) {
        this.exception = exception;
    }

    /**
     * @return the userProfile
     */
    public UserProfile getUserProfile() {
        return userProfile;
    }

    /**
     * @param userProfile
     *            the userProfile to set
     */
    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

}
