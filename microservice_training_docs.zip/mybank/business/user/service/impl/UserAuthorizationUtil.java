/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.user.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.AuthorizationException;

/**
 * User Authorization util on business/subBusinesses access
 * 
 * @author MyBank Dev Team
 * 
 */
public class UserAuthorizationUtil {
	
    private static final List<String> ELEVATED_ACCESS = new ArrayList<String>();
    
    static{
        ELEVATED_ACCESS.add(ValidationConstants.ACCT_REQUEST_USER_TREASURY);
        ELEVATED_ACCESS.add(ValidationConstants.ACCT_REQUEST_USER_TREASURY_DIVESTED);
        ELEVATED_ACCESS.add(ValidationConstants.ACCT_REQUEST_USER_TREASURY_ADMIN);
    }
    
    public static List<String> getElevatedAccessList(){
    	return ELEVATED_ACCESS;
    }
    
    /**
     * Validates business
     * 
     * @param acctReq
     * @param user
     * @throws AuthorizationException
     */
    public static void validateUserBusinessSubBusiness(AccountRequest acctReq,
            User user) throws AuthorizationException {
        UserProfile userProfile = null;

        if (user != null && user.getUserProfile() != null && acctReq != null) {
            userProfile = user.getUserProfile();

            // Obtain role available for business/subBusiness
            UserRole currentRole = UserAuthorizationUtil.obtainCurrentRole(
                    userProfile.getRoles(), acctReq);

            // If no current role for business/subBusiness then error
            if (currentRole == null) {
                MyBankLogger.logError(new UserAuthorizationUtil(),
                        "User doesnt have access to this action.");
                throw new AuthorizationException(
                        "User doesnt have access to this action.");
            }

        } else {
            MyBankLogger.logError(new UserAuthorizationUtil(),
                    "No roles found for user.");
            throw new AuthorizationException("No roles found for user.");
        }

        MyBankLogger.logDebug(new UserAuthorizationUtil(),
                "Ending Authorization Validation");
    }

    /**
     * Validates that BI is the only role for creation Validates that BI can not
     * move to Pending Bank Account or Complete
     * 
     * @param acctReq
     * @param user
     * @throws AuthorizationException
     */
    public static void validateUserActionsByRole(AccountRequest acctReq,
            User user, boolean isCreateOrUpdate) throws AuthorizationException {

        boolean isValidAction = true;

        UserProfile userProfile = user.getUserProfile();

        UserRole currentRole = null;
        if (userProfile != null && userProfile.getRoles() != null) {

            // Obtain role available for business/subBusiness
            currentRole = UserAuthorizationUtil.obtainCurrentRole(
                    userProfile.getRoles(), acctReq);

        } else {
            MyBankLogger.logError(new UserAuthorizationUtil(),
                    "No roles found for user.");
            throw new AuthorizationException("No roles found for user.");
        }

        // Obtain current role is not BI then user does not have access to
        // actions
        if (currentRole != null) {

            if (currentRole.getMyBankRole().equalsIgnoreCase(
                    ValidationConstants.ACCT_REQUEST_USER_INITIATOR)) {
                // Validates that BI can not move to Pending Bank Account or
                // Complete
                if (acctReq.getRequestStatus() != null
                        && (acctReq
                                .getRequestStatus()
                                .equalsIgnoreCase(
                                        ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF) || acctReq
                                .getRequestStatus()
                                .equalsIgnoreCase(
                                        ValidationConstants.ACCOUNT_STATUS_COMPLETED))) {
                    isValidAction = false;
                }

                if (!isValidAction) {
                    MyBankLogger
                            .logError(new UserAuthorizationUtil(),
                                    "Business Initiator doesnt have access to this action.");
                    throw new AuthorizationException(
                            "Business Initiator doesnt have access to this action.");
                }

            }
            // Validates user is a Treasury Services User creating a request on
            // behalf of (any Business/SubBusiness)
            if (ELEVATED_ACCESS.stream().anyMatch(currentRole.getMyBankRole()::equalsIgnoreCase)) {
                UserAuthorizationUtil.validateTreasuryServicesActions(acctReq,
                        user);
            }

            if (currentRole.getMyBankRole().equalsIgnoreCase(
                    ValidationConstants.ACCT_REQUEST_USER_INITIATOR_RO)
                    || currentRole.getMyBankRole().equalsIgnoreCase(
                            ValidationConstants.ACCT_REQUEST_USER_TREASURY_RO)) {
                if (isCreateOrUpdate) {
                    isValidAction = false;
                }

                if (!isValidAction) {
                    MyBankLogger
                            .logError(new UserAuthorizationUtil(),
                                    "This is a Read Only User and doesnt have access to this action.");
                    throw new AuthorizationException(
                            "This is a Read Only User and doesnt have access to this action.");
                }
            }

        } else {
            throw new AuthorizationException(
                    "User doesnt have access to this action.");
        }
        MyBankLogger.logDebug(new UserAuthorizationUtil(),
                "Ending Authorization Validation");
    }

    /**
     * Validates Treasury Services that submit request for on behalf of, then
     * that user can not complete request
     * 
     * @param acctReq
     * @param user
     * @throws AuthorizationException
     * 
     * Commented Code
     * Validates user has Treasuy Services role
        UserAuthorizationUtil.validateUserRole(
                ValidationConstants.ACCT_REQUEST_USER_TREASURY,ValidationConstants.ACCT_REQUEST_USER_TREASURY_ADMIN, user);
                Validates that TU that submit the request is not the same to complete
                it
     */
    public static void validateTreasuryServicesActions(AccountRequest acctReq,
            User user) throws AuthorizationException {

        String sso = user.getUserProfile().getSso();
        
        if (acctReq.getRequestStatus().equalsIgnoreCase(
                ValidationConstants.ACCOUNT_STATUS_COMPLETED)
                && acctReq.getCreateUser().equals(sso)) {
            MyBankLogger
                    .logError(new UserAuthorizationUtil(),
                            "Treasury Services User doesnt have access to this action.");
            throw new AuthorizationException(
                    "Treasury Services User doesnt have access to this action.");
        }
        List<UserRole> roleList = user.getUserProfile().getRoles().stream()
                .filter(role -> ELEVATED_ACCESS.stream().anyMatch(role.getMyBankRole()::equalsIgnoreCase)
                        && !StringUtils.isEmpty(role.getBusiness()))
                .collect(Collectors.toList());
        
        
        if (!CollectionUtils.isEmpty(roleList) && !roleList.stream().anyMatch(currentRole -> StringUtils
                .equalsIgnoreCase(currentRole.getBusiness(), StringUtils.trimToEmpty(acctReq.getBussName()))
                && (StringUtils.isEmpty(currentRole.getSubBusiness())
                        || StringUtils.equalsIgnoreCase(currentRole.getSubBusiness(), StringUtils.trimToEmpty(acctReq.getSubBusName()))))) {
            MyBankLogger.logError(new UserAuthorizationUtil(),
                    "Treasury Services User doesnt have Business/Sub Business access to this action.");
            throw new AuthorizationException(
                    "Treasury Services User doesnt have Business/Sub Business access to this action.");
        }

        MyBankLogger.logDebug(new UserAuthorizationUtil(),
                "Ending Authorization Validation");
    }

    /**
     * Validates role is contained in the list of roles for user
     * 
     * @param specificRole
     * @param user
     * @throws AuthorizationException
  
    public static void validateUserRole(String specificRole,String specificRole_admin, User user)
            throws AuthorizationException {
        UserProfile userProfile = null;

        boolean isValidRole = false;

        if (user != null && user.getUserProfile() != null
                && specificRole != null) {
            userProfile = user.getUserProfile();

            for (UserRole role : userProfile.getRoles()) {
                if (specificRole.equalsIgnoreCase(role.getMyBankRole())
                		|| specificRole_admin.equalsIgnoreCase(role.getMyBankRole())) {
                    isValidRole = true;
                    break;
                }
            }

            if (!isValidRole) {
                MyBankLogger.logError(new UserAuthorizationUtil(),
                        "User doesnt have the role to this acction.");
                throw new AuthorizationException(
                        "User doesnt have the role to this acction.");
            }

        } else {
            MyBankLogger.logError(new UserAuthorizationUtil(),
                    "No roles found for user.");
            throw new AuthorizationException("No roles found for user.");
        }

        MyBankLogger.logDebug(new UserAuthorizationUtil(),
                "Ending Authorization Validation");
    }
    */

    /**
     * Obtain current role for user by business/subBusiness Counting that user
     * can only have one role for a business/subBusiness
     * 
     * @param roles
     * @param accReq
     * @return
     */
    public static UserRole obtainCurrentRole(List<UserRole> roles,
            AccountRequest acctReq) {
        UserRole currentRole = null;

        if (roles != null && acctReq != null) {
            String business = null;
            String subBusiness = null;
            boolean canValidate = false;

            if (acctReq.getBussName() != null) {
                business = StringUtils.trimToEmpty(acctReq.getBussName());
                canValidate = true;
            }
            if (acctReq.getSubBusName() != null) {
                subBusiness = StringUtils.trimToEmpty(acctReq.getSubBusName());
            }

            // Find the current user by business/subBusiness
            if (canValidate) {
                for (UserRole role : roles) {

                    if (ELEVATED_ACCESS.stream().anyMatch(role.getMyBankRole()::equalsIgnoreCase)
                            || role.getMyBankRole()
                                    .equalsIgnoreCase(ValidationConstants.ACCT_REQUEST_USER_FINANCE_ADMIN)) {
                        currentRole = role;
                    } else {

                        if (role.getBusiness().equalsIgnoreCase(business)) {
                            // Validate also subBusiness
                            if (subBusiness != null
                                    && role.getSubBusiness() != null) {
                                if (role.getSubBusiness().equalsIgnoreCase(
                                        subBusiness)) {
                                    currentRole = role;
                                    break;
                                }
                            } else { // No subBusiness to validate
                                currentRole = role;
                                break;
                            }
                        }

                    }
                }
            }
        }
        return currentRole;
    }

}
