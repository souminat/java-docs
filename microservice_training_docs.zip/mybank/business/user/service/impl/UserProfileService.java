/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.user.service.impl;

import java.util.List;

import com.ge.treasury.mybank.domain.user.UserProfile;

/**
 * Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface UserProfileService {

    /**
     * Search for user information by sso and domain
     * 
     * @param sso
     * @param domain
     * @return
     */
    public UserProfile getUserBySSODomain(String sso);
    
    public List<UserProfile> getUsersByRole(String roles);

    public String userLookUp(String sso);
}
