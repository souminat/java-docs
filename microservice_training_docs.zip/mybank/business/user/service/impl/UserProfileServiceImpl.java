/**
 */
package com.ge.treasury.mybank.business.user.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.domain.user.FineGrainAuthRequest;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;

/**
 * Contains the implementation of IDMUserService methods
 * 
 * @author MyBank Dev Team
 * 
 */
@Service
public class UserProfileServiceImpl implements UserProfileService,
        ValidationConstants {

    @Value("${finegrain.ms.baseUrl}")
    private String fineGrainBaseUrl;

    @Value("${finegrain.ms.getUserProfile}")
    private String getUserProfile;
    
    @Value("${finegrain.ms.getUsersByAppRole}")
    private String getUsersByAppRole;
    
    @Value("${user.lookup.baseUrl}")
    private String userLookupBaseUrl;

   /**
    * ESDRM changes
    * @Autowired
    private MDMService mdmService;*/
    
    @Autowired
    private OAuth2RestOperations msFineGrainAuthRestTemplate;
    
    @Autowired
    private OAuth2RestOperations myBankRestTemplate;
     
    /**
     * ESDRM changes
    *  private static final Pattern businessRegex = Pattern.compile("^Business (Initiator|Read Only)$",
            Pattern.CASE_INSENSITIVE);*/
    
    /*
     * Search for user information by sso and domain (non-Javadoc)
     * 
     * @see com.ge.treasury.mybank.business.idm.service.impl.IDMUserService#
     * getUserBySSODomain (java.lang.String, java.lang.String)
     */
    @Override
    public UserProfile getUserBySSODomain(String sso) throws BusinessException {
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "getUserBySSODomain " + sso);

        UserProfile profile = null;

        String url = fineGrainBaseUrl + getUserProfile;

        MyBankLogger.logDebug(this, "Microservice URL= " + url);

        // set RequestData
        FineGrainAuthRequest requestData = new FineGrainAuthRequest();
        requestData.setSso(sso);
        requestData.setAppName(MYBANK_IDM_APPNAME);//MYBANK_IDM_APPNAME
        requestData.setStatus(MYBANK_IDM_STATUSACTIVE);

        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        String jsonString = null;
        try {
            jsonString = ow.writeValueAsString(requestData);
        } catch (IOException e) {
            MyBankLogger.logError(this, e.getMessage(), e);
            throw new SystemException(e.getMessage());
        }

        try {
            // set headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<String>(jsonString,
                    headers);

            // Retrieve object by doing a POST on the specified URL
            ResponseEntity<String> response = msFineGrainAuthRestTemplate.exchange(url,
                    HttpMethod.POST, entity, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JSONObject jsonObject = new JSONObject(response.getBody());
                List<UserProfile> userProfies = this
                        .obtainUserFromJSON(jsonObject);
                if (userProfies != null) {
                    profile = userProfies.get(0);
                }

            } else {
                MyBankLogger.logError(this, MYBANK_USERPROFILE_GENERIC_ERROR);
                throw new SystemException(MYBANK_USERPROFILE_GENERIC_ERROR);
            }
        } catch (HttpClientErrorException httpEx) {
            JSONObject httpExJson = new JSONObject(
                    httpEx.getResponseBodyAsString());
            String statusMessage = MYBANK_USERPROFILE_GENERIC_ERROR;
            if (httpExJson.has("statusMessage")) {
                statusMessage = httpExJson.getString("statusMessage");
            }
            MyBankLogger.logError(this, statusMessage);
            throw new SystemException(statusMessage,httpEx);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage());
            throw new SystemException(ex);
        }

        MyBankLogger.logInfo(this,
                "User information obtained successfully from DB");

        MyBankLogger.logEnd(this, "getUserBySSODomain " + sso,
                System.currentTimeMillis() - startTime);
        return profile;
    }

    private List<UserProfile> obtainUserFromJSON(JSONObject jsonObjectProfile) {
        return obtainUserFromJSON(jsonObjectProfile, false);
    }

    /**
     * Returns the list of users contained in jsonArray
     * 
     * @param jsonArray
     * @return
     */
    private List<UserProfile> obtainUserFromJSON(JSONObject jsonObjectProfile, boolean obtainName)
            throws BusinessException {
        List<UserProfile> userProfiles = null;

        if (jsonObjectProfile != null) {
            UserProfile profile = null;

            String status = null;
            try {
                if (jsonObjectProfile.has("status")) {
                    status = jsonObjectProfile.getString("status");
                }

                if (status != null
                        && status
                                .equalsIgnoreCase(ValidationConstants.MYBANK_IDM_STATUSRESPONSE)) {
                    JSONArray jsonArrayProfiles = jsonObjectProfile
                            .getJSONArray("responseData");
                    for (int i = 0; i < jsonArrayProfiles.length(); i++) {
                        if (userProfiles == null) {
                            userProfiles = new ArrayList<UserProfile>();
                        }
                        profile = new UserProfile();
                        JSONObject jsonObject = jsonArrayProfiles
                                .getJSONObject(i);

                        profile.setSso(jsonObject.get("sso").toString());
                        profile.setAppName(jsonObject.get("appName").toString());
                        
                        if(obtainName) {
                            String userJson = userLookUp(profile.getSso());
                            
                            if(null!=userJson){
                            	JSONObject requestorUserJsonObject = new JSONObject(userJson);
                            	profile.setName(requestorUserJsonObject.getString("firstName") + " " + requestorUserJsonObject.getString("lastName"));
                            }
                            
                        }

                        List<UserRole> roles = null;
                        JSONArray roleArray = jsonObject.getJSONArray("roles");
                        for (int j = 0; j < roleArray.length(); j++) {
                            if (roles == null) {
                                roles = new ArrayList<UserRole>();
                            }

                            JSONObject roleJson = roleArray.getJSONObject(j);
                            UserRole role = new UserRole();

                            if (roleJson.has("appRole")) {
                                role.setMyBankRole(roleJson
                                        .getString("appRole"));
                            }
                            if (roleJson.has("business")) {
                                role.setBusiness(roleJson.getString("business"));
                            }
                            if (roleJson.has("subBusiness")) {
                                role.setSubBusiness(roleJson
                                        .getString("subBusiness"));
                            }
                            if (roleJson.has("statusRole")) {
                                role.setStatusRole(roleJson
                                        .getString("statusRole"));
                            }
                            roles.add(role);
                        }

                        /**
                         * Commented out below code to make sure all active IDM
                         * roles are present with user role list. When ESDRM
                         * changes happens users should be able to access the
                         * old accounts data which they have access to in IDM.
                         * profile.setRoles(filterInactiveBussinesses(roles));
                         */
                        profile.setRoles(roles);
                        userProfiles.add(profile);
                    }
                } else {
                    String statusMessage = MYBANK_USERPROFILE_GENERIC_ERROR;
                    if (jsonObjectProfile.has("statusMessage")) {
                        statusMessage = jsonObjectProfile
                                .getString("statusMessage");
                    }
                    MyBankLogger.logError(this, statusMessage);
                    throw new SystemException(statusMessage);
                }
            } catch (Exception ex) {
                MyBankLogger.logError(this, ex.getMessage());
                throw new SystemException(ex);
            }
        }

        return userProfiles;
    }
    
    /**
     * ESDRM changes : When ESDRM
     * changes happens users should be able to access the
     * old accounts data which they have access to in IDM.
     * 
     * private List<UserRole> filterInactiveBussinesses(List<UserRole> rolesList) {
        if (rolesList == null) {
            return java.util.Collections.emptyList();
        }
        
        List<UserRole> roles = new ArrayList<UserRole>();
        List<UserRole> search = new ArrayList<UserRole>();
        for (UserRole role : rolesList) {
            // If Role is Active
            if (MYBANK_IDM_STATUSACTIVE.equalsIgnoreCase(role.getStatusRole())
                    // If Role is of Business
                    && businessRegex.matcher(role.getMyBankRole()).matches()) {
                search.add(role);
            // Else-If Role is Active and Treasury User
            } else if (MYBANK_IDM_STATUSACTIVE.equalsIgnoreCase(role.getStatusRole())
                    && !businessRegex.matcher(role.getMyBankRole()).matches()) {
                roles.add(role);
            }
        }
        if (!search.isEmpty()) {
            try{
                roles.addAll(mdmService.isBusinessSubBusinessOpen(search));
            }catch(Exception e) {
                MyBankLogger.logError(this, "UserProfileServiceImpl.filterInactiveBussinesses: " + e.getMessage(), e);  
            }
        }
        
        return roles;
    }
     */
    
    @Override
    public List<UserProfile> getUsersByRole(String roles) {
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "getTreasuryServicesUsers");

        List<UserProfile> profiles = null;

        String url = fineGrainBaseUrl + getUsersByAppRole;

        MyBankLogger.logDebug(this, "Microservice URL= " + url);

        // set RequestData
        FineGrainAuthRequest requestData = new FineGrainAuthRequest();
        requestData.setAppName(MYBANK_IDM_APPNAME);
        requestData.setStatus(MYBANK_IDM_STATUSACTIVE);
        requestData.setRole(roles);

        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        String jsonString = null;
        try {
            jsonString = ow.writeValueAsString(requestData);
        } catch (IOException e) {
            MyBankLogger.logError(this, e.getMessage(), e);
            throw new SystemException(e.getMessage());
        }

        try {
            // set headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<String>(jsonString,
                    headers);

            // Retrieve object by doing a POST on the specified URL
            ResponseEntity<String> response = msFineGrainAuthRestTemplate.exchange(url,
                    HttpMethod.POST, entity, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JSONObject jsonObject = new JSONObject(response.getBody());
                List<UserProfile> userProfiles = this
                        .obtainUserFromJSON(jsonObject, true);
                if (userProfiles != null) {
                    profiles = userProfiles;
                }

            } else {
                MyBankLogger.logError(this, MYBANK_USERPROFILE_GENERIC_ERROR);
                throw new SystemException(MYBANK_USERPROFILE_GENERIC_ERROR);
            }
        } catch (HttpClientErrorException httpEx) {
            JSONObject httpExJson = new JSONObject(
                    httpEx.getResponseBodyAsString());
            String statusMessage = MYBANK_USERPROFILE_GENERIC_ERROR;
            if (httpExJson.has("statusMessage")) {
                statusMessage = httpExJson.getString("statusMessage");
            }
            MyBankLogger.logError(this, statusMessage);
            throw new SystemException(statusMessage,httpEx);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage());
            throw new SystemException(ex);
        }

        MyBankLogger.logInfo(this,
                "User information obtained successfully from DB");

        MyBankLogger.logEnd(this, "getTreasuryServicesUsers",
                System.currentTimeMillis() - startTime);
        return profiles;
    }

    @Override
    public String userLookUp(String sso) {
        String response = null;
        try {
        	response = myBankRestTemplate.getForObject(userLookupBaseUrl + sso /*+ "*"*/, String.class);
		} catch (Exception e) {
			MyBankLogger.logError(this, MYBANK_HRAPI_GENERIC_ERROR.concat("UserProfileServiceImpl.filterInactiveBussinesses: ") + e.getMessage(), e);
		}
    	return response;
    }
}
