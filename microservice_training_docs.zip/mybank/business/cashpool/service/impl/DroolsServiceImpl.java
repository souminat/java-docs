package com.ge.treasury.mybank.business.cashpool.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMUtil;
import com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;

@Component
public class DroolsServiceImpl implements DroolsService {

    @Value("${workflow.decision.url}")
    private String droolsUrl;

    @Autowired
    private OAuth2RestOperations myBankRestTemplate;

    @Autowired
    AccountRequestDao requestDao;

    @Autowired
    MDMService mdmService;

    private HashMap<String, String> mapa;

    private void setRequestParams(AccountRequest accReq) {

        mapa = new HashMap<String, String>();

        mapa.put(ValidationConstants.ACCOUNT_TYPE, accReq.getAccountType());
        mapa.put(ValidationConstants.LECODE_TAX, accReq.getLeCode());
        mapa.put(ValidationConstants.LECODE, accReq.getLeCode());
        mapa.put(ValidationConstants.COUNTRY, accReq.getCountry());
        mapa.put(ValidationConstants.CURRENCY, accReq.getCurrency());
        mapa.put(ValidationConstants.LE_COUNTRY, fetchLeCountry(accReq));
    }

    @Override
    public Map<String, String> validateCashpoolPossible(User user, AccountRequest accountRequest) {

        // Perform drools call and get the actual response
        setRequestParams(accountRequest);
        String json = MDMUtil.constructJsonString(mapa);

        Map<String, String> resposneMap = new HashMap<String, String>();

        ResponseEntity<String> response = null;
        try {
            response = getDroolsResponse(droolsUrl, json);
            // Http Status 200
            if (null != response) {

                MyBankLogger.logInfo(this, ValidationConstants.RESPONSE_DROOLS.concat(response.getBody()));
                resposneMap.put(ValidationConstants.DROOLS_STATUS, ValidationConstants.STATUS_FAILED);
                String[] responseArray = StringUtils.splitByWholeSeparator(response.getBody(),
                        ValidationConstants.CASHPOOL_OUTPOOT);
                if (responseArray.length > 1) {
                    resposneMap.put(ValidationConstants.RESPONSE,
                            StringUtils.splitByWholeSeparator(responseArray[1], "}}")[0]);
                } else {
                    throw new BusinessException(ValidationConstants.RESPONSE_FETCH_FAILED + response.getBody());
                }
            }
        } catch (HttpClientErrorException httpEx) {

            // Http Status 400
            String httpExResp = httpEx.getResponseBodyAsString();
            if (!httpExResp.contains(ValidationConstants.NO_RULES_FOUND)) {

                MyBankLogger.logError(this, ValidationConstants.RESPONSE_DROOLS.concat(httpExResp), httpEx);
                throw new BusinessException(ValidationConstants.RESPONSE_NOT_FOUND + httpExResp);
            } else {
                MyBankLogger.logInfo(this, ValidationConstants.RESPONSE_DROOLS.concat(httpExResp));
                resposneMap.put(ValidationConstants.DROOLS_STATUS, ValidationConstants.STATUS_SUCCESS);
                resposneMap.put(ValidationConstants.RESPONSE, httpEx.getResponseBodyAsString());
            }
        } catch (Exception ex) {
            MyBankLogger.logError(this, ValidationConstants.DROOLS_ERROR.concat(ex.getMessage()), ex);
            throw new SystemException(ValidationConstants.RESPONSE_FETCH_FAILED + ex.getMessage());
        }

        return resposneMap;
    }

    private ResponseEntity<String> getDroolsResponse(String url, String json) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), headers);

        // Get the response as string
        return myBankRestTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST,
                httpEntity, String.class);
    }

    private String fetchLeCountry(AccountRequest accReq) {
        String leCountry = "";
        JSONArray data = mdmService.getMDMLEDetails(accReq);

        Iterator<Object> itr = data.iterator();

        while (itr.hasNext()) {
            JSONObject obj = (JSONObject) itr.next();
            leCountry = StringHelper.getStringValue(obj.get(MDMConstants.LE_COUNTRY_CODE));
        }

        return leCountry;
    }

}
