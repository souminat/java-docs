package com.ge.treasury.mybank.business.cashpool.service.impl;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_T_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_TYPE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_MDM_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.FILTER_CONST;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.SELECT;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_2;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.corems.service.impl.AuditService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.business.user.service.impl.UserProfileService;
import com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingDetail;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingRequest;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingResponse;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.notification.Notification;


@Component
public class CashpoolServiceImpl implements CashpoolService, ValidationConstants {

	@Autowired
	MDMService mdmService;

	@Autowired
	AccountRequestDao requestDao;

	@Autowired
	DroolsService droolsService;

	@Autowired
	Notification notification;
	
	@Autowired
    private AuditService auditService;

	@Autowired
	private AccountRequestService accountService;

	@Autowired
	private MyBankLookupService lookupService;

	@Autowired
	private UserProfileService userProfileService;

	@Value("${mybank.notification.email}")
	private String notificationEmail;
	@Value("${app.environment}")
	private String appEnvironment;

	@Value("${mdm.ms.accountCore}")
	private String accountCore;

	@Value("${mdm.ms.bank}")
    private String bankBranch;

	@Value("${mybank.myfunding.url}")
	private String myFundingURL;
	
	@Value("${myfunding.basicauth.user}")
	private String myFundingUserId;
	
	@Value("${myfunding.basicauth.password}")
	private String myFundingPass;
	
	@Value("#{'${mybank.cashpool.sputnik.headerles}'.split(';')}")
	private List<String> sputnikHeaderLes;

	private static final String GOLD_LE_CODE = "gold_le_code";
	private static final String BUS_NAME = "business_name";
	private static final String IN = " in ";
	private static final String NOT_IN = " not in ";
	private static final String OPEN_BRACE = "(";
	private static final String TRIM = "TRIM";
	private static final String CLOSED_BRACE = ")";
	private static final String COMMA = ",";
	private static final String EQUALS = "=";
	private static final String SINGLE_QUOT = "'";
	private static final String COUNTRY_CODE = "country_code";
	private static final String CURRENCY_CODE = "currency_code";

	private static final String AND = " and ";
	private static final String CASHPOOL_TCODE_NOT_NULL = "cash_pool_tcode is not null";
	private static final String CASHPOOL_TCODE = "cash_pool_tcode";
	private static final String CASHPOOL_GOLD_CODE = "cash_pool_gold_code";
	private static final String ULTIMATE_PARENT_MDM_ID = "ult_parent_mdm_id";

	private static final String SPUTNIK_CATEGORY = "CASHPOOLCATEGORY_SPUTNIK";
	private static final String OIL_GAS_CATEGORY = "CASHPOOLCATEGORY_OIL_GAS";
	private static final String CAPITAL_CATEGORY = "CASHPOOLCATEGORY_CAPITAL";
	private static final String INDUSTRIAL_CATEGORY = "CASHPOOLCATEGORY_IND";
	private static final String RECORDS = "records";

	private static final String STANDALONE_PROCESS_CODE = "CASHPOOLPROCODE_STANDALONE";

	static Map<String, List<String>> categories = new HashMap<String, List<String>>();

	/**
	 * @Override public void saveCashPoolComments(CashPoolProcess cashPool,
	 *           AccountRequest accountRequest, User user) { String outPutMsg =
	 *           "";
	 * 
	 *           //Handling Status:SUCCESS - CashPool Not Possible for Drools
	 *           if(cashPool.getCashPoolStatusCode
	 *           ().equals(ValidationConstants.STATUS_FAILED)){ outPutMsg =
	 *           cashPool.getCashPoolResponse
	 *           ().split("CashpoolProcessOutput=")[1].replaceAll("}}", ""); }
	 * 
	 *           //Save Comments AccountComment comment = new AccountComment();
	 *           comment.setAcctRequestId(accountRequest.getAcctReqID());
	 *           comment.setCommentType(ValidationConstants.ACCOUNT_COMMENT_TYPE_REQUEST);
	 *           comment
	 *           .setComments(cashPool.getCashPoolStatusCode().equals(ValidationConstants
	 *           .STATUS_SUCCESS)?"Drools Logic - " + outPutMsg:"Drools Logic -
	 *           " + "CashPool Possible");
	 *           comment.setRole(user.getUserProfile().getRoles().get(0).getMyBankRole());
	 *           comment.setSsoId("System");
	 * 
	 *           requestDao.saveComment(user, comment);
	 * 
	 *           }
	 */

	private String getCategory(String leCode, String busiNess) {
		String category = null;
		if (categories.containsKey(SPUTNIK_CATEGORY) && categories.get(SPUTNIK_CATEGORY).contains(leCode)) {
			category = SPUTNIK_CATEGORY;
		} else if (categories.containsKey(OIL_GAS_CATEGORY) && categories.get(OIL_GAS_CATEGORY).contains(busiNess)) {
			category = OIL_GAS_CATEGORY;
		} else if (categories.containsKey(CAPITAL_CATEGORY) && categories.get(CAPITAL_CATEGORY).contains(busiNess)) {
			category = CAPITAL_CATEGORY;
		} else {
			category = INDUSTRIAL_CATEGORY;
		}
		return category;

	}

	private String getCategoryStringForURL(String category) {
		StringBuilder url = new StringBuilder();

		if (SPUTNIK_CATEGORY.equals(category)) {

			MyBankLogger.logInfo(this, "SPUTNIQ URL "
					+ StringUtils.join(categories.get(SPUTNIK_CATEGORY), SINGLE_QUOT + COMMA + SINGLE_QUOT));
			url.append(GOLD_LE_CODE).append(IN).append(OPEN_BRACE);
			url.append(SINGLE_QUOT);
			url.append(StringUtils.join(categories.get(SPUTNIK_CATEGORY), SINGLE_QUOT + COMMA + SINGLE_QUOT));
			url.append(SINGLE_QUOT);

			url.append(CLOSED_BRACE);
		} else if (OIL_GAS_CATEGORY.equals(category)) {
			MyBankLogger.logInfo(this,
					"OLG URL " + StringUtils.join(categories.get(OIL_GAS_CATEGORY), SINGLE_QUOT.concat(",")));

			url.append(TRIM).append(OPEN_BRACE).append(BUS_NAME).append(CLOSED_BRACE).append(IN).append(OPEN_BRACE).append(TRIM).append(OPEN_BRACE);
			url.append(SINGLE_QUOT);
			url.append(StringUtils.join(categories.get(OIL_GAS_CATEGORY), SINGLE_QUOT + CLOSED_BRACE + COMMA + TRIM + OPEN_BRACE + SINGLE_QUOT));
			url.append(SINGLE_QUOT);
			url.append(CLOSED_BRACE);

			url.append(CLOSED_BRACE);
		} else if (CAPITAL_CATEGORY.equals(category)) {
			MyBankLogger.logInfo(this,
					"CAPITAL URL " + StringUtils.join(categories.get(CAPITAL_CATEGORY), SINGLE_QUOT.concat(",")));
			url.append(TRIM).append(OPEN_BRACE).append(BUS_NAME).append(CLOSED_BRACE).append(IN).append(OPEN_BRACE).append(TRIM).append(OPEN_BRACE);
			url.append(SINGLE_QUOT);
			url.append(StringUtils.join(categories.get(CAPITAL_CATEGORY), SINGLE_QUOT + CLOSED_BRACE + COMMA + TRIM + OPEN_BRACE + SINGLE_QUOT));
			url.append(SINGLE_QUOT);
			url.append(CLOSED_BRACE);

			url.append(CLOSED_BRACE);
		} else {

		    url.append(TRIM).append(OPEN_BRACE).append(BUS_NAME).append(CLOSED_BRACE).append(NOT_IN).append(OPEN_BRACE).append(TRIM).append(OPEN_BRACE);
			url.append(SINGLE_QUOT);
			url.append(StringUtils.join(categories.get(OIL_GAS_CATEGORY), SINGLE_QUOT + CLOSED_BRACE + COMMA + TRIM + OPEN_BRACE + SINGLE_QUOT));
			url.append(SINGLE_QUOT);
			url.append(CLOSED_BRACE);

			url.append(COMMA).append(TRIM).append(OPEN_BRACE);
			url.append(SINGLE_QUOT);
			url.append(StringUtils.join(categories.get(CAPITAL_CATEGORY), SINGLE_QUOT + CLOSED_BRACE + COMMA + TRIM + OPEN_BRACE + SINGLE_QUOT));
			url.append(SINGLE_QUOT);
			url.append(CLOSED_BRACE);

			url.append(CLOSED_BRACE);
			url.append(AND);
			url.append(GOLD_LE_CODE).append(NOT_IN).append(OPEN_BRACE);
			url.append(SINGLE_QUOT);
			url.append(StringUtils.join(categories.get(SPUTNIK_CATEGORY), SINGLE_QUOT + COMMA + SINGLE_QUOT));
			url.append(SINGLE_QUOT);

			url.append(CLOSED_BRACE);
		}
		url.append(AND);
		url.append("upper(ACCOUNT_STATUS) = 'OPEN'");
		url.append(AND);
		url.append("SRCE_SYS_NM = 'MDM'");
		return url.toString();
	}

	private String prepareCpURLForStandAloneAccount(String countryCode, String currencyCode, String categoryURL) {

		StringBuilder filterString = new StringBuilder();

		filterString.append(CASHPOOL_TCODE_NOT_NULL).append(AND).append(COUNTRY_CODE).append(EQUALS).append(SINGLE_QUOT)
				.append(countryCode).append(SINGLE_QUOT).append(AND).append(CURRENCY_CODE).append(EQUALS)
				.append(SINGLE_QUOT).append(currencyCode).append(SINGLE_QUOT).append(AND).append(categoryURL);
		filterString.append(AND);
        filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
        filterString.append(AND);
        filterString.append("SRCE_SYS_NM = 'MDM'");

		return filterString.toString();

	}

    private String prepareCpURLForGreenChannel(String leCode, String currencyCode, String category, String categoryURL,
            Set<String> goldCodeList) {
        StringBuilder filterString = new StringBuilder();
        if (null != leCode) {

            filterString.append(CASHPOOL_TCODE_NOT_NULL).append(AND).append(CURRENCY_CODE).append(EQUALS)
                    .append(SINGLE_QUOT).append(currencyCode).append(SINGLE_QUOT).append(AND);
            filterString.append(GOLD_LE_CODE).append(EQUALS).append(SINGLE_QUOT).append(leCode).append(SINGLE_QUOT);
            if (!SPUTNIK_CATEGORY.equals(category)) {
                filterString.append(AND).append(categoryURL);
            }
            filterString.append(AND);
            filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
            filterString.append(AND);
            filterString.append("SRCE_SYS_NM = 'MDM'");
        } else if (!CollectionUtils.isEmpty(goldCodeList)) {
            filterString.append(CASHPOOL_TCODE_NOT_NULL).append(AND).append(CURRENCY_CODE).append(EQUALS)
                    .append(SINGLE_QUOT).append(currencyCode).append(SINGLE_QUOT).append(AND);
            filterString.append(CASHPOOL_GOLD_CODE).append(IN).append(OPEN_BRACE).append(SINGLE_QUOT)
                    .append(StringUtils.join(goldCodeList, SINGLE_QUOT + COMMA + SINGLE_QUOT)).append(SINGLE_QUOT)
                    .append(CLOSED_BRACE);
            if (!SPUTNIK_CATEGORY.equals(category)) {
                filterString.append(AND).append(categoryURL);
            }
            filterString.append(AND);
            filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
            filterString.append(AND);
            filterString.append("SRCE_SYS_NM = 'MDM'");
        }

        return filterString.toString();

    }

	private String prepareCpURLForRedChannel(AccountRequest acctReq, String category, String categoryURL) {
		StringBuilder filterString = new StringBuilder();

		filterString.append(CASHPOOL_TCODE_NOT_NULL);
		filterString.append(AND);
		filterString.append(CURRENCY_CODE).append(EQUALS).append(SINGLE_QUOT).append(acctReq.getCurrency())
				.append(SINGLE_QUOT);
		filterString.append(AND);
		filterString.append(categoryURL);
		filterString.append(AND);
        filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
        filterString.append(AND);
        filterString.append("SRCE_SYS_NM = 'MDM'");

		return filterString.toString();

	}
	
	private String prepareCpURLForBankFilter(AccountRequest acctReq, String redChannelResult) {
        StringBuilder filterString = new StringBuilder();

        filterString.append(BANK_ACCOUNT_CENTRALIZE_T_CODE).append(IN).append(OPEN_BRACE).append(SINGLE_QUOT)
        .append(redChannelResult).append(SINGLE_QUOT)
        .append(CLOSED_BRACE);
        filterString.append(AND);
        filterString.append(BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID).append(IN).append(OPEN_BRACE).append(SINGLE_QUOT)
        .append(callBankForUltimateParent(acctReq)).append(SINGLE_QUOT)
        .append(CLOSED_BRACE);
        filterString.append(AND);
        filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
        filterString.append(AND);
        filterString.append("SRCE_SYS_NM = 'MDM'");

        return filterString.toString();

    }
	
    private String prepareBankURLForRedChannel(String bankFilter) {
        StringBuilder filterString = new StringBuilder();

        filterString.append(bankFilter);
        filterString.append(AND);
        filterString.append(UPPER_2).append(BANK_BANK_TYPE).append(UPPER_1).append("BANK")
                .append(SINGLE_QUOT).append(CLOSED_BRACE);
        filterString.append(AND);
        filterString.append(UPPER_2).append(BANK_BANK_STATUS).append(UPPER_1).append("Active")
                .append(SINGLE_QUOT).append(CLOSED_BRACE);
        ;

        return filterString.toString();
    }

	private void prepareCategories() {

		List<MyBankLookup> cashPoolCategoryList = lookupService.getLovsByLookupType("CASHPOOL_CATEGORIES",
				"LOOKUP_TYPE", "ASC");
		for (MyBankLookup category : cashPoolCategoryList) {
			if (OIL_GAS_CATEGORY.equals(category.getLookupCode())) {

				categories.put(OIL_GAS_CATEGORY, Arrays.asList(StringUtils.split(category.getDesc(), "|")));
			} else if (CAPITAL_CATEGORY.equals(category.getLookupCode())) {

				categories.put(CAPITAL_CATEGORY, Arrays.asList(StringUtils.split(category.getDesc(), "|")));
			} else if (SPUTNIK_CATEGORY.equals(category.getLookupCode())) {
				categories.put(SPUTNIK_CATEGORY, Arrays.asList(StringUtils.split(category.getDesc(), "|")));
			}

		}

	}

	@Override
	@Transactional
	public AccountRequest checkCashPoolValidity(User user, AccountRequest acctRequest)
			throws InterruptedException, BusinessException {

		String status = null;
		String rejReason = null;
		Instant startTime = Instant.now();
		AccountRequest acctReqResult = null;
		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		Map<String, String> droolsResponse = droolsService.validateCashpoolPossible(user, acctRequest);
		MyBankLogger.logPerf(this, userId, transactionId, "checkCashPoolValidity.DroolsResponse",
		        getTimeDifference(startTime));
		if (droolsResponse.containsKey(ValidationConstants.RESPONSE)
				&& ValidationConstants.STATUS_FAILED.equals(droolsResponse.get(ValidationConstants.DROOLS_STATUS))) {
			status = STANDALONE_PROCESS_CODE;
			rejReason = droolsResponse.get(ValidationConstants.RESPONSE);
			return createAccountRequest(acctRequest.getAcctReqID(), status, rejReason);

		}

		startTime = Instant.now();
		acctReqResult = callChannel(acctRequest, "STAND_ALONE");
		MyBankLogger.logPerf(this, userId, transactionId, "checkCashPoolValidity.STAND_ALONE",
		        getTimeDifference(startTime));
		MyBankLogger.logPerf(this, userId, transactionId, RECORDS, getRecordsCount(acctReqResult.getChannelResponse()));
		if (!(getRecordsCount(acctReqResult.getChannelResponse()) == 0)) {
			startTime = Instant.now();
			acctReqResult = callChannel(acctRequest, "GREEN_CHANNEL");
			MyBankLogger.logPerf(this, userId, transactionId, "checkCashPoolValidity.GREEN_CHANNEL",
			        getTimeDifference(startTime));
			if (getRecordsCount(acctReqResult.getChannelResponse()) == 0) {
				startTime = Instant.now();
				acctReqResult = callChannel(acctRequest, "RED_CHANNEL");
				MyBankLogger.logPerf(this, userId, transactionId, "checkCashPoolValidity.RED_CHANNEL",
				        getTimeDifference(startTime));
				
                if (!(getRecordsCount(acctReqResult.getChannelResponse()) == 0)
                        || (!CollectionUtils.isEmpty(acctReqResult.getCashPoolProcesses()))) {
                    status = "CASHPOOLPROCODE_RED";
                } else {
                    status = STANDALONE_PROCESS_CODE;
                }

			} else {
				status = "CASHPOOLPROCODE_GREEN";

			}

		} else {
			status = STANDALONE_PROCESS_CODE;
		}
		
		if(STANDALONE_PROCESS_CODE.equalsIgnoreCase(status)){
		    rejReason = "No Cashpool tcodes in Category, Country and Currency";
		}

		acctReqResult.setCashPoolProcessCode(status);
		acctReqResult.setCashPoolRejectReason(rejReason);

		return acctReqResult;
	}

	private String getCashPoolTcodeDetailsFromMDM(Set<String> cashPoolTcodeSet,String category) {

		HashMap<String, String> params = new HashMap<>();

		params.put(FILTER_CONST, prepareURLForTcodes(cashPoolTcodeSet,category));
		return mdmService.callMDMDenodo(params, accountCore, HttpMethod.GET, true);

	}

	private String prepareURLForTcodes(Set<String> cashPoolTcodeSet,String category) {

		StringBuilder filterString = new StringBuilder();
		filterString.append("tcode in ").append(OPEN_BRACE);
		filterString.append(SINGLE_QUOT);
		filterString.append(StringUtils.join(cashPoolTcodeSet, SINGLE_QUOT + COMMA + SINGLE_QUOT));
		filterString.append(SINGLE_QUOT);

		filterString.append(CLOSED_BRACE);
        if (SPUTNIK_CATEGORY.equalsIgnoreCase(category)) {
            filterString.append(AND);
            filterString.append(GOLD_LE_CODE).append(IN).append(OPEN_BRACE);
            filterString.append(SINGLE_QUOT);
            filterString.append(StringUtils.join(sputnikHeaderLes, SINGLE_QUOT + COMMA + SINGLE_QUOT));
            filterString.append(SINGLE_QUOT);

            filterString.append(CLOSED_BRACE);
        }
		filterString.append(AND);
		filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
		filterString.append(AND);
		filterString.append("SRCE_SYS_NM = 'MDM'");
		return filterString.toString();

	}

	private String prepareURLForCashPoolTcodes(CashPoolProcess cashPoolProcess) {

		StringBuilder filterString = new StringBuilder();
		filterString.append("cash_pool_gold_code = ").append(SINGLE_QUOT).append(cashPoolProcess.getCashPoolHeaderLe()).append(SINGLE_QUOT);
		filterString.append(AND);
        filterString.append(CURRENCY_CODE).append(EQUALS).append(SINGLE_QUOT).append(cashPoolProcess.getCashPoolCurrency())
                .append(SINGLE_QUOT);
        filterString.append(AND);
        filterString.append(getCategoryStringForURL(cashPoolProcess.getCashPoolCategory()));
		filterString.append(AND);
		filterString.append("upper(ACCOUNT_STATUS) = 'OPEN'");
		filterString.append(AND);
		filterString.append("SRCE_SYS_NM = 'MDM'");
		return filterString.toString();

	}

	@Override
	public AccountRequest callChannel(AccountRequest acctRequest, String channelType) {
		String categoryURL = null;
		String category = null;
		AccountRequest acctReqFromChannel = null;
		if (CollectionUtils.isEmpty(categories)) {
			prepareCategories();

		}
		if (null != acctRequest) {
			category = getCategory(acctRequest.getLeCode(), acctRequest.getBussName());
		}
		categoryURL = getCategoryStringForURL(category);
		if ("STAND_ALONE".equals(channelType)) {
			acctReqFromChannel = callStandAloneAccount(acctRequest,category, categoryURL);
		} else if ("GREEN_CHANNEL".equals(channelType)) {
			acctReqFromChannel = callGreenChannel(acctRequest, category, categoryURL);

		} else if ("RED_CHANNEL".equals(channelType)) {
			acctReqFromChannel = callRedChannel(acctRequest, category, categoryURL);

		}
		if (null != acctReqFromChannel) {
			acctReqFromChannel.setCashPoolCategory(category);
		}
		return acctReqFromChannel;

	}

	private AccountRequest createAccountRequest(Long acctReqId, String status, String rejReason) {

		AccountRequest accReq = new AccountRequest();
		accReq.setAcctReqID(acctReqId);
		accReq.setCashPoolProcessCode(status);
		accReq.setCashPoolRejectReason(rejReason);
		return accReq;
	}

	private AccountRequest callStandAloneAccount(AccountRequest acctRequest, String category,String categoryURL) {

		HashMap<String, String> params = new HashMap<>();
		String result = null;
		params.put(FILTER_CONST,
				prepareCpURLForStandAloneAccount(acctRequest.getCountry(), acctRequest.getCurrency(), categoryURL));
		params.put(SELECT, CASHPOOL_TCODE);
		result = mdmService.callMDMDenodo(params, accountCore, HttpMethod.GET, true);
		result = applyBankFilter(result,acctRequest);
		result = getTcodeDatafromResult(result,category);
		acctRequest.setChannelResponse(result);
		return acctRequest;
	}

	private AccountRequest callGreenChannel(AccountRequest acctRequest, String category, String categoryURL) {

		HashMap<String, String> paramsFirst = new HashMap<>();
		String result = null;

		paramsFirst.put(FILTER_CONST,
				prepareCpURLForGreenChannel(acctRequest.getLeCode(), acctRequest.getCurrency(), category, categoryURL,null));
		paramsFirst.put(SELECT, CASHPOOL_GOLD_CODE);
		Instant startTime = Instant.now();
		result = mdmService.callMDMDenodo(paramsFirst, accountCore, HttpMethod.GET, true);
		MyBankLogger.logInfo(this, "green channel check 1st query : " + (getTimeDifference(startTime)));
		MyBankLogger.logInfo(this, RECORDS + getRecordsCount(result));
		Set<String> cashpoolGoldCodeList = getCashpoolGoldCodeList(result);
		
        if (!CollectionUtils.isEmpty(cashpoolGoldCodeList)) {
            HashMap<String, String> paramsSecond = new HashMap<>();

            paramsSecond.put(FILTER_CONST, prepareCpURLForGreenChannel(null, acctRequest.getCurrency(), category,
                    categoryURL, cashpoolGoldCodeList));
            paramsSecond.put(SELECT, CASHPOOL_TCODE);
            Instant startTimeCashpool = Instant.now();
            result = mdmService.callMDMDenodo(paramsSecond, accountCore, HttpMethod.GET, true);
            MyBankLogger.logInfo(this,
                    "green channel check 2nd query : " + (getTimeDifference(startTimeCashpool)));
            MyBankLogger.logInfo(this, RECORDS + getRecordsCount(result));
        }

        result = applyBankFilter(result,acctRequest);
		result = getTcodeDatafromResult(result,category);
		acctRequest.setChannelResponse(result);
		return acctRequest;
	}

	

    private Set<String> getCashpoolGoldCodeList(String result) {
        Set<String> cashPoolTcodeSet = new HashSet<String>();
        if (getRecordsCount(result) > 0) {

            JSONObject jsonObject = new JSONObject(result);
            JSONArray data = jsonObject.getJSONArray("elements");
            Iterator<Object> itr = data.iterator();
            while (itr.hasNext()) {
                JSONObject obj = (JSONObject) itr.next();
                String cashPoolTcode = StringHelper.getStringValue(obj.get(CASHPOOL_GOLD_CODE));
                if (null != cashPoolTcode) {
                    cashPoolTcodeSet.add(cashPoolTcode);
                }
            }
        }
        return cashPoolTcodeSet;
    }
    
    private Set<String> getBankDataList(String result,String column) {
        Set<String> bankDataSet = new HashSet<String>();
        if (getRecordsCount(result) > 0) {

            JSONObject jsonObject = new JSONObject(result);
            JSONArray data = jsonObject.getJSONArray("elements");
            Iterator<Object> itr = data.iterator();
            while (itr.hasNext()) {
                JSONObject obj = (JSONObject) itr.next();
                String mdmId = StringHelper.getStringValue(obj.get(column));
                if (null != mdmId) {
                    bankDataSet.add(mdmId);
                }
            }
        }
        return bankDataSet;
    }

    private String getTcodeDatafromResult(String result,String category) {
		String cashPoolTcodes = null;
		if (getRecordsCount(result) > 0) {

			Set<String> cashPoolTcodeSet = new HashSet<String>();
			JSONObject jsonObject = new JSONObject(result);
			JSONArray data = jsonObject.getJSONArray("elements");
			Iterator<Object> itr = data.iterator();
			while (itr.hasNext()) {
			    String cashPoolTcode = null;
				JSONObject obj = (JSONObject) itr.next();
				if(obj.has(BANK_ACCOUNT_CENTRALIZE_T_CODE.toLowerCase())){
				    cashPoolTcode = String.valueOf(obj.get(BANK_ACCOUNT_CENTRALIZE_T_CODE.toLowerCase()));
				}
				    
				if (null != cashPoolTcode) {
					cashPoolTcodeSet.add(cashPoolTcode);
				}
			}
			Instant startTime = Instant.now();
			cashPoolTcodes = getCashPoolTcodeDetailsFromMDM(cashPoolTcodeSet,category);
			MyBankLogger.logInfo(this, "get tcode data : " + (getTimeDifference(startTime)));
			MyBankLogger.logInfo(this, RECORDS + getRecordsCount(cashPoolTcodes));
		}
		return cashPoolTcodes;
	}

	private AccountRequest callRedChannel(AccountRequest acctReq, String category, String categoryURL) {
		List<CashPoolProcess> cashPoolList = null;
		HashMap<String, String> params = new HashMap<>();
		String result = null;
		cashPoolList = checkDecisionAvailablity(acctReq);
		acctReq.setCashPoolProcesses(null);
		if (!CollectionUtils.isEmpty(cashPoolList)) {
			if (!StringUtils.isEmpty(cashPoolList.get(0).getCashPoolHeaderLe())) {
				result = getCashPoolGoldIdDetailsFromMDM(cashPoolList.get(0),acctReq);
			}
			acctReq.setCashPoolProcessCode(cashPoolList.get(0).getCashPoolProcessCode());
			acctReq.setCashPoolProcesses(cashPoolList);

		} else {
			params.put(FILTER_CONST, prepareCpURLForRedChannel(acctReq, category, categoryURL));
			params.put(SELECT, CASHPOOL_TCODE);
			Instant startTime = Instant.now();
			result = mdmService.callMDMDenodo(params, accountCore, HttpMethod.GET, true);
			MyBankLogger.logInfo(this, "Red channel check : " + (getTimeDifference(startTime)));
			MyBankLogger.logInfo(this, RECORDS + getRecordsCount(result));
			
			result = applyBankFilter(result,acctReq);

		}
		result = getTcodeDatafromResult(result,category);
		acctReq.setChannelResponse(result);
		return acctReq;

	}
	
	private String applyBankFilter(String result, AccountRequest acctReq) {
	    Set<String> tcodeList = getBankDataList(result, CASHPOOL_TCODE);
        if (!CollectionUtils.isEmpty(tcodeList)) {
            HashMap<String, String> paramsBank = new HashMap<>();
            paramsBank.put(FILTER_CONST, prepareCpURLForBankFilter(acctReq,
                    StringUtils.join(tcodeList, SINGLE_QUOT + COMMA + SINGLE_QUOT)));
            paramsBank.put(SELECT, BANK_ACCOUNT_CENTRALIZE_T_CODE.toLowerCase());
            Instant startTime = Instant.now();
            String resultForBankFilter = mdmService.callMDMDenodo(paramsBank, accountCore, HttpMethod.GET, true);
            MyBankLogger.logInfo(this, "Ultimate parent bank filter check : " + (getTimeDifference(startTime)));
            MyBankLogger.logInfo(this, RECORDS + getRecordsCount(resultForBankFilter));
            return resultForBankFilter;
        }
        return null;
    }

    private String callBankForUltimateParent(AccountRequest acctReq) {
        HashMap<String, String> params = new HashMap<>();
        String result = null;
        params.put(FILTER_CONST, prepareBankURLForRedChannel(UPPER_2.concat(BANK_MDM_ID).concat(UPPER_1)
                .concat(acctReq.getBankId()).concat(SINGLE_QUOT).concat(CLOSED_BRACE)));
        params.put(SELECT, ULTIMATE_PARENT_MDM_ID);
        Instant startTime = Instant.now();
        result = mdmService.callMDMDenodo(params, bankBranch, HttpMethod.GET, true);
        MyBankLogger.logInfo(this, "Getting Ultimate parent MDM ID : " + (getTimeDifference(startTime)));
        MyBankLogger.logInfo(this, RECORDS + getRecordsCount(result));

        Set<String> ultimateParentId = getBankDataList(result, ULTIMATE_PARENT_MDM_ID);

        if (!CollectionUtils.isEmpty(ultimateParentId)) {
            HashMap<String, String> paramsBankId = new HashMap<>();
            String resultParams = null;
            paramsBankId.put(FILTER_CONST,
                    prepareBankURLForRedChannel(ULTIMATE_PARENT_MDM_ID.concat(IN).concat(OPEN_BRACE).concat(SINGLE_QUOT)
                            .concat(StringUtils.join(ultimateParentId, SINGLE_QUOT + COMMA + SINGLE_QUOT))
                            .concat(SINGLE_QUOT).concat(CLOSED_BRACE)));
            paramsBankId.put(SELECT, BANK_MDM_ID.toLowerCase());
            Instant startTimeBankId = Instant.now();
            resultParams = mdmService.callMDMDenodo(paramsBankId, bankBranch, HttpMethod.GET, true);
            MyBankLogger.logInfo(this,
                    "Getting Ultimate parent MDM ID : " + (getTimeDifference(startTimeBankId)));
            MyBankLogger.logInfo(this, RECORDS + getRecordsCount(resultParams));

            Set<String> bankIds = getBankDataList(resultParams, BANK_MDM_ID.toLowerCase());
            if (!CollectionUtils.isEmpty(bankIds)) {
                return StringUtils.join(bankIds, SINGLE_QUOT + COMMA + SINGLE_QUOT);
            }
        }
        return null;

    }

	@Override
	public AccountRequest checkCashPoolDecisionAvailability(AccountRequest acctReq) {
		String category = null;
		String result = null;
		List<CashPoolProcess> cashPoolList = null;
		if (categories.isEmpty()) {
			prepareCategories();
		}
		category = getCategory(acctReq.getLeCode(), acctReq.getBussName());
		acctReq.setCashPoolCategory(category);
		cashPoolList = checkDecisionAvailablity(acctReq);
		if (!CollectionUtils.isEmpty(cashPoolList)) {
			if (!StringUtils.isEmpty(cashPoolList.get(0).getCashPoolHeaderLe())) {
				result = getCashPoolGoldIdDetailsFromMDM(cashPoolList.get(0),acctReq);
			}
			acctReq.setCashPoolProcesses(cashPoolList);

		}
		result = getTcodeDatafromResult(result,category);
		acctReq.setChannelResponse(result);
		return acctReq;
	}

	private List<CashPoolProcess> checkDecisionAvailablity(AccountRequest acctReq) {

		CashPoolProcess cashPoolInput = new CashPoolProcess();

		if (!"ACCTREQTYPE_MODIFY".equals(acctReq.getRequestType())) {
			cashPoolInput.setAcctRequestId(acctReq.getAcctReqID());
		}
		cashPoolInput.setTcodeParticipant(acctReq.gettCode());
		cashPoolInput.setCashPoolCategory(acctReq.getCashPoolCategory());
		cashPoolInput.setCashPoolCurrency(acctReq.getCurrency());
		return requestDao.selectCashPoolProcess(cashPoolInput);
	}

	private String getCashPoolGoldIdDetailsFromMDM(CashPoolProcess cashPoolProcess,AccountRequest acctReq) {

		HashMap<String, String> params = new HashMap<>();

		params.put(FILTER_CONST, prepareURLForCashPoolTcodes(cashPoolProcess));
		params.put(SELECT, CASHPOOL_TCODE);
		String result =  mdmService.callMDMDenodo(params, accountCore, HttpMethod.GET, true);
		
		result = applyBankFilter(result,acctReq);
        
        return result;

	}

	private int getRecordsCount(String result) {
		int count = 0;
		JSONObject jsonObject = null;
		JSONArray data = null;
		if (!"".equals(StringUtils.trimToEmpty(result))) {
			jsonObject = new JSONObject(result);
			data = jsonObject.getJSONArray("elements");
			count = data.length();
		}
		return count;
	}

	@Override
	public MyFundingResponse updateCashpoolProcess(CashPoolProcess cashPoolReq) {
		MyFundingResponse response = new MyFundingResponse();
		MyFundingDetail detail = new MyFundingDetail();
		AccountRequest accRequestOld = new AccountRequest();
        AccountRequest newObject = new AccountRequest();
        User user = new User();
		try {
		    
            Map<String, Object> searchMap = new HashMap<String, Object>();
            searchMap.put("acctReqID", cashPoolReq.getAcctRequestId());
            AccountRequest acctRequest = accountService.findAccount(user, searchMap);
            List<CashPoolProcess> cashPoolProcessesOld = acctRequest.getCashPoolProcesses();
            List<CashPoolProcess> cashPoolProcesses = new ArrayList<CashPoolProcess>();
            List<CashPoolProcess> cashPoolProcessesOldRequried = new ArrayList<CashPoolProcess>();
            
			int updateCount = requestDao.updateCashPoolProcessData(cashPoolReq);
			if (updateCount > 0) {
				response.setMessage(DEAL_SUCCESS);
				response.setStatus(MYBANK_MYFUNDING_SUCCESS);
				detail.setMyBankRequestId(String.valueOf(cashPoolReq.getAcctRequestId()));
				detail.setMyFundingDealId(String.valueOf(cashPoolReq.getMyFundingDealId()));
				response.setDealDetail(detail);
				
                for (CashPoolProcess cashPoolProcess : cashPoolProcessesOld) {
                    cashPoolProcess.setCashPoolRequest(null);
                    cashPoolReq.setMyFundingDealId(cashPoolReq.getMyFundingDealId() == null
                            ? cashPoolProcess.getMyFundingDealId() : cashPoolReq.getMyFundingDealId());
                    cashPoolReq.setCashPoolProcessCode(cashPoolProcess.getCashPoolProcessCode());
                    cashPoolReq.setCashPoolProcessId(cashPoolProcess.getCashPoolProcessId());
                    cashPoolProcessesOldRequried.add(cashPoolProcess);
                }
	            cashPoolReq.setCashPoolRequest(null);
	            cashPoolProcesses.add(cashPoolReq);
	            newObject.setCashPoolProcesses(cashPoolProcesses);
	            accRequestOld.setAcctReqID(cashPoolReq.getAcctRequestId());
	            accRequestOld.setRequestStatus(acctRequest.getRequestStatus());
	            newObject.setAcctReqID(cashPoolReq.getAcctRequestId());
	            newObject.setRequestStatus(acctRequest.getRequestStatus());
	            user.setSso("MYBANK_MYFUNDING_JOB");
	            accRequestOld.setCashPoolProcesses(cashPoolProcessesOldRequried);
	            auditService.createAudit(user, accRequestOld, newObject);
	            
			} else {
				response.setMessage(DEAL_FAILURE);
				response.setStatus(MYBANK_MYFUNDING_FAILURE);
				detail.setMyBankRequestId(String.valueOf(cashPoolReq.getAcctRequestId()));
				detail.setMyFundingDealId(String.valueOf(cashPoolReq.getMyFundingDealId()));
				response.setDealDetail(detail);
			}
			
		} catch (HttpClientErrorException e) {
			MyBankLogger.logError(this, e.getResponseBodyAsString(), e);
			response.setMessage(DEAL_EXCEPTION + ExceptionUtils.getFullStackTrace(e));
			response.setStatus(MYBANK_MYFUNDING_EXCEPTION);
			detail.setMyBankRequestId(String.valueOf(cashPoolReq.getAcctRequestId()));
			detail.setMyFundingDealId(String.valueOf(cashPoolReq.getMyFundingDealId()));
			response.setDealDetail(detail);
		} catch (Exception e) {
            MyBankLogger.logError(this, e.getMessage(), e);
            response.setMessage(DEAL_EXCEPTION + ExceptionUtils.getFullStackTrace(e));
            response.setStatus(MYBANK_MYFUNDING_EXCEPTION);
            detail.setMyBankRequestId(String.valueOf(cashPoolReq.getAcctRequestId()));
            detail.setMyFundingDealId(String.valueOf(cashPoolReq.getMyFundingDealId()));
            response.setDealDetail(detail);
        }

		return response;
	}

	@Override
	public MyFundingResponse triggerMyFunding(MyFundingRequest request) {

		MyFundingResponse response = new MyFundingResponse();
		RestTemplate mdmBankCentralizeTemplate = new RestTemplate();
		MyFundingDetail detail = new MyFundingDetail();
		detail.setMyBankRequestId(request.getMyBankRequestId());
		response.setDealDetail(detail);
		try {

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			// Code to add the user name and pass code
			String auth = myFundingUserId + ":" + myFundingPass;
			byte[] authStringEnc = Base64.getEncoder().encode(auth.getBytes());
			String authHeader = "Basic " + new String(authStringEnc);
			headers.set("Authorization", authHeader);

			HttpEntity<MyFundingRequest> reqEntity = new HttpEntity<MyFundingRequest>(request, headers);

			response = mdmBankCentralizeTemplate.postForObject(myFundingURL, reqEntity, MyFundingResponse.class);
		} catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			response.setStatus(ValidationConstants.MYBANK_MYFUNDING_FAILURE);
			response.setMessage("Error in connecting My Funding Service : " + e.getMessage());
			throw new BusinessException(e);
		}

		return response;

	}

	@Override
	@Async
	public void sendCashpoolNotification(String acctReqID) {
		Map<String, String> tokenMap = new HashMap<String, String>();
		AccountRequest acctReq = null;
		CashPoolProcess cashPoolReq = null;
		String subject = null;
		String requestorFirstName = null;
		String requestorLastName = null;
		String requestorEmailAddress = null;
		JSONObject requestorUserJsonObject = null;
		User user = new User();
		Map<String, Object> searchMap = null;
		searchMap = new HashMap<String, Object>();
		searchMap.put("acctReqID", acctReqID);

		acctReq = accountService.findAccount(user, searchMap);
		cashPoolReq = null != acctReq ? acctReq.getCashPoolProcesses().get(0) : null;

		if (null != cashPoolReq) {

			String acctReqCreateUser = null != acctReq ? acctReq.getCreateUser() : null;
			String requestorUserJson = userProfileService.userLookUp(acctReqCreateUser);

			if (!StringUtils.isEmpty(requestorUserJson)) {
				requestorUserJsonObject = new JSONObject(requestorUserJson);
				if (null != requestorUserJsonObject) {

					requestorEmailAddress = requestorUserJsonObject.getString("emailAddress");
					requestorFirstName = requestorUserJsonObject.getString("firstName");
					requestorLastName = requestorUserJsonObject.getString("lastName");
				}

			}
			if (!"PROD".equalsIgnoreCase(appEnvironment)) {
				requestorEmailAddress = notificationEmail;
			}
			tokenMap.put("dealId", String.valueOf(cashPoolReq.getMyFundingDealId()));
			tokenMap.put("acctReqId", acctReqID);
			tokenMap.put("CashPoolHeaderLe", cashPoolReq.getCashPoolHeaderLe());
			tokenMap.put("status", lookupService.getDisplayName(cashPoolReq.getCashPoolStatusCode()));
			tokenMap.put("comments", cashPoolReq.getCashPoolComments());
			tokenMap.put("requester", requestorLastName + ", " + requestorFirstName);
			tokenMap.put("requesterSSO", acctReqCreateUser);

			subject = "Deal Id:" + cashPoolReq.getMyFundingDealId() + " processing completed";
		}
		try {
			notification.sendHtmlNotification(requestorEmailAddress, subject, "cashPoolStatusEmail.vm", tokenMap);
		} catch (Exception e) {
			MyBankLogger.logError(this, " CashpoolServiceImpl.sendCashpoolNotification - :" + e.getMessage(), e);
		}

	}
	
	private long getTimeDifference(Instant startInstant){
	    return Duration.between(startInstant, Instant.now()).toMillis();
	}
}