package com.ge.treasury.mybank.business.cashpool.service.impl;

import java.util.Map;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.user.User;

public interface DroolsService {

    /**
     * This method will consume account request pojo and provide if the cashpool is possible for given account request.
     * 
     * @param accountRequest
     * @return
     */
    public Map<String,String> validateCashpoolPossible(User user,AccountRequest accountRequest);
}
