package com.ge.treasury.mybank.business.cashpool.service.impl;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingRequest;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingResponse;
import com.ge.treasury.mybank.domain.user.User;

public interface CashpoolService {

    AccountRequest checkCashPoolValidity(User user, AccountRequest acctRequest) throws InterruptedException;

    AccountRequest callChannel(AccountRequest acct, String channelType);
 
    MyFundingResponse updateCashpoolProcess(CashPoolProcess cashPoolReq);
    
    MyFundingResponse triggerMyFunding (MyFundingRequest request);
    
    void sendCashpoolNotification(String accountReqId);
    
    AccountRequest checkCashPoolDecisionAvailability(AccountRequest acctReq);
}
