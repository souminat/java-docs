package com.ge.treasury.mybank.business.bulkapproval.service.impl;

import static com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.bulkapproval.dao.impl.BulkApprovalDao;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadService;
import com.ge.treasury.mybank.business.user.service.impl.UserProfileService;
import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.notification.NotificationUtil;

@Service
public class BulkApprovalServiceImpl implements BulkApprovalService {

	@Autowired
	BulkApprovalDao bulkApprovalDao;
	@Autowired
	AccountRequestService accReqService;
	@Autowired
	FileUploadService fileUploadService;
    @Autowired
    private NotificationUtil notification;
	
    @Autowired
    private UserProfileService userProfileService;
    
	@Value("${mybank.gelib.applicationId}")
	private String applicationId;
	@Value("${mybank.gelib.app.userId}")
	private String defaultUserId;
	@Value("${mybank.gelib.app.password}")
	private String applicationPassword;
	@Value("${mybank.gelib.localDirectory}")
	private String localDirectory;
	@Value("${mybank.notification.supportemail}")
	private String bulkUploadCommonTo;
	 @Value("${app.environment}")
	    private String appEnvironment;
	
	@Override
	public FileUpload getFileUploadDetailsById(Long uploadId)throws DBException {
		return bulkApprovalDao.getFileUploadDetailsById(uploadId);
	}

	@Override
	public List<FileUpload> getApprovalExportData(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException {
		return bulkApprovalDao.getApprovalExportData(bulkApprovalSearch);
	}

	@Override
	public List<FileUpload> getBulkApprovalDetailsBYFilter(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException {
		return bulkApprovalDao.getFileUploadDetailsByFilter(bulkApprovalSearch);
	}

	@Override
	public int insertBulkApprovalRecord(BulkApprovalRequest accReq)throws DBException {
		return bulkApprovalDao.insertBulkApprovalRecord(accReq);
	}

	@Override
	public int updateBulkApprovalStageRecord(BulkApprovalRequest accReq)throws DBException {
		return bulkApprovalDao.updateBulkApprovalStageRecord(accReq);
	}
	
	@Override
	public FileUpload updateFileUploadStatus(FileUpload fileUpload, User user)throws DBException {
		fileUpload.setLastUpdateDate(new Date());
		return bulkApprovalDao.updateFileUploadStatus(fileUpload, user);
	}
	
	@Override
	public FileUpload updateFileUploadRecord(FileUpload fileUpload, User user)throws DBException{
		return bulkApprovalDao.updateFileUploadRecord(fileUpload, user);
	}
	
	@Override
	public FileUpload getFileUploadDetails(Long fileUpldId)throws DBException {
		return bulkApprovalDao.getFileUploadDetails(fileUpldId);
	}
		
	@Override
	public List<BulkApprovalRequest> getFileUploadStagingDetails(BulkApprovalRequest bulkApprovalRequest)throws DBException {
		return bulkApprovalDao.getFileUploadStagingDetails(bulkApprovalRequest);
	}

	
	@Override
	public void insertStageRecords (List<BulkApprovalRequest> recordsList) throws  DBException{
		for (BulkApprovalRequest accReq : recordsList) {
			this.insertBulkApprovalRecord(accReq);
		}
	}
	
	@Override
	public void updateStageRecords(List<BulkApprovalRequest> recordsList, Map<Long, List<String>> errorMap, User user,
			Date today) throws DBException {
	

		for (BulkApprovalRequest accReq : recordsList) {
			String stageStatus = errorMap.containsKey(accReq.getStgId()) ? FILEUPLOADACT_FAILURE
					: FILEUPLOADACT_SUCCESS;
			List<String> errList = errorMap.get(accReq.getStgId());
			String errMessage = null;
			if (!CollectionUtils.isEmpty(errList)) {
				errMessage = StringUtils.join(errList, COMMA);
			}
			accReq.setFailureReason(errMessage);
			accReq.setStatusCode(stageStatus);
			accReq.setLastUpdateUser(user.getSso());
			accReq.setLastUpdateDate(today);
			this.updateBulkApprovalStageRecord(accReq);// Each Record update
		}
		
	}
	
	@Override
	public void processFile(AccountRequest accRequest, String fileType,Map<Long, List<String>> errorMap, User user){
		
	
				if(!errorMap.containsKey(accRequest.getStgId())){
				
					try{
						if(ValidationConstants.ACCT_REQUEST_TYPE_OPEN.equals(accRequest.getRequestType())||ValidationConstants.ACCT_REQUEST_TYPE_ACQUIRED.equals(accRequest.getRequestType()))
						{
					      accRequest.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
						}
						accReqService.createAccountRequest(user, accRequest, true, true);
					}catch(ValidationFailedException e){
						MyBankLogger.logError(this, "BulkApprovalServiceImpl.processFile: " + e.getMessage(), e);
						Errors errList = e.getErrors();
						if(null!=errList){
							List<String> errs = new ArrayList<String> ();
							List<ObjectError> objErroList = errList.getAllErrors();
							for(ObjectError o : objErroList){
								errs.add(BULK_UPLOAD_VALIDATION_ERR +o.getDefaultMessage());
							}
							
							errorMap.put(accRequest.getStgId(), errs);
						}
					}catch(Exception e){
						MyBankLogger.logError(this, "BulkApprovalServiceImpl.processFile: " + e.getMessage(), e);
						List<String> errList = new ArrayList<String>();
						errList.add(BULK_UPLOAD_SYSTEM_ERR +"MDM returned with a System Exception ");
						errorMap.put(accRequest.getStgId(),errList);
					}
					
				}
		        
	}
	@Override
	public void insertSignerStageRecords (List<BulkAccountSigner> recordsList) throws DBException{
		for (BulkAccountSigner bulkAccountSigner : recordsList) {
			this.insertSignersToStaging(bulkAccountSigner);
		}
	}
	
	
	
	@Override
	public void insertSignersToStaging(BulkAccountSigner bulkAccountSigner)
			throws DBException {
		bulkApprovalDao.insertSignersToStaging(bulkAccountSigner);
	
	}
	
	
	@Override
	public void updateSignersToStaging(BulkAccountSigner bulkAccountSigner)
			throws DBException {
		
		bulkApprovalDao.updateSignersToStaging(bulkAccountSigner);
		
	}
	@Override
	public void updateSignersStageRecords(List<BulkAccountSigner> recordsList,Map<Long, List<String>> errorMap, User user,Date today) throws DBException{
		

		for (BulkAccountSigner accReq : recordsList) {
			String stageStatus = errorMap.containsKey(accReq.getStgId()) ? FILEUPLOADACT_FAILURE :  FILEUPLOADACT_SUCCESS;
			List<String> errList = errorMap.get(accReq.getStgId());
			String errMessage = null;
			if(!CollectionUtils.isEmpty(errList)){
				errMessage = StringUtils.join(errList, ",");
			}
			accReq.setFailureReason(errMessage);
			accReq.setStatus(stageStatus);
			accReq.setLastUpdateUser(user.getSso());
			accReq.setLastUpdateDate(today);
			this.updateSignersToStaging(accReq);
		}
		
	}
	
	@Override
	public List<BulkAccountSigner> getSignerStagingDetails(BulkAccountSigner bulkAccountSigner) throws DBException{
		return bulkApprovalDao.getSignerStagingDetails(bulkAccountSigner);
	}

	@Override
	public AccountDocument getMetadataForFile(String fileId) throws SystemException{
		AccountDocument document = new AccountDocument();
			document = fileUploadService.getMetadataForFile(fileId, defaultUserId, applicationId, applicationPassword);
		return document;
	}
	
	@Override
	public void sendFileUploadProcessdNotification(FileUpload fileUpload, User user, int faliedRecords, String event,File goodFile,File errorFile,Exception ex,Object account) {
		Map<String, String> tokenMap = new HashMap<String, String>();
		String toAddress = null;
		String requestorEmailAddress = "";
		
		String requestorSSO = fileUpload.getCreateUser();
		
		String requestorUserJson = userProfileService.userLookUp(requestorSSO);
		
		if(null!=requestorUserJson){
			JSONObject requestorUserJsonObject = new JSONObject(requestorUserJson);
			requestorEmailAddress = requestorUserJsonObject.getString("emailAddress");
		}
		
		if("PROD".equalsIgnoreCase(appEnvironment)){
			toAddress=requestorEmailAddress;
		}
		else{
			toAddress=bulkUploadCommonTo;
		}
		tokenMap.put("fileUpldId", String.valueOf(fileUpload.getFileUpldId()));
		tokenMap.put("fileName", fileUpload.getFileName());
		tokenMap.put("lastUpdateUserSSO", fileUpload.getLastUpdateUser());
		tokenMap.put("lastUpdateUserName", user.getFirstName() + " " + user.getLastName());
		tokenMap.put("totalRecords", String.valueOf(fileUpload.getTotalCount()));
		tokenMap.put("status", event);
		if(account!= null){
			if(account instanceof com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest){
				BulkApprovalRequest record = (BulkApprovalRequest)account;
				tokenMap.put("record", record.toString());
			}else{
				BulkAccountSigner record = (BulkAccountSigner)account;
				tokenMap.put("record", record.toString());
			}
		}else{
			tokenMap.put("record", "--");
		}
		String msg=null;
		if(null!=goodFile && null!=errorFile){
			msg=" has partially accpeted";
		}
		else if((null==goodFile && null!=errorFile)||null!=ex){
			msg=" has failed";
		}
		else{
			msg=UPLOADED_MSG;
		}
		try {
			notification.sendHtmlNotificationWithAttachment(toAddress.toString(), MYBANK_BULK_UPLOAD_FILE + fileUpload.getFileName() + ID + fileUpload.getFileUpldId() +
					msg,
				FILE_UPLOAD_STATUS_TEMPLATE_VM, tokenMap,goodFile,errorFile,ex);
			
		}catch(Exception e){
			MyBankLogger.logError(this, "BulkApprovalServiceImpl.sendFileUploadProcessdNotification: " + e.getMessage(), e);
		}
		
	}

	@Override
	public void sendBulkUploadNotification(FileUpload fileUpload, User user, int faliedRecords, String event) {
		Map<String, String> tokenMap = new HashMap<String, String>();
		StringBuilder toAddress = new StringBuilder();
		String requestorEmailAddress = null;
		String approverEmailAddress = null;
		
		String requestorSSO = fileUpload.getCreateUser();
		String approverSSO = fileUpload.getLastUpdateUser();
		
		String requestorUserJson = userProfileService.userLookUp(requestorSSO);
		
		if(null!=requestorUserJson){
			JSONObject requestorUserJsonObject = new JSONObject(requestorUserJson);
			requestorEmailAddress = requestorUserJsonObject.getString("emailAddress");
		}

		
        
        String approverUserJson = userProfileService.userLookUp(approverSSO);
       
        if(null!=approverUserJson){
			JSONObject approverUserJsonObj = new JSONObject(approverUserJson);
			approverEmailAddress = approverUserJsonObj.getString("emailAddress");
		}
        
        Long successRecords = fileUpload.getAcceptedCount() - faliedRecords;
		tokenMap.put("fileUpldId", String.valueOf(fileUpload.getFileUpldId()));
		tokenMap.put("fileName", fileUpload.getFileName());
		tokenMap.put("lastUpdateUserSSO", fileUpload.getLastUpdateUser());
		tokenMap.put("lastUpdateUserName", user.getFirstName() + " " + user.getLastName());
		tokenMap.put("totalRecords", String.valueOf(fileUpload.getAcceptedCount()));
		tokenMap.put("successRecords", String.valueOf(successRecords));
		tokenMap.put("faliedRecords", String.valueOf(faliedRecords));
		tokenMap.put("status", event);
        if(!"".equals(StringUtils.trimToEmpty(requestorEmailAddress))){
        	toAddress.append(requestorEmailAddress);
        
        }
        else{
        	toAddress.append(bulkUploadCommonTo);
        	MyBankLogger.logDebug(this, "requestor email address not found");
        }
        if(!"".equals(StringUtils.trimToEmpty(approverEmailAddress))){
        	toAddress.append(",").append(approverEmailAddress);
        }
        MyBankLogger.logDebug(this, "to email address is "+toAddress.toString());
		
		try {
			switch (event) {
			case FILEUPLOADACT_APPROVED:
				notification.sendHtmlNotification(toAddress.toString(), MYBANK_BULK_UPLOAD_FILE + fileUpload.getFileName() + ID + fileUpload.getFileUpldId() +
						APPROVED_MSG,
						BULK_UPLOAD_TEMPLATE_VM, tokenMap);
				break;
			case FILEUPLOADACT_REJECTED:
				notification.sendHtmlNotification(toAddress.toString(), MYBANK_BULK_UPLOAD_FILE + fileUpload.getFileName() + ID + fileUpload.getFileUpldId() +
						REJECTED_MSG, BULK_UPLOAD_TEMPLATE_VM, tokenMap);
				break;
			case FILEUPLOADACT_SUCCESS:
				notification.sendHtmlNotification(toAddress.toString(), MYBANK_BULK_UPLOAD_FILE + fileUpload.getFileName() + ID + fileUpload.getFileUpldId() +
						PROCESSING_COMP_MSG + ALL + fileUpload.getAcceptedCount() + PROCESSED_SUCCESS_MSG,
						BULK_UPLOAD_TEMPLATE_VM, tokenMap);
				break;
			case FILEUPLOADACT_FAILURE:
			case FILEUPLOADACT_PARTIAL:
				notification.sendHtmlNotification(toAddress.toString(), MYBANK_BULK_UPLOAD_FILE + fileUpload.getFileName() + ID + fileUpload.getFileUpldId() +
						PROCESSING_COMP_MSG + faliedRecords + OUT_OF + fileUpload.getAcceptedCount() + PROCESSED_FAILED_MSG,
						BULK_UPLOAD_TEMPLATE_VM, tokenMap);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			MyBankLogger.logError(this, "BulkUploadProcessScheduler.run.sendBulkUploadNotification - :" + e.getMessage(), e);
			throw new SystemException("Could not send email, pls try again or contact System Admin " + e);
		}
	}
}
