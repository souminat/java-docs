package com.ge.treasury.mybank.business.bulkapproval.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;

public interface BulkApprovalService {

	public FileUpload getFileUploadDetailsById(Long uploadId)throws DBException;

	public List<FileUpload> getApprovalExportData(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException;

	public List<FileUpload> getBulkApprovalDetailsBYFilter(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException;
	
	public FileUpload updateFileUploadStatus(FileUpload fileUpload, User user)throws DBException;
	
	public FileUpload updateFileUploadRecord(FileUpload fileUpload, User user)throws DBException;

	public int insertBulkApprovalRecord(BulkApprovalRequest accReq)throws DBException;
	
	public int updateBulkApprovalStageRecord(BulkApprovalRequest accReq)throws DBException;
	
	public void updateStageRecords(List<BulkApprovalRequest> recordsList,Map<Long, List<String>> errorMap,User user, Date today) throws DBException;

	public FileUpload getFileUploadDetails(Long fileUpldId)throws DBException;
	
	List<BulkApprovalRequest> getFileUploadStagingDetails(BulkApprovalRequest bulkApprovalRequest)throws DBException;
	
	public void insertStageRecords (List<BulkApprovalRequest> recordsList) throws DBException;
	
	public void processFile(AccountRequest accReq,String fileType,Map<Long, List<String>> errorMap, User user);
	public void insertSignersToStaging(BulkAccountSigner bulkAccountSigner)throws DBException;

	public void insertSignerStageRecords(List<BulkAccountSigner> recordsList)throws DBException;
	
	public void updateSignersToStaging(BulkAccountSigner bulkAccountSigner)throws DBException;
	public void updateSignersStageRecords(List<BulkAccountSigner> recordsList,Map<Long, List<String>> errorMap,User user, Date today)throws DBException;

	List<BulkAccountSigner> getSignerStagingDetails(BulkAccountSigner bulkAccountSigner)throws DBException;
	AccountDocument getMetadataForFile(String fileId)throws SystemException;
	
	void sendBulkUploadNotification(FileUpload fileUpload, User user, int failedRecords, String event);
	
	public void sendFileUploadProcessdNotification(FileUpload fileUpload, User user, int faliedRecords, String event,java.io.File goodFile,java.io.File errorFile,Exception ex,Object account) ;
}
