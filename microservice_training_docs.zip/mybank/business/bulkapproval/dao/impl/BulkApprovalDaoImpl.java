package com.ge.treasury.mybank.business.bulkapproval.dao.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.FileUploadMapper;
import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

@Component
public class BulkApprovalDaoImpl implements BulkApprovalDao {
	
	@Autowired
	private FileUploadMapper fileUploadMapper;

	@Override
	public FileUpload getFileUploadDetailsById(Long uploadId)throws DBException {
		try{
			return fileUploadMapper.getFileUploadById(uploadId);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while fetching file upload details");
			throw new DBException(e);
		}
	}

	@Override
	public List<FileUpload> getApprovalExportData(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException {
		try{
			return fileUploadMapper.getApprovalExportData(bulkApprovalSearch);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while fetching Export details");
			throw new DBException(e);
			
		}
	}

	@Override
	public List<FileUpload> getFileUploadDetailsByFilter(
			BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException {
		try{
		return fileUploadMapper.getFileUploadByFilter(bulkApprovalSearch);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while fetching fileupload details for filter");
			throw new DBException(e);
			
		}
	}


	@Override
	public int insertBulkApprovalRecord(BulkApprovalRequest accReq)throws DBException {
		try{
		return fileUploadMapper.insertBulkApprovalRecord(accReq);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while inserting staging record");
			throw new DBException(e);
			
		}
	}

	@Override
	public FileUpload updateFileUploadStatus(FileUpload fileUpload, User user)throws DBException {
		try{
		fileUpload.setLastUpdateDate(new Date());
		fileUpload.setLastUpdateUser(user.getSso());

		fileUploadMapper.updateFileUploadStatus(fileUpload);

		return fileUpload;
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while updating file upload status");
			throw new DBException(e);
		}
	}
	
	@Override
	public FileUpload updateFileUploadRecord(FileUpload fileUpload, User user){
		try{
			fileUpload.setLastUpdateDate(new Date());
			fileUpload.setLastUpdateUser(user.getSso());
			fileUploadMapper.updateFileUploadRecord(fileUpload);

			return fileUpload;
			}
			catch(Exception e){
				MyBankLogger.logError(this, "Exception while updating file upload status");
				throw new DBException(e);
			}
	}
	
	@Override
	public int updateBulkApprovalStageRecord(BulkApprovalRequest accReq)throws DBException{
		try{
			return fileUploadMapper.updateBulkApprovalStageRecord(accReq);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while updating bulk approval staging records");
			throw new DBException(e);
		}
	}

	@Override
	public FileUpload getFileUploadDetails(Long fileUpldId)throws DBException {
		try{
		return fileUploadMapper.getFileUploadDetails(fileUpldId);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while fetching file upload details");
			throw new DBException(e);
		}
	}
	
	@Override
	public List<BulkApprovalRequest> getFileUploadStagingDetails(BulkApprovalRequest bulkApprovalRequest)throws DBException {
		
		try{
			return fileUploadMapper.getFileUploadStagingDetails(bulkApprovalRequest);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while fetching bulk staging  details");
			throw new DBException(e);
			
		}
	}

	
	@Override
	public int insertSignersToStaging(BulkAccountSigner bulkAccountSigner)throws DBException {
		try{
			return fileUploadMapper.insertSignersToStaging(bulkAccountSigner);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while inserting singer into staging");
			throw new DBException(e);
			
		}
	}

	@Override
	public void updateSignersToStaging(BulkAccountSigner bulkAccountSigner)throws DBException {
		try{
			fileUploadMapper.updateSignersToStaging(bulkAccountSigner);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while updating singer into staging");
			throw new DBException(e);
			
		}
	}

	@Override
	public List<BulkAccountSigner> getSignerStagingDetails(BulkAccountSigner bulkAccountSigner)throws DBException {
		try{
			return fileUploadMapper.getSignerStagingDetails(bulkAccountSigner);
		}
		catch(Exception e){
			MyBankLogger.logError(this, "Exception while fetching singer details");
			throw new DBException(e);
			
		}
	}

}
