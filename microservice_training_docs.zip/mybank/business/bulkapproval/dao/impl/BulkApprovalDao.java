package com.ge.treasury.mybank.business.bulkapproval.dao.impl;

import java.util.List;

import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

public interface BulkApprovalDao {

	
	public FileUpload getFileUploadDetailsById(Long uploadId)throws DBException;

	public List<FileUpload> getApprovalExportData(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException;

	public List<FileUpload> getFileUploadDetailsByFilter(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException;

	public int insertBulkApprovalRecord(BulkApprovalRequest accReq)throws DBException;
	
	public int updateBulkApprovalStageRecord(BulkApprovalRequest accReq)throws DBException;

	public FileUpload updateFileUploadStatus(FileUpload fileUpload, User user)throws DBException;

	public FileUpload updateFileUploadRecord(FileUpload fileUpload, User user)throws DBException;
	
	public FileUpload getFileUploadDetails(Long fileUpldId)throws DBException;
	
	public List<BulkApprovalRequest> getFileUploadStagingDetails(BulkApprovalRequest bulkApprovalRequest)throws DBException;

	public int insertSignersToStaging(BulkAccountSigner bulkAccountSigner)throws DBException;
	
	public void updateSignersToStaging(BulkAccountSigner bulkAccountSigner)throws DBException;

	public List<BulkAccountSigner> getSignerStagingDetails(BulkAccountSigner bulkAccountSigner)throws DBException;

}
