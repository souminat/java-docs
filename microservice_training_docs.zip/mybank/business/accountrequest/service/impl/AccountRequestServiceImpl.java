/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.accountrequest.service.impl;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.AND_STRING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_T_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.FILTER_CONST;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_EQUALS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_2;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.treasury.mybank.business.corems.service.impl.AuditService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMUtil;
import com.ge.treasury.mybank.config.CacheService;
import com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao;
import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.FileUploadParameters;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingRequest;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.ResourceNotFoundException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.notification.NotificationUtil;

/**
 * Contains the implementation of AccountRequestService methods
 * 
 * @author MyBank Dev Team
 * 
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class AccountRequestServiceImpl implements AccountRequestService, ValidationConstants {

	
	@Value("${mdm.ms.buhierarchy}")
	private String buHierarchyUrl;
	
	@Value("${mdm.ms.companyCode}")
	private String companyCodeUrl;
	
	@Autowired
	private AccountRequestDao accountDao;
	@Autowired
	private AuditService auditService;
	@Autowired
	private MDMService mdmService;
	@Autowired
	private NotificationUtil notification;

	@Autowired
	FileUploadService fileUploadService;

	@Autowired
	MyBankLookupService lookupservice;

	@Autowired
	private CacheService cacheService;
	
	@Value("${mybank.gelib.applicationId}")
	private String applicationId;
	@Value("${mybank.gelib.app.userId}")
	private String defaultUserId;
	@Value("${mybank.gelib.app.password}")
	private String applicationPassword;
	@Value("${mybank.gelib.localDirectory}")
	private String localDirectory;
	@Value("${mybank.gelib.defaultFolderId}")
	private String defaultFolderId;
	
	@Value("${mdm.ms.account}")
	private String accountUrl;

	static final String ESB_EMAIL_PROPERTIES = "mybank.esb.email";
	
	private static final String CASH_POOL_TCODE = "cash_pool_tcode";
	private static final String CASH_POOL_GOLD_CODE = "cash_pool_gold_code";
	private static final String ACCT_TITLE = "acct_title";
	private static final String ACCT_OPEN_DATE = "acct_open_date";
	private static final String COMPONENT_CODE = "component_code";
	private static final String COMPANY_CODE = "company_code";
	private static final String CO_CODE_REJECT_REASON = "nonco_code_reason";
	private static final String BU_CODE = "bu_code";
	private static final String ELEMENTS = "elements";

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId
	 *            the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the defaultUserId
	 */
	public String getDefaultUserId() {
		return defaultUserId;
	}

	/**
	 * @param defaultUserId
	 *            the defaultUserId to set
	 */
	public void setDefaultUserId(String defaultUserId) {
		this.defaultUserId = defaultUserId;
	}

	/**
	 * @return the applicationPassword
	 */
	public String getApplicationPassword() {
		return applicationPassword;
	}

	/**
	 * @param applicationPassword
	 *            the applicationPassword to set
	 */
	public void setApplicationPassword(String applicationPassword) {
		this.applicationPassword = applicationPassword;
	}

	/**
	 * @return the localDirectory
	 */
	public String getLocalDirectory() {
		return localDirectory;
	}

	/**
	 * @param localDirectory
	 *            the localDirectory to set
	 */
	public void setLocalDirectory(String localDirectory) {
		this.localDirectory = localDirectory;
	}

	/**
	 * @return the defaultFolderId
	 */
	public String getDefaultFolderId() {
		return defaultFolderId;
	}

	/**
	 * @param defaultFolderId
	 *            the defaultFolderId to set
	 */
	public void setDefaultFolderId(String defaultFolderId) {
		this.defaultFolderId = defaultFolderId;
	}

	/**
	 * Service Method to save an Account Request
	 * 
	 * @throws ResourceNotFoundException
	 * @throws BusinessException
	 * @throws ValidationFailedException
	 */
	@Override
	// @Transactional(propagation = Propagation.REQUIRES_NEW,
	// rollbackFor = SystemException.class)
	public AccountRequest createAccountRequest(User user, AccountRequest accRequest, boolean isbulkUpload,
			boolean isCloseRequest)
			throws ValidationFailedException {

		long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "createAccountRequest " + accRequest);
		
		List<AccountSigner> signers = null;

		if (accRequest.getAcctReqID() != null && !(accRequest.getAcctReqID().toString()).isEmpty()) {
			MyBankLogger.logInfo(this, "Updating Account Request");

			// Call to update
			String statusCode = accRequest.getRequestStatus();
			String requestType = accRequest.getRequestType();
			String accountPurpose=accRequest.getAccountPurpose();
			String bankClassification=accRequest.getBankClassification();
			String coCodeRejectReason=accRequest.getCoCodeRejectReason();

			try {
				accRequest = this.updateAccountRequestComplete(user, accRequest,isbulkUpload);
			} finally {
				accRequest.setRequestStatus(statusCode);
				accRequest.setRequestType(requestType);
				accRequest.setAccountPurpose(accountPurpose);
				accRequest.setBankClassification(bankClassification);
				accRequest.setCoCodeRejectReason(coCodeRejectReason);
			}

			// Checks account Status, once status changed to COMPLETE, need to
			// construct that MDM JSON and call MDM service
			sendtoMDM(accRequest, user);

		} else {
			AccountRequest newAccRequest;
			AccountRequest oldObject = new AccountRequest();

			MyBankLogger.logInfo(this, "Inserting Account Request");
			accRequest.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);

			newAccRequest = accountDao.saveAccountRequest(user, accRequest);

			AccountRequest newObject = newAccRequest;
			// Check and save flags information
			if (newAccRequest.getFlags() != null) {
				insertFlags(newAccRequest, user);
			}

			// Check and insert comments
			if (accRequest.getComments() != null) {
				insertComments(accRequest,user);
			}

			// Check and insert documents
			if (accRequest.getDocuments() != null) {
				insertDocuments(newAccRequest, user);
			}

			// Check and insert signers
			signers = new ArrayList<AccountSigner>();
			insertSigners(accRequest, signers, user);

			// Insert in Audit Microservice
			try {
				setAudit(newObject);
				auditService.createAudit(user, oldObject, newObject);
			} catch (InterruptedException e) {
				MyBankLogger.logError(this, "AccountRequestServiceImpl.createAccountRequest: " + e.getMessage(), e);
				throw new SystemException(e);
			}
		}

		MyBankLogger.logEnd(this, "createAccountRequest ", System.currentTimeMillis() - startTime);
		return accRequest;
	}
	

	private void sendtoMDM(AccountRequest accRequest, User user) throws ValidationFailedException{
		
		List<AccountSigner> signers = null;
		if (accRequest.getRequestStatus().equalsIgnoreCase(ACCOUNT_STATUS_COMPLETED)) {
			if (accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_OPEN)) {
				// Complete OPEN Request --> Send to MDM -
				signers = completeOpenRequest(user, accRequest.getSigners());
			} else if (accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_MODIFY)
					|| accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_ACQUIRED)) {
				// Complete MODIFY Request
				signers = completeModifyRequest(user, accRequest.getSigners());
			} else if (accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_CLOSE)
					||accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_DIVESTED)) {
				// ON Complete CLOSE Request
				signers = completeCloseRequest(user, accRequest.getSigners());
			}
			if (signers != null && !signers.isEmpty()) {
				accRequest.setSigners(signers);
			}

			MyBankLogger.logInfo(this, "Sending Account Request to MDM (for create/update MDM account) -> " + accRequest.toString());

			try {
				mdmService.sendToMDM(accRequest);
			} catch (SystemException | ValidationFailedException e) {
				AccountRequest rollBackAcctReq = new AccountRequest();
				BeanUtils.copyProperties(accRequest, rollBackAcctReq);
				rollBackAcctReq.setRequestStatus(ACCOUNT_STATUS_PEND_BANKCONF);
				rollBackAcctReq.setAcctReqID(accRequest.getAcctReqID());
				accountDao.updateAccountRequest(user, rollBackAcctReq);

				throw e;
			}

		}
	}
	
	private void insertFlags(AccountRequest newAccRequest,User user){
		for (AccountFlag flag : newAccRequest.getFlags()) {
			if (flag.getIsFlagChecked().contains(FLAG_STATUS_CHECKED_NO)) {
				flag.setFlagCmment("");
			}
			flag.setAcctReqID(newAccRequest.getAcctReqID());
			accountDao.saveAccountFlag(user, flag);
		}
	}

	private void insertComments(AccountRequest accRequest,User user){
	
		for (AccountComment comment : accRequest.getComments()) {
			if (comment.getCommentId() == null || StringUtils.isEmpty(comment.getCommentId().toString())) {
				comment.setAcctRequestId(accRequest.getAcctReqID());
				comment.setCommentType(ACCOUNT_COMMENT_TYPE_REQUEST);
				comment.setRole("Treasury Services Admin");
				if(!CollectionUtils.isEmpty(user.getUserProfile().getRoles())){
					comment.setRole(user.getUserProfile().getRoles().get(0).getMyBankRole());
				}
				comment.setSsoId(user.getUserProfile().getSso());
				accountDao.saveComment(user, comment);
			}
		}
	}
	
	private void insertDocuments(AccountRequest accRequest,User user){
		
		String subFolderId = null;

		// check if already exist
		subFolderId = accountDao
				.getSubFolderID(accRequest.getAcctReqID() != null ? accRequest.getAcctReqID() : 0);
			if (subFolderId == null || subFolderId.isEmpty())
				subFolderId = fileUploadService.createSubFolder(accRequest.getAcctReqID().toString(),
						defaultFolderId, defaultUserId, applicationId, applicationPassword);
		for (AccountDocument document : accRequest.getDocuments()) {
			if (document.getDocId() == null || StringUtils.isEmpty(document.getDocId().toString())) {
				FileUploadParameters response = null;
				boolean fromMDM = false;
				
					if ("1".equalsIgnoreCase(document.getFileId().toString())) {
						response = fileUploadService.uploadFile(accRequest.getAcctReqID().toString(),
								document.getDocType(), accRequest.getRequestType(), user.getSso(),
								document.getDocName(), subFolderId, document.getDocURL());
					} else {
						fromMDM = true;
					}

				fileUploadService.deleteLocalFile(new File(document.getDocURL()));

				if (response != null && response.getFileID() != null) {
					document.setDocURL(response.getFileURL());
					document.setFileId(new BigInteger(response.getFileID()));
					document.setFolderId(new BigInteger(subFolderId));
					document.setAcctReqID(accRequest.getAcctReqID());
					document.setIsActive(FLAG_STATUS_YES);
					accountDao.saveAccountDocument(user, document);
				} else if (fromMDM) {
					document.setAcctReqID(accRequest.getAcctReqID());
					document.setIsActive(FLAG_STATUS_YES);
					accountDao.saveAccountDocument(user, document);
				}
			}
		}
	}
	
	private void insertSigners(AccountRequest accRequest,List<AccountSigner> signers,User user){
		if (accRequest.getSigners() != null && !accRequest.getSigners().isEmpty()) {

			for (AccountSigner signer : accRequest.getSigners()) {
				// MODIFY Request or CLOSE REQUEST
				// Copy - Copy Signers with Active flag if there is no End
				// Date, if there is end date then Insert as Inactive...
				if (accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_MODIFY)
						|| accRequest.getRequestType().equalsIgnoreCase(ACCT_REQUEST_TYPE_CLOSE)) {

					 setSigners(signers, signer);
				}
			}

			if (!signers.isEmpty()) {
				accRequest.setSigners(signers);
			}
			// Calls to update signers
			this.updateSigners(user, accRequest, null, false);
		}
	}
	
	private AccountRequest setAudit(AccountRequest newObject) throws DBException, InterruptedException{
		
		if ((StringUtils.isEmpty(newObject.getRouteCode()) && StringUtils.isEmpty(newObject.getRouteCodeType()))
				|| StringUtils.isEmpty(newObject.getBranchMDMID())) {
			newObject.setRouteCode(null);
			newObject.setRouteCodeType(null);
			newObject.setBranchMDMID(null);
		}
		return newObject;
	}
	
	@Override
	public void updateSignersInMDM(User user, AccountRequest accRequest){

		try {
			mdmService.sendToMDM(accRequest);
		} catch (SystemException | ValidationFailedException e) {
			AccountRequest rollBackAcctReq = new AccountRequest();
			BeanUtils.copyProperties(accRequest, rollBackAcctReq);
			rollBackAcctReq.setRequestStatus(ACCOUNT_STATUS_PEND_BANKCONF);
			rollBackAcctReq.setAcctReqID(accRequest.getAcctReqID());
			accountDao.updateAccountRequest(user, rollBackAcctReq);
			MyBankLogger.logError(this, "Error in sending request to MDM : "+e);
		}
	}

	@Override
	public AccountRequest createAccountRequestForBulkUpload(User user, AccountRequest accRequest, String fileType)
			throws ValidationFailedException {
		
		AccountRequest newAccRequest = accountDao.saveAccountRequest(user, accRequest);

		if (newAccRequest.getFlags() != null) {
			for (AccountFlag flag : newAccRequest.getFlags()) {
				if (flag.getIsFlagChecked().contains(FLAG_STATUS_CHECKED_NO)) {
					flag.setFlagCmment("");
				}
				flag.setAcctReqID(newAccRequest.getAcctReqID());
				accountDao.saveAccountFlag(user, flag);
			}
		}

		// Check and insert comments
		if (accRequest.getComments() != null) {
			insertComments(accRequest, user);
		}

		// Add documents
		List<AccountDocument> tempDocList = new ArrayList<AccountDocument>();
		if (!CollectionUtils.isEmpty(accRequest.getDocuments())) {
			insertDocumentsForBulkUpload(accRequest, tempDocList, user);
		}

		// Check and insert signers
		List<AccountSigner> signers = new ArrayList<AccountSigner>();
		if (accRequest.getSigners() != null && !accRequest.getSigners().isEmpty()) {
			insertSigners(accRequest, signers, user);
		}

		return accRequest;
	}

	private void insertDocumentsForBulkUpload(AccountRequest accRequest,List<AccountDocument> tempDocList,User user){
		for (AccountDocument document : accRequest.getDocuments()) {
			String docType = document.getDocType();

			try {

				document.setAcctReqID(accRequest.getAcctReqID());
				document.setIsActive(FLAG_STATUS_YES);
				document.setDocType(docType);
				tempDocList.add(document);

				accountDao.saveAccountDocument(user, document);

			} catch (DBException e) {
				MyBankLogger.logError(this, "Error while saving the document" + e.getMessage(), e);
				throw new SystemException(e);
			}
		}
		// remove old docs add new
		accRequest.getDocuments().clear();
		accRequest.setDocuments(tempDocList);
	}
	
	private void setSigners(List<AccountSigner> signers,AccountSigner signer){
		if (signer.getSignerEndDate() == null) {
			signer.setIsActive(FLAG_STATUS_YES);
			signers.add(signer);
		} else if (signer.getSignerEndDate() != null) {
			signer.setIsActive(FLAG_STATUS_NO);
			signers.add(signer);
		}
	}
	
	/**
	 * Service Method to get Account Requests
	 */
	@Override
	public List<AccountRequest> findAccounts(User user, Map<String, Object> searchMap) {
		return accountDao.findAccounts(user, searchMap);
	}

	/**
	 * Service Method to get Account Requests in Pending Status
	 */
	@Override
	public int getPendingRequests() {
		return accountDao.getPendingRequests();
	}

	/**
	 * Service Method to cancel Account Requests
	 */
	@Override
	// @Transactional(propagation = Propagation.REQUIRED)
	public void cancelAccount(User user, Long acctReqID, String comments) {

		List<AccountFlag> flags = null;
		AccountComment comment = new AccountComment();
		comment.setAcctRequestId(acctReqID);
		comment.setComments(comments);
		comment.setCreateDate(new Date());
		comment.setCreateUser(user.getFirstName() + " " + user.getLastName());
		comment.setRole(user.getUserProfile().getRoles().get(0).getMyBankRole());
		comment.setSsoId(user.getUserProfile().getSso());
		comment.setCommentType(ValidationConstants.ACCOUNT_COMMENT_TYPE_REQUEST);

		AccountRequest accRequestOld = accountDao.searchAccountRequest(acctReqID);

		AccountRequest acctReq = new AccountRequest();
		BeanUtils.copyProperties(accRequestOld, acctReq);
		acctReq.setAcctReqID(acctReqID);
		acctReq.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_CANCELLED);

		accountDao.updateAccountRequest(user, acctReq);

		flags = accountDao.searchAccountFlags(acctReqID);

		// on Cancel Requests reset flags flag_comment empty "" and
		// IS_FLAG_CHECKED to N
		if (!flags.isEmpty()) {
			for (AccountFlag flag : flags) {
				flag.setIsFlagChecked("N");
				flag.setFlagCmment("");
				accountDao.updateAccountFlag(user, flag);
			}
		}

		// Call Audit service on Cancel.
		try {
			auditService.createAudit(user, accRequestOld, acctReq);
		} catch (InterruptedException e) {
			MyBankLogger.logError(this, "AccountRequestServiceImpl.cancelAccountRequest: " + e.getMessage(), e);
			throw new SystemException(e);
		}

		accountDao.saveComment(user, comment);
	}

	/**
	 * Method to find accounts
	 */
	@Override
	public AccountRequest findAccount(User user, Map<String, Object> searchMap) {
		return accountDao.findAccount(user, searchMap);
	}

	@Override
	public AccountRequest findAccountFromMDM(String tcode, String accURL, boolean isDocRequired) throws SystemException {
		AccountRequest accReq = new AccountRequest();

		StringBuilder filter = new StringBuilder();
		HashMap<String, String> params = new HashMap<>();
		String url = accURL;
		
		try{
			filter.append("(");
			filter.append(
					"(UPPER(" + BANK_ACCOUNT_CENTRALIZE_T_CODE + ") = UPPER('" + URLDecoder.decode(tcode, "UTF-8") + "'))");
			filter.append(" and ");
			filter.append("UPPER(" + "ACCOUNT_STATUS" + ") =  UPPER(" + "'OPEN'" + ")");
			filter.append(" and ");
			filter.append(UPPER_2 + "SRCE_SYS_NM" + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + "MDM" + "')");
			filter.append(")");
			params.put(FILTER_CONST, filter.toString());
	
			String response = mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
	
			if (null != response) {
				JSONObject jsonObject = new JSONObject(response);
				JSONArray data = jsonObject.getJSONArray(ELEMENTS);
				if(null==data || data.length() == 0){
					return null;
				}
	
				Iterator<Object> itr = data.iterator();
	
				accReq = setJsonAttributes(accReq,itr,isDocRequired);
			}
		}catch(UnsupportedEncodingException ex){
			throw new BusinessException(ex);
		}

		return accReq;
	}
	
	
	
	
	/*
	 * Service Method to get Last Updated TimeStamp for particular Request
	 * (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService#getLastUpdatedTimeStamp (java.lang.Long)
	 */
	@Override
	public LastUpdatedDetails getLastUpdatedDetails(Long acctReqID) {
		return accountDao.getLastUpdatedDetails(acctReqID);
	}

	/*
	 * Method to Update the Account Request (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService#updateAccountRequestC
	 * (com.ge.treasury.mybank.domain.accountrequest.AccountRequest)
	 */
	@Override
	public AccountRequest updateAccountRequestComplete(User user, AccountRequest accRequest,boolean bulkUpload) {
		long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "updateAccountRequestC " + accRequest);

		AccountRequest currentAccReq = null;
		Map<String, Object> searchMap = null;
		
			String openDate = StringUtils.trimToNull(accRequest.getAcctOpenDate());
			String closeDate= StringUtils.trimToNull(accRequest.getAcctClosedDate());
			String projectName=StringUtils.trim(accRequest.getProjectName());
			
			try {
				// Obtain current information for signers and documents
				searchMap = new HashMap<String, Object>();
				searchMap.put(FileUploadConstants.ACCTREQID, accRequest.getAcctReqID().toString());
				currentAccReq = fetchCurrentAccountRequest(searchMap, bulkUpload, user);
	
            if (StringUtils.length(accRequest.getCashPoolRejectReason()) > 250) {
                MyBankLogger.logInfo(this,
                        "Cashpool reject reason before trimming for request ID ( "
                                .concat(String.valueOf(accRequest.getAcctReqID()))
                                .concat(" ) is :".concat(accRequest.getCashPoolRejectReason())));
                accRequest.setCashPoolRejectReason(
                        StringUtils.substring(StringUtils.defaultString(accRequest.getCashPoolRejectReason()), 0, 250));
            }
				updateOptionalFieldsToEmpty(accRequest);
				
				// Update account request
				accRequest = accountDao.updateAccountRequest(user, accRequest);
				
				if(null != currentAccReq){
					
					// Update flags
					if (accRequest.getFlags() != null) {
						updateFlags(accRequest, user);
					}
		
					// Treasury can attach documents to the request
					if (accRequest.getDocuments() != null) {
						updateDocsForTreasury(accRequest, user);
					}
					if (SPB.equals(currentAccReq.getBankClassification()) && !SPB.equals(accRequest.getBankClassification())) {
						updateSPBDocs(accRequest, user);
					}
		
					// Check and insert signers
					if (accRequest.getSigners() != null && !accRequest.getSigners().isEmpty()) {
						// Calls to update signers
						this.updateSigners(user, accRequest, currentAccReq, false);
					}
		
					// Previous comments cannot be edited but new entries can be added
					if (accRequest.getComments() != null) {
					    addChannelChangeComments(accRequest,currentAccReq);
						insertComments(accRequest, user);
					}
		
					searchMap = new HashMap<String, Object>();
					searchMap.put(FileUploadConstants.ACCTREQID, accRequest.getAcctReqID().toString());
		
					accRequest = accountDao.findAccount(user, searchMap);
		
					createAudit(currentAccReq, accRequest, user);
				}
	
			} catch (DBException ex) {
				MyBankLogger.logError(this, "accountDao.updateAccountRequest: " + ex.getMessage(), ex);
				throw new DBException("Unable to Update account request information, database operation failed."
						+ " For more information please check the log file.");
			}
			//set both open and close dates
			setDates(accRequest, openDate, closeDate);
			
	        
	       	accRequest.setProjectName(projectName);
	        
			MyBankLogger.logEnd(this, "updateAccountRequestC ", System.currentTimeMillis() - startTime);
		
			return accRequest;
	}
	
	private AccountRequest fetchCurrentAccountRequest(Map<String, Object> searchMap,boolean bulkUpload,User user){
		AccountRequest currentAccReq = null;
		 if(!bulkUpload){
         	currentAccReq = accountDao.findAccount(user, searchMap);
         }
         else{
         	currentAccReq = new AccountRequest();
         }
		 return currentAccReq;
	}
	
	private void addChannelChangeComments(AccountRequest accRequest, AccountRequest currentAccReq) {
	    StringBuilder comments = new StringBuilder();
        if(null != accRequest.getCashPoolProcessCode() 
                && (null == currentAccReq.getCashPoolProcessCode()
                || !accRequest.getCashPoolProcessCode().equalsIgnoreCase(currentAccReq.getCashPoolProcessCode()))){
            comments.append(lookupservice.getDisplayName(accRequest.getCashPoolProcessCode()).concat(" Selected."));
        }
        addRejectReason(accRequest,currentAccReq,comments);
        
        if(comments.length() > 0){
            AccountComment comment = new AccountComment();
            comment.setComments(comments.toString());
            accRequest.getComments().add(comment);
        }
    }

    private void addRejectReason(AccountRequest accRequest, AccountRequest currentAccReq, StringBuilder comments) {
        if (null != accRequest.getCashPoolRejectReason() && (null == currentAccReq.getCashPoolRejectReason()
                || !accRequest.getCashPoolRejectReason().equalsIgnoreCase(currentAccReq.getCashPoolRejectReason()))) {
            if (comments.length() > 0) {
                comments.append(" ");
            }
            String[] rejectReason = StringUtils
                    .splitByWholeSeparator(StringUtils.defaultString(accRequest.getCashPoolRejectReason()), " : ");
            if (rejectReason.length > 0) {
                comments.append("Reason: ".concat(rejectReason[rejectReason.length - 1]));
            }
        }
        
    }

    private void updateFlags(AccountRequest accRequest,User user){
		for (AccountFlag flag : accRequest.getFlags()) {
			if (flag.getIsFlagChecked().contains(FLAG_STATUS_CHECKED_NO)) {
				flag.setFlagCmment("");
			}
			flag.setAcctReqID(accRequest.getAcctReqID());
			accountDao.updateAccountFlag(user, flag);
		}
	}
	
	private void updateSPBDocs(AccountRequest accRequest,User user){
		if (accRequest.getDocuments() != null) {
			for (AccountDocument document : accRequest.getDocuments()) {
				if (SPB.equals(document.getDocType()) && document.getDocId() != null) {
					document.setAcctReqID(accRequest.getAcctReqID());
					document.setIsActive(FLAG_STATUS_NO);
					accountDao.updateDocument(user, document);
				}
			}
		}
	}
	
	private void updateDocsForTreasury(AccountRequest accRequest,User user){
		for (AccountDocument document : accRequest.getDocuments()) {
			if (document.getDocId() == null) {
				document.setAcctReqID(accRequest.getAcctReqID());
				document.setIsActive(FLAG_STATUS_YES);
				accountDao.saveAccountDocument(user, document);
			}
		}
	}
	
	private void setDates(AccountRequest accRequest,String openDate,String closeDate){
		if(null!=openDate){
			accRequest.setAcctOpenDate(openDate);
        }
        
        if(null!=closeDate){
        	accRequest.setAcctClosedDate(closeDate);
        }
        
	}
	
    private void updateOptionalFieldsToEmpty(AccountRequest accRequest) {
        if (null == accRequest.getCashpoolLeCode() && null == accRequest.getCashpoolTCode()) {
            accRequest.setCashpoolLeCode("");
            accRequest.setCashpoolTCode("");
        }

        accRequest.setCompanyCode(StringUtils.defaultIfBlank(accRequest.getCompanyCode(), ""));
        accRequest.setComponentCode(StringUtils.defaultIfBlank(accRequest.getComponentCode(), ""));
        accRequest.setIban(StringUtils.defaultIfBlank(accRequest.getIban(), ""));
        accRequest.setMdmTcodeAlternate(StringUtils.defaultIfBlank(accRequest.getMdmTcodeAlternate(), ""));
        accRequest.setAccountPurpose(StringUtils.defaultIfBlank(accRequest.getAccountPurpose(), ""));
        accRequest.setCashPoolRejectReason(StringUtils.defaultIfBlank(accRequest.getCashPoolRejectReason(), ""));

    }

    @Override
	public List<AccountSigner> findSignerById(AccountSigner signer) {
		return accountDao.findSignerById(signer);
	}

	/*
	 * Method to Adding/Removing Signers information (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService#updateSigners
	 * (com.ge.treasury.mybank.domain.accountrequest.AccountRequest)
	 */
	@Override
	public AccountRequest updateSigners(User user, AccountRequest accRequest, AccountRequest currentAccReq,
			boolean onlySigners) {
		long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "updateSigners " + accRequest);

		Map<String, Object> searchMap = null;
		AccountRequest accReqUpdated = null;
		
		try {
				if (currentAccReq == null) {
					// Obtain current information for signers and documents
					searchMap = new HashMap<String, Object>();
					searchMap.put(FileUploadConstants.ACCTREQID, accRequest.getAcctReqID().toString());
	
					currentAccReq = accountDao.findAccount(user, searchMap);
				}
				if(null==currentAccReq){
					
					currentAccReq = findAccountFromMDM(accRequest);
					
				}
	
				if (accRequest.getSigners() != null) {
					for (AccountSigner signer : accRequest.getSigners()) {
						
						checkAndInsertSigners(accRequest, currentAccReq,signer, user);
					}
				}
	
				searchMap = new HashMap<String, Object>();
				searchMap.put(FileUploadConstants.ACCTREQID, accRequest.getAcctReqID().toString());
	
				if(null != user){
					user.setCreateUser(accRequest.getCreateUser());
				}
				accReqUpdated = accountDao.findAccount(user, searchMap);
	
				if (onlySigners) {
					createAudit(currentAccReq, accReqUpdated, user);
				}
	
			} catch (DBException ex) {
				MyBankLogger.logError(this, "updateSigners: " + ex.getMessage(), ex);
				throw new DBException("Unable to Update account signers information, database operation failed."
						+ " For more information please check the log file.");
			}
		
			MyBankLogger.logEnd(this, "updateSigners ", System.currentTimeMillis() - startTime);
		
			return accReqUpdated;
	}

	
	private AccountRequest findAccountFromMDM(AccountRequest accRequest){
		AccountRequest currentAccReq = null;
		try {
			currentAccReq = this.findAccountFromMDM(accRequest.gettCode(),accountUrl,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			MyBankLogger.logError(this, "Exception while getting signer for mdm tcodes only " + e);
		}
		return currentAccReq;
	}
	
	private void checkAndInsertSigners(AccountRequest accRequest, AccountRequest oldAccRequest, AccountSigner signer,User user){
		Map<Long,AccountSigner> oldAcctSignerMap = new HashMap<Long,AccountSigner>();
		if(!CollectionUtils.isEmpty(oldAccRequest.getSigners())) {
			oldAcctSignerMap = oldAccRequest.getSigners().stream()
                    .collect(Collectors.toMap(oldsigner -> oldsigner.getSignerId(), oldsigner -> oldsigner));
		}
		if (signer.getSignerId() == null) {
			// if there i a signature card assigned to signer
			// Add signer
			signer.setAcctReqID(accRequest.getAcctReqID());
			if (signer.getIsActive() == null) {
				if (signer.getSignerEndDate() != null) {
					signer.setIsActive(FLAG_STATUS_NO);
				} else {
					signer.setIsActive(FLAG_STATUS_YES);
				}
			}
			accountDao.saveSigner(user, signer);

		} 
		else if(checkSigners(signer, oldAcctSignerMap)) {
				accountDao.updateAccountSigner(user, signer);
			}
		
	}
	
	private void createAudit(AccountRequest currentAccReq,AccountRequest accReqUpdated,User user){
		try {
			auditService.createAudit(user, currentAccReq, accReqUpdated);
		} catch (InterruptedException e) {
			MyBankLogger.logError(this, "AccountRequestServiceImpl.updateSigners: " + e.getMessage(), e);
			throw new SystemException(e);
		}
	}
	
	
	@Override
	public void updateSigners(User user, List<AccountSigner> signers) {
		long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "updateSigners");

		try {
			if (signers != null) {
				for (AccountSigner signer : signers) {
					accountDao.updateAccountSigner(user, signer);
				}
			}
		} catch (DBException ex) {
			MyBankLogger.logError(this, "updateSigners: " + ex.getMessage(), ex);
			throw new DBException("Unable to Update account signers information, database operation failed."
					+ " For more information please check the log file.");
		}

		MyBankLogger.logEnd(this, "updateSigners ", System.currentTimeMillis() - startTime);
	}

	
	private boolean checkSigners(AccountSigner signer, Map<Long,AccountSigner> oldAcctSignerMap) {
		
		ObjectMapper om = new ObjectMapper();
		try {		
				if(oldAcctSignerMap.containsKey(signer.getSignerId())) {
							
					String oldObjectStr = om.writeValueAsString(oldAcctSignerMap.get(signer.getSignerId()));
					String newObjectStr = om.writeValueAsString(signer);
					
							
					Map<String, String> beforeMap = (Map<String, String>) (om.readValue(
										oldObjectStr, Map.class));
					beforeMap.remove("lastUpdateDate");
					beforeMap.remove("lastUpdateUser");
					beforeMap.remove("createDate");
					beforeMap.remove("createUser");
					
					Map<String, String> afterMap = (Map<String, String>) (om.readValue(
								newObjectStr, Map.class));
					afterMap.remove("lastUpdateDate");
					afterMap.remove("lastUpdateUser");
					afterMap.remove("createDate");
					afterMap.remove("createUser");
			
					return !beforeMap.equals(afterMap);
						
					}
		} catch (IOException ex) {
			MyBankLogger.logError(this, "checkSigners : " + ex.getMessage(), ex);
			throw new SystemException("Exception occured while comparing old and new account signers " + ex);
		}
		
		return false;
		
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService#getCommentsByTcode(java.lang.String)
	 */
	@Override
	public List<AccountComment> getCommentsByTcode(String tCode) {
		return accountDao.getCommentsByTcode(tCode);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService#getRequestIdByTcode(java.lang.String)
	 */
	@Override
	public String getRequestIdByTcode(String tCode) {
		return accountDao.getRequestIdByTcode(tCode);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService#isAccountPendingClose(java.lang.Long,
	 * java.lang.String)
	 */
	@Override
	public Long getPendingCloseOrModifyByTcode(String tCode) {
		return accountDao.getPendingCloseOrModifyByTcode(tCode);
	}

	private List<AccountSigner> completeOpenRequest(User user, List<AccountSigner> signersList) {
		List<AccountSigner> signers = new ArrayList<AccountSigner>();
		for (AccountSigner signer : signersList) {
			// set start date to only Active ones and send only Active signers
			// to MDM
			if (signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_YES)) {
				signer.setSignerStartDate(new Date());
				signers.add(signer);
			}
		}

		if (!signers.isEmpty()) {
			this.updateSigners(user, signers);
		}
		return signers;
	}

	/*
	 * 
	 */
	private List<AccountSigner> completeModifyRequest(User user, List<AccountSigner> signersList) {
		List<AccountSigner> signers = new ArrayList<AccountSigner>();
		List<AccountSigner> modifiedSigners = new ArrayList<AccountSigner>();

		for (AccountSigner signer : signersList) {
			// To respect signers with no changes.
			if (signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_YES) && signer.getSignerStartDate() != null) {
				signers.add(signer);
			}

			// set start date to only new Active ones added which doesnt have
			// start date.
			if (signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_YES) && signer.getSignerStartDate() == null) {
				signer.setSignerStartDate(new Date());
				signers.add(signer);
				modifiedSigners.add(signer);
			}

			// set End DatE for Inactive signers WHICH already doesnt have end
			// date
			// not include new added and then inactivated which doesnt have
			// start date
			if (signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_NO) && signer.getSignerEndDate() == null
					&& signer.getSignerStartDate() != null) {
				// we need to update flag also, on close its simple, when u set
				// end date then make it "N" also
				signer.setIsActive(FLAG_STATUS_NO);
				signer.setSignerEndDate(new Date());
				modifiedSigners.add(signer);
			}

			// ignore the ones which already have end data, and send to MDM both
			// Active and Inactive with end data
			if ((signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_YES)
					|| signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_NO)) && signer.getSignerEndDate() != null) {
				signers.add(signer);
			}
		}

		if (!modifiedSigners.isEmpty()) {
			this.updateSigners(user, modifiedSigners);
		}

		return signers;
	}

	/*
	 * 
	 */
	private List<AccountSigner> completeCloseRequest(User user, List<AccountSigner> signersList) {
		List<AccountSigner> signers = new ArrayList<AccountSigner>();
		List<AccountSigner> modifiedSigners = new ArrayList<AccountSigner>();

		for (AccountSigner signer : signersList) {
			// set END DATE on all Active Signers
			if (signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_YES) && signer.getSignerStartDate() != null) {
				// we need to update flag also, on close its simple, when u set
				// end date then make it "N" also
				signer.setIsActive(FLAG_STATUS_NO);
				signer.setSignerEndDate(new Date());
				modifiedSigners.add(signer);
			}
			// and send to MDM both Active and Inactive with end
			// data
			if ((signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_YES)
					|| signer.getIsActive().equalsIgnoreCase(FLAG_STATUS_NO)) && signer.getSignerEndDate() != null
					&& signer.getSignerStartDate() != null) {
				signers.add(signer);
			}
		}

		if (!modifiedSigners.isEmpty()) {
			this.updateSigners(user, modifiedSigners);
		}

		return signers;
	}

	/*
	 * Method to reserve bank account (non-Javadoc)
	 * 
	 * @see com.ge.treasury.mybank.business.accountrequest.service.impl.
	 * AccountRequestService
	 * #reserveBankAccount(com.ge.treasury.mybank.domain.user.User,
	 * com.ge.treasury.mybank.domain.accountrequest.AccountRequest)
	 */
	@Override
	// @Transactional(propagation = Propagation.REQUIRED)
	public void reserveBankAccount(User user, AccountRequest accRequest) {
		MyBankLogger.logInfo(this, "Reserve Bank Account - Sending Email");
		boolean isEmailError = false;
		try {
			String leAddress = null;
			String branchName = null;
			String branchAddress = null;

			if (!accRequest.getComments().isEmpty()) {
				setCommentsForReserveAccount(accRequest);
			}

			List<String> emailList = new ArrayList<String>();
			String mails = null;

			if (accRequest.getBankId() != null) {
				// Call MDM Bank to get Bank details
				JSONArray details = mdmService.getMDMBankDetails(accRequest);
				for (int i = 0; i < details.length(); ++i) {
					JSONObject elements = details.getJSONObject(i);
					
					emailList = checkBankContact(accRequest, elements, emailList);
				}
				
				
				mails = setEmails(emailList);
			}

			if (accRequest.getLeCode() != null) {
				// Call MDM to get Le details
				JSONArray leDetails = mdmService.getMDMLEDetails(accRequest);
				leAddress = getLeAddress(leDetails);

			}

			if (accRequest.getRouteCode() != null && accRequest.getBankId() != null) {
				// Call MDM to get Branch Details
				JSONArray branchDetails = mdmService.getMDMRouteDetails(accRequest);
				if (null != branchDetails) {
					List<String> branchLocDetails = setBranchLocDetails(branchDetails);
					branchName = branchLocDetails.get(0);
					branchAddress = branchLocDetails.get(1);
				}
			}

			Map<String, String> tokenMap = new HashMap<String, String>();
			tokenMap.put("country", accRequest.getCountry());
			tokenMap.put("accReqId", accRequest.getAcctReqID().toString());

			tokenMap.put("bankName", StringUtils.defaultString(accRequest.getBankName()));
			tokenMap.put("routeCode", StringUtils.defaultString(accRequest.getRouteCode()));
			tokenMap.put("routeCodeType", StringUtils.defaultString(accRequest.getRouteCodeType()));
			tokenMap.put("accountType", StringUtils.defaultString(accRequest.getAccountType()));
			tokenMap.put("currency", StringUtils.defaultString(accRequest.getCurrency()));
			tokenMap.put("tCode", StringUtils.defaultString(accRequest.gettCode()));
			tokenMap.put("accountTitle", StringUtils.defaultString(accRequest.getAccountTitle()));
			tokenMap.put("leName", StringUtils.defaultString(accRequest.getLeName()));
			tokenMap.put("leAddress", StringUtils.defaultString(leAddress));
			tokenMap.put("branchName", StringUtils.defaultString(branchName));
			tokenMap.put("branchAddress", StringUtils.defaultString(branchAddress));
			
			DateFormat df = new SimpleDateFormat(ValidationConstants.DATE_TIME_FORMAT, Locale.ENGLISH);
			String formatedDate = "";
			formatedDate = df.format(new Date());
			tokenMap.put("currDate", formatedDate);
			
			
			isEmailError = sendEmail(accRequest, tokenMap, mails);

		} catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new BusinessException(e);
		} finally {
			sendEmailError(isEmailError);
		}

	}

	private List<String> checkBankContact(AccountRequest accRequest,JSONObject elements,List<String> emailList){
		String email = null;			
				try {
					JSONArray contactArr = elements.getJSONArray("contacts");
					if (null != contactArr) {
						for (int c = 0; c < contactArr.length(); c++) {
							JSONObject jsonUser = contactArr.getJSONObject(c);
							String bankContactType = jsonUser.getString("type_of_contact");
							if ("Bank Contact".equalsIgnoreCase(StringUtils.trimToEmpty(bankContactType))) {
								email = jsonUser.getString("contact_email");
								emailList.add(email);
							}
						}
					}
				} catch (Exception e) {
					MyBankLogger.logError(this, "Contact not present for -> " + accRequest.toString()
							+ " Exception Message ->" + e.getMessage(), e);
				}
		return emailList;
	}
	
	private String setEmails(List<String> emailList){
		String email=null;
		if (null != emailList && !emailList.isEmpty()) {
			StringBuilder sb = new StringBuilder();
			for (String bankEmail : emailList) {
				if (null != bankEmail && !bankEmail.isEmpty()) {
					sb.append(bankEmail);
					sb.append(",");
				}
			}

			if (null != sb.toString() && !sb.toString().isEmpty()) {
				email = sb.toString();
			}
		}
		return email;
	}
	
	private String getLeAddress(JSONArray leDetails){
		String leAddress = null;
		if (null != leDetails) {
			for (int i = 0; i < leDetails.length(); ++i) {

				JSONObject elements = leDetails.getJSONObject(i);
				JSONArray locations = elements.getJSONArray("location_list");
				for (int j = 0; j < locations.length(); j++) {
					JSONObject locElement = locations.getJSONObject(j);
					leAddress = locElement.getString("long_address_desc");
				}
			}
		}
		return leAddress;
	}
	
	private List<String> setBranchLocDetails(JSONArray branchDetails){
		String branchName = null;
		String branchAddress = null;
		List<String> branchLocDetails = new ArrayList<String>();
		if (null != branchDetails) {
			for (int a = 0; a < branchDetails.length(); a++) {
				JSONObject branchElements = branchDetails.getJSONObject(a);
				branchName = branchElements.getString("bank_long_name");
				branchAddress = branchElements.getString("address");
			}
		}
		branchLocDetails.add(branchName);
		branchLocDetails.add(branchAddress);
		return branchLocDetails;
	}
	
	private String setCommentsForReserveAccount(AccountRequest accRequest){
		String comments = null;
		for (int i = 0; i < accRequest.getComments().size(); i++) {
			comments = accRequest.getComments().get(i).getComments();
		}
		return comments;
		
	}
	
	private boolean sendEmail(AccountRequest accRequest,Map<String, String> tokenMap,String mails){
		boolean isEmailError=false;
		String accountNumber = accRequest.getAcctNumber();
		
		if (accountNumber == null || accountNumber.isEmpty()) {
			accountNumber = "";
		}
		if (mails != null) {
			notification.sendHtmlNotification(mails,
					"For Your Action MyBank Request ID:" + accRequest.getAcctReqID().toString()
							+ " -- Account Number:" + accountNumber + " -- Business Account Group Name:"
							+ accRequest.getBussName(),
					"reserveAccountTemplate.vm", tokenMap);
		} else {
			isEmailError = true;
		}
		return isEmailError;
	}
	
	private void sendEmailError(final boolean isEmailError) {
		if (isEmailError) {
			MyBankLogger.logError(this, "Contact Email address is not available for selected bank.");
			throw new BusinessException("Contact Email address is not available for selected bank.");
		}
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	@Override
	public List<AccountRequest> getExportData(Map<String, Object> searchMap) {
		return accountDao.getExportData(searchMap);
	}

	@Override
	public Boolean assignRequestToUser(AccountRequest account) {
		return accountDao.assignRequestToUser(account);
	}

@Override
public AccountRequest findAccountFromMDMforModify(String tcode, String accURL, boolean isDocRequired) throws SystemException{
		
		AccountRequest accReq = new AccountRequest();

		StringBuilder filter = new StringBuilder();
		HashMap<String, String> params = new HashMap<>();
		String url = accURL;
		try{
			filter.append("(");
	
			filter.append(
					UPPER_2 + BANK_ACCOUNT_CENTRALIZE_T_CODE + UPPER_1 + URLDecoder.decode(tcode, "UTF-8") + "')");
	
			filter.append(")");
			
			
		
			params.put(FILTER_CONST, filter.toString());
	
			String response = mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
	
			if (null != response) {
				JSONObject jsonObject = new JSONObject(response);
				JSONArray data = jsonObject.getJSONArray(ELEMENTS);
				if(null==data || data.length() == 0){
					return null;
				}
	
				Iterator<Object> itr = data.iterator();
				
				accReq = setJsonAttributesForModify(accReq, itr, isDocRequired);
				
			
			}
		}catch(UnsupportedEncodingException ex){
			throw new BusinessException(ex);
		}

		return accReq;
		
	} 

	private AccountRequest setJsonAttributesForModify(AccountRequest accReq,Iterator<Object> itr, boolean isDocRequired){
		try{
			while (itr.hasNext()) {
				JSONObject obj = (JSONObject) itr.next();
				accReq.settCode(StringHelper.getStringValue(obj.get("tcode")));
				accReq.setBuCode(StringHelper.getStringValue(obj.get(BU_CODE)));
				accReq.setBussName(StringHelper.getStringValue(obj.get("business_name")));
				accReq.setSubBusName(StringHelper.getStringValue(obj.get("sub_business_name")));
				accReq.setLeCode(StringHelper.getStringValue(obj.get("gold_le_code")));
				accReq.setLeVersion(StringHelper.getStringValue(obj.getInt("le_version_number")));
				accReq.setLeName(StringHelper.getStringValue(obj.get("gold_le_name")));
				
				accReq.setRequestStatus(StringHelper.getStringValue(obj.get("account_status")));
				
				accReq.setCountry(StringHelper.getStringValue(obj.get("country_code")));
				accReq.setCountryName("");
				accReq.setCurrency(StringHelper.getStringValue(obj.get("currency_code")));
				accReq.setCurrencyName("");
				accReq.setBankId(StringHelper.getStringValue(obj.get("bank_mdm_id")));
				accReq.setBankName(StringHelper.getStringValue(obj.get("bank_name")));
				
				
				accReq.setCashpoolTCode("null".equalsIgnoreCase(String.valueOf(obj.get(CASH_POOL_TCODE))) ? "" : String.valueOf(obj.get(CASH_POOL_TCODE)));
				
				accReq.setCashpoolLeCode("null".equalsIgnoreCase(String.valueOf(obj.get(CASH_POOL_GOLD_CODE))) ? "" : String.valueOf(obj.get(CASH_POOL_GOLD_CODE)));
				
				accReq.setRouteCode(StringHelper.getStringValue(obj.get("rte_code")));
				accReq.setRouteCodeType(StringHelper.getStringValue(obj.get("rte_code_type")));
				accReq.setBranchMDMID(StringHelper.getStringValue(obj.get("branch_mdm_id")));
				accReq.setAccountType(StringHelper.getStringValue(obj.get("acct_type")));
				
				accReq.setAccountTitle("null".equalsIgnoreCase(String.valueOf(obj.get(ACCT_TITLE))) ? "" : String.valueOf(obj.get(ACCT_TITLE)));
				accReq.setAcctNumber(StringHelper.getStringValue(obj.get("natl_bank_acct_nbr")));
				
				accReq.setIban("null".equalsIgnoreCase(String.valueOf(obj.get("iban"))) ? "" : String.valueOf(obj.get("iban")));
				accReq.setIsBankAcctReserved("Y");

				DateFormat df = new SimpleDateFormat(ValidationConstants.MDMDATE_FORMAT, Locale.ENGLISH);
				accReq.setCreateDate(obj.get(ACCT_OPEN_DATE).equals(null)?null:(Date) df.parse(obj.getString(ACCT_OPEN_DATE)));
				
				
				
				accReq.setComponentCode("null".equalsIgnoreCase(String.valueOf(obj.get(COMPONENT_CODE))) ? "" : String.valueOf(obj.get(COMPONENT_CODE)));
				accReq.setMdmTcodeAlternate("");
				accReq.setCompanyCode("null".equalsIgnoreCase(String.valueOf(obj.get(COMPANY_CODE))) ? "" : String.valueOf(obj.get(COMPANY_CODE)));
				
				accReq.setMeCode(StringHelper.getStringValue(obj.get("me_code")));
				
				accReq.setAccountPurpose("null".equalsIgnoreCase(String.valueOf(obj.get("acct_purp"))) ? "" : String.valueOf(obj.get("acct_purp")));
				accReq.setAcctOpenDate("null".equalsIgnoreCase(String.valueOf(obj.get(ACCT_OPEN_DATE))) ? "" : String.valueOf(obj.get(ACCT_OPEN_DATE)));
				
				if(checkNestedAttributes("signers", obj, true)){
				// fetch signers
				JSONArray signerDataArr = obj.getJSONArray("signers");
					Iterator<Object> signerItr = signerDataArr.iterator();
					List<AccountSigner> signerList = new ArrayList<AccountSigner>();
					signerList = setSignerList(signerItr, df, signerList);
					accReq.setSigners(signerList);
				}
				// fetch Documents
				if (checkNestedAttributes("docs", obj, isDocRequired)) {
					JSONArray docDataArr = obj.getJSONArray("docs");
					Iterator<Object> docItr = docDataArr.iterator();
					List<AccountDocument> docList = new ArrayList<AccountDocument>();
					docList = setDocList(docItr, docList);
					accReq.setDocuments(docList);
				}
				
				
				
				accReq.setBankClassification(this.lookupservice.getLookupCode(obj.getString("network_type")));
				
				accReq.setProjectName("null".equalsIgnoreCase(String.valueOf(obj.get("project_name")))?"" : String.valueOf(obj.get("project_name")));
				accReq.setCashPoolRejectReason(StringHelper.getStringValue(obj.get("cashpool_reject_reason")));
				accReq.setCoCodeRejectReason("null".equalsIgnoreCase(String.valueOf(obj.get(COMPANY_CODE))) ? String.valueOf(obj.get(CO_CODE_REJECT_REASON)) : "");
			}
				
				
		}catch(JSONException | ParseException ex){
			throw new BusinessException(ex);
		}
		
		return accReq;
	}
	
	private AccountRequest setJsonAttributes(AccountRequest accReq,Iterator<Object> itr, boolean isDocRequired){
		try{
			while (itr.hasNext()) {
				JSONObject obj = (JSONObject) itr.next();
				accReq.settCode(StringHelper.getStringValue(obj.get("tcode")));
				accReq.setBuCode(StringHelper.getStringValue(obj.get(BU_CODE)));
				accReq.setBussName(StringHelper.getStringValue(obj.get("business_name")));
				accReq.setSubBusName(StringHelper.getStringValue(obj.get("sub_business_name")));
				accReq.setLeCode(StringHelper.getStringValue(obj.get("gold_le_code")));
				accReq.setLeVersion(StringHelper.getStringValue(obj.getInt("le_version_number")));
				accReq.setLeName(StringHelper.getStringValue(obj.get("gold_le_name")));
				
				accReq.setRequestStatus(StringHelper.getStringValue(obj.get("account_status")));
	
				accReq.setCountry(StringHelper.getStringValue(obj.get("country_code")));
				accReq.setCountryName("");
				accReq.setCurrency(StringHelper.getStringValue(obj.get("currency_code")));
				accReq.setCurrencyName("");
				accReq.setBankId(StringHelper.getStringValue(obj.get("bank_mdm_id")));
				accReq.setBankName(StringHelper.getStringValue(obj.get("bank_name")));
				accReq.setCashpoolTCode(StringHelper.getStringValue(obj.get(CASH_POOL_TCODE)));
				accReq.setCashpoolLeCode(StringHelper.getStringValue(obj.get(CASH_POOL_GOLD_CODE)));
				accReq.setRouteCode(StringHelper.getStringValue(obj.get("rte_code")));
				accReq.setRouteCodeType(StringHelper.getStringValue(obj.get("rte_code_type")));
				accReq.setBranchMDMID(StringHelper.getStringValue(obj.get("branch_mdm_id")));
				accReq.setAccountType(StringHelper.getStringValue(obj.get("acct_type")));
				accReq.setAccountTitle(StringHelper.getStringValue(obj.get(ACCT_TITLE)));
				accReq.setAcctNumber(StringHelper.getStringValue(obj.get("natl_bank_acct_nbr")));
				accReq.setIban(StringHelper.getStringValue(obj.get("iban")));
				accReq.setIsBankAcctReserved("Y");
	
				DateFormat df = new SimpleDateFormat(ValidationConstants.MDMDATE_FORMAT, Locale.ENGLISH);
				//set createDate to null if acct_open_date is null
				accReq.setCreateDate(obj.get(ACCT_OPEN_DATE).equals(null)?null:(Date) df.parse(obj.getString(ACCT_OPEN_DATE)));
				accReq.setComponentCode(StringHelper.getStringValue(obj.get(COMPONENT_CODE)));
				accReq.setMdmTcodeAlternate("");
				accReq.setCompanyCode(StringHelper.getStringValue(obj.get(COMPANY_CODE)));
				accReq.setMeCode(StringHelper.getStringValue(obj.get("me_code")));
				accReq.setAccountPurpose(StringHelper.getStringValue(obj.get("acct_purp")));
				accReq.setAcctOpenDate(StringHelper.getStringValue(obj.get(ACCT_OPEN_DATE)));
	
				// fetch signers
				if(checkNestedAttributes("signers", obj, true)) {
					JSONArray signerDataArr = obj.getJSONArray("signers");
					Iterator<Object> signerItr = signerDataArr.iterator();
					List<AccountSigner> signerList = new ArrayList<AccountSigner>();
					signerList = setSignerList(signerItr, df, signerList);
					accReq.setSigners(signerList);
				}
				
				// fetch Documents
				if(checkNestedAttributes("docs", obj, isDocRequired)){
					JSONArray docDataArr = obj.getJSONArray("docs");
					Iterator<Object> docItr = docDataArr.iterator();
					List<AccountDocument> docList = new ArrayList<AccountDocument>();
					docList = setDocList(docItr, docList);
					accReq.setDocuments(docList);
				}
				accReq.setBankClassification(this.lookupservice.getLookupCode(obj.getString("network_type")));
				
				accReq.setProjectName("null".equalsIgnoreCase(String.valueOf(obj.get("project_name")))?"" : String.valueOf(obj.get("project_name")));
				accReq.setCashPoolRejectReason(StringHelper.getStringValue(obj.get("cashpool_reject_reason")));
				accReq.setCoCodeRejectReason("null".equalsIgnoreCase(String.valueOf(obj.get(COMPANY_CODE))) ? String.valueOf(obj.get(CO_CODE_REJECT_REASON)) : "");
			}
		}catch(JSONException | ParseException ex){
			throw new BusinessException(ex);
		}
		
		return accReq;
	}

	private List<AccountSigner> setSignerList(Iterator<Object> signerItr,DateFormat df, List<AccountSigner> signerList){
		while (signerItr.hasNext()) {
			AccountSigner ac = new AccountSigner();
			JSONObject signer_obj = (JSONObject) signerItr.next();
			String signerType = StringHelper.getStringValue(signer_obj.get("sgntry_type"));
			
			try {
				if(null!=StringUtils.trimToNull(signerType)){
					//set signer start and end dates
					ac = setSignerDates(ac, signer_obj, df);
					
					ac.setSignerName(StringHelper.getStringValue(signer_obj.get("sgntry_name")));
					ac.setSignerType(this.lookupservice.getLookupCode(signerType));
					ac.setSsoId(StringHelper.getStringValue(signer_obj.get("sgntry_sso")));
					ac.setFolderId(signer_obj.getBigInteger("sgntry_foldr_id"));
					ac.setFileId(signer_obj.getBigInteger("sgntry_file_id"));
					ac.setDocName(signer_obj.getString("sgntry_doc_name"));
					ac.setDocURL(signer_obj.getString("sgntry_doc_url"));
					signerList.add(ac);
				}
			} catch (DBException | JSONException | ParseException e) {
				throw new BusinessException(e);
			}
		}
			return signerList;
	}

	private AccountSigner setSignerDates(AccountSigner ac,JSONObject signer_obj,DateFormat df) throws JSONException, ParseException{
		if (null!= StringHelper.getStringValue(signer_obj.get("sgntry_end_date"))) {
			ac.setSignerEndDate(df.parse(StringHelper.getStringValue(signer_obj.get("sgntry_end_date"))));
		}
		if(null!= StringHelper.getStringValue(signer_obj.get("sgntry_start_date"))){
			ac.setSignerStartDate(df.parse(StringHelper.getStringValue(signer_obj.get("sgntry_start_date"))));
		}
		return ac;
		
	}
	
	private List<AccountDocument> setDocList(Iterator<Object> docItr, List<AccountDocument> docList){
		while (docItr.hasNext()) {
			JSONObject doc_obj = (JSONObject) docItr.next();
			AccountDocument ad = new AccountDocument ();
			ad.setDocName(StringHelper.getStringValue(doc_obj.get("doc_name")));
			ad.setDocURL(StringHelper.getStringValue(doc_obj.get("doc_url")));
			if(null!= StringHelper.getStringValue(doc_obj.get("file_id"))){
				ad.setFileId(BigInteger.valueOf(Long.valueOf(String.valueOf(doc_obj.get("file_id")))));
			}
			if(null!= StringHelper.getStringValue(doc_obj.get("foldr_id"))){
				ad.setFolderId(BigInteger.valueOf(Long.valueOf(String.valueOf(doc_obj.get("foldr_id")))));
			}
			ad.setDocType(StringHelper.getStringValue(doc_obj.get("doc_type_name")));
			if(null != ad.getFileId()){
			    docList.add(ad);
			}
		}
			return docList;
	}
	
    @Override
	public BulkApprovalRequest createApprovalReq ( AccountRequest source, BulkApprovalRequest target) {
	
    if(null != source && ("Closed".equalsIgnoreCase(source.getRequestStatus()) && !"Open".equalsIgnoreCase(target.getAccountStatus()))) {
    	source = null;
    }	
    	
	if(null == source){
	    return target;
	}
	target.setAccountStatus((StringUtils.trimToNull(target.getAccountStatus()) == null) ? source.getAccountStatus() : target.getAccountStatus());
	target.setAccountType((StringUtils.trimToNull(target.getAccountType()) == null) ? source.getAccountType() : target.getAccountType());
	target.setAccountNumber((StringUtils.trimToNull(target.getAccountNumber()) == null) ? source.getAcctNumber() : target.getAccountNumber());
	target.setIban((StringUtils.trimToNull(target.getIban()) == null) ? source.getIban() : ("null".equalsIgnoreCase(target.getIban())?"":target.getIban()));
	target.setLeCode((StringUtils.trimToNull(target.getLeCode()) == null) ? source.getLeCode() : target.getLeCode());
	target.setCountry((StringUtils.trimToNull(target.getCountry()) == null) ? source.getCountry() : target.getCountry());
	target.setCurrency((StringUtils.trimToNull(target.getCurrency()) == null) ? source.getCurrency() : target.getCurrency());
	target.setBankId((StringUtils.trimToNull(target.getBankId()) == null) ? source.getBankId() : target.getBankId());
	target.setRouteCode((StringUtils.trimToNull(target.getRouteCode()) == null) ? source.getRouteCode() : target.getRouteCode());
	target.setRouteCodeType((StringUtils.trimToNull(target.getRouteCodeType()) == null) ? source.getRouteCodeType() : target.getRouteCodeType());
	target.setBranchID((StringUtils.trimToNull(target.getBranchID()) == null) ? source.getBranchMDMID() : target.getBranchID());
	target.setBankClassification((StringUtils.trimToNull(target.getBankClassification()) == null) ? MDMUtil.fetchNetworkTypeDesc(source.getBankClassification()) : target.getBankClassification());
	target.setCashpoolTCode((StringUtils.trimToNull(target.getCashpoolTCode()) == null) ? source.getCashpoolTCode() : ("null".equalsIgnoreCase(target.getCashpoolTCode())?"":target.getCashpoolTCode()));
	target.setAccountTitle((StringUtils.trimToNull(target.getAccountTitle()) == null) ? source.getAccountTitle() : ("null".equalsIgnoreCase(target.getAccountTitle())?"":target.getAccountTitle()));
	target.setCompanyCode((StringUtils.trimToNull(target.getCompanyCode()) == null) ? source.getCompanyCode() : ("null".equalsIgnoreCase(target.getCompanyCode())?"":target.getCompanyCode()));
	target.setMe((StringUtils.trimToNull(target.getMe()) == null) ? source.getMeCode() : target.getMe());
	target.setAccountPurpose((StringUtils.trimToNull(target.getAccountPurpose()) == null) ? source.getAccountPurpose() : ("null".equalsIgnoreCase(target.getAccountPurpose())?"":target.getAccountPurpose()));
	target.setComponentCode((StringUtils.trimToNull(target.getComponentCode()) == null) ? source.getComponentCode() : ("null".equalsIgnoreCase(target.getComponentCode())?"":target.getComponentCode()));
	target.setProjectName((StringUtils.trimToNull(target.getProjectName()) == null) ? source.getProjectName() : ("null".equalsIgnoreCase(target.getProjectName())?"":target.getProjectName()));
	if(StringUtils.isEmpty(target.getCompanyCode())) {
		target.setCoCodeRejectReason((StringUtils.trimToNull(target.getCoCodeRejectReason()) == null) ? lookupservice.getDisplayName(source.getCoCodeRejectReason()) : ("null".equalsIgnoreCase(target.getCoCodeRejectReason())?"":target.getCoCodeRejectReason()));

	}else {
		target.setCoCodeRejectReason("");
	}
	return target;
}
    
    @Override
    public CashPoolProcess saveCashPoolProcess (MyFundingRequest source, User user) {

    	try {
    		CashPoolProcess cp =  this.accountDao.saveCashPoolProcess(user, getEntityForCP(source));
    		return cp;
    	} catch (Exception e) {
    		MyBankLogger.logError(this, "saveCashPoolProcess DAO: " + e.getMessage(), e);
    		throw new BusinessException("Error in creating a Cashpool DB Request : "  +e);
    	}
    	
    }
    
    private CashPoolProcess getEntityForCP (MyFundingRequest source) throws IOException {
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonInString = mapper.writeValueAsString(source);
    	
    	CashPoolProcess request = new CashPoolProcess () ;
    	request.setAcctRequestId(Long.valueOf(source.getMyBankRequestId()));
    	request.setTcodeParticipant(source.gettCode());
    	request.setCashPoolProcessCode(CASHPOOLPROCODE_RED);
    	request.setCashPoolStatusCode(CASHPOOLSTATCODE_SUBMITTED);
    	request.setMyFundingDealId(null);
    	request.setCashPoolRequest(jsonInString);
    	request.setCashPoolCurrency(source.gettCodeCurrency());
    	request.setCashPoolLeCode(source.getLeId());
    	request.setCashPoolCategory(source.getCashPoolCategory());
    	return request;
    }
    
       	
    	
    
    @Override
    public void updateCashPoolProcess(CashPoolProcess cashPoolProcess, User user) {
    	
    	try {
    	    AccountRequest accRequestOld = new AccountRequest();
    	    AccountRequest newObject = new AccountRequest();
    		cashPoolProcess.setLastUpdateDate(new Date());
    		cashPoolProcess.setLastUpdateUser(user.getSso());
    		this.accountDao.updateCashPoolProcessData(cashPoolProcess);
    		
    		AccountRequest accountRequest = this.accountDao.searchAccountRequest(cashPoolProcess.getAcctRequestId());
    		newObject.setRequestStatus(accountRequest.getRequestStatus());
    		accRequestOld.setRequestStatus(accountRequest.getRequestStatus());
    		List<CashPoolProcess> cashPoolProcesses = new ArrayList<CashPoolProcess>();
    		cashPoolProcess.setCashPoolRequest(null);
    		cashPoolProcesses.add(cashPoolProcess);
    		newObject.setCashPoolProcesses(cashPoolProcesses);
    		accRequestOld.setAcctReqID(cashPoolProcess.getAcctRequestId());
    		newObject.setAcctReqID(cashPoolProcess.getAcctRequestId());
    		auditService.createAudit(user, accRequestOld, newObject);
    	} catch (Exception e) {
    		MyBankLogger.logError(this, "saveCashPoolProcess DAO: " + e.getMessage(), e);
    		throw new BusinessException("Error in updating cashPool data : "+e);
    	}
    	
    	
    }
    
    @Override
    public void searchCashPoolProcessByRequestID (String requestId){
    	try {
    		List<CashPoolProcess> list = this.accountDao.searchCashPoolProcessByRequestID(requestId);
    		if(!CollectionUtils.isEmpty(list)){
    			throw new BusinessException ("Open MyFunding request exists for this Request ID : " + requestId);
    		}
    	} catch (Exception e) {
    		MyBankLogger.logError(this, "searchCashPoolProcessByRequestID :  " + e.getMessage(), e);
    		throw new BusinessException("Error in Processing MyFunding Request : " + e.getMessage());
    	}
    	
    }

    @Override
    public List<CashPoolProcess> selectCashPoolProcess(CashPoolProcess cashPoolReq) {
        try {
            return this.accountDao.selectCashPoolProcess(cashPoolReq);
        } catch (Exception e) {
            MyBankLogger.logError(this, "selectCashPoolProcess :  " + e.getMessage(), e);
            throw new BusinessException("Error in Fetching Deal ID Information : " + e.getMessage());
        }
    }

	@Override
	public Map<String, String> getLovLookUpValues() {
		List<MyBankLookup> lookUpvalues =  cacheService.fetchLookUpData();
        Map<String, String> lovLookupValues = new HashMap<String, String>();
        if (!CollectionUtils.isEmpty(lookUpvalues)) {
            lovLookupValues = lookUpvalues.stream()
                    .collect(Collectors.toMap(MyBankLookup::getLookupCode, MyBankLookup::getDispname));
        }
        return lovLookupValues;
	}
	
	private boolean checkNestedAttributes(String attribute, JSONObject obj,boolean isAttributeRequired) {
		if(isAttributeRequired && obj.has(attribute) && !("null".equalsIgnoreCase(String.valueOf(obj.get(attribute))))) {
			return true;
		}
		return false;
		
	}

    @Override
    public Long getLastUpdatedPlatformInstance(String tCode) {
        return accountDao.getLastUpdatedPlatformInstance(tCode);
    }

    @Override
    public List<Map<String, String>> getBusSubbus(String code) {
        return accountDao.getBusSubbus(code);
    }

    @Override
    public List<Map<String, String>> getBuCodes(String code) {
        return accountDao.getBuCodes(code);
    }

}
