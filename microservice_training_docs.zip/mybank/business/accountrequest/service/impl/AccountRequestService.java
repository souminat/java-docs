/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.accountrequest.service.impl;

import java.util.List;
import java.util.Map;


import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingRequest;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;

/**
 * Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface AccountRequestService {

    /**
     * Method to save an Account Request
     * 
     * @param accRequest
     * @return
     * @throws DBException
     * @throws ResourceNotFoundException
     * @throws BusinessException
     * @throws SystemException
     */
    public AccountRequest createAccountRequest(User user,
            AccountRequest accRequest, boolean isModifyRequest,
            boolean isCloseRequest) throws ValidationFailedException;
    
    
    
    /**
     * Method to save an Account Request for Bulk Upload
     * 
     * @param accRequest
     * @return
     * @throws DBException
     * @throws ResourceNotFoundException
     * @throws BusinessException
     * @throws SystemException
     */
    public AccountRequest createAccountRequestForBulkUpload(User user,
            AccountRequest accRequest, String fileType) throws ValidationFailedException;

    /**
     * Method to obtain all the Account Requests
     * 
     * @param user
     * @param searchMap
     * @param start
     * @param limit
     * @param direction
     * @param orderBy
     * @param maxTradesSize
     * @return
     * @throws DBException
     */
    public List<AccountRequest> findAccounts(User user,
            Map<String, Object> searchMap);
    
    
    public int getPendingRequests();

    /**
     * Method to cancel the Account Requests
     * 
     * @param user
     * @param acctReqID
     * @throws DBException
     */
    public void cancelAccount(User user, Long acctReqID, String comment);

    /**
     * Method to Get individual accounts
     * 
     * @param user
     * @param searchMap
     * @return
     * @throws DBException
     */
    public AccountRequest findAccount(User user, Map<String, Object> searchMap);

    /**
     * Method to Update the Account Request
     * 
     * @param accRequest
     * @throws DBException
     */
    public AccountRequest updateAccountRequestComplete(User user,
            AccountRequest accRequest,boolean bulkUpload);

    /**
     * Method to Adding/Removing Signers information
     * 
     * @param accRequest
     * @throws DBException
     */
    public AccountRequest updateSigners(User user, AccountRequest accRequest,
            AccountRequest currentAccReq, boolean onlySigners);

    public void updateSigners(User user, List<AccountSigner> signers);
    
    public List<AccountSigner> findSignerById (AccountSigner signer) ;

    /**
     * 
     * @param tCode
     * @return
     * @throws DBException
     */
    public List<AccountComment> getCommentsByTcode(String tCode);

    /**
     * 
     * @param tCode
     * @return
     * @throws DBException
     */
    public String getRequestIdByTcode(String tCode) ;

    /**
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    LastUpdatedDetails getLastUpdatedDetails(Long acctReqID) ;

    /**
     * Check if account status is pending
     * 
     * @param acctReqId
     * @param tCode
     * @return
     * @throws DBException
     */
    public Long getPendingCloseOrModifyByTcode(String tCode) ;

    /**
     * 
     * @param user
     * @param accRequest
     * @throws DBException
     */
    public void reserveBankAccount(User user, AccountRequest accRequest);
    
    public List<AccountRequest> getExportData( Map<String, Object> searchMap);
    
    public Boolean assignRequestToUser(AccountRequest account);
    
    public void updateSignersInMDM(User user, AccountRequest accRequest);
    
    public AccountRequest findAccountFromMDM(String tcode, String accURL, boolean isDocRequired) throws SystemException;
    
    public AccountRequest findAccountFromMDMforModify(String tcode, 
			String accURL, boolean isDocRequired) throws SystemException;
    
    public BulkApprovalRequest createApprovalReq ( AccountRequest source, BulkApprovalRequest target);

    public CashPoolProcess saveCashPoolProcess (MyFundingRequest request, User user);

   
    public void searchCashPoolProcessByRequestID (String requestId);



	public void updateCashPoolProcess(CashPoolProcess cashPoolProcess, User user);



    public List<CashPoolProcess> selectCashPoolProcess(CashPoolProcess cashPoolReq);
    
    public Map<String, String> getLovLookUpValues();
    
    /**
     * Get the platform instance for a given tcode.
     * This is required to retain the platform instance for the given tcode.
     * 
     * @param tCode
     * @return
     */
    Long getLastUpdatedPlatformInstance(String tCode);

    List<Map<String, String>> getBusSubbus(String code);

    List<Map<String, String>> getBuCodes(String newCode);
    
}
