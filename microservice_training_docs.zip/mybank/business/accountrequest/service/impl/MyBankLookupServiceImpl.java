/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.accountrequest.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.MyBankLookupDao;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Contains the implementation of MyBankLookupService methods
 * 
 * @author MyBank Dev Team
 * 
 */
@Service
public class MyBankLookupServiceImpl implements MyBankLookupService,
        ValidationConstants {

    @Autowired
    private MyBankLookupDao lookupDao;

    @Autowired
	private AccountRequestService accountRequestService;
    /**
     * @return the lookupDao
     */
    public MyBankLookupDao getLookupDao() {
        return lookupDao;
    }

    /**
     * @param lookupDao
     *            the lookupDao to set
     */
    public void setLookupDao(MyBankLookupDao lookupDao) {
        this.lookupDao = lookupDao;
    }

    /**
     * Calls method from dao to get all lookup data
     */
    @Override
    public List<MyBankLookup> getAllLov(String orderBy, String direction)
            throws DBException {
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "getAllLovs method start");

        List<MyBankLookup> lovs = null;
        try {
            lovs = lookupDao.getAllLov(orderBy, direction);
        } catch (DBException ex) {
            MyBankLogger.logError(this, "getAllLovs: " + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Lookup information (all). For more "
                            + "information please check the log file.");
        }

        MyBankLogger.logEnd(this, "getAllLovs", System.currentTimeMillis()
                - startTime);
        return lovs;
    }

    /**
     * Calls method from dao to get a list of lookup data By type
     */
    @Override
    public List<MyBankLookup> getLovsByLookupType(String lookupType,
            String orderBy, String direction) throws DBException {
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "getLovsByLookupType method start: "
                + lookupType);

        List<MyBankLookup> lovs = null;
        try {
            String[] elements = lookupType.split(",");
            if (elements.length > 1) {
                List<String> lookupTypes = Arrays.asList(elements);
                lovs = lookupDao.getLovsByLookupTypeList(lookupTypes, orderBy,
                        direction);
            } else {
                lovs = lookupDao.getLovsByLookupType(lookupType, orderBy,
                        direction);
            }
        } catch (DBException ex) {
            MyBankLogger.logError(this, "getLovsByObjType: " + ex.getMessage(),
                    ex);
            throw new DBException(
                    "Unable to get Lookup information (by type). For more "
                            + "information please check the log file.");
        }

        MyBankLogger.logEnd(this, "getLovsByObjType",
                System.currentTimeMillis() - startTime);
        return lovs;
    }

    /**
     * Method to getDisplayName sending lookupCode
     */
    @Override
    public String getDisplayName(String code) throws DBException {
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "lookupDao.getDisplayName method start: "
                + code);

        try {
            MyBankLogger.logEnd(this, "lookupDao.getLovLookupTypeByCode",
                    System.currentTimeMillis() - startTime);
            Map<String, String> lovLookupValues = accountRequestService.getLovLookUpValues();
           
            return lovLookupValues.containsKey(code) ? lovLookupValues.get(code) : code;
            
        } catch (DBException ex) {
            MyBankLogger.logError(this,
                    "lookupDao.getDisplayName: " + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get DisplayName Lookup information. For more "
                            + "information please check the log file.");
        }

    }
    
    @Override
	public String getLookupCode(String code) throws DBException {
		 long startTime = System.currentTimeMillis();
		 MyBankLogger.logStart(this, "lookupDao.getLookupCode method start: "
	                + code);
		  try {
	            MyBankLogger.logEnd(this, "lookupDao.getLookupCode",
	                    System.currentTimeMillis() - startTime);
	            Map<String, String> lovLookupValues = accountRequestService.getLovLookUpValues();
	            for (Entry<String, String> entry : lovLookupValues.entrySet()) {
	                if (Objects.equals(code, entry.getValue())) {
	                    return entry.getKey();
	                }
	            }
	            return null;
	        } catch (DBException ex) {
	            MyBankLogger.logError(this,
	                    "lookupDao.getLookupCode: " + ex.getMessage(), ex);
	            throw new DBException(
	                    "Unable to get LookupCode Lookup information. For more "
	                            + "information please check the log file.");
	        }
	}

}