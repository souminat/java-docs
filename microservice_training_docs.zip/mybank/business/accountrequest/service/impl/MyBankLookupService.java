/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.accountrequest.service.impl;

import java.util.List;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface MyBankLookupService {

    /**
     * Calls method from dao to get all lookup data
     * 
     * @param orderBy
     * @param direction
     * @return
     * @throws DBException
     */
    public List<MyBankLookup> getAllLov(String orderBy, String direction)
            throws DBException;

    /**
     * Calls method from dao to get a list of lookup data By type
     * 
     * @param lookupType
     * @param orderBy
     * @param direction
     * @return
     * @throws DBException
     */
    public List<MyBankLookup> getLovsByLookupType(String lookupType,
            String orderBy, String direction) throws DBException;

    /**
     * Method to get DisplayName sending lookupCode
     * 
     * @param code
     * @return
     * @throws DBException
     */
    public String getDisplayName(String code) throws DBException;
    
    public String getLookupCode(String code) throws DBException ;

}
