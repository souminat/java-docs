package com.ge.treasury.mybank.business.platforminstance.service.impl;

import java.util.List;

import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;

public interface PlatformInstanceService {

    /**
     * This method will return all Active Platform instance relation along with bank ID details.
     * 
     * @return
     */
    List<PlatformInstance> getAllPlatformInstance();
}
