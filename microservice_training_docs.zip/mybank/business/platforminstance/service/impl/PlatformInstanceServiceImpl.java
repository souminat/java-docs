package com.ge.treasury.mybank.business.platforminstance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.platforminstance.dao.impl.PlatformInstanceDao;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;
/**
 * Contains the details of Platform Instance mapping
 * 
 * @author MyBank Development Team
 * 
 */
@Component
public class PlatformInstanceServiceImpl implements PlatformInstanceService {
    
    @Autowired
    PlatformInstanceDao platformInstanceDao;

    @Override
    public List<PlatformInstance> getAllPlatformInstance() {
        return platformInstanceDao.getAllPlatformInstance();
    }

}
