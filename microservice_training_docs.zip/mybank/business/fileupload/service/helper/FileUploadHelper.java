package com.ge.treasury.mybank.business.fileupload.service.helper;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.mchange.io.FileUtils;


public class FileUploadHelper {

    private FileUploadHelper() {
        throw new IllegalAccessError("Utility class");
    }

    /**
     * Obtains json string value from an object
     * 
     * @return
     * @throws BusinessException
     */
    public static String obtainJsonString(Object objectValue) throws BusinessException {
        String jsonString = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            jsonString = mapper.writeValueAsString(objectValue);
            MyBankLogger.logDebug(new FileUploadHelper(), jsonString);
        } catch (JsonParseException e) {
            MyBankLogger.logError(new FileUploadHelper(), e.getMessage());
            throw new BusinessException(e);
        } catch (JsonMappingException e) {
            MyBankLogger.logError(new FileUploadHelper(), e.getMessage());
            throw new BusinessException(e);
        } catch (IOException e) {
            MyBankLogger.logError(new FileUploadHelper(), e.getMessage());
            throw new BusinessException(e);
        }
        return jsonString;
    }

    /**
     * Obtains object value from an json String
     * 
     * @return
     * @throws BusinessException
     */
    public static Object obtainObjectValue(String jsonString, Object objectType)
            throws BusinessException, JsonMappingException, JsonParseException {
        Object objectValue = null;
        ObjectMapper mapper = new ObjectMapper();

        if (jsonString != null) {
            try {
                if (objectType instanceof AccountRequest) {
                    objectValue = mapper.readValue(jsonString, AccountRequest.class);
                } else if (objectType instanceof FileUpload) {
                    objectValue = mapper.readValue(jsonString, FileUpload.class);
                }
            } catch (IOException e) {
                MyBankLogger.logError(new FileUploadHelper(), e.getMessage());
                throw new BusinessException(e);
            }
        }
        return objectValue;
    }

    /**
     * Convert file to clob (String)
     * 
     * @param file
     * @return
     * @throws IOException
     * @throws BusinessException
     * Commented out code from fileToClob method
     * String fileString = null;
     * try {
            FileInputStream fstream = new FileInputStream(file);
            DataInputStream input = new DataInputStream(fstream);
            BufferedReader buffer = new BufferedReader(new InputStreamReader(input));
            String line;

            while ((line = buffer.readLine()) != null) {
                if (fileString == null) {
                    fileString = "";
                }
                fileString = fileString + line.trim() + "\n";
            }
            IOUtils.closeQuietly(input);
            if (!StringUtils.isEmpty(fileString)) {
            	fileString = fileString.replaceAll(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", ",");
            }
        } catch (Exception e) {
            MyBankLogger.logEnd(new FileUploadHelper(), e.getMessage());
            throw new BusinessException(e);
        }
     * 
     * 
     */
    public static String fileToClob(File file) throws IOException, BusinessException {
      
        return FileUtils.getContentsAsString(file);
    }
    
    public static File clobToFile(String fileString) throws IOException, BusinessException {
    	
    	StringBuilder sb = new StringBuilder(fileString);
    	File f = new File("temp.csv");
    	PrintWriter pw = new PrintWriter(f);
    	pw.write(sb.toString());
        pw.close();
    	return f;
    }
    public static Object trimReflective(Object object) throws Exception {
        if (object == null)
            return null;

        Class<? extends Object> c = object.getClass();
        try {
            // Introspector usage to pick the getters conveniently thereby
            // excluding the Object getters
            for (PropertyDescriptor propertyDescriptor : Introspector
                    .getBeanInfo(c, Object.class).getPropertyDescriptors()) {
                Method method = propertyDescriptor.getReadMethod();
                String name = method.getName();

                // If the current level of Property is of type String
                trimForStringProperty(object, method, name, c);

                // If an Object Array of Properties - added additional check to
                // avoid getBytes returning a byte[] and process
                if (method.getReturnType().isArray()
                        && !method.getReturnType().isPrimitive()
                        && !method.getReturnType().equals(String[].class)
                        && !method.getReturnType().equals(byte[].class)) {
                    MyBankLogger.logInfo(FileUploadHelper.class,"Method Return Type : " + method.getReturnType());
                    // Type check for primitive arrays (would fail typecasting
                    // in case of int[], char[] etc)
                    trimForObjectArrayProperty(object, method);
                }
                // If a String array
                if (method.getReturnType().equals(String[].class)) {
                    String[] propertyArray = (String[]) method.invoke(object);
                    trimForStringArrayProperty(object, c, propertyArray, name);
                }
                // Collections start
                if (Collection.class.isAssignableFrom(method.getReturnType())) {
                    Collection collectionProperty = (Collection) method
                            .invoke(object);
                    trimForCollectionsProperty(collectionProperty);
                }
                // Separate placement for Map with special conditions to process
                // keys and values
                if (method.getReturnType().equals(Map.class)) {
                    Map mapProperty = (Map) method.invoke(object);
                    if (mapProperty != null) {
                        // Keys
                        for (int index = 0; index < mapProperty.keySet().size(); index++) {
                            if (mapProperty.keySet().toArray()[index] instanceof String) {
                                String element = (String) mapProperty.keySet()
                                        .toArray()[index];
                                if (element != null) {
                                    mapProperty.put(element.trim(),
                                            mapProperty.get(element));
                                    mapProperty.remove(element);
                                }
                            } else {
                                // Recursively revisit with the current property
                                trimReflective(mapProperty.get(index));
                            }

                        }
                        // Values
                        for (Map.Entry entry : (Set<Map.Entry>) mapProperty
                                .entrySet()) {

                            if (entry.getValue() instanceof String) {
                                String element = (String) entry.getValue();
                                if (element != null) {
                                    entry.setValue(element.trim());
                                }
                            } else {
                                // Recursively revisit with the current property
                                trimReflective(entry.getValue());
                            }
                        }
                    }
                } else {// Catch a custom data type as property and send through
                        // recursion
                    Object property = (Object) method.invoke(object);
                    if (property != null) {
                        trimReflective(property);
                    }
                }
            }

        } catch (Exception e) {
            MyBankLogger.logError(new FileUploadHelper(), "Not able to trim the object ", e);
        }

        return object;

    }
    
    private static void trimForStringProperty(Object object,Method method,String name, Class<? extends Object> c){
    	try {
			if (method.getReturnType().equals(String.class)) {
			    String property = (String) method.invoke(object);
			    if (property != null) {
			        Method setter = c.getMethod("set" + name.substring(3),
			                new Class<?>[] { String.class });
			        if (setter != null)
			            // Setter to trim and set the trimmed String value
			            setter.invoke(object, property.trim());
			    }
			}
		} catch (IllegalAccessException | IllegalArgumentException
				| InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			MyBankLogger.logError(FileUploadHelper.class, "Error in trimming String value : " + e);
			throw new SystemException("Error in trimming String value : "+e.getMessage());
		}
    }
    
    private static void trimForObjectArrayProperty(Object object,Method method){
             try {
				if (method.invoke(object) instanceof Object[]) {
				     Object[] objectArray = (Object[]) method.invoke(object);
				     if (objectArray != null) {
				         for (Object obj : (Object[]) objectArray) {
				             // Recursively revisit with the current property
				             trimReflective(obj);
				         }
				     }
				 }
			} catch (Exception e) {
				MyBankLogger.logError(FileUploadHelper.class, "Error in trimming Object Array : " + e);
				throw new SystemException("Error in trimming Object Array : "+e.getMessage());
			}
         
    }
    
    private static void trimForStringArrayProperty(Object object,Class<? extends Object> c,String[] propertyArray,String name){
    	try {
			if (propertyArray != null) {
			    Method setter = c.getMethod("set" + name.substring(3),
			            new Class<?>[] { String[].class });
			    if (setter != null) {
			        String[] modifiedArray = new String[propertyArray.length];
			        for (int i = 0; i < propertyArray.length; i++)
			            if (propertyArray[i] != null)
			                modifiedArray[i] = propertyArray[i].trim();

			        // Explicit wrapping
			        setter.invoke(object,
			                new Object[] { modifiedArray });
			    }
			}
		} catch (NoSuchMethodException | SecurityException
				| IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
			MyBankLogger.logError(FileUploadHelper.class, "Error in trimming String Array : " + e);
			throw new SystemException("Error in trimming String Array : "+e.getMessage());
		}
    }
    
    private static void trimForCollectionsProperty( Collection collectionProperty){
    	 if (collectionProperty != null) {
             for (int index = 0; index < collectionProperty.size(); index++) {
                 if (collectionProperty.toArray()[index] instanceof String) {
                     String element = (String) collectionProperty
                             .toArray()[index];

                     if (element != null) {
                         // Check if List was created with
                         // Arrays.asList (non-resizable Array)
                         if (collectionProperty instanceof List) {
                             ((List) collectionProperty).set(index,
                                     element.trim());
                         } else {
                             collectionProperty.remove(element);
                             collectionProperty.add(element.trim());
                         }
                     }
                 } else {
                     // Recursively revisit with the current property
                     try {
						trimReflective(collectionProperty.toArray()[index]);
					} catch (Exception e) {
						MyBankLogger.logError(FileUploadHelper.class, "Error in trimming Collections : " + e);
						throw new SystemException("Error in trimming Collections : "+e.getMessage());
					}
                 }
             }
         }
    } 
    
    private static void trimForMapProperty(Map mapProperty) throws Exception{
    	if (mapProperty != null) {
            // Keys
            for (int index = 0; index < mapProperty.keySet().size(); index++) {
                if (mapProperty.keySet().toArray()[index] instanceof String) {
                    String element = (String) mapProperty.keySet()
                            .toArray()[index];
                    if (element != null) {
                        mapProperty.put(element.trim(),
                                mapProperty.get(element));
                        mapProperty.remove(element);
                    }
                } else {
                    // Recursively revisit with the current property
                    trimReflective(mapProperty.get(index));
                }

            }
            // Values
            for (Map.Entry entry : (Set<Map.Entry>) mapProperty
                    .entrySet()) {

                if (entry.getValue() instanceof String) {
                    String element = (String) entry.getValue();
                    if (element != null) {
                        entry.setValue(element.trim());
                    }
                } else {
                    // Recursively revisit with the current property
                    trimReflective(entry.getValue());
                }
            }
        }
    }
}
