package com.ge.treasury.mybank.business.fileupload.service.impl;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.CNTRY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.MDM_CURRENCY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.AND_STRING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_COUNTRY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_CURRENCY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_NATIONAL_BANK_ACCOUNT_NUMBER;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ROUTE_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_T_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_COUNTRY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_TYPE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_MDM_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BUSINESS_BUSINESS_ACCOUNT_GROUP;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BUSINESS_SUBBUSINESS_ACCOUNT_GROUP;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BUS_ACCT_GRP_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.CORE_ATTRIBUTES;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.CURRENCY_CURRENCY_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ELEMENTS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ENTITY_NAME_LE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.FILTER_CONST;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PARTY_NM;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PARTY_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PRIMARY_ALT_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PRIMRY_SCOURCE_SYSTEM;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.MDM_MARS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.MY_BANK;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_AND;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.PROJECT_NAME;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_EQUALS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_LIKE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ORDER_ASCENDING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ORDER_DESCENDING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.S0;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.S1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.S2;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.S3;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.SUB_BUS_ACCT_GRP_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BUS_SBUS_REL_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.TOTAL_COUNT_REQUIRED;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_2;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Service;

import com.ge.treasury.mybank.business.fileupload.dao.impl.BulkUploadDao;
import com.ge.treasury.mybank.business.fileupload.service.helper.FileUploadHelper;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMUtil;
import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.MDMDetails;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.mdm.Pagination;
import com.ge.treasury.mybank.domain.mdm.ResponseObjects;
import com.ge.treasury.mybank.domain.mdm.SearchCriteria;
import com.ge.treasury.mybank.domain.mdm.SearchCriteriaList;
import com.ge.treasury.mybank.domain.mdm.Sort;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;

@Service
public class BulkUploadServiceImpl implements BulkUploadService, ValidationConstants  {


	@Value("${mdm.ms.buhierarchy}")
	private String buHierarchyUrl;
	
	@Value("${mdm.ms.business}")
	private String businessUrl;

	@Value("${mdm.ms.country}")
	private String countryUrl;

	@Value("${mdm.ms.currency}")
	private String currencyUrl;

	@Value("${mdm.ms.account}")
	private String accountUrl;
	
	@Value("${mdm.ms.accountCore}")
	private String accountCoreUrl;
	
	@Value("${mdm.ms.projectTSA}")
	private String projectTsaUrl;
	
	@Value("${mdm.ms.routeCode}")
	private String routeCodeUrl;
	
	@Value("${mdm.ms.companyCode}")
	private String companyCodeUrl;
	
	@Value("${mdm.ms.me}")
	private String meUrl;
	
	@Value("${mdm.ms.le}")
	private String le_v2Url;
	
	@Value("${mdm.ms.bank}")
	private String bankUrl;

	@Autowired
	MDMService mdmService;

	@Autowired
	BulkUploadDao bulkUploadDao;
	
	
	@Autowired
    private OAuth2RestOperations mdmBankCentralizeTemplate;	
	
	private Set<String> businessList = new HashSet<String>();
	private Set<String> subBusinessList = new HashSet<String>();
	
	@Override
	public String fetchRouteCodeDetails(String bankId, String code) throws UnsupportedEncodingException  {

		String url = routeCodeUrl;

		final StringBuilder filter = new StringBuilder();

		filter.append("(");
		filter.append("UPPER(" + "PARENT_MDM_ID" + ") = UPPER('" + bankId + "')");
		filter.append(" and ");
		filter.append("(");
		filter.append("UPPER(" + "RTE_CODE" + ") = UPPER('" + URLDecoder.decode(code, "UTF-8") + "')");
		filter.append(")");
		filter.append(")");
		HashMap<String, String> params = new HashMap<>();
		params.put("$filter", filter.toString());
		return this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
	}
	
	@Override
	public String fetchRouteCodeType(String bankId, String code) throws UnsupportedEncodingException {

		String url = routeCodeUrl;

		final StringBuilder filter = new StringBuilder();

		filter.append("(");
		filter.append("UPPER(" + "PARENT_MDM_ID" + ") = UPPER('" + bankId + "')");
		filter.append(" and ");
		filter.append("(");
		filter.append("UPPER(" + "RTE_CODE_TYPE" + ") = UPPER('" + URLDecoder.decode(code, "UTF-8") + "')");
		filter.append(")");
		filter.append(")");
		HashMap<String, String> params = new HashMap<>();
		params.put("$filter", filter.toString());
		return this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
	}
	@Override
	public String fetchBankBranchDetails(String bankId, String routeCode,String routeType,String branchId) throws UnsupportedEncodingException {

		String url = routeCodeUrl;

		final StringBuilder filter = new StringBuilder();

		filter.append("(");
		filter.append(UPPER_2 + "PARENT_MDM_ID" + UPPER_1 + bankId + "')");
		filter.append(" and ");
		filter.append("(");
		filter.append(UPPER_2 + "RTE_CODE" + UPPER_1 + URLDecoder.decode(routeCode, "UTF-8") + "')");
		filter.append(")");
		filter.append(" and ");
		filter.append("(");
		filter.append(UPPER_2 + "RTE_CODE_TYPE" + UPPER_1 + URLDecoder.decode(routeType, "UTF-8") + "')");
		filter.append(")");
		filter.append(" and ");
		filter.append("(");
		filter.append(UPPER_2 + "BRANCH_MDM_ID" + UPPER_1 + URLDecoder.decode(branchId, "UTF-8") + "')");
		filter.append(")");
		filter.append(")");
		HashMap<String, String> params = new HashMap<>();
		params.put("$filter", filter.toString());
		return this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
	}
	@Override
	public String fetchMEDetails(String code)throws UnsupportedEncodingException{
		final StringBuilder filter = new StringBuilder();
		try {
			
			
			filter.append("(");
			filter.append("(");
			filter.append(UPPER_2 + LE_PRIMARY_ALT_CODE + ")= UPPER('" + URLDecoder.decode(code, "UTF-8")+"')");
			filter.append(")");
			filter.append(" " + OPERATOR_AND + " ");
            filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");
        	filter.append(" " + OPERATOR_AND + " ");
            filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + MDM_MARS + "')");
			filter.append(")");


		} catch (Exception e) {
			MyBankLogger.logError(this, "Error in Decoding :: fetchMEDetails ", e);
		}

		HashMap<String, String> params = new HashMap<>();

		params.put(FILTER_CONST, filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", "0");

		String jsonOutput = mdmService.callMDMDenodo(params, meUrl, HttpMethod.GET, false);

		return jsonOutput;

	}
	

	private void getBusinessAndSubBusiness(MDMDetails mdmData) {

		HashMap<String, String> params = new HashMap<>();

		try {
			final StringBuilder filter = new StringBuilder();
			filter.append("(");

			filter.append(UPPER_2 + BUS_ACCT_GRP_STATUS + UPPER_1 + ACTIVE + "')");

				filter.append(AND_STRING);
			filter.append(UPPER_2 + SUB_BUS_ACCT_GRP_STATUS + UPPER_1 + ACTIVE + "')");
				filter.append(AND_STRING);
			filter.append(UPPER_2 + BUS_SBUS_REL_STATUS + UPPER_1 + ACTIVE + "')");

			filter.append(")");

			params.put(FILTER_CONST, filter.toString());
			params.put(TOTAL_COUNT_REQUIRED, "false");

		} catch (Exception e) {
			MyBankLogger.logError(this, "Business Decode error", e);
		}

		String jsonOutput = mdmService.callMDMDenodo(params, businessUrl, HttpMethod.GET, false);

		JSONObject jsonObject = new JSONObject(jsonOutput);
		JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
		if (elements.length() > 0) {
			for (int i = 0; i < elements.length(); i++) {
				JSONObject obj = elements.getJSONObject(i);
				String businessKey = obj.get(BUSINESS_BUSINESS_ACCOUNT_GROUP.toLowerCase()).toString();
				String subBusinessValue = obj.get(BUSINESS_SUBBUSINESS_ACCOUNT_GROUP.toLowerCase()).toString();
				businessList.add(businessKey);
				subBusinessList.add(subBusinessValue);
				
				if( mdmData.getBusSubBusCombination().containsKey(businessKey.toUpperCase())){
					mdmData.getBusSubBusCombination().get(businessKey.toUpperCase()).add(subBusinessValue.toUpperCase());
				}else{
					List<String> newList = new ArrayList<String>();
					newList.add(subBusinessValue.toUpperCase());
					mdmData.getBusSubBusCombination().put(businessKey.toUpperCase(), newList);
				}
			}
			mdmData.setBusinessList(businessList);
			mdmData.setSubBusinessList(subBusinessList);
			
		}
	}
	
	@Override
	public String getMDMBankDetails(String bankMdmId,String countryCode)  {

		final StringBuilder filter = new StringBuilder();
		HashMap<String, String> params = new HashMap<>();

		try {

			filter.append("(");

			filter.append(UPPER_2 + BANK_MDM_ID + UPPER_1 + URLDecoder.decode(bankMdmId, "UTF-8") + "')");
			
            if (null != StringUtils.trimToNull(countryCode)) {
                filter.append(AND_STRING);

                filter.append(
                        UPPER_2 + BANK_BANK_COUNTRY_CODE + UPPER_1 + URLDecoder.decode(countryCode, "UTF-8") + "')");
            }
			
			filter.append(AND_STRING);

			filter.append(UPPER_2 + BANK_BANK_TYPE + UPPER_1 + URLDecoder.decode("BANK", "UTF-8") + "')");

			filter.append(AND_STRING);

			filter.append(UPPER_2 + BANK_BANK_STATUS + UPPER_1 + URLDecoder.decode(ACTIVE, "UTF-8") + "')");
			
			filter.append(")");

			params.put(FILTER_CONST, filter.toString());

		} catch (Exception e) {
			MyBankLogger.logError(this, "BulkUploadServiceImpl.getMDMBankDetails: " + e.getMessage(), e);
			throw new SystemException("Error fetching Bank Details");
		}
		String jsonOutput = mdmService.callMDMDenodo(params, bankUrl, HttpMethod.GET, false);
		return jsonOutput;
	}
	
	@Override
	public String validateLE (String leCode){
	    String upperLeCode = StringUtils.upperCase(leCode);

	    return mdmService.callMDMDenodo(mdmService.setLeFilterParams(false, upperLeCode), le_v2Url, HttpMethod.GET, true);

	}
	
	@Override
	public String getGoldLeNames(String leCode){

	    String upperLeCode = StringUtils.upperCase(leCode);

        return mdmService.callMDMDenodo(mdmService.setLeFilterParams(false, upperLeCode), le_v2Url, HttpMethod.GET, true);

    }
	
	@Override
	public boolean isValidTCode(String tCode){
		final StringBuilder filter = new StringBuilder();
		boolean isValid = false;
		try {
			filter.append("(");

			filter.append(
					UPPER_2 + BANK_ACCOUNT_CENTRALIZE_T_CODE + UPPER_1 + URLDecoder.decode(tCode, "UTF-8") + "')");
			filter.append(AND_STRING);

			filter.append(
					UPPER_2 + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + ") NOT IN ('CLOSED','DIVESTED')");

			filter.append(")");
			
		} catch (Exception e) {
			MyBankLogger.logError(this, "Error in Decoding :: isValidTCode ", e);
		}

		HashMap<String, String> params = new HashMap<>();

		params.put(FILTER_CONST, filter.toString());

		String jsonOutput = mdmService.callMDMDenodo(params, accountCoreUrl, HttpMethod.GET, false);

		JSONObject jsonObject = new JSONObject(jsonOutput);
		JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
		if (elements.length() > 0) {
			isValid = true;
		}
		return isValid;
	}
	
	@Override
	public boolean isValidCompanyCode(String goldId, String companyCode){
		StringBuilder filter = null;
		boolean isValid = false;
		HashMap<String, String> params = null;
		//Validate Company code 
		try {
			filter = new StringBuilder();
			params = new HashMap<>();
			filter.append("(");
			filter.append(UPPER_2 + "company_code" + UPPER_1 + URLDecoder.decode(companyCode, "UTF-8") + "')");
			filter.append(")");
			params.put(FILTER_CONST, filter.toString());
			String jsonOutput = mdmService.callMDMDenodo(params, companyCodeUrl, HttpMethod.GET, false);

			JSONObject jsonObject = new JSONObject(jsonOutput);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			
			if (elements.length() > 0) {
				filter = new StringBuilder();
				params = new HashMap<>();
				String branchCode = null;
				
				Iterator<Object> itr = elements.iterator();
				while (itr.hasNext()) {
					JSONObject obj = (JSONObject) itr.next();
					branchCode = String.valueOf(obj.get("associated_le"));
				}
				
				if(null!=branchCode){
					if(branchCode.equalsIgnoreCase(goldId)){
						isValid = true;
					}else{
						//Invoke LE Service to validate
						filter.append("(");
						filter.append("(UPPER(" + "PARENT_CODE" + ") ").append(OPERATOR_LIKE)
								.append(" UPPER('%" + URLDecoder.decode(goldId, "UTF-8") + "%'))");
						filter.append(" " + OPERATOR_AND + " ");
						filter.append(UPPER_2 + LE_PRIMARY_ALT_CODE + ") ").append(OPERATOR_EQUALS)
						.append(" UPPER('" + branchCode + "')");
						filter.append(" " + OPERATOR_AND + " ");
						filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS)
								.append(" UPPER('" + "GOLD" + "')");
						filter.append(" " + OPERATOR_AND + " ");
						filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");
						filter.append(" " + OPERATOR_AND + " ")
        				.append(MDMConstants.ACTIVE_FLAG)
        						.append(OPERATOR_EQUALS).append("'Y'");      
						filter.append(")");

						params.put(FILTER_CONST, filter.toString());
						String leServiceResponse =  this.mdmService.callMDMDenodo(params, le_v2Url, HttpMethod.GET, true);
						JSONObject jsonObject_le = new JSONObject(leServiceResponse);
						JSONArray elements_le = jsonObject_le.getJSONArray(ELEMENTS);
						if (elements_le.length() > 0) {
							isValid = true;
						}
						
					}
				}
			}
		}catch (Exception e) {
			MyBankLogger.logError(this, "Error in fetch company Code ", e);
		}
		return isValid;
	}


	@Override
	public FileUpload createFileUpload(FileUpload fileUpload, File file, User user,String status) throws DBException {
		long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "createFileUpload");

		String fileString = null;
		
		// Receive File object and save to db as clob
		try {
			if(null!=file){
				fileString = FileUploadHelper.fileToClob(file);
				fileUpload.setFileName(file.getName());
				fileUpload.setUploadedFile(fileString);
			}
			
		} catch (IOException e) {
			MyBankLogger.logError(this, "BulkUploadServiceImpl.createFileUpload: " + e.getMessage(), e);
			throw new BusinessException(e.getMessage());
		}

		fileUpload.setUpldStatusCode(status);
		fileUpload.setUpldUserSSO(user.getSso());
		
		try {
			bulkUploadDao.saveFileUpload(fileUpload, user);
		} catch (DBException ex) {
			MyBankLogger.logError(this, "fileUploadDao.saveFileUpload: " + ex.getMessage(), ex);
			throw new DBException("Unable to Insert file upload information, database operation failed."
					+ " For more information please check the log file.");
		}
		MyBankLogger.logEnd(this, "createFileUpload: " + (System.currentTimeMillis() - startTime));

		return fileUpload;
	}

	@Override
    public List<FileUpload> loadProcessingQueueSortBy(BulkApprovalSearchCriteria bulkApprovalSearch)throws DBException{
    	return bulkUploadDao.loadProcessingQueueSortBy(bulkApprovalSearch);
    }

	@Override
	public FileUpload downLoadFile(Long fileUploadId)throws DBException {
		return bulkUploadDao.downloadFile(fileUploadId);
	}

	@Override
	public MDMDetails loadMDMDetails(MDMDetails mdmData) {
		MyBankLogger.logDebug(this, "loading MDM Data...");
		getBusinessAndSubBusiness(mdmData);
		MyBankLogger.logDebug(this, "MDM Data loaded successfully");
		
		return mdmData;
	}

	@Override
	public AccountRequest searchAccountByCombination(Map<String, Object> searchMap) throws DBException {
	
		return bulkUploadDao.searchAccountByCombination(searchMap);
	}

	@Override
	public String validateProjectName(String projectName) throws JSONException, ParseException {
		final StringBuilder filter = new StringBuilder();
		
		try {
			filter.append("(");

			filter.append(PROJECT_NAME + OPERATOR_EQUALS);

			filter.append("'" + projectName + "'");

			filter.append(")");
			
		} catch (Exception e) {
			MyBankLogger.logError(this, "Error in Setting Project Name ::".concat(projectName), e);
		}

		HashMap<String, String> params = new HashMap<>();

		params.put(FILTER_CONST, filter.toString());

		String response = mdmService.callMDMDenodo(params, projectTsaUrl, HttpMethod.GET, false);
		
		if (null != response) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray data = jsonObject.getJSONArray(ELEMENTS);
			if(null != data && data.length() > 0){
				return ValidationConstants.ACTIVE;
			}
		}
		
		return ValidationConstants.PROJECT_NOT_FOUND;
	}

    @Override
    public List<String> getAllCountry() {
        final StringBuilder filter = new StringBuilder();
        List<String> countryCodes = new ArrayList<String>();

        filter.append("(");

        filter.append(UPPER_2 + "CNTRY_STATUS" + ") = UPPER('" + ACTIVE + "')");

        filter.append(")");
        HashMap<String, String> params = new HashMap<>();
        params.put(FILTER_CONST, filter.toString());
        String response = this.mdmService.callMDMDenodo(params, countryUrl, HttpMethod.GET, true);
        JSONObject jsonObject = new JSONObject(response);
        JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
        if (elements.length() > 0) {
            for (int i = 0; i < elements.length(); i++) {
                JSONObject obj = elements.getJSONObject(i);
                countryCodes.add(obj.get(CNTRY_CODE).toString());
            }
        }
        
        return countryCodes;
    }

    @Override
    public List<String> getAllCurrency() {
        final StringBuilder filter = new StringBuilder();
        List<String> currencyCodes = new ArrayList<String>();

        filter.append("(");

        filter.append(UPPER_2 + CURRENCY_CURRENCY_STATUS + ") = UPPER('" + ACTIVE + "')");

        filter.append(")");

        HashMap<String, String> params = new HashMap<>();
        params.put(FILTER_CONST, filter.toString());

        String response =  this.mdmService.callMDMDenodo(params, currencyUrl, HttpMethod.GET, true);
        JSONObject jsonObject = new JSONObject(response);
        JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
        if (elements.length() > 0) {
            for (int i = 0; i < elements.length(); i++) {
                JSONObject obj = elements.getJSONObject(i);
                currencyCodes.add(obj.get(MDM_CURRENCY_CODE.toLowerCase()).toString());
            }
        }
        
        return currencyCodes;
    }

    @Override
    public List<String> searchAccountCombination(BulkApprovalRequest account) throws UnsupportedEncodingException {
        StringBuilder subFilterSB = new StringBuilder();
        String url = accountCoreUrl;
        List<String> tCodes = new ArrayList<String>();
        subFilterSB.append("(");

        subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_T_CODE + ") NOT IN UPPER('"
                + URLDecoder.decode(account.gettCode(), "UTF-8") + "'))");

        subFilterSB.append(" and ");
        subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + ") NOT IN ('CLOSED','DIVESTED'))");

        subFilterSB.append(" and ");
        subFilterSB
                .append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID + ") =  UPPER('" + account.getBankId() + "'))");

        subFilterSB.append(" and ");
        subFilterSB.append(
                "(UPPER(" + BANK_ACCOUNT_CENTRALIZE_COUNTRY_CODE + ") =  UPPER('" + account.getCountry() + "'))");

        subFilterSB.append(" and ");
        subFilterSB.append(
                "(UPPER(" + BANK_ACCOUNT_CENTRALIZE_CURRENCY_CODE + ") =  UPPER('" + account.getCurrency() + "'))");

        subFilterSB.append(" and ");
        subFilterSB.append(
                "(UPPER(" + BANK_ACCOUNT_CENTRALIZE_ROUTE_CODE + ") =  UPPER('" + account.getRouteCode() + "'))");

        subFilterSB.append(" and ");
        subFilterSB.append("(UPPER(" + BANK_ACCOUNT_CENTRALIZE_NATIONAL_BANK_ACCOUNT_NUMBER + ") =  UPPER('"
                + account.getAccountNumber() + "'))");
        subFilterSB.append(" and ");
        subFilterSB.append(UPPER_2 + "SRCE_SYS_NM" + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + "MDM" + "')");

        subFilterSB.append(")");

        HashMap<String, String> params = new HashMap<>();

        params.put(FILTER_CONST, subFilterSB.toString());
        params.put("$totalCountRequired", "true");
        params.put("$orderby", "rqst_id" + " " + ORDER_DESCENDING);

        String jsonResponse = this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
        
        JSONObject jsonObject = new JSONObject(jsonResponse);
        JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
        if (elements.length() > 0) {
            for (int i = 0; i < elements.length(); i++) {
                JSONObject obj = elements.getJSONObject(i);
                tCodes.add(obj.get(BANK_ACCOUNT_CENTRALIZE_T_CODE.toLowerCase()).toString());
            }
        }
        return tCodes;
    }

    @Override
	public String validateCoCodeBuCombination(String companyCode) {
    	HashMap<String, String> params = new HashMap<>();
    	StringBuilder filter = new StringBuilder();
    	filter.append("(");
  	   
		try {
			filter.append(UPPER_2 + MDMConstants.COMPANY_CODE + UPPER_1 + URLDecoder.decode(companyCode,"UTF-8") + "')");
		} catch (UnsupportedEncodingException e1) {
			MyBankLogger.logError(this, "Error in decoding company code : " + e1.getMessage());
			throw new BusinessException("Error in decoding company code : " + e1.getMessage());
		}
		
        filter.append(")");
    	params.put(FILTER_CONST, filter.toString());
          
        String jsonOutput = mdmService.callMDMDenodo(params, companyCodeUrl, HttpMethod.GET, true);
        if(null != jsonOutput) {
        	return getBuFromCompanyCode(jsonOutput);
        }
        return null;
        
	}
    
    //Derive Bu Code from Company Code response
    private String getBuFromCompanyCode(String response) {
    	String buCode = null;
    	JSONObject jsonObject = new JSONObject(response);
    	JSONArray data = jsonObject.getJSONArray(ELEMENTS);
    
		if(null !=data || data.length() != 0) {
			
			Iterator<Object> itr = data.iterator();
			 try {
	  				while (itr.hasNext()) {
	  					JSONObject obj = (JSONObject) itr.next();

	  					buCode = StringHelper.getStringValue(obj.get(MDMConstants.ASSOCIATED_BU));
	  				} 
	  			} catch (Exception e) {
	  				MyBankLogger.logError(this, "Error in fetching bu code : " + e.getMessage());
	  				throw new BusinessException("Error in fetching bu code : " + e.getMessage());
	  			}
		}
		return buCode;
    }
    
	@Override
	public String validateBuCode(String buCode) {
		return mdmService.getBusinessFromBu(buCode, true);
	}
	
}
