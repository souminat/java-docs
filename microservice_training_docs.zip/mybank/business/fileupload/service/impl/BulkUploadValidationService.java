package com.ge.treasury.mybank.business.fileupload.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.BulkUploadError;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;

public interface BulkUploadValidationService {

    /**
     * Validate gold Id and its dependent attributes (component code,
     * companyCode). Need to validate the variable only when data is changed by
     * User. If any errors are found return the same using BulkUploadError.
     * 
     * @param requestFromUi
     * @param mdmRequest
     * @return
     */
    List<BulkUploadError> goldIdValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest);
    
    /**
     * Validate Country currency to see if its valid.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param requestFromUi
     * @param mdmRequest
     * @return
     */
    List<BulkUploadError> countryCurrencyValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest);
    
    /**
     * Validate Document to see if its valid.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @param mdmRequest
     * @return
     */
    List<BulkUploadError> documentValidate(BulkApprovalRequest account,AccountRequest mdmRequest);
    
    /**
     * Validate Tcode, Cashpool Tcode and Alternate account.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @param mdmRequest
     * @return
     */
    List<BulkUploadError> tCodeValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest);
    
    /**
     * Validate meCode.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @return
     */
    List<BulkUploadError> meCodeValidate(BulkApprovalRequest requestFromUi);
    
    /**
     * Validate projectName.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @return
     */
    List<BulkUploadError> projectNameValidate(BulkApprovalRequest requestFromUi);
    
    /**
     * Validate accountStatus.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @return
     */
    List<BulkUploadError> accountStatusValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest);
    
    /**
     * Validate Country, Bank, Branch, route code and route type.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @return
     * @throws Exception 
     */
    List<BulkUploadError> bankBranchValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) throws UnsupportedEncodingException;
    
    /**
     * Validate Account Number, TCode, BankId, routeCode Country and Currency for its uniqueness in MDM.
     * Need to validate the variable only when data is changed by User. If any
     * errors are found return the same using BulkUploadError.
     * 
     * @param account
     * @return
     * @throws Exception 
     */
    List<BulkUploadError> accountCombinationValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) throws UnsupportedEncodingException;
   
    /**
     * Validate Company Code, Company code reject reason combination.
     * Need to ensure for a tcode always either a company code/reject reason should be present 
     * 
     * @param account
     * @return
     * @throws Exception 
     */
    List<BulkUploadError> coCodeRejectReasonValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest);
    
    
    /**
     * Validate BU Code with respect to Company Code entered or present in MDM.
     * Derive business/sub-business based on BU Code if data entered by user
     * Check Component Code eligibility when Component Code data changed by user
     * Need to validate variable only when data is changed by user
     * 
     * 
     * @param account
     * @return
     * @throws Exception 
     */
    List<BulkUploadError> buCodeValidate(BulkApprovalRequest requestFromUi,
            AccountRequest accReqMDM);
    
    void setRowNumber(int rowNumber);
    
    public void setUpldTypeCode(String upldTypeCode);
}
