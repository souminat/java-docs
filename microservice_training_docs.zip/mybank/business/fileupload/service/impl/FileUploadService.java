package com.ge.treasury.mybank.business.fileupload.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.FileUploadParameters;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

public interface FileUploadService {

    /**
     * Method to uplaod a specific file into GE library
     * 
     * @param fileName
     * @param docType
     * @param requestType
     * @param uploader
     * @param subFolderId
     * @param filePath
     * @return - Returns FileUploadParameters
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    public FileUploadParameters uploadFile(String subFolderName,
            String docType, String requestType, String uploader, String fileNm,
            String folderId, String filePath);

    /**
     * Method downloads specific file from GE library onto given folder
     * location.
     * 
     * @param fileId
     * @param fileName
     * @param downloadFolder
     * @return - Returns true if download is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    public boolean downloadFileById(String fileId, String fileName,
            String downloadFolder, String userId, String AppID,
            String AppPassword);

    /**
     * Method to modify a specific file onto GE library
     * 
     * @param fileId
     * @param fileName
     * @param filePath
     * @return - Returns true if update is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    public FileUploadParameters updateFileOnLibrary(String fileId,
            String fileName, String filePath, String userId, String AppID,
            String AppPassword);

    /**
     * Business service to create the sub folder.
     * 
     * @param subFolderName
     * @param parentFolderID
     * @return String
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    public String createSubFolder(String subFolderName, String parentFolderID,
            String userId, String AppID, String AppPassword);

    /**
     * Business service to find the folder ID.
     * 
     * @param acctReqID
     * @return String
     * @throws DBException
     */
    public String getSubFolderID(long acctReqID) throws DBException;

    /**
     * Method to delete specific file from a given folder
     * 
     * @param folderId
     * @param fileId
     * @param fileName
     * @return - Returns true if delete is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    public boolean deleteFile(User user,String folderId, String fileId, String userId,
            String AppID, String AppPassword);

    /**
     * Business service to find sub folder in libraries.
     * 
     * @param folderName
     * @param userId
     * @param AppID
     * @param AppPassword
     *            *
     * @return
     * @throws IOException
     * @throws BusinessException
     */
    public String findSubFolder(String folderName, String defaultFolderId,
            String userId, String AppID, String AppPassword);

    /**
     * Business service to get the folder id of duplicate file.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    public List<AccountDocument> getFileDetails(String acctReqID)
            throws DBException;

    /**
     * Business service to get the file from server path.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    public void downloadFileByOutputStream(HttpServletResponse response,
            String fileName, String localDirectory) throws IOException;

    /**
     * Method to get current date in MM/dd/YYYY format.
     * 
     * @return - Returns formatted date value as String.
     */
    public String dateFormatter(String dateFormat);    
    
    /**
     * Method to delete the file from local directory.
     * 
     * @param file
     * @return - Returns true if file deleted else false.
     */
    public boolean deleteLocalFile(File file);
    
    /**
     * Method to get the METADATA information for a file from GE library
     * 
     * @param fileId
     * 
     * @return - Returns AccountDocument containing the METADATA information
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public AccountDocument getMetadataForFile(String fileID, String userId, String AppID, String AppPassword);
}
