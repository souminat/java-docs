package com.ge.treasury.mybank.business.fileupload.service.impl;

import java.util.List;

import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

public interface FileUploadActivityService {

	public int saveFileUploadActivity(FileUploadActivity fileUploadActivity)throws DBException;

	public List<FileUploadActivity> getFileUploadActivityDetailsById(Long fileUpldId)throws DBException;

}
