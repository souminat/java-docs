package com.ge.treasury.mybank.business.fileupload.service.impl;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.json.JSONException;

import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.MDMDetails;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

public interface BulkUploadService {

	public List<FileUpload> loadProcessingQueueSortBy(BulkApprovalSearchCriteria bulkApprovalSearch) throws DBException;

	public FileUpload downLoadFile(Long fileUploadId) throws DBException;

	public MDMDetails loadMDMDetails(MDMDetails mdmData);
	
	public String getGoldLeNames(String leCode);
	
	public String validateLE (String leCode);
	
	public String validateProjectName(String projectName) throws JSONException, ParseException;
	
	/**
	 * get bu code from the Bulk templates(OPEN/MODIFY-ALL/MODIFY-SPECIFIC/INTERNAL) and
	 * check whether entered data is a valid bu code from bu service from MDM
	 * 
	 * @param buCode
	 * @return
	 */
	public String validateBuCode(String buCode);
	
	/**
	 * get company code from Bulk templates(OPEN/MODIFY-ALL/MODIFY-SPECIFIC/INTERNAL) and
	 * query MDM company code service to get associated bu and check whether that bu code is the one
	 * entered from template in the bu code field
	 * 
	 * @param company code
	 * @return
	 */
	public String validateCoCodeBuCombination(String companyCode);
	
	public boolean isValidTCode(String tCode);
	
	public boolean isValidCompanyCode(String goldId, String companyCode);
	
	public String getMDMBankDetails(String bankMdmId,String countryCode);
	
	public String fetchRouteCodeDetails(String bankId, String code) throws UnsupportedEncodingException;
	
	public String fetchRouteCodeType(String bankId, String code) throws UnsupportedEncodingException;
	

	public AccountRequest searchAccountByCombination(Map<String, Object> searchMap)throws DBException;
	
	public FileUpload createFileUpload(FileUpload fileUpload, File file, User user,String status) throws DBException;

	public String fetchBankBranchDetails(String bankId, String routeCode,
			String routeType, String branchId) throws UnsupportedEncodingException;

	public String fetchMEDetails(String code) throws UnsupportedEncodingException;
	
	
	/**
	 * get list of active countries
	 * 
	 * @return
	 */
	List<String> getAllCountry();
	
	/**
	 * get list of active currency
	 * 
	 * @return
	 */
	List<String> getAllCurrency();
	
    /**
     * Get the list of accounts matching the given criteria. if there are any
     * tcodes in response user should not be allowed to create this request.
     * 
     * @param account
     * @return
     * @throws UnsupportedEncodingException 
     */
    public List<String> searchAccountCombination(BulkApprovalRequest account) throws UnsupportedEncodingException;
    
}
