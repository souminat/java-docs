package com.ge.treasury.mybank.business.fileupload.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ge.folders.thinapi.client.GEFolders;
import com.ge.treasury.mybank.business.fileupload.dao.impl.FileUploadDao;
import com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.FileUploadParameters;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.web.controllers.fileupload.FileUploadController;

@Service
public class FileUploadServiceimpl implements FileUploadService,
        FileUploadConstants {

    @Autowired
    FileUploadDao fileUploadDao;

    @Value(APPLICATIONID)
    private String applicationId;
    @Value(USERID)
    private String defaultUserId;
    @Value(PASSWORD)
    private String applicationPassword;

    
    @Autowired
    AccountRequestDao accReqDao;
    /**
     * Method to uplaod a specific file into GE library
     * 
     * @param subFolderName
     * @param docType
     * @param requestType
     * @param uploader
     * @param fileName
     * @param subFolderId
     * @param filePath
     * @param userId
     * @param appID
     * @param appPassword
     * 
     * @return - Returns FileUploadParameters
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @Override
    public FileUploadParameters uploadFile(String subFolderName,
            String docType, String requestType, String uploader,
            String fileName, String subFolderId, String filePath){
    	long startTime = System.currentTimeMillis();
    	String newFileName = FilenameUtils.normalize(fileName);
    	String newFilePath = FilenameUtils.normalize(filePath);
    	MyBankLogger.logStart(this, "Start Uplaoding file : " + newFileName);
        StringBuilder uploadXML = new StringBuilder(XML_VERSION + CALLAPI_START)
                .append(METHOD_START + UPLOAD_FILE_METHOD + METHOD_END
                        + PARAMETERS_START)
                .append(FOLDER_ID_START + subFolderId + FOLDER_ID_END)
                .append(FILE_NAME_START + newFileName.replace("&", "&amp;") + FILE_NAME_END)
                .append(FILE_TITLE_START +newFileName.replace("&", "&amp;") + FILE_TITLE_END)
                .append(DESCRIPTION_START + DESCRIPTION_END + EXPIRE_DATE_START
                        + EXPIRE_DATE_END)
                .append(FILE_PATH_START + newFilePath.replace("&", "&amp;") + FILE_PATH_END)
                .append(METADATA_START + docType + METADATA_FIELD1 + uploader
                        + METADATA_FIELD2 + dateFormatter(DATE_FORMAT)
                        + METADATA_FIELD3 + getTextRequestType(requestType)
                        + METADATA_FIELD4 + subFolderName + METADATA_END)
                .append(PARAMETERS_END + CALLAPI_END);
        
        File oldfile =new File(newFilePath.replace("&", "&amp;"));
        File newfile =new File(newFilePath);
        
        oldfile.renameTo(newfile);
        
        String uploadXMLResp = GEFolders.callAPI(uploadXML.toString(), defaultUserId,
                applicationId, applicationPassword);
        
        newfile.renameTo(oldfile);
        
        FileUploadParameters fileUploadParameters = new FileUploadParameters();
        Document doc = getXMLDocument(uploadXMLResp);
        
		NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
            	MyBankLogger.logInfo(this,"File uploaded successfully");
                NodeList subNodes = element
                        .getElementsByTagName(EXTENDED_RESPONSE);
                for (int j = 0; j < subNodes.getLength(); j++) {
                    Element elementSub = (Element) subNodes.item(i);
                    fileUploadParameters.setFileID(processXMlTag(FILE_ID,
                            elementSub));
                    fileUploadParameters.setFileURL(processXMlTag(FILE_URL,
                            elementSub));
                }            
                
            } else if (FAILURE.equals(status)) {
                if (processXMlTag(ERROR_CODE, element).equals(ERROR_51115)
                        && processXMlTag(ERROR_MESSAGE, element).equals(
                                FILE_ALREADY_EXIST)) {
                	MyBankLogger.logInfo(this,"File exist already");
                    fileUploadParameters.setErrorMessage(FILE_EXIST);
                } else {
                	MyBankLogger.logError(this, UPLOAD_FAIL
							+ processXMlTag(ERROR_MESSAGE, element)
							+ CONTACT_ADMIN);
                    throw new BusinessException(UPLOAD_FAIL
                            + processXMlTag(ERROR_MESSAGE, element)
                            + CONTACT_ADMIN);
                }
            } else {
            	MyBankLogger.logError(this, UPLOAD_FAIL
						+ processXMlTag(ERROR_MESSAGE, element)
						+ CONTACT_ADMIN);
                throw new BusinessException(UPLOAD_FAIL
                        + processXMlTag("ERROR_MESSAGE", element)
                        + CONTACT_ADMIN);
            }
        }
        MyBankLogger.logEnd(this, "Uploading completed : ", System.currentTimeMillis() - startTime);
        return fileUploadParameters;
    }   
    
    /**
     * Method to modify a specific file onto GE library
     * 
     * @param fileId
     * @param fileName
     * @param filePath
     * @return - Returns true if update is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @Override
    public FileUploadParameters updateFileOnLibrary(String fileID,
            String fileName, String filePath, String userId, String appID,
            String appPassword){
    	long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "Start updating file : " + fileName);
        StringBuilder updateXML = new StringBuilder(XML_VERSION)
                .append(CALLAPI_START + METHOD_START + UPDATE_FILE_METHOD
                        + METHOD_END + PARAMETERS_START)
                .append(FILE_ID_START + fileID + FILE_ID_END)
                .append(FILE_NAME_START + fileName + FILE_NAME_END)
                .append(FILE_TITLE_START + fileName + FILE_TITLE_END)
                .append(DESCRIPTION_START + DESCRIPTION_END + EXPIRE_DATE_START
                        + EXPIRE_DATE_END)
                .append(FILE_PATH_START + filePath + FILE_PATH_END)
                .append(ADD_VERSION_START + TRUE + ADD_VERSION_END)
                .append(PARAMETERS_END + CALLAPI_END);
        FileUploadParameters fileUploadParameters = new FileUploadParameters();
        String updateXMLResp = GEFolders.callAPI(updateXML.toString(), userId,
                appID, appPassword);
        Document doc = getXMLDocument(updateXMLResp);
        NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
            	MyBankLogger.logInfo(this,"File updated successfully");
                NodeList subNodes = element
                        .getElementsByTagName(EXTENDED_RESPONSE);
                for (int j = 0; j < subNodes.getLength(); j++) {
                    Element elementSub = (Element) subNodes.item(i);
                    fileUploadParameters.setFileID(processXMlTag(FILE_ID,
                            elementSub));
                    fileUploadParameters.setFileURL(processXMlTag(FILE_URL,
                            elementSub));
                }
            } else {
            	MyBankLogger.logError(this, UPDATE_FAIL
						+ processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
                throw new BusinessException(UPDATE_FAIL
                        + processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
            }
        }
        MyBankLogger.logEnd(this, "Updating completed : ", System.currentTimeMillis() - startTime);
        return fileUploadParameters;
    }

    /**
     * Method downloads specific file from GE library onto given folder
     * location.
     * 
     * @param fileId
     * @param fileName
     * @param downloadFolder
     * @return - Returns true if download is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @Override
    public boolean downloadFileById(String fileId, String fileName,
            String downloadFolder, String userId, String appID,
            String appPassword){
    	long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "Start downlaoding file : " + fileName);
        StringBuilder downloadXML = new StringBuilder(XML_VERSION)
                .append(CALLAPI_START + METHOD_START + DOWNLOAD_FILE_METHOD
                        + METHOD_END + PARAMETERS_START)
                .append(FILE_ID_START + fileId + FILE_ID_END)
                //.append(FILE_NAME_START + fileName.replace("&", "&amp;") + FILE_NAME_END)
                .append(FILE_PATH_START + downloadFolder + FILE_PATH_END)
                .append(PARAMETERS_END + CALLAPI_END);
        String downloadXMLResp = GEFolders.callAPI(downloadXML.toString(), 
                userId, appID, appPassword);
        Document doc = getXMLDocument(downloadXMLResp);
        NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength();) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
            	MyBankLogger.logInfo(this,"File downlaoded successfully");
            	MyBankLogger.logEnd(this, "Download completed : ", System.currentTimeMillis() - startTime);
                return true;
            } else {
            	MyBankLogger.logError(this, DOWNLOAD_FAIL
						+ processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
                throw new BusinessException(DOWNLOAD_FAIL
                        + processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
            }
        }
        MyBankLogger.logEnd(this, "Download completed : ", System.currentTimeMillis() - startTime);
        return false;
    }

    /**
     * Business service to create the sub folder.
     * 
     * @param subFolderName
     * @param parentFolderID
     * @return String
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @Override
    public String createSubFolder(String subFolderName, String parentFolderID,
            String userId, String appID, String appPassword){
    	long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "Start creating folder.");
        String subFolderId = new String();
        StringBuilder createSubFolderXML = new StringBuilder(XML_VERSION)
                .append(CALLAPI_START + METHOD_START + CREATE_FOLDER_METHOD
                        + METHOD_END + PARAMETERS_START)
                .append(FOLDER_NAME_START + subFolderName + FOLDER_NAME_END)
                .append(FOLDER_TITLE_START + subFolderName + FOLDER_TITLE_END)
                .append(FOLDER_ID_START + parentFolderID + FOLDER_ID_END)
                .append(PUBLIC_READ_START + FALSE + PUBLIC_READ_END)
                .append(PUBLIC_WRITE_START + FALSE + PUBLIC_WRITE_END)
                .append(INHERITANCE_START + TRUE + INHERITANCE_END
                        + EXPIRE_DATE_START + EXPIRE_DATE_END)
                .append(PARAMETERS_END + CALLAPI_END);
        String createSubFolderXMLResp = GEFolders.callAPI(
                createSubFolderXML.toString(), userId, appID, appPassword);
        Document doc = getXMLDocument(createSubFolderXMLResp);
        
        NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
            	MyBankLogger.logInfo(this,"Folder created successfully");
                subFolderId = processXMlTag(RESPONSE_TEXT, element);
            } else if (FAILURE.equals(status)) {
                if (processXMlTag(ERROR_CODE, element).equals(ERROR_41142)
                        && processXMlTag(ERROR_MESSAGE, element).equals(
                                NAME_ALREADY_EXIST)) {
                	MyBankLogger.logInfo(this,"Folder is already exist.");
                    subFolderId = NAME_EXIST;
                } else {
                	MyBankLogger.logError(this, CREATE_FOLDER_FAIL
							+ processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
                    throw new BusinessException(CREATE_FOLDER_FAIL
                            + processXMlTag(ERROR_MESSAGE, element)
                            + CONTACT_ADMIN);
                }
            } else {
            	MyBankLogger.logError(this, CREATE_FOLDER_FAIL
						+ processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
                throw new BusinessException(CREATE_FOLDER_FAIL
                        + processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
            }
        }
        MyBankLogger.logEnd(this, "Creating folder is completed : ", System.currentTimeMillis() - startTime);
        return subFolderId;
    }   

    /**
     * Business service to find the folder id.
     * 
     * @param folderName
     * @param defaultFolderId
     * @return String
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @Override
    public String findSubFolder(String folderName, String defaultFolderId,
            String userId, String appID, String appPassword){
    	long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "Start Searching the folder.");
        String id = "";
        StringBuilder findSubFolder = new StringBuilder(XML_VERSION)
                .append(CALLAPI_START + METHOD_START + SEARCH_FOLDER_METHOD
                        + METHOD_END + PARAMETERS_START)
                .append(FOLDER_ID_START + defaultFolderId + FOLDER_ID_END)
                .append(FOLDER_TITLE_START + folderName + FOLDER_TITLE_END)
                .append(RECURSIVE_START + TRUE + RECURSIVE_END)
                .append(PARAMETERS_END + CALLAPI_END);
        String findSubFolderXMLResp = GEFolders.callAPI(
                findSubFolder.toString(), userId, appID, appPassword);
        Document doc = getXMLDocument(findSubFolderXMLResp);
        NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
                NodeList subNodes = element.getElementsByTagName(RESPONSE_TEXT);
                for (int j = 0; j < subNodes.getLength(); j++) {
                    Element elementSub = (Element) subNodes.item(j);
                    NodeList subNodeTree = elementSub
                            .getElementsByTagName(TREE);
                    for (int k = 0; k < subNodeTree.getLength(); k++) {
                        Element elementSubTree = (Element) subNodeTree.item(k);
                        NodeList subNodeBranch = elementSubTree
                                .getElementsByTagName(BRANCH);
                        for (int l = 0; l < subNodeBranch.getLength();) {
                            Element elementSubranch = (Element) subNodeBranch
                                    .item(l);
                            return elementSubranch.getAttribute(ID);
                        }
                    }
                }
            }
        }
        MyBankLogger.logEnd(this, "Searching the folder is completed : ", System.currentTimeMillis() - startTime);
        return id;
    }
    
    /**
     * Business service to find the folder ID.
     * 
     * @param acctReqID
     * @return String
     * @throws DBException
     */
    @Override
    public String getSubFolderID(long acctReqID) throws DBException {
        return fileUploadDao.getSubFolderID(acctReqID);
    }

    /**
     * Business service to get the folder id of duplicate file.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    @Override
    public List<AccountDocument> getFileDetails(String acctReqID)
            throws DBException {
        return fileUploadDao.getFileDetails(acctReqID);
    }

    /**
     * Method to get the file from server path.
     * 
     * @param fileName
     * @param localDirectory
     * @return
     */
    @Override
    public void downloadFileByOutputStream(HttpServletResponse response,
            String fileName, String localDirectory) throws IOException {
        OutputStream outputStream = null;
        String newFileName = FilenameUtils.normalize(fileName);
        String newLocalDirectory = FilenameUtils.normalize(localDirectory);
        File file = new File(newLocalDirectory + newFileName); 
        FileInputStream fileInputStream = new FileInputStream(file);
	    try {
	            MimetypesFileTypeMap mimeTypesMap = new MimetypesFileTypeMap();
	            String mimeType = mimeTypesMap.getContentType(newFileName);
	            if(null != response){
		            response.setContentType(mimeType);
		            response.setHeader(CONTENT_DISPOSITION, ATTACHMENT_FILENAME
		                    + "\"" +  newFileName /*replaceOffendingCharacters(fName)*/ + "\"");
		           
		            outputStream = response.getOutputStream(); 
		        }
	
		            byte[] buffer = new byte[4096];
		            int count = 0;
		            if(null != fileInputStream && null != outputStream){
			            while ((count = fileInputStream.read(buffer)) >= 0) {
			                outputStream.write(buffer, 0, count);
			            
			            } 
		            }
	        } finally {
	           IOUtils.closeQuietly(outputStream);
	           IOUtils.closeQuietly(fileInputStream);
	        }
    }
    

    /**
     * Method to convert XML node value into string value.
     * 
     * @param tagName
     * @param element
     * @return - Returns XML node value as String.
     */
    public String processXMlTag(String tagName, Element element) {
        String text = "";
        NodeList name = element.getElementsByTagName(tagName);
        Element line = (Element) name.item(0);
        text = getCharacterDataFromElement(line);
        return text;
    }

    /**
     * 
     * @param xmlString
     * @return
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    private static Document getXMLDocument(String xmlString){
    	DocumentBuilder db = null;
    	InputSource is = null;
    	try {
    		 DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    	        dbf.setFeature(XML_PARAM_FEATURE, false);
    	        dbf.setFeature(XML_GEN_FEATURE, false);
    	        dbf.setXIncludeAware(false);
    	        dbf.setExpandEntityReferences(false);

    	        db = dbf.newDocumentBuilder();
    	        is = new InputSource();
    	        is.setCharacterStream(new StringReader(xmlString));
    	        return db.parse(is);

		} catch (ParserConfigurationException | SAXException | IOException e) {
			MyBankLogger.logError(FileUploadController.class,"Exception in getting XML Document : "+e);
			throw new SystemException("SystemException : " + e.getMessage());
		}
       
    }

    /**
     * Method to convert XML node value into string value.
     * 
     * @param e
     * @return - Returns XML node value as String.
     */
    public static String getCharacterDataFromElement(Element e) {
        Node child = e.getFirstChild();
        if (child instanceof CharacterData) {
            CharacterData cd = (CharacterData) child;
            return cd.getData();
        }
        return "";
    }

    /**
     * Method to get current date in MM/dd/YYYY format.
     * 
     * @return - Returns formatted date value as String.
     */
    @Override
    public String dateFormatter(String dateFormat) {
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
        Date date = new Date();
        return formatter.format(date.getTime());
    }

    /**
     * Method to get requestType.
     * 
     * @param requestType
     * @return - Returns requestType as text value.
     */
    public String getTextRequestType(String requestType) {
        String textRequestType = "";
        if (requestType.equals(REQUEST_TYPE_OPEN)) {
            textRequestType = OPEN;
        } else if (requestType.equals(REQUEST_TYPE_MODIFY)) {
            textRequestType = MODIFY;
        } else if (requestType.equals(REQUEST_TYPE_CLOSE)) {
            textRequestType = CLOSE;
        }
        return textRequestType;
    }
    
    
    /**
     * Method to delete the file from local directory.
     * 
     * @param file
     * @return - Returns true if file deleted else false.
     */
    @Override
    public boolean deleteLocalFile(File file){
    	if (!(file.isDirectory()))
    	{
    		return file.delete();
    	}
		return false;
    }

    /**
     * Method to get the METADATA information for a file from GE library
     * 
     * @param fileId
     * @param userId
     * @param appID
     * @param appPassword
     * 
     * @return - Returns AccountDocument containing the METADATA information
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    @Override
    public AccountDocument getMetadataForFile(String fileID, String userId, String appID, String appPassword){
        long startTime = System.currentTimeMillis();
        MyBankLogger.logStart(this, "Start getting METADATA for file : " + fileID);
        
        StringBuilder updateXML = new StringBuilder(XML_VERSION)
                .append(CALLAPI_START 
                        + METHOD_START + GET_FILE_METADATA + METHOD_END
                        + PARAMETERS_START)
                .append(FILE_ID_START + fileID + FILE_ID_END)
                .append(PARAMETERS_END + CALLAPI_END);
        
        AccountDocument accountDocument = new AccountDocument();
        String updateXMLResp = GEFolders.callAPI(updateXML.toString(), userId, appID, appPassword);
        Document doc = getXMLDocument(updateXMLResp);
        NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
                NodeList subNodes = element.getElementsByTagName(RESPONSE_TEXT);
                for (int j = 0; j < subNodes.getLength(); j++) {
                    Element response = (Element) subNodes.item(j);
                    NodeList trees = response.getElementsByTagName(TREE);
                    
                    accountDocument = setAccountDocument(accountDocument, trees, fileID);
                }
            } else {
                MyBankLogger.logError(this, DOWNLOAD_METADATA_FAIL
                        + processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
                throw new BusinessException(DOWNLOAD_METADATA_FAIL
                        + processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
            }
        }
        MyBankLogger.logEnd(this, "Getting METADATA for file completed : ", System.currentTimeMillis() - startTime);
        return accountDocument;
    }

    private AccountDocument setAccountDocument(AccountDocument accountDocument,NodeList trees,String fileID){
    	
    	for (int k = 0; k < trees.getLength(); k++) {
            Element elementSubTree = (Element) trees.item(k);
            NodeList leafs = elementSubTree.getElementsByTagName(LEAF);
            for (int l = 0; l < leafs.getLength(); l++) {
                Element leaf = (Element) leafs.item(l);
                if(leaf.getAttribute(ID).equalsIgnoreCase(fileID)) {
                    accountDocument.setFileId(new BigInteger(leaf.getAttribute(ID)));
                    accountDocument.setFolderId(new BigInteger(leaf.getAttribute(FID)));
                    accountDocument.setDocName(processXMlTag(METADATA_LEAF_TEXT, leaf));
                    accountDocument.setDocURL(processXMlTag(METADATA_LEAF_URL, leaf));
                    accountDocument.setModifiedOn(processXMlTag(METADATA_MODIFIED_ON, leaf));
                    
                    NodeList fields = leaf.getElementsByTagName(METADATA_FIELD);
                    for (int m = 0; m < fields.getLength(); m++) {
                        Element field = (Element) fields.item(m);
                        String tagName = processXMlTag(METADATA_NAME, field);
                        if("Document type".equalsIgnoreCase(tagName)) {
                            accountDocument.setDocType(processXMlTag(METADATA_VALUE, field));
                        }
                    }
                }
            }
        }
		return accountDocument;
    }
    /**
     * Method to delete specific file from a given folder
     * 
     * @param folderId
     * @param fileId
     * @param fileName
     * @return - Returns true if delete is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
	@Override
	public boolean deleteFile(User user, String folderId, String fileId,
			String userId, String AppID, String AppPassword){
		long startTime = System.currentTimeMillis();
		MyBankLogger.logStart(this, "Start deleting file : ");
        StringBuilder deleteFileXML = new StringBuilder(XML_VERSION)
                .append(CALLAPI_START + METHOD_START + DELETE_FILE_METHOD
                        + METHOD_END + PARAMETERS_START)
                .append(FOLDER_ID_START + folderId + FOLDER_ID_END)
                .append(FILE_ID_START + fileId + FILE_ID_END)
                .append(PARAMETERS_END + CALLAPI_END);
        String deleteFileXMLResp = GEFolders.callAPI(deleteFileXML.toString(),
                userId, AppID, AppPassword);
        //inactive status of the document in DB
        AccountDocument document = accReqDao.getDocumentByFileId(fileId);
        if(document != null){
	        document.setIsActive("N");
	        accReqDao.updateDocument(user, document);
        }
        
        Document doc = getXMLDocument(deleteFileXMLResp);
        NodeList nodes = doc.getElementsByTagName(RESULT);
        for (int i = 0; i < nodes.getLength();) {
            Element element = (Element) nodes.item(i);
            String status = processXMlTag(RESPONSE_STATUS, element);
            if (SUCCESS.equals(status)) {
            	MyBankLogger.logInfo(this,"File deleted successfully");
            	MyBankLogger.logEnd(this, "Delete file completed : ", System.currentTimeMillis() - startTime);
                return true;
            } else {
            	MyBankLogger.logError(this, DELETE_FAIL
						+ processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
                throw new BusinessException(DELETE_FAIL
                        + processXMlTag(ERROR_MESSAGE, element) + CONTACT_ADMIN);
            }
        }
        MyBankLogger.logEnd(this, "Delete file completed : ", System.currentTimeMillis() - startTime);
        return false;
	}
}