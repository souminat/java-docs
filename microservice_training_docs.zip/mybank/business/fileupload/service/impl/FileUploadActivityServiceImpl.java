package com.ge.treasury.mybank.business.fileupload.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.treasury.mybank.business.fileupload.dao.impl.BulkUploadDao;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

@Service
public class FileUploadActivityServiceImpl implements FileUploadActivityService {

	@Autowired
	BulkUploadDao bulkUploadDao;

	@Override
	public int saveFileUploadActivity(FileUploadActivity fileUploadActivity)throws DBException {
		return bulkUploadDao.saveFileUploadActivity(fileUploadActivity);
	}

	@Override
	public List<FileUploadActivity> getFileUploadActivityDetailsById(Long fileUpldId)throws DBException {
		return bulkUploadDao.getFileUploadActivityDetailsById(fileUpldId);
	}

}
