package com.ge.treasury.mybank.business.fileupload.service.impl;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ELEMENTS;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.BulkUploadError;
import com.ge.treasury.mybank.domain.accountrequest.MDMDetails;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.validations.BulkUploadFileValidator;

@Service
public class BulkUploadValidationServiceImpl
        implements BulkUploadValidationService, BulkApprovalConstants, ValidationConstants {

    @Autowired
    private BulkUploadService bulkUploadService;
    @Autowired
    private MyBankLookupService lookupService;
    @Autowired
    private BulkUploadFileValidator bulkUploadFileValidator;
    
    private int row;
    
    private String upldTypeCode;

    private static final String LE_CODE = "leCode";
    private static final String BUSINESS_PROPERTY = "bussName";
    private static final String BANK_CLASSIFICATION_PROPERTY = "bankClassification";
    private static final String COUNTRY_PROPERTY = "country";
    private static final String CURRENCY_PROPERTY = "currency";
    private static final String BANK_PROPERTY = "bankId";
    private static final String ROUTE_CODE_PROPERTY = "routeCode";
    private static final String ROUTE_TYPE_PROPERTY = "routeCodeType";
    private static final String BRANCH_ID_PROPERTY = "branchID;branchMDMID";
    private static final String ACCOUNT_NUMBER_PROPERTY = "accountNumber;acctNumber";
    private static final String COMPONENT_CODE_PROPERTY = "componentCode";
    private static final String CO_CODE_RJCT_RSN_PROPERTY = "coCodeRejectReason";
    private static final String COMPANY_CODE_PROPERTY = "companyCode";
    private static final String BU_CODE_PROPERTY = "buCode";

    private List<BulkUploadError> errorList = null;

    @Override
    public List<BulkUploadError> goldIdValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) {
        MyBankLogger.logInfo(this, "goldIdValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        String leCode = getDataFromRequest(requestFromUi, mdmRequest, LE_CODE);
        String response = bulkUploadService.validateLE(leCode);
        JSONObject obj = null;

        if (null != StringUtils.trimToNull(response)) {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray data = jsonObject.getJSONArray("elements");
            if (data.length() == 0) {
                errorList.add(addError(requestFromUi.gettCode(), GOLD_ID, INVALID.concat(BLANK_SPACE).concat(GOLD_ID),
                        leCode));
            } else {
                obj = data.getJSONObject(0);
            }
        }
        
        if (!CollectionUtils.isEmpty(errorList) && null == StringUtils.trimToNull(requestFromUi.getLeCode())
                && ("null".equalsIgnoreCase(requestFromUi.getComponentCode())
                        || "null".equalsIgnoreCase(requestFromUi.getCompanyCode()))) {
            errorList.remove(0);
        }

        validateComponentCode(requestFromUi, mdmRequest, obj);
        validateCompanyCode(requestFromUi, mdmRequest);
        MyBankLogger.logInfo(this, "goldIdValidate --> Ended ");

        return errorList;
    }

    @SuppressWarnings("unused")
	@Override
    public List<BulkUploadError> buCodeValidate(BulkApprovalRequest requestFromUi,
            AccountRequest accReqMDM){
    	MyBankLogger.logInfo(this, "buCodeValidate --> Started");
    	errorList = new ArrayList<BulkUploadError>();
    	String companyCode = getDataFromRequest(requestFromUi, accReqMDM, COMPANY_CODE_PROPERTY);
    	String buCode = getDataFromRequest(requestFromUi, accReqMDM, BU_CODE_PROPERTY);
    	
    	checkBuCodeResponse(requestFromUi, errorList);
    	
    	if((null != StringUtils.trimToNull(companyCode)) &&  !"null".equalsIgnoreCase(StringUtils.trimToNull(requestFromUi.getCompanyCode())) && null != StringUtils.trimToNull(requestFromUi.getBuCode())) {
    		errorList.add(addError(requestFromUi.gettCode(), COMPANY_CODE + " - " + BU_CODE, BU_CODE_PRESENT, companyCode + " - " + requestFromUi.getBuCode()));
    	}else if(null == StringUtils.trimToNull(requestFromUi.getCompanyCode()) && null == StringUtils.trimToNull(requestFromUi.getBuCode()) && null == StringUtils.trimToNull(buCode)) {
    		errorList.add(addError(requestFromUi.gettCode(), COMPANY_CODE + " - " + BU_CODE, BU_CODE_ABSENT, requestFromUi.getBuCode()));
    	}
    	
    	businessValidate(requestFromUi, accReqMDM,errorList);
    	
    	MyBankLogger.logInfo(this, "buCodeValidate --> ended");
    	return errorList;
    } 
    
    private void checkBuCodeResponse(BulkApprovalRequest requestFromUi, List<BulkUploadError> errorList) {
    	if(StringUtils.isNotEmpty(requestFromUi.getBuCode())) {
    		String response = bulkUploadService.validateBuCode(requestFromUi.getBuCode());
    	
	    	if(null != StringUtils.trimToNull(response)) {
	    	  JSONObject jsonObject = new JSONObject(response);
	    	  JSONArray data = jsonObject.getJSONArray(ELEMENTS);
	          
	          if (null== data || data.length() == 0) {
	              errorList.add(addError(requestFromUi.gettCode(), BU_CODE, INVALID.concat(BLANK_SPACE).concat(BU_CODE),
	            		  requestFromUi.getBuCode()));
	          } 
	    	}
    	}
    }
    
    ////Set business sub-business from on BU code response
    @SuppressWarnings("null")
	private void setBussSubBuss(BulkApprovalRequest requestFromUi,AccountRequest accReqMDM,String response) {
    	 if(StringUtils.isNotEmpty(response)) {
			 
    		 JSONObject jsonObject = new JSONObject(response);
		     JSONArray data = jsonObject.getJSONArray(ELEMENTS);
			    	  
			   	if (null != data || data.length() != 0) {
			   		
			   		Iterator<Object> itr = data.iterator();
					while (itr.hasNext()) {
						
						JSONObject obj = (JSONObject) itr.next();
						requestFromUi.setBussName(StringHelper.getStringValue(obj.get(MDMConstants.RPTLEVEL1__BU_DESCRIPTION)));
						requestFromUi.setSubBusiness(StringHelper.getStringValue(obj.get(MDMConstants.RPTLEVEL2__BU_DESCRIPTION)));
					} 
						 
			    }
		 }
   	 
    }
    
    private List<BulkUploadError> businessValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest, List<BulkUploadError> errorList) {
        MyBankLogger.logInfo(this, "businessValidate --> Started ");
       
        if(StringUtils.isNotEmpty(requestFromUi.getCompanyCode()) 
        			&& !StringUtils.equalsIgnoreCase("null",requestFromUi.getCompanyCode()) && (StringUtils.isEmpty(requestFromUi.getBuCode()) || "null".equalsIgnoreCase(requestFromUi.getBuCode()))) {
        	String buCode = bulkUploadService.validateCoCodeBuCombination(requestFromUi.getCompanyCode());
        	String response = bulkUploadService.validateBuCode(buCode);
        	setBussSubBuss(requestFromUi, mdmRequest, response);
        	 
        }else if(StringUtils.isNotEmpty(requestFromUi.getBuCode()) && !"null".equalsIgnoreCase(requestFromUi.getBuCode())) {
	        String response = bulkUploadService.validateBuCode(requestFromUi.getBuCode());
	        setBussSubBuss(requestFromUi, mdmRequest, response);
        }
        
        MDMDetails mdmData = new MDMDetails();
        bulkUploadService.loadMDMDetails(mdmData);

        boolean busSubChanged = !StringUtils.isEmpty(requestFromUi.getBussName()) || !StringUtils.isEmpty(requestFromUi.getSubBusiness());

        if (!StringUtils.isEmpty(requestFromUi.getComponentCode()) || busSubChanged) {
            String business = getDataFromRequest(requestFromUi, mdmRequest, BUSINESS_PROPERTY);
            String componentCode = getDataFromRequest(requestFromUi, mdmRequest, COMPONENT_CODE_PROPERTY);
            List<MyBankLookup> lookupTypes = lookupService.getLovsByLookupType("COMPCODE_BUSINESS",
                    ControllersConstants.DEFAULT_LOV_ORDER, ControllersConstants.DEFAULT_DIRECTION);

            Collection<String> businessListNames = lookupTypes.stream().map(lookup -> StringUtils.trimToEmpty(lookup.getDispname())).collect(Collectors.toList());

            businessComponentValid(requestFromUi.gettCode(),businessListNames,business,componentCode);
        }
        MyBankLogger.logInfo(this, "businessValidate --> Ended ");
        return errorList;
    }

    @Override
    public List<BulkUploadError> countryCurrencyValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) {
        MyBankLogger.logInfo(this, "countryCurrencyValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        if (!StringUtils.isEmpty(requestFromUi.getCountry())
                && !bulkUploadService.getAllCountry().contains(requestFromUi.getCountry().toUpperCase())) {
            errorList.add(addError(requestFromUi.gettCode(), BANK_COUNTRY,
                    INVALID.concat(BLANK_SPACE).concat(BANK_COUNTRY), requestFromUi.getBussName()));
        }
        if (!StringUtils.isEmpty(requestFromUi.getCurrency())
                && !bulkUploadService.getAllCurrency().contains(requestFromUi.getCurrency().toUpperCase())) {
            errorList.add(addError(requestFromUi.gettCode(), BANK_CURRENCY,
                    INVALID.concat(BLANK_SPACE).concat(BANK_CURRENCY), requestFromUi.getBussName()));
        }
        MyBankLogger.logInfo(this, "countryCurrencyValidate --> Ended ");
        return errorList;
    }

    @Override
    public List<BulkUploadError> documentValidate(BulkApprovalRequest account, AccountRequest mdmRequest) {
        MyBankLogger.logInfo(this, "documentValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        validateSPBDocument(account, mdmRequest);
        validateBankConfirmation(account);
        validateDocuments(account);
        MyBankLogger.logInfo(this, "documentValidate --> Ended ");
        return errorList;
    }

    @Override
    public List<BulkUploadError> tCodeValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) {
        MyBankLogger.logInfo(this, "tCodeValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        boolean modifyForDivested = null != mdmRequest
                && MDM_ACCT_STATUS_DIVESTED.equalsIgnoreCase(mdmRequest.getRequestStatus());
        boolean reOpenForClosed = null != mdmRequest
        		&& MDM_ACCT_STATUS_CLOSE.equalsIgnoreCase(mdmRequest.getRequestStatus()) && MDM_ACCT_STATUS_OPEN.equalsIgnoreCase(requestFromUi.getAccountStatus());
        Long accountRequestId = bulkUploadFileValidator.isTcodeInflightRequest(requestFromUi);
        if (null != accountRequestId && !BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL.equals(upldTypeCode)) {
            errorList.add(addError(requestFromUi.gettCode(), TCODE,
                    INFLIGHT_REQUEST_MSG.concat(BLANK_SPACE).concat(String.valueOf(accountRequestId)),
                    requestFromUi.gettCode()));
        }
        if (!StringUtils.isEmpty(requestFromUi.gettCode()) && !modifyForDivested
                && !bulkUploadService.isValidTCode(requestFromUi.gettCode()) && !reOpenForClosed) {
            errorList.add(addError(requestFromUi.gettCode(), TCODE, INVALID.concat(BLANK_SPACE).concat(TCODE),
                    requestFromUi.gettCode()));
        }

        validateCashPoolTcode(requestFromUi);

        MyBankLogger.logInfo(this, "tCodeValidate --> Ended ");
        return errorList;
    }

    
    
    @Override
    public List<BulkUploadError> meCodeValidate(BulkApprovalRequest requestFromUi) {
        MyBankLogger.logInfo(this, "meCodeValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        try {
            if (!StringUtils.isEmpty(requestFromUi.getMe())
                    && !bulkUploadFileValidator.isValidMECode(requestFromUi.getMe())) {
                errorList.add(addError(requestFromUi.gettCode(), ME_COLUMN,
                        INVALID.concat(BLANK_SPACE).concat(ME_COLUMN), requestFromUi.getMe()));
            }
        } catch (Exception e) {
            MyBankLogger.logError(this,
                    "Unable to get ME Data in BulkUploadValidationService.meCodeValidate ".concat(e.getMessage()),e);
        }
        MyBankLogger.logInfo(this, "meCodeValidate --> Ended ");
        return errorList;
    }

    @Override
    public List<BulkUploadError> projectNameValidate(BulkApprovalRequest requestFromUi) {
        MyBankLogger.logInfo(this, "projectNameValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        try {
            if (null != StringUtils.trimToNull(requestFromUi.getProjectName()) && !"null".equalsIgnoreCase(requestFromUi.getProjectName()) && ValidationConstants.PROJECT_NOT_FOUND
                    .equals(bulkUploadService.validateProjectName(requestFromUi.getProjectName()))) {
                errorList.add(addError(requestFromUi.gettCode(), TCODE, ValidationConstants.PROJECT_NOT_FOUND,
                        requestFromUi.getProjectName()));
            }
        } catch (JSONException | ParseException ex) {
            MyBankLogger.logError(this, "Unable to get ME Data in BulkUploadValidationService.projectNameValidate  "
                    .concat(ex.getMessage()),ex);
        }
        MyBankLogger.logInfo(this, "projectNameValidate --> Ended ");
        return errorList;
    }

    @Override
    public List<BulkUploadError> accountStatusValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) {
        MyBankLogger.logInfo(this, "accountStatusValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        if (mdmRequest == null) {
            return errorList;
        } else if (MDM_ACCT_STATUS_OPEN.equals(mdmRequest.getRequestStatus())
                && MDM_ACCT_STATUS_ACQUIRED.equals(requestFromUi.getAccountStatus())) {
            errorList.add(addError(requestFromUi.gettCode(), TCODE, ACCOUNT_OPEN, requestFromUi.gettCode()));
        } else if (bulkUploadFileValidator.isModifyDivested(mdmRequest, requestFromUi)) {
            errorList.add(addError(requestFromUi.gettCode(), TCODE, ACCOUNT_DIVESTED, requestFromUi.gettCode()));
        }

        MyBankLogger.logInfo(this, "accountStatusValidate --> Ended ");
        return errorList;
    }

    @Override
    public List<BulkUploadError> bankBranchValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) throws UnsupportedEncodingException
             {
        MyBankLogger.logInfo(this, "bankBranchValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();

        String bankId = getDataFromRequest(requestFromUi, mdmRequest, BANK_PROPERTY);
        String routeCode = getDataFromRequest(requestFromUi, mdmRequest, ROUTE_CODE_PROPERTY);
        String routeType = getDataFromRequest(requestFromUi, mdmRequest, ROUTE_TYPE_PROPERTY);
        String branchId = getDataFromRequest(requestFromUi, mdmRequest, BRANCH_ID_PROPERTY);
        
        bankCountryValidate(requestFromUi,mdmRequest);
        
        validateRouteCode(requestFromUi,bankId,routeCode);
        validateRouteCodeType(requestFromUi,bankId,routeType);
        validateBranchId(requestFromUi,routeCode,routeType,bankId,branchId);
        MyBankLogger.logInfo(this, "bankBranchValidate --> Ended ");
        return errorList;
    }
    
    @Override
    public List<BulkUploadError> accountCombinationValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) throws UnsupportedEncodingException {
        MyBankLogger.logInfo(this, "accountCombinationValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        BulkApprovalRequest account = new BulkApprovalRequest();
        account.settCode(requestFromUi.gettCode());
        account.setCountry(getDataFromRequest(requestFromUi, mdmRequest, COUNTRY_PROPERTY));
        account.setCurrency(getDataFromRequest(requestFromUi, mdmRequest, CURRENCY_PROPERTY));
        account.setRouteCode(getDataFromRequest(requestFromUi, mdmRequest, ROUTE_CODE_PROPERTY));
        account.setBankId(getDataFromRequest(requestFromUi, mdmRequest, BANK_PROPERTY));
        account.setAccountNumber(getDataFromRequest(requestFromUi, mdmRequest, ACCOUNT_NUMBER_PROPERTY));
        List<String> tcodePresent = bulkUploadService.searchAccountCombination(account);
        if (!CollectionUtils.isEmpty(tcodePresent)) {
            errorList.add(addError(requestFromUi.gettCode(), COMBINITAION_COLS, COMBINATION_MSG.concat(BLANK_SPACE).concat(StringUtils.join(tcodePresent,",")), requestFromUi.gettCode()));
        } 
        MyBankLogger.logInfo(this, "accountCombinationValidate --> Ended ");
        return errorList;
    }
    
    /**
     * Validate if component code is valid.
     * If Gold id or business is changed then check with existing component code.
     * 
     * @param requestFromUi
     * @param mdmRequest
     * @param obj
     * @param businessListNames
     * @param businessName
     */
    private void validateComponentCode(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest, JSONObject obj) {
        List<String> compCodeList = getCompanyCodeList(obj);
        if (null != StringUtils.trimToNull(requestFromUi.getComponentCode()) && !"null".equalsIgnoreCase(requestFromUi.getComponentCode())
                && !compCodeList.contains(StringUtils.upperCase(requestFromUi.getComponentCode()))) {
            errorList.add(addError(requestFromUi.gettCode(), COMP_CODE, INVALID.concat(BLANK_SPACE).concat(COMP_CODE),
                    requestFromUi.getComponentCode()));
        } else if (StringUtils.isEmpty(requestFromUi.getComponentCode())
                && !StringUtils.isEmpty(requestFromUi.getLeCode())
                && isInvalidComponentCode(compCodeList,mdmRequest)) {
            errorList.add(addError(requestFromUi.gettCode(), COMP_CODE,
                    COMPONENT_CODE_ERROR_MSG.concat(requestFromUi.getLeCode()), mdmRequest.getComponentCode()));
        }

    }
    
    private boolean isInvalidComponentCode(List<String> compCodeList, AccountRequest mdmRequest){
        return null != mdmRequest
                && !StringUtils.isEmpty(mdmRequest.getComponentCode())
                && !compCodeList.contains(mdmRequest.getComponentCode());
    }
    

    /**
     * Verify if the component code provided is valid. If company code not
     * provided, check if the existing company code matches the new gold Le
     * provided by User.
     * 
     * @param requestFromUi
     * @param mdmRequest
     */
    private void validateCompanyCode(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) {
        String leCode = getDataFromRequest(requestFromUi, mdmRequest, LE_CODE);
        if (!StringUtils.isEmpty(requestFromUi.getCompanyCode()) && !"null".equalsIgnoreCase(requestFromUi.getCompanyCode())
                && !bulkUploadService.isValidCompanyCode(leCode, requestFromUi.getCompanyCode())) {
            errorList.add(addError(requestFromUi.gettCode(), COMPANY_CODE, COMPANY_CODE_ERROR_MSG.concat(leCode),
                    requestFromUi.getCompanyCode()));
        } else if (StringUtils.isEmpty(requestFromUi.getCompanyCode())
                && !StringUtils.isEmpty(requestFromUi.getLeCode()) && isInvalidCompanyCode(requestFromUi, mdmRequest)) {
            errorList.add(addError(requestFromUi.gettCode(), COMPANY_CODE,
                    COMPANY_CODE_ERROR_MSG.concat(requestFromUi.getLeCode()), mdmRequest.getCompanyCode()));
        }

    }
    
    private boolean isInvalidCompanyCode(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest){
        return null != mdmRequest && !StringUtils.isEmpty(mdmRequest.getCompanyCode())
                && !bulkUploadService.isValidCompanyCode(requestFromUi.getLeCode(), mdmRequest.getCompanyCode());
    }

    /**
     * Validate the Bank confirmation document url and if its present in GE
     * LIbrarie
     * 
     * @param account
     */
    private void validateBankConfirmation(BulkApprovalRequest account) {
        if (!StringUtils.isEmpty(account.getBankConfirmation())) {
            if (!bulkUploadFileValidator.isValidURL(account.getBankConfirmation())) {
                errorList.add(addError(account.gettCode(), BANK_CONFIRMATION,
                        INVALID.concat(BLANK_SPACE).concat(DOCUMENTS), account.getBankConfirmation()));
            } else {
                String errorMessage = bulkUploadFileValidator.verifyValidDocument(account.getBankConfirmation());
                if (null != errorMessage) {
                    errorList.add(addError(account.gettCode(), BANK_CONFIRMATION,
                            INVALID.concat(BLANK_SPACE).concat(DOCUMENTS).concat(BLANK_SPACE).concat(errorMessage),
                            account.getBankConfirmation()));
                }
            }
        }

    }

    /**
     * Validate the Document url, Document type and if its present in GE
     * LIbrarie
     * 
     * @param account
     */
    private void validateDocuments(BulkApprovalRequest account) {
        if (!StringUtils.isEmpty(account.getDocumentType()) && StringUtils.isEmpty(account.getDocuments())) {
            errorList.add(addError(account.gettCode(), DOCUMENTS, DOCUMENTS_REQUIRED, account.getDocuments()));
        }

        if (!StringUtils.isEmpty(account.getDocuments())) {
            if (StringUtils.isEmpty(account.getDocumentType())) {
                errorList.add(
                        addError(account.gettCode(), DOCUMENT_TYPE, DOCUMENT_TYPE_REQUIRED, account.getDocumentType()));

            }
            if (!bulkUploadFileValidator.isValidURL(account.getDocuments())) {
                errorList.add(addError(account.gettCode(), DOCUMENTS, INVALID.concat(BLANK_SPACE).concat(DOCUMENTS),
                        account.getDocuments()));
            } else {
                String errorMessage = bulkUploadFileValidator.verifyValidDocument(account.getDocuments());
                if (null != errorMessage) {
                    errorList.add(addError(account.gettCode(), DOCUMENTS,
                            INVALID.concat(BLANK_SPACE).concat(DOCUMENTS).concat(BLANK_SPACE).concat(errorMessage),
                            account.getDocuments()));
                }
            }
        }

    }

    /**
     * Validate the SPB Document and if its present in GE LIbrarie
     * 
     * @param account
     * @param mdmRequest
     */
    private void validateSPBDocument(BulkApprovalRequest account, AccountRequest mdmRequest) {
        if (!StringUtils.isEmpty(account.getSpbDocument())) {
            if (!SPB.equalsIgnoreCase(getDataFromRequest(account, mdmRequest, BANK_CLASSIFICATION_PROPERTY))) {
                errorList.add(addError(account.gettCode(), SPB_DOCUMENT, SPB_ERROR, account.getSpbDocument()));
            }
            if (!bulkUploadFileValidator.isValidURL(account.getSpbDocument())) {
                errorList.add(addError(account.gettCode(), SPB_DOCUMENT, INVALID.concat(BLANK_SPACE).concat(DOCUMENTS),
                        account.getSpbDocument()));
            } else {
                String errorMessage = bulkUploadFileValidator.verifyValidDocument(account.getSpbDocument());
                if (null != errorMessage) {
                    errorList.add(addError(account.gettCode(), SPB_DOCUMENT,
                            INVALID.concat(BLANK_SPACE).concat(DOCUMENTS).concat(BLANK_SPACE).concat(errorMessage),
                            account.getSpbDocument()));
                }
            }
        }

    }
    
    private void validateCashPoolTcode(BulkApprovalRequest requestFromUi) {
        if (!StringUtils.isEmpty(requestFromUi.getCashpoolTCode()) && !"null".equalsIgnoreCase(requestFromUi.getCashpoolTCode())) {
            if (NO_CASH_POOL.equalsIgnoreCase(requestFromUi.getCashpoolTCode())) {
                requestFromUi.setCashpoolTCode(null);
            } else if (!bulkUploadService.isValidTCode(requestFromUi.getCashpoolTCode())) {
                errorList.add(addError(requestFromUi.gettCode(), ACC_POOL_TO_TCODE_COLUMN, ACC_POOL_TO_TCODE_MSG,
                        requestFromUi.getCashpoolTCode()));
            }
        }
    }

    private void bankCountryValidate(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest) {
        String bankId = getDataFromRequest(requestFromUi, mdmRequest, BANK_PROPERTY);
        if (!StringUtils.isEmpty(requestFromUi.getBankId())) {
            String response = bulkUploadService.getMDMBankDetails(requestFromUi.getBankId(), null);
            boolean validMdmId = false;
            if (null != StringUtils.trimToNull(response)) {
                JSONObject jsonObject = new JSONObject(response);
                JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
                if (elements.length() == 0) {
                    errorList.add(addError(requestFromUi.gettCode(), BANK_MDM_ID, INVALID.concat(BLANK_SPACE).concat(BANK_MDM_ID),
                            requestFromUi.getBankId()));
                } else {
                    validMdmId = true;
                }
            }
            String country = getDataFromRequest(requestFromUi, mdmRequest, COUNTRY_PROPERTY);
            if (validMdmId && !bulkUploadFileValidator.isCountryBankMdmValid(requestFromUi.getBankId(), country)) {
                errorList.add(addError(requestFromUi.gettCode(), BANK_MDM_ID, BANK_COUNTRY_MSG, requestFromUi.getBankId()));
            }
        }else if (!StringUtils.isEmpty(requestFromUi.getCountry()) && !bulkUploadFileValidator.isCountryBankMdmValid(bankId, requestFromUi.getCountry())) {
            errorList.add(addError(requestFromUi.gettCode(), BANK_COUNTRY, BANK_COUNTRY_MSG, requestFromUi.getCountry()));
        }
        
    }
    
    private void validateRouteCode(BulkApprovalRequest requestFromUi, String bankId, String routeCode)
            throws UnsupportedEncodingException {
        if ((!StringUtils.isEmpty(requestFromUi.getRouteCode()) || !StringUtils.isEmpty(requestFromUi.getBankId()))
                && !bulkUploadFileValidator.isValidRouteCodeDetails(bankId, routeCode)) {

            errorList.add(
                    addError(requestFromUi.gettCode(), ROUTE_CODE_COL, ROUTE_CODE_MSG, requestFromUi.getRouteCode()));
        }
    }

    private void validateRouteCodeType(BulkApprovalRequest requestFromUi, String bankId, String routeType)
            throws UnsupportedEncodingException {
        if ((!StringUtils.isEmpty(requestFromUi.getRouteCodeType()) || !StringUtils.isEmpty(requestFromUi.getBankId()))
                && !bulkUploadFileValidator.isValidRouteCodeType(bankId, routeType)) {
            errorList.add(addError(requestFromUi.gettCode(), ROUTE_CODE_TYPE_COL, ROUTE_CODE_TYPE_MSG,
                    requestFromUi.getRouteCodeType()));
        }
    }

    private void validateBranchId(BulkApprovalRequest requestFromUi, String routeCode, String routeType, String bankId,
            String branchId) throws UnsupportedEncodingException {

        boolean branchParentChanged = !StringUtils.isEmpty(requestFromUi.getBankId())
                || !StringUtils.isEmpty(requestFromUi.getRouteCode())
                || !StringUtils.isEmpty(requestFromUi.getRouteCodeType());
        if ((!StringUtils.isEmpty(requestFromUi.getBranchID()) || branchParentChanged)
                && !bulkUploadFileValidator.isValidBranchID(bankId, routeCode, routeType, branchId)) {
            errorList
                    .add(addError(requestFromUi.gettCode(), BRANCH_ID_COL, BRANCH_ID_MSG, requestFromUi.getBranchID()));
        }
    }
    
    private void businessComponentValid(String tCode, Collection<String> businessListNames,
            String businessName,String componentCode) {
        if (null != StringUtils.trimToNull(componentCode) && !"null".equalsIgnoreCase(componentCode)
                && !CollectionUtils.isEmpty(businessListNames) && !businessListNames.contains(StringUtils.trimToEmpty(businessName))) {
            errorList.add(addError(tCode, COMP_CODE,
                    INVALID.concat(USAGEOF).concat(BLANK_SPACE).concat(COMP_CODE), componentCode));
        }
        
    }

    @Override
    public List<BulkUploadError> coCodeRejectReasonValidate(BulkApprovalRequest requestFromUi,
            AccountRequest accReqMDM) {
        MyBankLogger.logInfo(this, "coCodeRejectReasonValidate --> Started ");
        errorList = new ArrayList<BulkUploadError>();
        String coCoderejectReason = getDataFromRequest(requestFromUi, accReqMDM, CO_CODE_RJCT_RSN_PROPERTY);

        if ((StringUtils.trimToNull(requestFromUi.getCompanyCode()) == null
                && StringUtils.trimToNull(requestFromUi.getCoCodeRejectReason()) != null)
                && null != accReqMDM
                && StringUtils.trimToNull(accReqMDM.getCompanyCode()) != null) {
            errorList.add(addError(requestFromUi.gettCode(), COMPANY_CODE + " - " + CO_CODE_REJECT_REASON,
                    CO_CODE_PRESENT, requestFromUi.getRouteCodeType()));
        } else if ((StringUtils.trimToNull(requestFromUi.getCompanyCode()) != null
                && StringUtils.trimToNull(requestFromUi.getCoCodeRejectReason()) == null)
                && StringUtils.trimToNull(coCoderejectReason) != null) {

            errorList.add(addError(requestFromUi.gettCode(), COMPANY_CODE + " - " + CO_CODE_REJECT_REASON,
                    COMPANY_CODE_RJCT_RSN_ABSENT, requestFromUi.getCompanyCode()));
        }
        MyBankLogger.logInfo(this, "coCodeRejectReasonValidate --> Ended ");
        return errorList;
    }

    private List<String> getCompanyCodeList(JSONObject obj) {
        List<String> compCodeList = new ArrayList<String>();
        if (null == obj) {
            return compCodeList;
        }
        JSONArray componentCodeArray = obj.getJSONArray("component_codes");
        
        if (componentCodeArray.length() > 0) {
            for (int i = 0; i < componentCodeArray.length(); i++) {
                JSONObject o = componentCodeArray.getJSONObject(i);
                compCodeList.add((String) o.get("component_code"));
            }
        }
        return compCodeList;
    }

    private BulkUploadError addError(String tCode, String column, String errorMsg, String value) {
        BulkUploadError error = new BulkUploadError();

        error.setError(errorMsg);
        error.setValue(value);
        error.setRow(Integer.toString(row));
        error.setColumn(column);
        error.settCode(tCode);

        return error;
    }

    private String getDataFromRequest(BulkApprovalRequest requestFromUi, AccountRequest mdmRequest, String property) {
        String fromUi = "";
        String mdm = "";
        String[] propertyArray = StringUtils.split(property, ";");
        String propertyUi = propertyArray[0];
        String propertyMdm = propertyArray.length > 1 ? propertyArray[1] : propertyArray[0];
        try {
            fromUi = (String) new PropertyDescriptor(propertyUi, BulkApprovalRequest.class).getReadMethod()
                    .invoke(requestFromUi);
            if (null != mdmRequest) {
                mdm = (String) new PropertyDescriptor(propertyMdm, AccountRequest.class).getReadMethod()
                        .invoke(mdmRequest);
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | IntrospectionException ex) {
            MyBankLogger.logError(this,
                    "Error while getting data from request BulkUploadValidationServiceImpl.getDataFromRequest ::"
                            .concat(ex.getMessage()),
                    ex);
        }
        return null != StringUtils.trimToNull(fromUi) ? fromUi : mdm;
    }

    @Override
    public void setRowNumber(int rowNumber) {
        this.row = rowNumber;
        
    }

    @Override
    public void setUpldTypeCode(String upldTypeCode) {
        this.upldTypeCode = upldTypeCode;
    }

}
