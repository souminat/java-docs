package com.ge.treasury.mybank.business.fileupload.dao.impl;

import java.util.List;
import java.util.Map;

import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

public interface BulkUploadDao {

	/**
	 * Save File Upload information
	 * 
	 * @param fileUpload
	 * @param user
	 * @return
	 * @throws DBException
	 */
	public void saveFileUpload(FileUpload fileUpload, User user) throws DBException;

	public FileUpload downloadFile(Long fileUploadId) throws DBException;

	public List<FileUpload> loadProcessingQueueSortBy(BulkApprovalSearchCriteria bulkApprovalSearch) throws DBException;

	public int saveFileUploadActivity(FileUploadActivity fileUploadActivity)throws DBException;

	public List<FileUploadActivity> getFileUploadActivityDetailsById(Long uploadId)throws DBException;
	
	public AccountRequest searchAccountByCombination(Map<String, Object> searchMap)throws DBException;
	
}
