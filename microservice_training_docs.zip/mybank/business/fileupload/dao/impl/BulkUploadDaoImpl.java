package com.ge.treasury.mybank.business.fileupload.dao.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.AccountRequestMapper;
import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.FileUploadMapper;
import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

@Component
public class BulkUploadDaoImpl implements BulkUploadDao {

	@Autowired
	private FileUploadMapper fileUploadMapper;
	
	@Autowired
	private AccountRequestMapper accountRequestMapper;

	@Override
	public void saveFileUpload(FileUpload fileUpload, User user) throws DBException {

		try {
			fileUpload.setCreateDate(new Date());
			fileUpload.setCreateUser(user.getSso());
			fileUpload.setLastUpdateDate(new Date());
			fileUpload.setLastUpdateUser(user.getSso());
			Long fileId = fileUploadMapper.fetchFileUploadNextSeq();
			fileUpload.setFileUpldId(fileId);
			fileUploadMapper.insertFileUpload(fileUpload);

		} catch (Exception e) {
			MyBankLogger.logError(this,"Exception while fetching file upload details");
			throw new DBException(e);
		}

	}

	@Override
	public FileUpload downloadFile(Long fileUploadId) throws DBException {
		try{
		return fileUploadMapper.getFileUploadDetails(fileUploadId);
		}
		catch(Exception e){
			MyBankLogger.logError(this,"Exception while fetching file upload details");
			throw new DBException(e);
		}
		
	}

	@Override
	public List<FileUpload> loadProcessingQueueSortBy(BulkApprovalSearchCriteria bulkApprovalSearch) throws DBException {
		try {
			return fileUploadMapper.loadProcessingQueueSortBy(bulkApprovalSearch);
		}
		catch(Exception e){
			MyBankLogger.logError(this,"Exception while loading processing Queue details");
			throw new DBException(e);
		}
	}

	@Override
	public int saveFileUploadActivity(FileUploadActivity fileUploadActivity)throws DBException {
		try {
			fileUploadActivity.setCreateDate(new Date());
			fileUploadActivity.setLastUpdateDate(new Date());			
			return fileUploadMapper.insertFileUploadActivity(fileUploadActivity);
			
		}	catch(Exception e){
			MyBankLogger.logError(this,"Exception while saving file upload activities");
			throw new DBException(e);
		}
		
	}

	@Override
	public List<FileUploadActivity> getFileUploadActivityDetailsById(Long uploadId)throws DBException {
		try{
		return fileUploadMapper.getFileUploadActivityDetailsById(uploadId);
		}
		catch(Exception e){
			MyBankLogger.logError(this,"Exception while fetching file upload activities");
			throw new DBException(e);
		}
		}

	@Override
	public AccountRequest searchAccountByCombination(Map<String, Object> searchMap)throws DBException {
		try{
		return accountRequestMapper.searchAccountByCombination(searchMap);
		}
		catch(Exception e){
			MyBankLogger.logError(this,"Exception while fetching accountDetails");
			throw new DBException(e);
		}
	}

	}

