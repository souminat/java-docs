package com.ge.treasury.mybank.business.fileupload.dao.impl;

import java.util.List;

import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * @author MyBank Development Team
 * 
 */
public interface FileUploadDao {

    /**
     * Business service to get the folder id of a file.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    public String getSubFolderID(long acctReqID) throws DBException;

    /**
     * Business service to get the file details of duplicate file.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    public List<AccountDocument> getFileDetails(String acctReqID)
            throws DBException;
}
