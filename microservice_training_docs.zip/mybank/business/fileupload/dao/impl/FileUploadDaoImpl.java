package com.ge.treasury.mybank.business.fileupload.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.AccountRequestMapper;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

@Component
public class FileUploadDaoImpl implements FileUploadDao, FileUploadConstants {

    @Autowired
    private AccountRequestMapper accountMapper;

    /**
     * Business service to get the folder id of a file.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    @Override
    public String getSubFolderID(long acctReqID) throws DBException {
        try {
            return accountMapper.getSubfolderID(acctReqID);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(FOLDER_NOT_FOUND);
        }
    }

    /**
     * Business service to get the file details of duplicate file.
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    @Override
    public List<AccountDocument> getFileDetails(String acctReqID)
            throws DBException {
        try {
            return accountMapper.getAllDocuments(acctReqID);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(FILE_NOT_FOUND);
        }
    }

}
