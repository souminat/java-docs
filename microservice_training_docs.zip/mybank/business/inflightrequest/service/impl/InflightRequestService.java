package com.ge.treasury.mybank.business.inflightrequest.service.impl;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;

public interface InflightRequestService {

    /**
     * This method is used to update the inflight request.
     * 
     * accountRequest should contain only fields which are required to update in
     * inflight request.
     * 
     * fileUpload is an optional input field, this is used by modify internal
     * template to update the inflight reuqests.
     * 
     * @param accountRequest
     * @param fileUpload
     */
    void updateInflightRequests(AccountRequest accountRequest, FileUpload fileUpload,AccountRequest accReqMDM);

}
