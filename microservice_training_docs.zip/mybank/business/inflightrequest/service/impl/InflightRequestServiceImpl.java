package com.ge.treasury.mybank.business.inflightrequest.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
@Component
public class InflightRequestServiceImpl implements InflightRequestService {
	
    @Autowired
    private AccountRequestService accountService;

    @Autowired
    private MyBankLookupService lookupService;
    
    private static final String SYSTEM = "System";

    @Override
    public void updateInflightRequests(AccountRequest accountRequest, FileUpload fileUpload, AccountRequest accReqMDM) {
        Long inflightRequest = accountService.getPendingCloseOrModifyByTcode(accountRequest.gettCode());

        if (null != inflightRequest) {

            User systemUser = new User();
            UserProfile profile = new UserProfile();
            List<UserRole> roles = new ArrayList<UserRole>();
            UserRole treasury = new UserRole();
            systemUser.setSso(SYSTEM);
            treasury.setMyBankRole(SYSTEM);
            profile.setSso(SYSTEM);
            roles.add(treasury);
            profile.setRoles(roles);
            systemUser.setUserProfile(profile);
            

            HashMap<String, Object> searchMap = new HashMap<String, Object>();
            searchMap.put(FileUploadConstants.ACCTREQID, inflightRequest);

            AccountRequest accRequest = accountService.findAccount(systemUser, searchMap);
            
            setLeCodeForInflightReq(accReqMDM, accRequest, accountRequest);
            setCoCodeRejectReasonForInflightReq(accReqMDM,accRequest,accountRequest);
            setBuCodeForInflightReq(accReqMDM, accRequest, accountRequest);
            setCompCodeForInflightReq(accRequest,accountRequest);
            
            updateRequestFromUI(accRequest, accountRequest, fileUpload);
            accountService.updateAccountRequestComplete(systemUser, accRequest, false);
        }

    }
    
    //update LE code for the inflight request based on the company code if provided from modify internal template
    private void setLeCodeForInflightReq(AccountRequest accReqMDM,AccountRequest accReqDb, AccountRequest approvalRequestFromUI) {
    	if(StringUtils.isNotEmpty(approvalRequestFromUI.getCompanyCode()) && !StringUtils.equalsIgnoreCase(approvalRequestFromUI.getCompanyCode(), "null")
    						&& !StringUtils.equals(accReqMDM.getLeCode(),accReqDb.getLeCode())) {
    		
    			accReqDb.setLeCode(accReqMDM.getLeCode());
        		accReqDb.setLeName(accReqMDM.getLeName());
        		accReqDb.setLeVersion(accReqMDM.getLeVersion());
    	}
    }
    
    //Set cocodereject reason from Bulk or MDM if inflight request is not having reject reason or Bulk file is having reject reason
    private void setCoCodeRejectReasonForInflightReq(AccountRequest accReqMDM,AccountRequest accReqDb, AccountRequest approvalRequestFromUI) {
    	  if(StringUtils.isNotEmpty(approvalRequestFromUI.getBuCode()) && !checkCoCodeRjctRsnInDb(accReqDb, approvalRequestFromUI)) {
    		  approvalRequestFromUI.setCoCodeRejectReason(StringUtils.defaultIfEmpty(approvalRequestFromUI.getCoCodeRejectReason(), accReqMDM.getCoCodeRejectReason()));  
    	  }
    }
    private boolean checkCoCodeRjctRsnInDb(AccountRequest accReqDb, AccountRequest approvalRequestFromUI) {
    	return StringUtils.isNotEmpty(accReqDb.getCoCodeRejectReason()) 
    				&& StringUtils.isEmpty(approvalRequestFromUI.getCoCodeRejectReason());
    }
   
    //Set bucode, business & sub-business from either Bulk or MDM if cocodereject reason provided from Bulk file and company code present for inflight request
    private void setBuCodeForInflightReq(AccountRequest accReqMDM,AccountRequest accReqDb, AccountRequest approvalRequestFromUI) {
    	if(StringUtils.isNotEmpty(accReqDb.getCompanyCode()) && StringUtils.isNotEmpty(approvalRequestFromUI.getCoCodeRejectReason())) {
    		approvalRequestFromUI.setBuCode(StringUtils.defaultIfEmpty(approvalRequestFromUI.getBuCode(),accReqMDM.getBuCode()));
    		approvalRequestFromUI.setBussName(StringUtils.defaultIfEmpty(approvalRequestFromUI.getBussName(), accReqMDM.getBussName()));
    		approvalRequestFromUI.setSubBusName(StringUtils.defaultIfEmpty(approvalRequestFromUI.getSubBusName(), accReqMDM.getSubBusName()));
    	}
    }
    //set component code to "NULL" for the bulk request pojo compaonent code field value if ineligible bu code is enter from template and inflight request having component code
    private void setCompCodeForInflightReq(AccountRequest accReqDb,AccountRequest approvalRequestFromUI) {
        List<MyBankLookup> lookupTypes = lookupService.getLovsByLookupType("COMPCODE_BUSINESS",
                ControllersConstants.DEFAULT_LOV_ORDER, ControllersConstants.DEFAULT_DIRECTION);

        Collection<String> businessListNames = lookupTypes.stream().map(lookup -> StringUtils.trimToEmpty(lookup.getDispname())).collect(Collectors.toList());

    	if(StringUtils.isNotEmpty(accReqDb.getComponentCode()) && !businessListNames.contains(StringUtils.trimToEmpty(approvalRequestFromUI.getBussName()))) {
    		approvalRequestFromUI.setComponentCode("NULL");
    	}
    }
    
    private void updateRequestFromUI(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            FileUpload fileUpload) {
        DateFormat df = new SimpleDateFormat(ValidationConstants.INFLIGHT_DATE_FORMAT, Locale.ENGLISH);
        String formatedDate = df.format(new Date().getTime());

        StringBuilder changedComments = new StringBuilder();
        changedComments.append("OVERRIDEN-DATA;UserId:");
        changedComments.append(fileUpload.getCreateUser()).append(";");
        changedComments.append("FileId:").append(fileUpload.getFileUpldId()).append(";");
        changedComments.append("Date:").append(formatedDate).append(";");

        checkUpdateAccountTitle(accountRequest, approvalRequestFromUI, changedComments);
        checkUpdateBusinessSubBusiness(accountRequest,approvalRequestFromUI,changedComments);
        checkUpdateCoCodeExceotionReason(accountRequest,approvalRequestFromUI,changedComments);
        checkUpdateComponentCode(accountRequest,approvalRequestFromUI,changedComments);
        checkUpdateBuCode(accountRequest, approvalRequestFromUI, changedComments);
        checkUpdateMe(accountRequest,approvalRequestFromUI,changedComments);
        checkUpdateAccountPurpose(accountRequest,approvalRequestFromUI,changedComments);
        checkUpdateBankClassifcaiton(accountRequest,approvalRequestFromUI,changedComments);
        checkUpdateDocuments(accountRequest,approvalRequestFromUI,changedComments);
        
        AccountComment newComment = new AccountComment();
        newComment.setComments(changedComments.toString());
        accountRequest.getComments().add(newComment);

    }

    private void checkUpdateDocuments(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if(!CollectionUtils.isEmpty(approvalRequestFromUI.getDocuments())){
            for(AccountDocument document:approvalRequestFromUI.getDocuments()){
                changedComments.append("Document Added:").append(document.getDocName()).append(";");
                accountRequest.getDocuments().add(document);
            }
        }
        
    }

    private void checkUpdateAccountTitle(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getAccountTitle())) {
            changedComments.append("Account Title:").append(accountRequest.getAccountTitle()).append("->")
                    .append(approvalRequestFromUI.getAccountTitle()).append(";");
            accountRequest.setAccountTitle(approvalRequestFromUI.getAccountTitle());
        }
        
    }

    private void checkUpdateMe(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getMeCode())) {
            changedComments.append("ME:").append(accountRequest.getMeCode()).append("->")
                    .append(approvalRequestFromUI.getMeCode()).append(";");
            accountRequest.setMeCode(approvalRequestFromUI.getMeCode());
        }
        
    }

    private void checkUpdateComponentCode(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getComponentCode())) {
            changedComments.append("Component Code:").append(defaultIfNull(accountRequest.getComponentCode()))
                    .append("->").append(defaultIfNull(approvalRequestFromUI.getComponentCode())).append(";");
            accountRequest.setComponentCode(defaultIfNull(approvalRequestFromUI.getComponentCode()));
        }
        
    }

    private void checkUpdateBankClassifcaiton(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getBankClassification())) {
            Map<String, String> bankClassificationMap = getLookupMap("NETWORK_TYPE");
            String newBankClassificaiton = getBankClassification(approvalRequestFromUI, bankClassificationMap);
            changedComments.append("Bank Classification:")
                    .append(defaultIfNull(bankClassificationMap.getOrDefault(accountRequest.getBankClassification(),
                            accountRequest.getBankClassification())))
                    .append("->").append(defaultIfNull(approvalRequestFromUI.getBankClassification())).append(";");
            accountRequest.setBankClassification(newBankClassificaiton);
        }
        
    }

    private void checkUpdateAccountPurpose(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getAccountPurpose())) {
            changedComments.append("Account Purpose:")
                    .append(defaultIfNull(accountRequest.getAccountPurpose()))
                    .append("->").append(defaultIfNull(approvalRequestFromUI.getAccountPurpose())).append(";");
            accountRequest.setAccountPurpose(defaultIfNull(approvalRequestFromUI.getAccountPurpose()));
        }
        
    }

    private void checkUpdateCoCodeExceotionReason(AccountRequest accountRequest, AccountRequest approvalRequestFromUI,
            StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getCompanyCode()) 
        		|| null != StringUtils.trimToNull(approvalRequestFromUI.getBuCode())) {
            changedComments.append("Company Code:").append(defaultIfNull(accountRequest.getCompanyCode())).append("->")
                    .append(defaultIfNull(approvalRequestFromUI.getCompanyCode())).append(";");
            accountRequest.setCompanyCode(defaultIfNull(approvalRequestFromUI.getCompanyCode()));
        }
        
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getCoCodeRejectReason())
        		|| null != StringUtils.trimToNull(defaultIfNull(approvalRequestFromUI.getCompanyCode()))) {
            Map<String, String> rejectReasonMap = getLookupMap("CMPNYCD_EXCEPTION_RSN");
            String newRejectReason = getRejectReason(approvalRequestFromUI, rejectReasonMap);
            changedComments.append("Company Code Reject Reason:")
                    .append(defaultIfNull(rejectReasonMap.getOrDefault(accountRequest.getCoCodeRejectReason(),
                            accountRequest.getCoCodeRejectReason())))
                    .append("->").append(defaultIfNull(approvalRequestFromUI.getCoCodeRejectReason())).append(";");
            accountRequest.setCoCodeRejectReason(newRejectReason);
        }
        
    }

    private void checkUpdateBuCode(AccountRequest accountRequest, AccountRequest approvalRequestFromUI, StringBuilder changedComments) {
    	
    	if(null != StringUtils.trimToNull(approvalRequestFromUI.getBuCode())
    			|| null != StringUtils.trimToNull(approvalRequestFromUI.getCompanyCode())) {
    		changedComments.append("BU Code:").append(accountRequest.getBuCode()).append("->")
    				.append(approvalRequestFromUI.getBuCode()).append(";");
    		accountRequest.setBuCode(approvalRequestFromUI.getBuCode());
    	}
    }
    
    private void checkUpdateBusinessSubBusiness(AccountRequest accountRequest, AccountRequest approvalRequestFromUI, StringBuilder changedComments) {
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getBussName())) {
            changedComments.append("Business:").append(accountRequest.getBussName()).append("->")
                    .append(approvalRequestFromUI.getBussName()).append(";");
            accountRequest.setBussName(approvalRequestFromUI.getBussName());
        }
        if (null != StringUtils.trimToNull(approvalRequestFromUI.getSubBusName())) {
            changedComments.append("Sub Business:").append(accountRequest.getSubBusName()).append("->")
                    .append(approvalRequestFromUI.getSubBusName()).append(";");
            accountRequest.setSubBusName(approvalRequestFromUI.getSubBusName());
        }
        
    }

    private String getBankClassification(AccountRequest approvalRequestFromUI,
            Map<String, String> bankClassificationMap) {
        String newBankClassification = approvalRequestFromUI.getBankClassification();
        if (bankClassificationMap.containsValue(approvalRequestFromUI.getBankClassification())) {
            newBankClassification = getKeyFromValue(approvalRequestFromUI.getBankClassification(), bankClassificationMap);
        }
        return newBankClassification;
    }

    private String defaultIfNull(String internalField) {
        return "Null".equalsIgnoreCase(String.valueOf(internalField)) ? "" : internalField;
    }

    private String getRejectReason(AccountRequest approvalRequestFromUI,
            Map<String, String> rejectReasonMap) {
        String newRejectReason = approvalRequestFromUI.getCoCodeRejectReason();
        if (!"Null".equalsIgnoreCase(approvalRequestFromUI.getCompanyCode()) && !StringUtils.isEmpty(approvalRequestFromUI.getCompanyCode())) {
            newRejectReason = "";
        } else if (rejectReasonMap.containsValue(approvalRequestFromUI.getCoCodeRejectReason())) {
            newRejectReason = getKeyFromValue(approvalRequestFromUI.getCoCodeRejectReason(), rejectReasonMap);
        }
        return newRejectReason;
    }

    private String getKeyFromValue(String value, Map<String, String> map) {
        for (Entry<String, String> entry : map.entrySet()) {
            if (Objects.equals(value, entry.getValue())) {
                return entry.getKey();
            }
        }
        return "";
    }

    private Map<String, String> getLookupMap(String lookupType) {
        List<MyBankLookup> lookupTypes = lookupService.getLovsByLookupType(lookupType,
                ControllersConstants.DEFAULT_LOV_ORDER, ControllersConstants.DEFAULT_DIRECTION);
        if (!CollectionUtils.isEmpty(lookupTypes)) {
            return lookupTypes.stream()
                    .collect(Collectors.toMap(MyBankLookup::getLookupCode, MyBankLookup::getDispname));

        }
        return null;
    }

}
