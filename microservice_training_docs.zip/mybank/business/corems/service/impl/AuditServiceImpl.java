/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.corems.service.impl;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;
import com.ge.treasury.mybank.domain.corems.Audit;
import com.ge.treasury.mybank.domain.corems.AuditAttributes;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.AuditHelper;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.web.SanatizedServletRequest;

/**
 * Contains the implementation of AuditService methods Implementation - calling
 * Audit Microservice
 * 
 * @author MyBank Dev Team
 */
@Service
@EnableAsync
public class AuditServiceImpl implements AuditService, ValidationConstants {

	
	@Autowired
	private MyBankLookupService lookupService;

	@Value("${audit.ms.baseUrl}")
	private String auditBaseUrl;

	@Value("${audit.ms.createAudit}")
	private String createAudit;

	@Autowired
	private OAuth2RestOperations msAuditRestTemplate;

	
	private PolicyFactory policy = new HtmlPolicyBuilder().toFactory();
	/**
	 * Method that calls Audit Microservice to be able to insert an audit
	 * 
	 * @throws InterruptedException
	 */
	@Override
	@Async
	public void createAudit(User user, AccountRequest oldObject,
			AccountRequest newObject) throws DBException, InterruptedException {

		// Get display names instead of codes from LOVS on requestType field
		String requestTypeOldValue = null;
		String requestTypeNewValue = null;
		String accountPurposeOldValue = null;
		String accountPurposeNewValue = null;
		String bankClassificationOldValue = null;
		String bankClassificationNewValue = null;

		if (oldObject.getRequestType() != null) {
			requestTypeOldValue = lookupService.getDisplayName(oldObject
					.getRequestType());
			oldObject.setRequestType(requestTypeOldValue);
		}
		if (newObject.getRequestType() != null) {
			requestTypeNewValue = lookupService.getDisplayName(newObject
					.getRequestType());
			newObject.setRequestType(requestTypeNewValue);
		}
		if (newObject.getAccountPurpose() != null) {
			accountPurposeNewValue = lookupService.getDisplayName(newObject
					.getAccountPurpose());
			if (!"".equals(StringUtils.trimToEmpty(accountPurposeNewValue))) {
				newObject.setAccountPurpose(accountPurposeNewValue);
			}
		}
		if (oldObject.getAccountPurpose() != null) {
			accountPurposeOldValue = lookupService.getDisplayName(oldObject
					.getAccountPurpose());
			if (!"".equals(StringUtils.trimToEmpty(accountPurposeOldValue))) {
				oldObject.setAccountPurpose(accountPurposeOldValue);
			}
		}

		if (newObject.getBankClassification() != null) {
			bankClassificationNewValue = lookupService.getDisplayName(newObject
					.getBankClassification());
			if (!"".equals(StringUtils.trimToEmpty(bankClassificationNewValue))) {
				newObject.setBankClassification(bankClassificationNewValue);
			}
		}
		if (oldObject.getBankClassification() != null) {
			bankClassificationOldValue = lookupService.getDisplayName(oldObject
					.getBankClassification());
			if (!"".equals(StringUtils.trimToEmpty(bankClassificationOldValue))) {
				oldObject.setBankClassification(bankClassificationOldValue);
			}
		}
		
		updateLookupCodeForSubType(oldObject,newObject);
		updateLookupCodeForFlags(oldObject,newObject);
		
		sanitizeSignerName(oldObject);
		sanitizeSignerName(newObject);
		
		updateLookupCodeForSigners(oldObject, newObject);
		updateLookupCodeForCoCodeRejectReason(oldObject, newObject);
		updateLookupCodeForCashpool(oldObject, newObject);
		updateLookupCodeForCashpoolProcessCode(oldObject, newObject);
		removeAuditOfPlatform(oldObject,newObject);

		Audit audit = new Audit();
		audit = setAuditDetails(user, oldObject, newObject);

		String json = "";
		ObjectWriter ow = new ObjectMapper().writer()
				.withDefaultPrettyPrinter();
		try {
			json = ow.writeValueAsString(audit);
			MyBankLogger.logDebug(this, "\n\n\n\n" + json + "\n\n\n\n");
			MyBankLogger.logInfo(this, "Json data to be sent to Audit--------->" + "\n\n\n\n " + json + "\n\n\n\n");
			System.out.println("Json data to be sent to Audit--------->" + "\n\n\n\n " + json + "\n\n\n\n");
		} catch (IOException e) {
			MyBankLogger.logError(this, e.getMessage(), e);
		}

		// set headers
		HttpHeaders headers = new HttpHeaders();
		MediaType mediaType = new MediaType("application", "json", StandardCharsets.UTF_16);
		headers.setContentType(/*MediaType.APPLICATION_JSON*/mediaType);
		HttpEntity<String> entity = new HttpEntity<String>(json.toString(),
				headers);

		// Get the response as string
		try {
			ResponseEntity<String> response = msAuditRestTemplate.exchange(
					auditBaseUrl + createAudit, HttpMethod.POST, entity,
					String.class);
			if (response.getStatusCode() != HttpStatus.OK) {
				throw new DBException("Unable to save Audit. For more "
						+ "information please check the log file.");
			} else {
				MyBankLogger.logInfo(this,
						"Audit Created/Stored successfully in DB");
			}
		} catch (HttpClientErrorException e) {
			MyBankLogger.logError(this, "Audit failed ------------------------------>" + e.getResponseBodyAsString());
		}
	}
	
	private void sanitizeSignerName(AccountRequest accReq) {
		List<AccountSigner> signers = accReq.getSigners();
		
		if(!CollectionUtils.isEmpty(signers)) {
			for(AccountSigner signer : signers) {
				signer.setSignerName(sanatize(signer.getSignerName()));
			}
		}
		accReq.setSigners(signers);
	}
	
    private static void removeAuditOfPlatform(AccountRequest oldObject, AccountRequest newObject) {
        if (null != oldObject.getPlatformInstance()) {
            PlatformInstance platformInstance = oldObject.getPlatformInstance();
            platformInstance.setLastUpdateDate(null);
            platformInstance.setLastUpdateUser(null);
            platformInstance.setCreateUser(null);
            platformInstance.setCreateDate(null);
        }
        
        if (null != newObject.getPlatformInstance()) {
            PlatformInstance platformInstance = newObject.getPlatformInstance();
            platformInstance.setLastUpdateDate(null);
            platformInstance.setLastUpdateUser(null);
            platformInstance.setCreateUser(null);
            platformInstance.setCreateDate(null);
        }

    }

	private void updateLookupCodeForCashpoolProcessCode(AccountRequest oldObject, AccountRequest newObject) {
	    if(null != StringUtils.trimToNull(oldObject.getCashPoolProcessCode())){
            String lookupName = lookupService.getDisplayName(oldObject.getCashPoolProcessCode());
            oldObject.setCashPoolProcessCode(!StringUtils.isEmpty(lookupName)?lookupName:oldObject.getCashPoolProcessCode());
        }
        
        if(null != StringUtils.trimToNull(newObject.getCashPoolProcessCode())){
            String lookupName = lookupService.getDisplayName(newObject.getCashPoolProcessCode());
            newObject.setCashPoolProcessCode(!StringUtils.isEmpty(lookupName)?lookupName:newObject.getCashPoolProcessCode());
        }
        
    }

    private void updateLookupCodeForCashpool(AccountRequest oldObject, AccountRequest newObject) {
	    if(!CollectionUtils.isEmpty(oldObject.getCashPoolProcesses())){
            for(CashPoolProcess cashPoolProcess:oldObject.getCashPoolProcesses()){
                String processCode = lookupService.getDisplayName(cashPoolProcess.getCashPoolProcessCode());
                cashPoolProcess.setCashPoolProcessCode(!StringUtils.isEmpty(processCode)?processCode:cashPoolProcess.getCashPoolProcessCode());
                
                String statusCode = lookupService.getDisplayName(cashPoolProcess.getCashPoolStatusCode());
                cashPoolProcess.setCashPoolStatusCode(!StringUtils.isEmpty(statusCode)?statusCode:cashPoolProcess.getCashPoolStatusCode());
            }
        }
        
        if(!CollectionUtils.isEmpty(newObject.getCashPoolProcesses())){
            for(CashPoolProcess cashPoolProcess:newObject.getCashPoolProcesses()){
                String processCode = lookupService.getDisplayName(cashPoolProcess.getCashPoolProcessCode());
                cashPoolProcess.setCashPoolProcessCode(!StringUtils.isEmpty(processCode)?processCode:cashPoolProcess.getCashPoolProcessCode());
                
                String statusCode = lookupService.getDisplayName(cashPoolProcess.getCashPoolStatusCode());
                cashPoolProcess.setCashPoolStatusCode(!StringUtils.isEmpty(statusCode)?statusCode:cashPoolProcess.getCashPoolStatusCode());
            }
        }
        
    }

    private void updateLookupCodeForSubType(AccountRequest oldObject, AccountRequest newObject) {
        if(null != StringUtils.trimToNull(oldObject.getSubtypeCode())){
            String lookupName = lookupService.getDisplayName(oldObject.getSubtypeCode());
            oldObject.setSubtypeCode(!StringUtils.isEmpty(lookupName)?lookupName:oldObject.getSubtypeCode());
        }
        
        if(null != StringUtils.trimToNull(newObject.getSubtypeCode())){
            String lookupName = lookupService.getDisplayName(newObject.getSubtypeCode());
            newObject.setSubtypeCode(!StringUtils.isEmpty(lookupName)?lookupName:newObject.getSubtypeCode());
        }
        
    }

    private void updateLookupCodeForFlags(AccountRequest oldObject, AccountRequest newObject) {
	    if(!CollectionUtils.isEmpty(oldObject.getFlags())){
            for(AccountFlag accountFlag:oldObject.getFlags()){
                String lookupName = lookupService.getDisplayName(accountFlag.getFlagCode());
                accountFlag.setFlagCode(!StringUtils.isEmpty(lookupName)?lookupName:accountFlag.getFlagCode());
            }
        }
	    
	    if(!CollectionUtils.isEmpty(newObject.getFlags())){
            for(AccountFlag accountFlag:newObject.getFlags()){
                String lookupName = lookupService.getDisplayName(accountFlag.getFlagCode());
                accountFlag.setFlagCode(!StringUtils.isEmpty(lookupName)?lookupName:accountFlag.getFlagCode());
            }
        }
        
    }
	
	private void updateLookupCodeForSigners(AccountRequest oldObject, AccountRequest newObject) {
        if(!CollectionUtils.isEmpty(oldObject.getSigners())){
            for(AccountSigner accountSigner:oldObject.getSigners()){
                String lookupName = lookupService.getDisplayName(accountSigner.getSignerType());
                accountSigner.setSignerType(!StringUtils.isEmpty(lookupName)?lookupName:accountSigner.getSignerType());
            }
        }
        
        if(!CollectionUtils.isEmpty(newObject.getSigners())){
            for(AccountSigner accountSigner:newObject.getSigners()){
                String lookupName = lookupService.getDisplayName(accountSigner.getSignerType());
                accountSigner.setSignerType(!StringUtils.isEmpty(lookupName)?lookupName:accountSigner.getSignerType());
            }
        }
        
    }
	
	private void updateLookupCodeForCoCodeRejectReason(AccountRequest oldObject, AccountRequest newObject) {
        if(null != StringUtils.trimToNull(oldObject.getCoCodeRejectReason())){
        	String lookupName = lookupService.getDisplayName(oldObject.getCoCodeRejectReason());
            oldObject.setCoCodeRejectReason(!StringUtils.isEmpty(lookupName)?lookupName:oldObject.getCoCodeRejectReason());
        
        }
        
        if(null != StringUtils.trimToNull(newObject.getCoCodeRejectReason())){
              String lookupName = lookupService.getDisplayName(newObject.getCoCodeRejectReason());
              newObject.setCoCodeRejectReason(!StringUtils.isEmpty(lookupName)?lookupName:newObject.getCoCodeRejectReason());
            
        }
        
    }

    /**
	 * Method to set Main Audit Details
	 * 
	 * @param accRequest
	 * @return
	 */
	private Audit setAuditDetails(User user, AccountRequest oldObject,
			AccountRequest newObject) {

		Audit audit = new Audit();
		audit.setDomain(MYBANK_AUDIT_DOMAIN);
		if (null != newObject) {
			audit.setDomainKey(newObject.getAcctReqID().toString());
		}
		audit.setEntity(MYBANK_AUDIT_ENTITY);
		audit.setTms(new Date());
		if(null != user && "MYBANK_MYFUNDING_JOB".equalsIgnoreCase(StringUtils.defaultString(user.getSso()))){
		    audit.setUserSSO("MYBANK_MYFUNDING_JOB");
		    audit.setUserRole("MYBANK_MYFUNDING_JOB");
		}else if (null != user) {
			audit.setUserRole(user.getUserProfile().getRoles().get(0)
					.getMyBankRole());
			audit.setUserSSO(user.getUserProfile().getSso());
		}
		// Compare Objects
		List<AuditAttributes> attributes;
		try {
			attributes = compareBeans(oldObject, newObject);
			if (null != attributes) {
				for (AuditAttributes aa : attributes) {
					MyBankLogger.logDebug(
							this,
							"Att:" + aa.getAttributeName() + " Old:"
									+ aa.getOldValue() + " New:"
									+ aa.getNewValue());
				}
				audit.setJSONAudit(attributes);
			}
		} catch (JsonParseException e) {
			MyBankLogger.logError(this, "JsonParseException", e);
		} catch (JsonMappingException e) {
			MyBankLogger.logError(this, "JsonMappingException", e);
		} catch (IOException e) {
			MyBankLogger.logError(this, "IOException", e);
		}

		return audit;
	}

	/**
	 * Method to compare OldObject/NewObject and retuns a list with all the
	 * oldvalues/new values from each attribute found
	 * 
	 * @param oldObject
	 * @param newObject
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	private List<AuditAttributes> compareBeans(AccountRequest oldObject,
			AccountRequest newObject) throws JsonParseException,
			JsonMappingException, IOException {
		if (newObject.getClass() != oldObject.getClass()) {
			throw new IllegalArgumentException(
					"The beans must be from the same Class!");
		}

		ObjectMapper om = new ObjectMapper();
		// Object to JSON in String
		String oldObjectStr = om.writeValueAsString(oldObject);
		String newObjectStr = om.writeValueAsString(newObject);

		Map<String, String> beforeMap = (Map<String, String>) (om.readValue(
				oldObjectStr, Map.class));
		Map<String, String> afterMap = (Map<String, String>) (om.readValue(
				newObjectStr, Map.class));

		AuditAttributes auditAttribute = null;
		AuditAttributes auditAttributeOld = null;
		List<AuditAttributes> listAttributes = new ArrayList<AuditAttributes>();
		List<AuditAttributes> listOldAttributes = new ArrayList<AuditAttributes>();

		if (beforeMap.equals(afterMap)) {
			MyBankLogger.logDebug(this, "The JSONS are equals.");
		} else {

			// List with NewValues
			Set<Entry<String, String>> changedEntries = new HashSet<Entry<String, String>>(
					afterMap.entrySet());
			changedEntries.removeAll(beforeMap.entrySet());
			Iterator<Entry<String, String>> iterator = changedEntries
					.iterator();
			// check and set audit Attribute New values
			while (iterator.hasNext()) {
				auditAttribute = new AuditAttributes();

				String value = iterator.next().toString();
				String[] attributes = AuditHelper
						.obtainAttributeFromString(value);
				if (attributes != null && attributes.length > 1) {
					String attributeName = attributes[0];
					String newValue = attributes[1];
					auditAttribute.setAttributeName(attributeName);
					auditAttribute.setNewValue(newValue);
					auditAttribute.setOldValue("");
					listAttributes.add(auditAttribute);
				}
			}

			// List with OldValues
			Set<Entry<String, String>> changedEntriesOld = new HashSet<Entry<String, String>>(
					beforeMap.entrySet());
			changedEntriesOld.removeAll(afterMap.entrySet());
			Iterator<Entry<String, String>> iteratorOld = changedEntriesOld
					.iterator();
			// check and set audit Attribute Old values
			while (iteratorOld.hasNext()) {
				auditAttributeOld = new AuditAttributes();

				String value = iteratorOld.next().toString();

				String[] attributesOld = AuditHelper
						.obtainAttributeFromString(value);
				if (attributesOld != null && attributesOld.length > 1) {
					String attributeName = attributesOld[0];
					String oldValue = attributesOld[1];
					auditAttributeOld.setAttributeName(attributeName);
					auditAttributeOld.setOldValue(oldValue);
					auditAttributeOld.setNewValue("");
					listOldAttributes.add(auditAttributeOld);
				}
			}

			/*// Getting the differences between documents
			String fileName = "";
			Collection<String> fileNewName = new ArrayList<String>();
			Collection<String> fileOldName = new ArrayList<String>();

			// Get documents from new object
			if (newObject.getDocuments() != null
					&& StringUtils.isNotEmpty(newObject.getDocuments()
							.toString()) && !newObject.getDocuments().isEmpty()) {
				for (int i = 0; i < newObject.getDocuments().size(); i++) {
					String file = newObject.getDocuments().get(i).getDocName();
					fileNewName.add(file);
				}
			}
			// Get documents from old object
			if (oldObject.getDocuments() != null
					&& StringUtils.isNotEmpty(oldObject.getDocuments()
							.toString()) && !oldObject.getDocuments().isEmpty()) {
				for (int i = 0; i < oldObject.getDocuments().size(); i++) {
					String file = oldObject.getDocuments().get(i).getDocName();
					fileOldName.add(file);
				}
			}
			fileNewName.removeAll(fileOldName);
			fileName = fileNewName.toString();*/

			/*String ssoUser = null;
			if (newObject.getSigners() != null
					&& StringUtils
							.isNotEmpty(newObject.getSigners().toString())
					&& !newObject.getSigners().isEmpty()) {
				ssoUser = newObject.getLastUpdateUser();
			}*/

			// Get the entire list with old/new values
			listAttributes = AuditHelper.obtainCompleteList(listOldAttributes,
					listAttributes, oldObject.getRequestStatus(),
					newObject.getRequestStatus(), oldObject,
					newObject);
		}
		return listAttributes;
	}
	
	private String sanatize(String name) {
		
		String[] str = StringUtils.split(name," ");
		StringBuilder trimmedName = new StringBuilder();
		for(String tempName : str) {
			trimmedName.append(tempName).append(" ");
		}
		return StringUtils.trim(trimmedName.toString());
	}


}