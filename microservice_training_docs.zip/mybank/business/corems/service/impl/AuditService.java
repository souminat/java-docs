/**
 * Copyright GE
 */
package com.ge.treasury.mybank.business.corems.service.impl;

import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Calling Audit Microservice Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface AuditService {

    /**
     * Method to save an Audit calling Microservice
     * 
     * @param accRequest
     * @return
     * @throws DBException
     * @throws InterruptedException
     */
    public void createAudit(User user, AccountRequest oldObject,
            AccountRequest newObject) throws DBException, InterruptedException;

}
