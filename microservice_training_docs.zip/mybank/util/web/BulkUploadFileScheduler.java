package com.ge.treasury.mybank.util.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.beanio.BeanReader;
import org.beanio.stream.RecordIOException;
import org.beanio.stream.csv.CsvReader;
import org.beanio.stream.csv.CsvWriter;
import org.springframework.stereotype.Controller;

import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.helper.FileUploadHelper;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadActivityService;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.BulkUploadError;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.validations.AccountValidationUtils;
import com.ge.treasury.mybank.util.business.validations.BulkUploadFileValidator;

@Controller
public class BulkUploadFileScheduler implements Runnable {

	private File file;
	private String fileUploadType;
	private BulkUploadFileValidator bulkUploadFileValidator;
	private User user;
	private BulkApprovalService approvalService;
	private FileUploadActivityService fileUploadActivityService;
	private FileUpload fileUpload;
	List<Object> exceptionRecordList = new ArrayList<Object>();
	
	public BulkUploadFileScheduler(File file, String fileUploadType,
			BulkUploadFileValidator bulkUploadFileValidator, User user,
			BulkApprovalService approvalService,FileUploadActivityService fileUploadActivityService,FileUpload fileUpload) {
		super();
		this.file = file;
		this.fileUploadType = fileUploadType;
		this.bulkUploadFileValidator = bulkUploadFileValidator;
		this.user = user;
		this.approvalService = approvalService;
		this.fileUploadActivityService = fileUploadActivityService;
		this.fileUpload =fileUpload;
	}

	public BulkUploadFileScheduler() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public void run() {
		
		
		try {
			String name = fileUpload.getFileName();
			Set<String> tcodeSet = new HashSet<String>();
			Set<String> accountNumbersSet=new HashSet<String>();
			Map<String,Set<String>> duplicateCheckMap=new HashMap<String,Set<String>>();
			duplicateCheckMap.put("tCode", tcodeSet);
			duplicateCheckMap.put("openAccountValidation", accountNumbersSet);
			
			if (name == null || name.matches(ValidationConstants.CSV_REGEX)) {
				if (file.exists()) {
					processBulkFile(duplicateCheckMap, name);
				} else {
					fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
					approvalService.updateFileUploadStatus(fileUpload, user);
					FileUploadActivity fileUploadActivity = 
							createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
					fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
					MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
					MyBankLogger.logError(this, "Failed to upload " + name + " because the file was empty.");
					throw new BusinessException("Failed to upload " + name + " because the file was empty.");
				}
			}
		} catch(Exception e){
			MyBankLogger.logError(this, ExceptionUtils.getFullStackTrace(e));
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
			fileUpload.setComments("System Error Occured :  please check with Support Team for Application logs.");
			approvalService.updateFileUploadStatus(fileUpload, user);
			FileUploadActivity fileUploadActivity = 
					createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
			approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, "Validation Failed", null,null,e,getLastProcessedRow());
			MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
			throw new BusinessException("Failed to upload " + file.getName() + " because the file was empty.");
		}
	
		
		
		
		
	}
	
	
	private void processBulkFile(Map<String,Set<String>> duplicateCheckMap,String name){

		try{
				List<BulkApprovalRequest> accountList = new ArrayList<BulkApprovalRequest>();
				List<BulkUploadError> errorList = new ArrayList<BulkUploadError>();
				List<BulkAccountSigner> bulkSigners=new ArrayList<BulkAccountSigner>(); 
				setFileUploadTypeCode();
				FileInputStream fis = new FileInputStream(FileUploadHelper.clobToFile(fileUpload.getUploadedFile()));
				
				BeanReader reader = CSVFileReader.readCSVFromStream(fis, fileUpload.getUpldTypeCode());
				Object record = null;
				int recordCount = 2;
				while ((record = reader.read()) != null) {
					if (BulkApprovalConstants.BULK_UPLOAD_OPEN_TEMPLATE.equals(reader.getRecordName())) {
						BulkApprovalRequest account = (BulkApprovalRequest) record;
						exceptionRecordList.add(account);
						bulkUploadFileValidator.validateMDMData(duplicateCheckMap, account, fileUpload, errorList,
								recordCount);
						accountList.add(account);
					}
					if (BulkApprovalConstants.BULK_UPLOAD_CLOSE_TEMPLATE.equals(reader.getRecordName())) {
						BulkApprovalRequest account = (BulkApprovalRequest) record;
						exceptionRecordList.add(account);
						bulkUploadFileValidator.validateMDMData(duplicateCheckMap, account, fileUpload, errorList,
								recordCount);
						accountList.add(account);
					}
					if(BulkApprovalConstants.BULK_UPLOAD_MODIFY_TEMPLATE.equals(reader.getRecordName()) || BulkApprovalConstants.BULK_UPLOAD_MODIFY_INTERNAL_TEMPLATE.equals(reader.getRecordName())) {
						BulkApprovalRequest account = (BulkApprovalRequest) record;
						exceptionRecordList.add(account);
						bulkUploadFileValidator.validateMDMData(duplicateCheckMap, account, fileUpload, errorList,
								recordCount);
						accountList.add(account);
					}
					if(BulkApprovalConstants.BULK_UPLOAD_SIGNER_TEMPLATE.equals(reader.getRecordName())) {
						BulkAccountSigner account = (BulkAccountSigner) record;
						account = trimSignerFields(account);
						exceptionRecordList.add(account);
						bulkUploadFileValidator.validateSignerData(account, fileUpload, errorList,
								recordCount);
						bulkSigners.add(account);
					}
					recordCount++;
				
			}
			if(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_SIGNER.equals(fileUpload.getUpldTypeCode())){
				fileUpload.setTotalCount((long) bulkSigners.size());
			}else{
				fileUpload.setTotalCount((long) accountList.size());
			}
			
			
			if (fileUpload.getBulkUploadError().isEmpty()) {
				
				processFileWhenNoError(name, fis);
			
			}else{
				processFileWhenError();
			}
		} catch (IOException e) {
			MyBankLogger.logError(this, ExceptionUtils.getFullStackTrace(e));
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
			fileUpload.setComments("System Error Occured :  please check with Support Team for Application logs.");
			approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, "Validation Failed", null,null,e,getLastProcessedRow());
			approvalService.updateFileUploadStatus(fileUpload, user);
			FileUploadActivity fileUploadActivity = 
					createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
			MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
			MyBankLogger.logError(this, "Failed to upload " + name + " => " + e.getMessage());
			throw new BusinessException("Failed to upload " + name + " => " + e.getMessage());
		}catch(Exception e){
			approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, "Validation Failed", null,null,e,getLastProcessedRow());
			MyBankLogger.logError(this, "Failed to upload " + name + " => " + e);
			throw new BusinessException("Failed to upload " + name + " => " + e.getMessage());
		}
		
	}
	
    private void setFileUploadTypeCode(){
        
        if(AccountValidationUtils.getUploadTypeMap().containsKey(fileUploadType)){
            fileUpload.setUpldTypeCode(AccountValidationUtils.getUploadTypeMap().get(fileUploadType));
        }
		
	}
	
	private void processFileWhenNoError(String name,FileInputStream fis) throws IOException{
		String fileString = "";
		try{
			fileString = FileUploadHelper.fileToClob(file);
			fileUpload.setUploadedFile(fileString);
			fileUpload.setSuccessFile(fileString);
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_PNDG_APPROVAL);
		} catch (IOException e) {
			MyBankLogger.logError(this, "BulkUploadFileScheduler.run:" + e.getMessage(), e);
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
			approvalService.updateFileUploadStatus(fileUpload, user);
			approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, "Validation Failed", null,null,e,null);
			exceptionRecordList.clear();
			approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, "Validation Failed", null,null,e,getLastProcessedRow());
			FileUploadActivity fileUploadActivity = 
					createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
			MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
			throw new BusinessException(e.getMessage());
		}
		
		approvalService.updateFileUploadRecord(fileUpload, user);
		
		
		MyBankLogger.logDebug(this, "Successfully uploaded file => " + name);
		FileUploadActivity fileUploadActivity = 
				createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_SUBMITTED);
		
		MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
		fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
		approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, "Submitted",null,null,null,null);
		fis.close();
		deleteFile();
	}
	
	private void deleteFile(){
		try {
			file.delete();
		} catch (Exception e) {
			MyBankLogger.logError(this, "BulkUploadFileScheduler.run:" + e.getMessage(), e);
		}
	}
	
	private void processFileWhenError() throws IOException{
		CsvReader csvReader = null;
		File tempFile = null;
		File goodFile=null;
		File errorFile=null;
		CsvWriter errorWriter = null;
		CsvWriter goodWriter = null;
		String activityStatus=null;
		String event=null;
		
		Map<String,String> lineToErrorString = new HashMap<String,String>();
		try{
			
		
		for (BulkUploadError error : fileUpload.getBulkUploadError()) {
			String concatErr = "["+error.getColumn()+" / "+error.getError()+" / "+error.gettCode()+" / "+error.getValue()+"]";
			if(lineToErrorString.containsKey(error.getRow())){
				StringBuilder currentError = new StringBuilder(lineToErrorString.get(error.getRow()));
				lineToErrorString.remove(error.getRow());
				currentError.append(" ~ " + concatErr);
				lineToErrorString.put(error.getRow(), currentError.toString());
			}else{
				lineToErrorString.put(error.getRow(), concatErr);
			}
		}
		
		
		//Also update File Details here :
		csvReader = new CsvReader(new FileReader(file));
		tempFile = new File("tempValidation_results.csv");
		goodFile = new File("good.csv");
		errorFile = new File("error.csv");
		
		errorWriter = new CsvWriter(new FileWriter(errorFile));
		goodWriter = new CsvWriter(new FileWriter(goodFile));
		String[] entries = null;
		createGoodAndErrorFiles(csvReader, errorWriter, goodWriter, entries, lineToErrorString);
		
		goodWriter.close();
		errorWriter.close();
		
		if(isValidFiles(file,goodFile,errorFile)){
			updateFileWithErrorDetails(tempFile,lineToErrorString);
			
		}
		else{
			throw new BusinessException("Unable to split the file into good and error files");
		}
	
		if(lineToErrorString.size()==fileUpload.getTotalCount()){
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED);
		    activityStatus=BulkApprovalConstants.FILEUPLOADACT_VALIDATION_FAILED;
		    event="Validation Failed";
		    goodFile=null;
		}
		else{
			 fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_PNDG_APPROVAL);					
			 fileUpload.setSuccessFile(FileUploadHelper.fileToClob(goodFile));
			  activityStatus=BulkApprovalConstants.FILEUPLOADACT_SUBMITTED;
			    event="Submitted";
			
		}
		fileUpload.setUploadedFile(FileUploadHelper.fileToClob(tempFile));
		fileUpload.setErrorFile(FileUploadHelper.fileToClob(errorFile));
	

	
	approvalService.updateFileUploadRecord(fileUpload, user);
		
		FileUploadActivity fileUploadActivity = 
				createFileUploadActivity(fileUpload, user, activityStatus);
		
		MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
		fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
		approvalService.sendFileUploadProcessdNotification(fileUpload, user, 0, event,goodFile,errorFile,null,null);

		}finally{
			
			try{
				
				if(csvReader!=null){
					csvReader.close();				
					}
				if(goodWriter!=null){
					goodWriter.close();			
					}
				if(errorWriter!=null){
					errorWriter.close();	
					}
				FileUtils.deleteQuietly(tempFile);
				FileUtils.deleteQuietly(goodFile);
				FileUtils.deleteQuietly(errorFile);
				}
				catch (IOException e) {
					MyBankLogger.logError(this, "BulkUploadFileScheduler.run:" + e.getMessage(), e);
				}
				
			
		}
		}
	private void createGoodAndErrorFiles(CsvReader csvReader,CsvWriter errorWriter,CsvWriter goodWriter,String[] entries,Map<String,String> lineToErrorString) throws RecordIOException, IOException{
		while ((entries = csvReader.read()) != null) {
		    List<String> list = new ArrayList<String>(Arrays.asList(entries));
		    if(csvReader.getRecordLineNumber()==1){
		    	goodWriter.write(list.toArray(new String[list.size()]));
		    	errorWriter.write(list.toArray(new String[list.size()]));
		    }else{
		    	writeToFile(csvReader, errorWriter, goodWriter, list, lineToErrorString);
		    }
		 
		   
		}
	}
	
	private void writeToFile(CsvReader csvReader,CsvWriter errorWriter,CsvWriter goodWriter,List<String> list,Map<String,String> lineToErrorString) throws IOException{
		// Add error message
    	if(null == lineToErrorString.get(String.valueOf(csvReader.getRecordLineNumber()))){
    		goodWriter.write(list.toArray(new String[list.size()]));
    		    		
    	}else{
    		errorWriter.write(list.toArray(new String[list.size()]));
    	}
	}
	private void updateFileWithErrorDetails(File tempFile, Map<String,String> lineToErrorString) {
		CsvReader csvReader = null;
		CsvWriter writer = null;
		CsvWriter errorWriter = null;
			
		
		try{
			
	
		csvReader = new CsvReader(new FileReader(file));
		File newErrorFile = new File("error.csv");
		
		writer = new CsvWriter(new FileWriter(tempFile));
		errorWriter = new CsvWriter(new FileWriter(newErrorFile));
		
		String[] entries = null;
		while ((entries = csvReader.read()) != null) {
		    List<String> list = new ArrayList<String>(Arrays.asList(entries));
		   
		    if(csvReader.getRecordLineNumber()==1){
		    	list.add("Error Details"); // Add the new element here
		    	errorWriter.write(list.toArray(new String[list.size()]));
		    }else{
		    	// Add error message
		    	if(null == lineToErrorString.get(String.valueOf(csvReader.getRecordLineNumber()))){
		    		list.add("");
		    		
		    	}else{
		    		list.add(lineToErrorString.get(String.valueOf(csvReader.getRecordLineNumber()))); // Add the new element here
		    		errorWriter.write(list.toArray(new String[list.size()]));
		    	}
		    	
		    }
		    writer.write(list.toArray(new String[list.size()]));
		   
		}
		}
		catch(Exception e){
			MyBankLogger.logError(this, "BulkUploadFileScheduler.run:" + e.getMessage(), e);
		}
		finally{
			
			try {
				   if(csvReader!=null){
					csvReader.close();
				    }
		        	if(writer!=null){
					writer.close();
		    	}
					if(errorWriter!=null){
						errorWriter.close();
					}
				} catch (IOException e) {
					MyBankLogger.logError(this, "BulkUploadFileScheduler.run:" + e.getMessage(), e);
				}
			}
			
			
		}
	

	private boolean isValidFiles(File tempFile, File goodFile, File errorFile) throws IOException{
		boolean flag=false;
		long  currentTime=System.currentTimeMillis();
		MyBankLogger.logInfo(this,"Start time for file good and bad file validation:"+ currentTime);
		MyBankLogger.logInfo(this,"Total number of records:"+ fileUpload.getTotalCount());
		MyBankLogger.logInfo(this,"File Name:"+ fileUpload.getFileName());
		if(isFileHeaderContentTextCountValid(tempFile,goodFile,errorFile)){
		        /*
		         * Commented the is sun file comparision as it was failing when records contains double quotes
		         * 		
		&&CSVFileReader.isSubFile(tempFile, goodFile)&&CSVFileReader.isSubFile(tempFile, errorFile)*/
			flag=true;
		}
		MyBankLogger.logInfo(this,"Total time taken to validate the file split:"+(System.currentTimeMillis()-currentTime));	
		return flag;
	}
	private boolean isFileHeaderContentTextCountValid(File tempFile, File goodFile, File errorFile) throws IOException{
		boolean flag=false;
		long  currentTime=System.currentTimeMillis();
		MyBankLogger.logInfo(this,"Start time for file Header and Content validation:"+ currentTime);
		if(CSVFileReader.getFileHeaderTextCount(tempFile)==CSVFileReader.getFileHeaderTextCount(errorFile) &&
			 CSVFileReader.getFileHeaderTextCount(tempFile)==CSVFileReader.getFileHeaderTextCount(goodFile)&&
                CSVFileReader.getStreamRecordCount(FileUploadHelper.fileToClob(tempFile),
                        fileUpload.getUpldTypeCode()) == (CSVFileReader.getStreamRecordCount(FileUploadHelper.fileToClob(errorFile),
                                fileUpload.getUpldTypeCode())
                                + CSVFileReader.getStreamRecordCount(FileUploadHelper.fileToClob(goodFile),
                                        fileUpload.getUpldTypeCode()))
				){
			flag=true;
		}
		MyBankLogger.logInfo(this,"Total time taken to validate Header and content:"+(System.currentTimeMillis()-currentTime));	
		return flag;
		
	}
	

	private BulkAccountSigner trimSignerFields(BulkAccountSigner signer){
		
		signer.settCode(StringUtils.trim(signer.gettCode()));
		signer.setSignerAction(StringUtils.trim(signer.getSignerAction()));
		signer.setSignerType(StringUtils.trim(signer.getSignerType()));
		signer.setSignerName(StringUtils.trim(signer.getSignerName()));
		signer.setSsoId(StringUtils.trim(signer.getSsoId()));
		signer.setSignerStartDate(StringUtils.trim(signer.getSignerStartDate()));
		signer.setSignerEndDate(StringUtils.trim(signer.getSignerEndDate()));
		signer.setDocURL(StringUtils.trim(signer.getDocURL()));
		
		return signer;
		
	}
	
	protected FileUploadActivity createFileUploadActivity(FileUpload fileUpload, User user, String status){
    	FileUploadActivity fileUploadActivity = new FileUploadActivity();
    	fileUploadActivity.setFileUpldId(fileUpload.getFileUpldId());
		fileUploadActivity.setStatusCode(status);
		fileUploadActivity.setComments(fileUpload.getComments());
		fileUploadActivity.setCreateUser(user.getSso());
		fileUploadActivity.setLastUpdateUser(user.getSso());
		fileUploadActivity.setUserRole(user.getUserProfile().getRoles().get(0).getMyBankRole());
    	return fileUploadActivity;
    }
	
	private Object getLastProcessedRow() {
        if(!CollectionUtils.isEmpty(exceptionRecordList)){
            return exceptionRecordList.get(exceptionRecordList.size() - 1);
        }
        return null;
    }
	
	
}