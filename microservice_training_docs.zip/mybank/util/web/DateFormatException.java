/**
 * 
 */
package com.ge.treasury.mybank.util.web;

/**
 * @author MyBank Team
 * 
 */
public class DateFormatException extends Exception {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    public DateFormatException(String msg) {
        super(msg);
    }

}
