package com.ge.treasury.mybank.util.web;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.beanio.BeanReader;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadActivityService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.validations.MessageValidator;
import com.ge.treasury.mybank.web.controllers.BaseController;

@Controller
public class BulkUploadSignerProcessScheduler extends BaseController implements Runnable {

	private FileUpload fileUpload;
	private User user;
	private BulkApprovalService bulkApprovalService;
	private AccountRequestService accountService;
	private FileUploadActivityService fileUploadActivityService;
	private String accntUrl;
	private static final Map<String,String> MODIFY_SUB_TYPE_MAP = new HashMap<String,String>();
	
	public BulkUploadSignerProcessScheduler() {
        //Default arg constructor
    }

	public BulkUploadSignerProcessScheduler(FileUpload fileUpload, User user, BulkApprovalService bulkApprovalService,
			AccountRequestService accountService,
			FileUploadActivityService fileUploadActivityService, MyBankLookupService lookupService,
			MDMService mdmService, MessageValidator messageValidator,BulkUploadService bulkUploadService,String accntUrl) {
		super();
		this.fileUpload = fileUpload;
		this.user = user;
		this.bulkApprovalService = bulkApprovalService;
		this.accountService = accountService;
		this.fileUploadActivityService = fileUploadActivityService;
		this.lookupService = lookupService;
		this.mdmService = mdmService;
		this.messageValidator = messageValidator;
		this.accntUrl=accntUrl;
	
	}
	
	static{
	    MODIFY_SUB_TYPE_MAP.put(BulkApprovalConstants.SIGNER_ACTION_REMOVE, BulkApprovalConstants.SIGNER_SUB_TYPE_REMOVAL);
	    MODIFY_SUB_TYPE_MAP.put(BulkApprovalConstants.SIGNER_ACTION_ADD, BulkApprovalConstants.SIGNER_SUB_TYPE_ADDITION);
	}


	@Override
	public void run() {
		FileUpload fileUploadResult = null;
		byte uploadedFileStream[] = null;
		BeanReader reader = null;
		List<BulkAccountSigner> bulkAccountSignerList = null;
		ByteArrayInputStream bis = null;
		Object record = null;
		Date today = new Date();
		Map<Long, List<String>> errorMap = new HashMap<Long, List<String>>();
		String failureReason = null;

		try {

			fileUploadResult = bulkApprovalService.getFileUploadDetails(fileUpload.getFileUpldId());
			uploadedFileStream = fileUploadResult.getSuccessFile().getBytes();
			fileUpload.setAcceptedCount(CSVFileReader.getStreamRecordCount(fileUploadResult.getSuccessFile(),fileUploadResult.getUpldTypeCode()));
			bis = new ByteArrayInputStream(uploadedFileStream);
			reader = CSVFileReader.readCSVFromStream(bis, fileUploadResult.getUpldTypeCode());

			bulkAccountSignerList = new ArrayList<BulkAccountSigner>();

			while ((record = reader.read()) != null) {
				BulkAccountSigner bulkAccountSinger = (BulkAccountSigner) record;
				bulkAccountSinger = trimSignerFields(bulkAccountSinger);
				
				ignoreSSOForNonSSO(bulkAccountSinger);
				
				bulkAccountSinger.setFileUploadId(fileUpload.getFileUpldId());
				bulkAccountSinger.setCreateDate(today);
				bulkAccountSinger.setLastUpdateDate(today);
				bulkAccountSinger.setCreateUser(user.getSso());
				bulkAccountSinger.setLastUpdateUser(user.getSso());

				updateSignerList(bulkAccountSinger,bulkAccountSignerList,reader);
			}

			if (!CollectionUtils.isEmpty(bulkAccountSignerList)) {
				
				bulkApprovalService.insertSignerStageRecords(bulkAccountSignerList);

			
				FileUploadActivity fileUploadActivity = createFileUploadActivity(fileUpload, user,
						BulkApprovalConstants.FILEUPLOADACT_APPROVED);
				fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);

				fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_APPROVED);
				fileUpload.setLastUpdateDate(today);
				fileUpload.setLastUpdateUser(user.getSso());
				bulkApprovalService.updateFileUploadStatus(fileUpload, user);

				
				
				for(BulkAccountSigner bulkAccountSinger : bulkAccountSignerList){
					getSignerDocumentMetadata(bulkAccountSinger, errorMap);
				}

				prepareUpdateAccountSignerList(bulkAccountSignerList, errorMap);

				String fileUploadStatus = "FILEUPLOADACT_SUCCESS";
				if (bulkAccountSignerList.size() == errorMap.size()) {
					fileUploadStatus = "FILEUPLOADACT_FAILURE";
                } else if ((bulkAccountSignerList.size() > errorMap.size() && errorMap.size() > 0)
                        || !StringUtils.isEmpty(fileUploadResult.getErrorFile())) {
                    fileUploadStatus = "FILEUPLOADACT_PARTIAL";
                }
				fileUploadActivity = new FileUploadActivity();
				fileUploadActivity = createFileUploadActivity(fileUpload, user, fileUploadStatus);
				fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);

				fileUpload.setUpldStatusCode(fileUploadStatus);
				fileUpload.setLastUpdateDate(today);
				fileUpload.setLastUpdateUser(user.getSso());
				bulkApprovalService.updateFileUploadStatus(fileUpload, user);

				bulkApprovalService.updateSignersStageRecords(bulkAccountSignerList, errorMap, user, today);
				
				sendBulkNotification(errorMap);
			}
		
		}catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			failureReason = BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " Unable to process the record -"
					+ e.getMessage();
			updateFailureStatus(failureReason);
			throw new BusinessException("Internal Server Error : " + e.getMessage());
		} finally {
			try {
				if(null != bis && null != reader){
					bis.close();
					reader.close();
				}
			} catch (IOException e) {
				MyBankLogger.logError(this, e.getMessage(), e);
			}
		}
	}
	
	@SuppressWarnings("deprecation")
    private void updateSignerList(BulkAccountSigner bulkAccountSinger, List<BulkAccountSigner> bulkAccountSignerList, BeanReader reader) {
	    if (BulkApprovalConstants.BULK_UPLOAD_SIGNER_TEMPLATE.equals(reader.getRecordName())) {
            if (!StringUtils.isEmpty(bulkAccountSinger.getSignerStartDate())) {
                bulkAccountSinger.setSignerStartDate1(new Date(bulkAccountSinger.getSignerStartDate()));
            }
            if (BulkApprovalConstants.SIGNER_ACTION_REMOVE
                    .equalsIgnoreCase(bulkAccountSinger.getSignerAction())) {
                bulkAccountSinger.setSignerEndDate1(new Date(bulkAccountSinger.getSignerEndDate()));
            }
            bulkAccountSignerList.add(bulkAccountSinger);
        }
    }

    private void ignoreSSOForNonSSO(BulkAccountSigner bulkAccountSinger) {
	  //Ignore SSO column for NON SSO signer type
        if(!StringUtils.isEmpty(bulkAccountSinger.getSsoId()) && BulkApprovalConstants.SIGNER_TYPE_NON_SSO
                .equalsIgnoreCase(bulkAccountSinger.getSignerType())){
            bulkAccountSinger.setSsoId(null);           
        }
    }

    private void getSignerDocumentMetadata(BulkAccountSigner bulkAccountSinger,Map<Long, List<String>> errorMap) {
		String fileId = "";
		List<String> errorList = null;
		String url = bulkAccountSinger.getDocURL();
		
		if (!url.isEmpty()) {
			Map<String, String> map;
			try {
				map = StringHelper.splitQuery(new URL(url));
				if (map.containsKey(BulkApprovalConstants.FILE_ID)) {
					fileId = map.get(BulkApprovalConstants.FILE_ID);
				}
				AccountDocument document = bulkApprovalService.getMetadataForFile(fileId);
				bulkAccountSinger.setDocName(document.getDocName());
				bulkAccountSinger.setFolderId(document.getFolderId());
				bulkAccountSinger.setFileId(BigInteger.valueOf(Long.parseLong(fileId)));

			} catch (UnsupportedEncodingException | MalformedURLException e) {
				MyBankLogger.logError(this, "Error in Decoding the Document URL" + e.getMessage(), e);
				throw new SystemException(e);
			} catch(Exception e){
				MyBankLogger.logError(this, "BulkUploadSignerProcessScheduler.run:" + e.getMessage(), e);
				errorList = new ArrayList<String>();
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " Unable to get document metadata -"
						+ e.getMessage());
				errorMap.put(bulkAccountSinger.getStgId(), errorList);
			}
		}
	}

	private BulkAccountSigner trimSignerFields(BulkAccountSigner signer){
		
		signer.settCode(StringUtils.trim(signer.gettCode()));
		signer.setSignerAction(StringUtils.trim(signer.getSignerAction()));
		signer.setSignerType(StringUtils.trim(signer.getSignerType()));
		signer.setSignerName(StringUtils.trim(signer.getSignerName()));
		signer.setSsoId(StringUtils.trim(signer.getSsoId()));
		signer.setSignerStartDate(StringUtils.trim(signer.getSignerStartDate()));
		signer.setSignerEndDate(StringUtils.trim(signer.getSignerEndDate()));
		signer.setDocURL(StringUtils.trim(signer.getDocURL()));
		
		return signer;
		
	}
	private void prepareUpdateAccountSignerList(List<BulkAccountSigner> sourceList, Map<Long, List<String>> errorMap) {

		Map<String, Object> searchMap = null;
		List<String> errorList = null;
		for (BulkAccountSigner source : sourceList) {
			AccountRequest accReq=null;
			try {
				if (!errorMap.containsKey(source.getStgId())) {
					searchMap = new HashMap<String, Object>();
					searchMap.put("tCode", source.gettCode());
					searchMap.put("orderBy", "ACCOUNT_REQUEST_ID");
					searchMap.put("direction","DESC");
					accReq = accountService.findAccountFromMDM(source.gettCode(),accntUrl,false);
					Long accountRequestId = accountService.getPendingCloseOrModifyByTcode(accReq.gettCode());
					
					if (null == accReq) {
						errorList = new ArrayList<String>();
						errorList.add(BulkApprovalConstants.BULK_UPLOAD_VALIDATION_ERR + " Invalid TCode -"
								+ source.gettCode());
						errorMap.put(source.getStgId(), errorList);
					}else if(null != accountRequestId){
						errorList = new ArrayList<String>();
						errorList.add(BulkApprovalConstants.BULK_UPLOAD_VALIDATION_ERR + " There is already an inflight request for this account. Please complete the pending request No. -"
								+ accountRequestId);
						errorMap.put(source.getStgId(), errorList);
					}else{
						
						accReq.setPlatformInstance(getPlatformInstance(accReq.gettCode()));
						
						if(accReq.getAcctReqID()==null){
							accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_MODIFY);
							accReq.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
							accReq.setSubtypeCode(MODIFY_SUB_TYPE_MAP.getOrDefault(StringUtils.upperCase(source.getSignerAction()), "MODIFY_REASON_O"));
							
							AccountRequest accReqDB=this.accountService.createAccountRequestForBulkUpload(user, accReq,
									fileUpload.getUpldTypeCode());
							accReq.setAcctReqID(accReqDB.getAcctReqID());
						}
						accReq.settCode(source.gettCode());
						source.setAcctReqID(accReq.getAcctReqID());

						String lookupType = getLookUpType(source);

						AccountSigner accountSinger = null;
						if (!BulkApprovalConstants.SIGNER_ACTION_ADD.equalsIgnoreCase(source.getSignerAction())) {
							accountSinger = prepareSignersForModifyOrRemove(accReq, source, errorMap);
							
						} else {
							String sso = source.getSsoId();
							if(source.getSignerType().toUpperCase().contains("COMPANY")
									|| source.getSignerType().toUpperCase().contains("FACSIMILE")){
								sso = "";
							}
							accountSinger = new AccountSigner(sso, lookupType, source.getSignerName(),
									source.getSignerStartDate1(), source.getSignerEndDate1(), source.getAcctReqID(),
									null, source.getDocName(), source.getFolderId(), source.getFileId(),
									source.getDocURL());
						}
						setErrListWhenSignerNotNull(accountSinger, accReq, source);
					}
				}

			} catch (Exception e) {
				MyBankLogger.logError(this, "BulkUploadSignerProcessScheduler.prepareUpdateAccountSignerList:" + e.getMessage(), e);
				errorList = new ArrayList<String>();
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " Unable to process the record - "
						+ e.getMessage());
				errorMap.put(source.getStgId(), errorList);

			}
		}

	}

	private String getLookUpType(BulkAccountSigner source){
		
		String lookupType = "";
		if (BulkApprovalConstants.SIGNER_TYPE_SSO.equalsIgnoreCase(source.getSignerType())) {
			lookupType = "ACCTREQSIGNERTYPE_SSO";
		} else if (BulkApprovalConstants.SIGNER_TYPE_FACSIMILE
				.equalsIgnoreCase(source.getSignerType())) {
			lookupType = "ACCTREQSIGNERTYPE_FACSIMILE";
		} else if (BulkApprovalConstants.SIGNER_TYPE_PERSONAL_CHOP
				.equalsIgnoreCase(source.getSignerType())) {
			lookupType = "ACCTREQSIGNERTYPE_PERSONCHOP";
		} else if (BulkApprovalConstants.SIGNER_TYPE_COMPANY_CHOP
				.equalsIgnoreCase(source.getSignerType())) {
			lookupType = "ACCTREQSIGNERTYPE_COMPCHOP";
		}else if(BulkApprovalConstants.SIGNER_TYPE_NON_SSO
				.equalsIgnoreCase(source.getSignerType())){
			lookupType = "ACCTREQSIGNERTYPE_NON-SSO";
		}
		return lookupType;
	}

	private AccountSigner prepareSignersForModifyOrRemove(AccountRequest accReq,BulkAccountSigner source,Map<Long, List<String>> errorMap){
		
		
		boolean signerFlag = false;
		boolean expiredSigner = false;
		AccountSigner accountSinger = null;
		
		String lookupType = getLookUpType(source);
		
		for (AccountSigner signer : accReq.getSigners()) {
			
			if ((source.getSignerType().toUpperCase().contains("SSO") || source.getSignerType().toUpperCase().contains("PERSONAL"))&& (source.getSsoId() != null
					&& source.getSsoId().equalsIgnoreCase(signer.getSsoId())
					&& lookupType.equalsIgnoreCase(signer.getSignerType()))
					&& signer.getSignerEndDate() == null)	{
				String activeStr = "";

				activeStr = source.getSignerEndDate1() != null ? ValidationConstants.FLAG_STATUS_NO : ValidationConstants.FLAG_STATUS_YES;
				

				String signerName = signer.getSignerName();
				Date signerStDt = !BulkApprovalConstants.SIGNER_ACTION_REMOVE.equalsIgnoreCase(source.getSignerAction()) ? 
									source.getSignerStartDate1() : signer.getSignerStartDate();
				
				String sso = source.getSignerType().toUpperCase().contains("COMPANY")
						|| source.getSignerType().toUpperCase().contains("FACSIMILE")  ? "" : signer.getSsoId();
				
				
				accountSinger = new AccountSigner(signer.getSignerId(), sso,
						lookupType, signerName, signerStDt,
						source.getSignerEndDate1(), source.getAcctReqID(), activeStr,
						signer.getDocName(), signer.getFolderId(),
						signer.getFileId(), source.getDocURL());
			}else{
				if (source.getSignerName() != null
						&& source.getSignerName().equalsIgnoreCase(signer.getSignerName())
						&& lookupType.equalsIgnoreCase(signer.getSignerType())
						&& signer.getSignerEndDate() == null){
					String activeStr = "";
					
					activeStr = source.getSignerEndDate1() != null ? ValidationConstants.FLAG_STATUS_NO : ValidationConstants.FLAG_STATUS_YES;
					
					String signerName = signer.getSignerName();
					Date signerStDt = signer.getSignerStartDate();
					String  sso = signer.getSsoId();
					if(!BulkApprovalConstants.SIGNER_ACTION_REMOVE.equalsIgnoreCase(source.getSignerAction())){
						signerName = source.getSignerName();	
						signerStDt = source.getSignerStartDate1();
					}

					accountSinger = new AccountSigner(signer.getSignerId(), sso,
							lookupType, signerName, signerStDt,
							source.getSignerEndDate1(), source.getAcctReqID(), activeStr,
							signer.getDocName(), signer.getFolderId(),
							signer.getFileId(), source.getDocURL());
				}
				
				signerFlag = !source.getSignerName().equalsIgnoreCase(signer.getSignerName())
						|| !lookupType.equalsIgnoreCase(signer.getSignerType()) ? true : false;
				
				
				expiredSigner = signer.getSignerEndDate() != null ? true : false;
				
				
			}
			
		}
		setErrListWhenSignerNull(signerFlag, expiredSigner, accountSinger, source, errorMap);
		
		return accountSinger;
	}
	
	private void setErrListWhenSignerNull(boolean signerFlag,boolean expiredSigner,AccountSigner accountSinger,BulkAccountSigner source,Map<Long, List<String>> errorMap){
		List<String> errorList = null;
		
		if (accountSinger == null) {
			errorList = new ArrayList<String>();
			if(expiredSigner){
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " Signer is already expired");
			}else if(signerFlag){
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " Signer Name/Signer Type cannot be changed while modifying/removing signers");
			}
			else{
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " Invalid Singer ");
			}
				errorMap.put(source.getStgId(), errorList);
		}
	}
	
	private void setErrListWhenSignerNotNull(AccountSigner accountSinger,AccountRequest accReq,BulkAccountSigner source){
		if (null != accountSinger) {
			List<AccountSigner> siList = new ArrayList<AccountSigner>();
			siList.add(accountSinger);
			accReq.setSigners(siList);
			this.accountService.updateSigners(user, accReq, null, true);
			List<AccountSigner> allSigners = this.accountService.findSignerById(siList.get(0));
			source.setSignerId(siList.get(0).getSignerId());
			accReq.getSigners().clear();
			accReq.getSigners().addAll(allSigners);
			this.accountService.updateSignersInMDM(user, accReq);
		}
	}
	
	private void updateFailureStatus(String failureReason) {

		Date today = new Date();
		BulkAccountSigner failedBulkSigner = null;
		FileUploadActivity fileUploadActivity = null;
		try {
			failedBulkSigner = new BulkAccountSigner();
			failedBulkSigner.setStatus(BulkApprovalConstants.FILEUPLOADACT_FAILURE);
			failedBulkSigner.setFileUploadId(fileUpload.getFileUpldId());
			failedBulkSigner.setLastUpdateDate(today);
			failedBulkSigner.setLastUpdateUser(user.getSso());
			failedBulkSigner.setFailureReason(failureReason);
		
			bulkApprovalService.updateSignersToStaging(failedBulkSigner);

			fileUploadActivity = createFileUploadActivity(fileUpload, user,
					BulkApprovalConstants.FILEUPLOADACT_FAILURE);
		
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);

			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_FAILURE);
			fileUpload.setLastUpdateDate(today);
			fileUpload.setLastUpdateUser(user.getSso());
		
			bulkApprovalService.updateFileUploadStatus(fileUpload, user);

		} catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);

		}

	}
	
	private void sendBulkNotification(Map<Long, List<String>> errorMap){
		try{
			bulkApprovalService.sendBulkUploadNotification(fileUpload, user, errorMap.size(),
				fileUpload.getUpldStatusCode());
		}catch (Exception e){
			MyBankLogger.logError(this, "BulkUploadProcessScheduler.run.sendEmailNotification - :" + e.getMessage(), e);
		}
	}
	
	private PlatformInstance getPlatformInstance(String tCode) {
        Long platformInstanceId = accountService.getLastUpdatedPlatformInstance(tCode);
        if(null != platformInstanceId){
            PlatformInstance platformInstance = new PlatformInstance();
            platformInstance.setPlatformInstanceId(platformInstanceId);
            return platformInstance;
        }else{
            return null;
        }
    }

}
