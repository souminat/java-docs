package com.ge.treasury.mybank.util.web;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.beanio.BeanReader;
import org.beanio.StreamFactory;
import org.beanio.stream.csv.CsvReader;

import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;

public class CSVFileReader {
	
    private static final Map<String,String> FILE_TYPE_MAP = new HashMap<String,String>();
    
	private CSVFileReader() {
		throw new IllegalAccessError("Utility class");
	}
	
	static{
	    FILE_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_OPEN, "com/ge/treasury/mybank/filemapping/bulkUploadOpenTemp.xml");
	    FILE_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_CLOSE, "com/ge/treasury/mybank/filemapping/bulkUploadCloseTemp.xml");
	    FILE_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY, "com/ge/treasury/mybank/filemapping/bulkUploadModifyTemp.xml");
	    FILE_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC, "com/ge/treasury/mybank/filemapping/bulkUploadModifyTemp.xml");
	    FILE_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_SIGNER, "com/ge/treasury/mybank/filemapping/bulkUploadSignerTemp.xml");
	    FILE_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL, "com/ge/treasury/mybank/filemapping/bulkUploadInternalTemp.xml");
	}

	public static BeanReader readCSVFromStream(InputStream uploadedStream, String fileType) {

		StreamFactory factory = null;
		
		if(FILE_TYPE_MAP.containsKey(fileType)){
		    factory = getStreamFactory(FILE_TYPE_MAP.get(fileType));
		}
		
		InputStream in = uploadedStream;
		BeanReader reader = (null != factory) ? factory.createReader("bulkUploadFile", new InputStreamReader(in)) : null;

		return reader;
	}

	private static StreamFactory getStreamFactory(String mappingFilePath) {
		StreamFactory factory = null;
		try {
			factory = StreamFactory.newInstance();
			factory.loadResource(mappingFilePath);
		} catch (Exception ex) {
			MyBankLogger.logError(CSVFileReader.class, ex.getMessage(), ex);
			return null;
		}

		return factory;
	}
public static long getStreamRecordCount(String stream, String fileType){
		
		BeanReader reader=null;
		byte uploadedFileStream[] = null;
		ByteArrayInputStream bis = null;
		long recordCount = 0;
		try{
		uploadedFileStream=stream.getBytes();
	    bis = new ByteArrayInputStream(uploadedFileStream);
		reader = readCSVFromStream(bis,fileType);
		
		while ((reader.read()) != null) {
			recordCount++;
		}
		}
		catch(Exception ex){
			MyBankLogger.logError(CSVFileReader.class, ex.getMessage(), ex);
		}
		finally{
		
			if(reader!=null){
				reader.close();
			}
			if(bis!=null){
				try {
					bis.close();
				} catch (IOException e) {
					MyBankLogger.logError(CSVFileReader.class, e.getMessage(), e);
				}
			}
		}
		
		
		return recordCount;
	}
public static long getFileContentTextCount(File file){
	long count=0;
	CsvReader csvReader = null;
	try{
		csvReader = new CsvReader(new FileReader(file));
	while (csvReader!=null && csvReader.read()!=null){
		if(csvReader.getRecordLineNumber()==1){
			continue;
		}
	count+=csvReader.getRecordText().length();
	}
	}
	catch(Exception e){
		MyBankLogger.logError(CSVFileReader.class, e.getMessage(), e);
		throw new BusinessException(e.getMessage(),e);
	}
	finally{
		closeReader(csvReader);
	}
	return count;
}
public static long getFileHeaderTextCount(File file){
	long count=0;
	CsvReader csvReader = null;
	try{
	csvReader = new CsvReader(new FileReader(file));	
	if (csvReader!=null && csvReader.read()!=null){
	count+=csvReader.getRecordText().length();
	}
	}
	catch(Exception e){
		MyBankLogger.logError(CSVFileReader.class, e.getMessage(), e);
		throw new BusinessException(e.getMessage(),e);
	}
	finally{
		closeReader(csvReader);
	}
	return count;
}
public static boolean isSubFile(File originalFile,File splittedFile){
	boolean flag=false;
	ArrayList<String> originalFileList=null;
	ArrayList<String> splittedFileList=null;
	try{
		long currentTime=System.currentTimeMillis();
		MyBankLogger.logInfo(CSVFileReader.class,"start time for sub file check:"+currentTime);
		
		originalFileList=getFileContentAsList(originalFile);
		splittedFileList=getFileContentAsList(splittedFile);
		if(originalFileList.containsAll(splittedFileList)){
			flag=true;
		}
		MyBankLogger.logInfo(CSVFileReader.class,"Total time for sub file check:"+(System.currentTimeMillis()-currentTime));
	}
	catch(Exception e){
		MyBankLogger.logError(CSVFileReader.class, e.getMessage(), e);
		throw new BusinessException(e.getMessage(),e);
	}
	
	return flag;
}
private static ArrayList<String> getFileContentAsList(File file){
	ArrayList<String> fileContentList=new ArrayList<String>();
	CsvReader csvReader = null; 
	try{
	csvReader=	new CsvReader(new FileReader(file));
	while (csvReader!=null && csvReader.read()!=null){
		fileContentList.add(csvReader.getRecordText());
	}
	}
	catch(Exception e){
		MyBankLogger.logError(CSVFileReader.class, e.getMessage(), e);
		throw new BusinessException(e.getMessage(),e);
	}
	finally{
		closeReader(csvReader);
	}
	return fileContentList;
	
}
private  static void closeReader(CsvReader csvReader){
	try {
		if(csvReader!=null){
		csvReader.close();
		}
	} catch (IOException e) {
		MyBankLogger.logError(CSVFileReader.class, e.getMessage(), e);
		throw new BusinessException(e.getMessage(),e);
	}
}


}
