package com.ge.treasury.mybank.util.web;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Calendar;

import com.ge.treasury.mybank.util.business.MyBankLogger;

/**
 * @author MyBank Dev Team
 * 
 */
public class StringUtils {

    private StringUtils() {
        throw new IllegalAccessError("Utility class");
    }

    /**
     * Returns Calendar date obtained from a string
     * 
     * @param date
     * @param format
     * @return
     * @throws DateFormatException
     */
    public static synchronized Calendar stringToCalendar(String date,
            String format) throws DateFormatException {
        String[] formater = (format.indexOf("/") > 0) ? format.split("/")
                : format.split("-");

        StringBuilder strPattern = new StringBuilder();

        for (int i = 0; i < formater.length; i++) {
            if (i > 0) {
                strPattern.append("[/|\\-]");
            }
            if ("dd".equals(formater[i]) || "mm".equals(formater[i])) {
                strPattern.append("[0-9]{0,2}");
            } else if (formater[i].matches("y*")) {
                strPattern.append("[0-9]{0,").append(formater[i].length())
                        .append("}");
            }
        }
        Pattern pattern = Pattern.compile(strPattern.toString());
        Matcher matcher = pattern.matcher(date);

        if (!matcher.matches()) {
            throw new DateFormatException("mismatch date format expected "
                    + format);
        }
        String[] dateInfo = (date.indexOf("/") > 0) ? date.split("/") : date
                .split("-");
        Calendar newCal = Calendar.getInstance();
        for (int i = 0; i < formater.length; i++) {
            if ("dd".equals(formater[i])) {
                newCal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateInfo[i]));
            } else if ("mm".equals(formater[i])) {
                newCal.set(Calendar.MONTH, Integer.parseInt(dateInfo[i]));
            } else if (formater[i].matches("y*")) {
                newCal.set(Calendar.YEAR, Integer.parseInt(dateInfo[i]));
            }
        }
        newCal.set(Calendar.HOUR_OF_DAY, 0);
        newCal.set(Calendar.MINUTE, 0);
        newCal.set(Calendar.SECOND, 0);
        return newCal;
    }

    /**
     * Returns true if string data can be converted to a numeric value, and
     * false if not
     * 
     * @param data
     * @return
     * @throws NumberFormatException
     */
    public static synchronized boolean validatesStringToNumeric(String data) {
        try {
            Integer numericValue = Integer.parseInt(data);
            MyBankLogger.logDebug(new StringUtils(),
                    "Numeric value as integer = " + numericValue);
            return true;
        } catch (NumberFormatException nfe) {
            MyBankLogger.logDebug(new StringUtils(),
                    "String value can not be converted to integer = " + data);
            return false;
        }
    }

    /**
     * Returns true if string data matches with a specific pattern
     * 
     * @param data
     * @return
     */
    public static synchronized boolean validatesStringMatches(String data,
            String regex) {
        if (data.matches(regex)) {
            return true;
        }
        return false;
    }
}
