package com.ge.treasury.mybank.util.web;

import java.net.InetAddress;
import java.net.UnknownHostException;

import com.ge.treasury.mybank.util.business.MyBankLogger;

public class ServerDetails {

    private ServerDetails() {
        super();
    }

    public static String getServerIpAddress() {
        InetAddress ip = null;
        try {
            ip = InetAddress.getLocalHost();

        } catch (UnknownHostException e) {
            MyBankLogger.logError(new ServerDetails(), e.getMessage(), e);
        }
        return ip.toString();

    }

    public static String getServerHostName() {
        InetAddress ip = null;
        try {
            ip = InetAddress.getLocalHost();

        } catch (UnknownHostException e) {
            MyBankLogger.logError(new ServerDetails(), e.getMessage(), e);
        }
        return ip.getHostName();

    }

}
