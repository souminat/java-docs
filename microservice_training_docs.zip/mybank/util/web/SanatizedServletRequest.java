package com.ge.treasury.mybank.util.web;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.Normalizer;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;

public class SanatizedServletRequest extends HttpServletRequestWrapper {


	private static final Logger log = LoggerFactory
			.getLogger(SanatizedServletRequest.class);

	private String encoding;
	private PolicyFactory policy = new HtmlPolicyBuilder().toFactory();

	public SanatizedServletRequest(HttpServletRequest request) {
		super(request);
		encoding = getCharacterEncoding() == null ? "UTF-8"
				: getCharacterEncoding();
	}

	
	@Override
	public String[] getParameterValues(String name) {
		String[] values = super.getParameterValues(name);
		if (values == null) {
			return null;
		}
		for (int i = 0; i < values.length; ++i) {
			values[i] = sanatize(values[i]);
		}

		return values;
	}

	@Override
	public String getParameter(String name) {
		String param1 = Normalizer.normalize(name, Normalizer.Form.NFKC);
		return sanatize(param1);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map getParameterMap() {
		if (super.getParameterMap() == null) {
			return null;
		}
		Map<String, String[]> params = new TreeMap<String, String[]>();
		for (Object key : super.getParameterMap().keySet()) {
			params.put(String.valueOf(key),
					getParameterValues(String.valueOf(key)));
		}
		return params;
	}

	@Override
	public String getQueryString() {
		return sanatize(unescapeUrl(super.getQueryString()));
	}

	public String getQueryString(String url) {
		return sanatize(unescapeUrl(url));
	}

	@Override
	public BufferedReader getReader() throws IOException {
		if (super
				.getRequestURI()
				.toString()
				.endsWith(
						FileUploadConstants.API
								+ FileUploadConstants.FILEUPLOAD)) {
			return super.getReader();
		}
		return new BufferedReader(new StringReader(IOUtils.toString(super
				.getReader())));
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		if (super
				.getRequestURI()
				.toString()
				.endsWith(
						FileUploadConstants.API
								+ FileUploadConstants.FILEUPLOAD)) {
			return super.getInputStream();
		}
		final InputStream sanatized = new ByteArrayInputStream(sanatize(
				IOUtils.toString(super.getInputStream(), "UTF-8")).getBytes(
				"UTF-8"));
		return new ServletInputStream() {

			@Override
			public int read() throws IOException {
				return sanatized.read();
			}

			@Override
			public void close() throws IOException {
				sanatized.close();
			}

			@Override
			public int readLine(byte[] b, int off, int len) throws IOException {
				return sanatized.read(b, off, len);
			}

			@Override
			public int read(byte[] b) throws IOException {
				return sanatized.read(b);
			}

			@Override
			public int read(byte[] b, int off, int len) throws IOException {
				return sanatized.read(b, off, len);
			}

			@Override
			public synchronized void reset() throws IOException {
				sanatized.reset();
			}

			@Override
			public long skip(long n) throws IOException {
				return sanatized.skip(n);
			}

			@Override
			public String toString() {
				return sanatized.toString();
			}

			@Override
			public synchronized void mark(int readlimit) {
				sanatized.mark(readlimit);
			}

			@Override
			public boolean markSupported() {
				return sanatized.markSupported();
			}
		};
	}
	

	public String unescapeUrl(String value1) {

		String value = value1;
		if (value == null) {
			return null;
		}
		try {
			value = URLDecoder.decode(value, encoding);
		} catch (UnsupportedEncodingException e) {
			log.error("Error while attempting to decode string: " + value, e);
		}
		return value;
	}

	private String sanatize(String value1) {
		String value = value1;
		if (value == null) {
			return value;
		}

		String prevState;
		do {
			prevState = value;
			value = StringEscapeUtils.unescapeHtml(value);
		} while (!Objects.equals(prevState, value));
		
		return StringEscapeUtils.unescapeHtml(policy.sanitize(value));
	}

}
