package com.ge.treasury.mybank.util.web;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ELEMENTS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.FILTER_CONST;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_2;
import static com.ge.treasury.mybank.util.business.constants.ValidationConstants.MDM_ACCT_STATUS_INPROCESS;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.beanio.BeanReader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.helper.FileUploadHelper;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadActivityService;
import com.ge.treasury.mybank.business.inflightrequest.service.impl.InflightRequestService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.config.CacheService;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.mdm.MDMAccount;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.validations.AccountValidationUtils;
import com.ge.treasury.mybank.util.business.validations.AccountValidator;
import com.ge.treasury.mybank.util.business.validations.MessageValidator;
import com.ge.treasury.mybank.web.controllers.BaseController;

@Controller
public class BulkUploadProcessScheduler extends BaseController implements Runnable {
	
	private FileUpload fileUpload;
	private User user;
	private BulkApprovalService bulkApprovalService;
	private AccountRequestService accountService;
	private FileUploadActivityService fileUploadActivityService;
	private MyBankLookupService lookupService;
	private MDMService mdmService;
	private MessageValidator messageValidator;
	
	@SuppressWarnings("unused")
	private CacheService cacheService;
	
	private BulkUploadService bulkUploadService;
	private String accntUrl;
	private Map<String, BulkApprovalRequest> approvalRequestMap = new HashMap<String, BulkApprovalRequest>(); 
	private String accountCoreUrl;
	private String companyCodeUrl;
	private InflightRequestService inflightRequestService;

	public BulkUploadProcessScheduler() {
	    //Default arg constructor
	}

	public BulkUploadProcessScheduler(FileUpload fileUpload, User user, BulkApprovalService bulkApprovalService,
			AccountRequestService accountService,
			FileUploadActivityService fileUploadActivityService, MyBankLookupService lookupService,InflightRequestService inflightRequestService,
			MDMService mdmService, MessageValidator messageValidator,CacheService cacheService,BulkUploadService bulkUploadService, String accntUrl,String accountCoreUrl, String companyCodeUrl)  {
		super();
		this.fileUpload = fileUpload;
		this.user = user;
		this.bulkApprovalService = bulkApprovalService;
		this.accountService = accountService;
		this.fileUploadActivityService = fileUploadActivityService;
		this.lookupService = lookupService;
		this.inflightRequestService = inflightRequestService;
		this.mdmService = mdmService;
		this.messageValidator = messageValidator;
		this.cacheService = cacheService;
		this.bulkUploadService = bulkUploadService;
		this.accntUrl = accntUrl;
		this.accountCoreUrl = accountCoreUrl;
		this.companyCodeUrl = companyCodeUrl;
	}



	@Override
	@SuppressWarnings({"deprecation"})
	public void run() {
	
		FileUpload fileUploadResult = null;
		byte uploadedFileStream[] = null;
		BeanReader reader = null;
		List<BulkApprovalRequest> bulkApprovalList = null;
		ByteArrayInputStream bis = null;
		Object record = null;
		Date today = new Date();
		Map<Long, List<String>> errorMap = new HashMap<Long, List<String>>();
		String failureReason=null;
		try {

				fileUploadResult = bulkApprovalService.getFileUploadDetails(fileUpload.getFileUpldId());
				
            uploadedFileStream = null != fileUploadResult.getSuccessFile()
                    ? fileUploadResult.getSuccessFile().getBytes() : fileUploadResult.getUploadedFile().getBytes();
	            fileUpload.setAcceptedCount(CSVFileReader.getStreamRecordCount(fileUploadResult.getSuccessFile(),fileUploadResult.getUpldTypeCode()));
				bis = new ByteArrayInputStream(uploadedFileStream);
				reader = CSVFileReader.readCSVFromStream(bis, fileUploadResult.getUpldTypeCode());
	
			
				bulkApprovalList = new ArrayList<BulkApprovalRequest>();
	
				String status = BulkApprovalConstants.FILEUPLOADACT_APPROVED;
				
				while ((record = reader.read()) != null) {
					BulkApprovalRequest bulkRequest = (BulkApprovalRequest) record;
					bulkRequest = (BulkApprovalRequest) FileUploadHelper.trimReflective(bulkRequest);
					BulkApprovalRequest approvalReqUi = new BulkApprovalRequest();
					BeanUtils.copyProperties(bulkRequest, approvalReqUi);
					checkIfTcodePresent(approvalReqUi);
					approvalRequestMap.put(approvalReqUi.gettCode(),approvalReqUi);
					//Exception code for modify specific template
                if (fileUploadResult.getUpldTypeCode()
                        .equalsIgnoreCase(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC)
                        || fileUploadResult.getUpldTypeCode()
                                .equalsIgnoreCase(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL)) {
                	//create bulk account Request
						AccountRequest accReqMDM = accountService.findAccountFromMDMforModify(bulkRequest.gettCode(),accountCoreUrl,false);
						bulkRequest = accountService.createApprovalReq(accReqMDM, bulkRequest);			
					}
					
						
						bulkRequest.setFileUpldId(fileUpload.getFileUpldId());
						bulkRequest.setStatusCode(BulkApprovalConstants.FILEUPLOADACT_APPROVED);
						bulkRequest.setCreateDate(today);
						bulkRequest.setLastUpdateDate(today);
						bulkRequest.setCreateUser(user.getSso());
						bulkRequest.setLastUpdateUser(user.getSso());
						switch (reader.getRecordName()) {
						case BulkApprovalConstants.BULK_UPLOAD_OPEN_TEMPLATE:
							status = BulkApprovalConstants.FILEUPLOADACT_OPEN_IN_PROCESS;
							bulkRequest.setAccountOpenDate1(new Date(bulkRequest.getAccountOpenDate()));
							bulkApprovalList.add(bulkRequest);
							break;
		
						case BulkApprovalConstants.BULK_UPLOAD_CLOSE_TEMPLATE:
							status = BulkApprovalConstants.FILEUPLOADACT_CLOSE_IN_PROCESS;
							bulkRequest.setAccountCloseDate1(new Date(bulkRequest.getAccountCloseDate()));
							bulkApprovalList.add(bulkRequest);
							break;
		
						case BulkApprovalConstants.BULK_UPLOAD_MODIFY_TEMPLATE:
							status = BulkApprovalConstants.FILEUPLOADACT_MODFY_IN_PROCESS;
						
							bulkApprovalList.add(bulkRequest);
							break;
							
						case BulkApprovalConstants.BULK_UPLOAD_MODIFY_INTERNAL_TEMPLATE:
                            status = BulkApprovalConstants.FILEUPLOADACT_MODFY_IN_PROCESS;
                        
                            bulkApprovalList.add(bulkRequest);
                            break;
		
						default:
							break;
						}
					}
				
				processFileRecords(bulkApprovalList, errorMap, fileUploadResult, status);

		}catch (Exception e) {
			MyBankLogger.logError(this, "BulkUploadProcessScheduler.run:" + e.getMessage(), e);
			failureReason=BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " - Unable to process the records "+e.getMessage();
			updateFailureStatus(failureReason);
			bulkApprovalService.sendBulkUploadNotification(fileUpload, user, errorMap.size(),
					fileUpload.getUpldStatusCode());
			throw new BusinessException("Internal Server Error : " + e.getMessage());
		} finally {
			try {
				bis.close();
				reader.close();
			}catch (IOException e) {
				MyBankLogger.logError(this, e.getMessage(), e);
			}
		}

	}

	private void checkIfTcodePresent(BulkApprovalRequest approvalReqUi) {
		if(StringUtils.isNotEmpty(approvalReqUi.gettCode())) {
			approvalReqUi.settCode(approvalReqUi.gettCode().toUpperCase());
		}
	}
	
	private void processFileRecords(List<BulkApprovalRequest> bulkApprovalList,Map<Long, List<String>> errorMap,FileUpload fileUploadResult,String status){
 		
		String failureReason=null;
		List<AccountRequest> accountReqList = null;
		
		Date today = new Date();
		if (!CollectionUtils.isEmpty(bulkApprovalList)) {
			bulkApprovalService.insertStageRecords(bulkApprovalList);

			FileUploadActivity fileUploadActivity = createFileUploadActivity(fileUpload, user,
					status);
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);

			fileUpload.setUpldStatusCode(status);
			fileUpload.setLastUpdateDate(today);
			fileUpload.setLastUpdateUser(user.getSso());
			bulkApprovalService.updateFileUploadStatus(fileUpload, user); 
			accountReqList = new ArrayList<AccountRequest>();
			
			prepareAccountRequests(bulkApprovalList, accountReqList, fileUploadResult.getUpldTypeCode(),errorMap);

			if (!CollectionUtils.isEmpty(accountReqList)) {
			
				processBulkRequests(accountReqList, errorMap);
			
			}else if(errorMap.size() != bulkApprovalList.size()){
				failureReason=BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR + " - Unable to create account requests ";
				updateFailureStatus(failureReason);
				return;
			}

			bulkApprovalService.updateStageRecords(bulkApprovalList, errorMap, user, today);

			String fileUploadStatus = "FILEUPLOADACT_SUCCESS";
			if (bulkApprovalList.size() == errorMap.size()) {
				fileUploadStatus = "FILEUPLOADACT_FAILURE";
            } else if ((bulkApprovalList.size() > errorMap.size() && errorMap.size() > 0)
                    || !StringUtils.isEmpty(fileUploadResult.getErrorFile())) {
				fileUploadStatus = "FILEUPLOADACT_PARTIAL";
			}

			fileUpload.setUpldStatusCode(fileUploadStatus);
			fileUpload.setLastUpdateDate(today);
			fileUpload.setLastUpdateUser(user.getSso());
			bulkApprovalService.updateFileUploadStatus(fileUpload, user);

			fileUploadActivity = createFileUploadActivity(fileUpload, user, fileUploadStatus);
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
			
			try{
				bulkApprovalService.sendBulkUploadNotification(fileUpload, user, errorMap.size(),
						fileUpload.getUpldStatusCode());
			}catch (Exception e){
				MyBankLogger.logError(this, "BulkUploadProcessScheduler.run.sendEmailNotification - :" + e.getMessage(), e);
			}
			
			
		}

	}
	
	private void processBulkRequests(List<AccountRequest> accountReqList,Map<Long, List<String>> errorMap){
		List<String> errorList=null;
		AccountRequest accReqDB=null;
		
		for (AccountRequest ar : accountReqList) {
			try{
			
			if (!errorMap.containsKey(ar.getStgId())) {	
				validateRecord(ar, errorMap);
			}
			
			
			if (!errorMap.containsKey(ar.getStgId())) {
			    
			    updateInflightRequests(ar);
			    
			    User requester = getRequester();
				 
				 accReqDB = this.accountService.createAccountRequestForBulkUpload(requester, ar,
						fileUpload.getUpldTypeCode());
				accReqDB.setStgId(ar.getStgId());
				
				prepareBulkApprovalRequest(accReqDB, errorMap, ar);
                
			}
			}
			catch(Exception e){
				MyBankLogger.logError(this, "BulkUploadProcessScheduler.run:" + e.getMessage(), e);
				errorList = new ArrayList<String>();
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR +" Unable to process the record - "+e.getMessage());
				errorMap.put(ar.getStgId(),errorList);
			
			}
		}
	}


    private void prepareBulkApprovalRequest(AccountRequest accReqDB,Map<Long, List<String>> errorMap,AccountRequest ar){
		
		if(fileUpload.getUpldTypeCode().equals(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_OPEN) 
		        	&& (ValidationConstants.ACCT_REQUEST_TYPE_OPEN.equals(accReqDB.getRequestType())||ValidationConstants.ACCT_REQUEST_TYPE_ACQUIRED.equals(accReqDB.getRequestType()))){
				
				accReqDB.setStgId(ar.getStgId());							
			    accReqDB.settCode(generateTcode(accReqDB,errorMap));
		}
		
		BulkApprovalRequest bulkApprovalRequest=new BulkApprovalRequest();
		bulkApprovalRequest.setStgId(accReqDB.getStgId());
		bulkApprovalRequest.setAccountReqId(accReqDB.getAcctReqID());
		bulkApprovalRequest.settCode(accReqDB.gettCode());
		bulkApprovalRequest.setLastUpdateDate(accReqDB.getLastUpdateDate());
		bulkApprovalRequest.setLastUpdateUser(accReqDB.getLastUpdateUser());
		bulkApprovalService.updateBulkApprovalStageRecord(bulkApprovalRequest);
		MyBankLogger.logInfo(this, "Account Request to be processed BulkProcessSch : " + accReqDB.toString());
		bulkApprovalService.processFile(accReqDB, fileUpload.getUpldTypeCode(), errorMap, getRequester());
	}
	
    private void validateRecord(AccountRequest accReq, Map<Long, List<String>> errorMap) {
		BindingResult errors =null;
		AccountValidator validator =null;
		List<String> errorList=null;
		try {
		 errors = new BeanPropertyBindingResult(accReq, "accountRequest");
		 validator = new AccountValidator(accountService, lookupService, messageValidator, mdmService);
            if (BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL
                    .equalsIgnoreCase(fileUpload.getUpldTypeCode())) {
                validator.setInflightValidationRequired(false);
            }
		 validator.validate(accReq, errors);

		if (null != errors && errors.hasErrors()) {
			 errorList = new ArrayList<String>();
			for (ObjectError error : errors.getAllErrors()) {
				MyBankLogger.logDebug(this, "Error : " + error.getCode() + " " + error.getDefaultMessage());
				errorList.add(BulkApprovalConstants.BULK_UPLOAD_VALIDATION_ERR + error.getCode() + " - " + error.getDefaultMessage());
			}
			errorMap.put(accReq.getStgId(), errorList);
		}
		
			
		} catch (Exception e) {
			MyBankLogger.logError(this, "BulkUploadProcessScheduler.validateRecord:" + e.getMessage(), e);
			errorList = new ArrayList<String>();
			errorList.add(BulkApprovalConstants.BULK_UPLOAD_VALIDATION_ERR +" Validation Failed - "+e.getMessage());
			errorMap.put(accReq.getStgId(),errorList);
		}
	}
	
	@SuppressWarnings("unused")
	private String getMdmMappedData(Set<String> list, String value) {
		String mdmData = value;
		if (!CollectionUtils.isEmpty(list)) {
			for (String str : list) {
				if (str.equalsIgnoreCase(value)) {
					mdmData = str;
				}
			}
		}
		return mdmData;
	}
	
	 /**
     *  MDMDetails mdmMasterData = cacheService.fetchMDMDataForValidation();
     *  Set<String> bussList = null != mdmMasterData ? mdmMasterData.getBusinessList() : null;
     *  Set<String> subBussList = null != mdmMasterData ? mdmMasterData.getSubBusinessList() : null;
     *  
     *  
     *  Open file type
     *  accReq.setBussName(getMdmMappedData(bussList, bulkReq.getBussName()));
     *  accReq.setSubBusName(getMdmMappedData(subBussList, bulkReq.getSubBusiness()));
     *  
     *  Modify file type
     *  accReq.setBussName(null != StringUtils.trimToNull(approvalRequestMap.get(bulkReq.gettCode()).getBussName()) ? getMdmMappedData(bussList, bulkReq.getBussName()) : accReqMDM.getBussName());
     *  accReq.setSubBusName(null != StringUtils.trimToNull(approvalRequestMap.get(bulkReq.gettCode()).getSubBusiness()) ? getMdmMappedData(subBussList, bulkReq.getSubBusiness()) : accReqMDM.getSubBusName());
     *  
     */
	private void prepareAccountRequests(List<BulkApprovalRequest> sourceList, List<AccountRequest> targetList,
		 String fileType,Map<Long, List<String>> errorMap){
		
		DateFormat orignal_format = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
		
		if(null != sourceList){
			
			for (BulkApprovalRequest bulkReq : sourceList) {
		
					
						
						try {
							if(!StringUtils.isEmpty(bulkReq.getBankClassification())){
								bulkReq.setBankClassification(lookupService.getLookupCode(bulkReq.getBankClassification().trim()));
							}


							if (BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_OPEN.equals(fileType)) {
												
								AccountRequest accReq = new AccountRequest();
							
							   accReq.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
							   accReq.setRequestType("Open".equalsIgnoreCase(bulkReq.getAccountStatus())?ValidationConstants.ACCT_REQUEST_TYPE_OPEN : ValidationConstants.ACCT_REQUEST_TYPE_ACQUIRED);
							   setBusSubBuss(accReq,null,bulkReq,fileType);     	
							   accReq.setLeCode(bulkReq.getLeCode());
							   
							   DateFormat df = new SimpleDateFormat(ValidationConstants.MDMDATE_FORMAT, Locale.ENGLISH);
							   Date formatedDate = orignal_format.parse(bulkReq.getAccountOpenDate());
							   accReq.setAcctOpenDate(df.format(formatedDate));
							   String response = this.bulkUploadService.getGoldLeNames(bulkReq.getLeCode());
							   
							   setLEDetails(accReq, response);
							   
							   
							   accReq.setCountry(bulkReq.getCountry());
							   accReq.setCountryName("");
							   accReq.setCurrency(bulkReq.getCurrency());
							   accReq.setCurrencyName("");
							   accReq.setBankId(bulkReq.getBankId());
							   accReq.setBankName(getMDMBankName(bulkReq.getBankId(),null));
							   accReq.setCashpoolTCode(bulkReq.getCashpoolTCode());
							   accReq.setCashpoolLeCode("");
							   accReq.setRouteCode(bulkReq.getRouteCode());
							   accReq.setRouteCodeType(bulkReq.getRouteCodeType());
							   
							   accReq.setBranchMDMID(bulkReq.getBranchID());
							   accReq.setAccountType(bulkReq.getAccountType());
							   accReq.setAccountTitle(bulkReq.getAccountTitle());
							   accReq.setAcctNumber(bulkReq.getAccountNumber());
							   accReq.setIban(bulkReq.getIban());
							   accReq.setIsBankAcctReserved("N");
							   accReq.setCreateDate(bulkReq.getCreateDate());
							   accReq.setCreateUser(bulkReq.getCreateUser());
							   accReq.setLastUpdateDate(bulkReq.getCreateDate());
							   accReq.setLastUpdateUser(bulkReq.getCreateUser());
							   accReq.setComponentCode(getComponentCode(bulkReq.getComponentCode(),bulkReq.getLeCode(),bulkReq.getBussName()));
							   accReq.setMdmTcodeAlternate("");
							   accReq.setCompanyCode(bulkReq.getCompanyCode());
							   accReq.setMeCode(bulkReq.getMe());
							   accReq.setAccountPurpose(bulkReq.getAccountPurpose());
							   accReq.setBankClassification(bulkReq.getBankClassification());
							   accReq.setProjectName(bulkReq.getProjectName());
							   accReq.setCoCodeRejectReason(lookupService.getLookupCode(bulkReq.getCoCodeRejectReason()));
							   
							   AccountComment ac = new AccountComment();
							   ac.setComments(bulkReq.getComments());
							   ac.setCommentType(ValidationConstants.ACCOUNT_COMMENT_TYPE_REQUEST);

							   List<AccountComment> commentList = new ArrayList<AccountComment>();
							   commentList.add(ac);
							   accReq.setComments(commentList);
							   
							   List<AccountDocument> documentList = new ArrayList<AccountDocument>();
							   
							   setDocument(documentList, bulkReq.getDocuments(), bulkReq.getDocumentType());
							   setDocument(documentList, bulkReq.getBankConfirmation(),BulkApprovalConstants.BANK_CONFIRMATION );
							   setDocument(documentList, bulkReq.getSpbDocument(), BulkApprovalConstants.SPECIAL_PURPOSE_BANK);
							   accReq.setDocuments(documentList);
							   
							   accReq.setStgId(bulkReq.getStgId());
							   targetList.add(accReq);

								

							} else if (BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_CLOSE.equals(fileType)) {
								AccountRequest accReq = accountService.findAccountFromMDMforModify(bulkReq.gettCode(),accntUrl,false);
								if (null != accReq && !"Closed".equalsIgnoreCase(accReq.getRequestStatus())) {
									// set file specific properties
									// TODO: close date missing
									accReq.settCode(bulkReq.gettCode().toUpperCase());
									List<AccountComment> acList = new ArrayList<AccountComment>();
									AccountComment ac = new AccountComment();
									ac.setComments(bulkReq.getComments());
									ac.setCommentType(ValidationConstants.ACCOUNT_COMMENT_TYPE_REQUEST);
									acList.add(ac);
									accReq.setComments(acList);
									List<AccountDocument> documentList = new ArrayList<AccountDocument>();
							      
									setDocument(documentList, bulkReq.getDocuments(), bulkReq.getDocumentType());
							        setDocument(documentList, bulkReq.getBankConfirmation(),BulkApprovalConstants.BANK_CONFIRMATION );
							       
							    	accReq.setDocuments(documentList);

									accReq.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
									
									if("Closed".equalsIgnoreCase(bulkReq.getAccountStatus())){
										accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_CLOSE);
									}else if("Divested".equalsIgnoreCase(bulkReq.getAccountStatus())){
										accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_DIVESTED);
									} 
									
									
									accReq.setStgId(bulkReq.getStgId());
									accReq.setCreateUser(bulkReq.getCreateUser());
							       accReq.setLastUpdateDate(bulkReq.getCreateDate());
							       accReq.setLastUpdateUser(bulkReq.getCreateUser());
							       accReq.setProjectName(StringUtils.defaultIfEmpty(bulkReq.getProjectName(), accReq.getProjectName()));
							       
							       accReq.setPlatformInstance(getPlatformInstance(accReq.gettCode()));
							       
							       DateFormat df = new SimpleDateFormat(ValidationConstants.MDMDATE_FORMAT, Locale.ENGLISH);
							       
							       Date formatedDate = orignal_format.parse(bulkReq.getAccountCloseDate());
							       accReq.setAcctClosedDate(df.format(formatedDate));
							       
								   targetList.add(accReq);
								}

                    } else if (BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY.equals(fileType)
                            || BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC.equals(fileType)
                            || BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL.equals(fileType)) {

								AccountRequest accReq = new AccountRequest();
								
								AccountRequest accReqMDM = accountService.findAccountFromMDMforModify(bulkReq.gettCode(),accntUrl,false);

								if(null == accReqMDM 
										|| (!"Open".equalsIgnoreCase(bulkReq.getAccountStatus()) && "Closed".equalsIgnoreCase(accReqMDM.getRequestStatus()))){
									throw new BusinessException("Account does not exist in MDM");
								}
								
								AccountComment ac = new AccountComment();
								ac.setComments(bulkReq.getComments());
								ac.setCommentType(ValidationConstants.ACCOUNT_COMMENT_TYPE_REQUEST);
								List<AccountComment> commentList = new ArrayList<AccountComment>();
								commentList.add(ac);
								accReq.setComments(commentList);
								
								verifyAndSetRequestType(bulkReq,accReqMDM,accReq);
								
								accReq.setRequestStatus(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
							
								accReq.setAccountType(bulkReq.getAccountType());
							    accReq.setAcctNumber(bulkReq.getAccountNumber());
							    accReq.setIban(bulkReq.getIban());
							    accReq.setLeCode(bulkReq.getLeCode());
							    
							    verifyAndPopulateGoldLeInfo(accReq,accReqMDM);
							    accReq.setCountry(bulkReq.getCountry());
							    accReq.setCurrency(bulkReq.getCurrency());
							    accReq.setBankId(bulkReq.getBankId());
							    
							    accReq.setBankName(null != StringUtils.trimToNull(approvalRequestMap.get(bulkReq.gettCode().toUpperCase()).getBankId()) ? getMDMBankName(bulkReq.getBankId(),null) : accReqMDM.getBankName());
							    
							    accReq.setRouteCode(bulkReq.getRouteCode());
							    
							    accReq.setBranchMDMID(bulkReq.getBranchID());
							    accReq.setRouteCodeType(bulkReq.getRouteCodeType());
							    accReq.setAccountTitle(bulkReq.getAccountTitle());
							    setBusSubBuss(accReq,accReqMDM,bulkReq,fileType);
							    accReq.setComponentCode(getComponentCode(bulkReq.getComponentCode(),bulkReq.getLeCode(),bulkReq.getBussName()));
							    
							    List<AccountDocument> documentList = new ArrayList<AccountDocument>();
							               
							    setDocument(documentList, bulkReq.getDocuments(), bulkReq.getDocumentType());
							    setDocument(documentList, bulkReq.getBankConfirmation(),BulkApprovalConstants.BANK_CONFIRMATION );
							    setDocument(documentList, bulkReq.getSpbDocument(), BulkApprovalConstants.SPECIAL_PURPOSE_BANK);
							    
							    accReq.setDocuments(documentList);
							    
							    accReq.settCode(bulkReq.gettCode().toUpperCase());
							    accReq.setCreateUser(bulkReq.getCreateUser());
							    accReq.setCreateDate(bulkReq.getCreateDate());
							    accReq.setStgId(bulkReq.getStgId());
								accReq.setCompanyCode(bulkReq.getCompanyCode());
								accReq.setMeCode(bulkReq.getMe());
								accReq.setAccountPurpose(bulkReq.getAccountPurpose());
								accReq.setBankClassification(bulkReq.getBankClassification());
								accReq.setProjectName(bulkReq.getProjectName());
								accReq.setCoCodeRejectReason(lookupService.getLookupCode(bulkReq.getCoCodeRejectReason()));
								accReq.setPlatformInstance(getPlatformInstance(accReq.gettCode()));
								
								if(null!=accReqMDM.getSigners()){
									prepareSignersForReopen(accReqMDM);
									accReq.setSigners(accReqMDM.getSigners());
								}
								
								if(null != StringUtils.trimToNull(accReqMDM.getAcctOpenDate())){
								    accReq.setAcctOpenDate(accReqMDM.getAcctOpenDate());
								}
								
								if(null != StringUtils.trimToNull(accReqMDM.getAcctClosedDate())){
							        accReq.setAcctClosedDate(accReqMDM.getAcctClosedDate());
							    }
								
								accReq.setCashPoolRejectReason(StringUtils.defaultString(accReqMDM.getCashPoolRejectReason()));

							    MyBankLogger.logError(this, "Account Status for BulkUpload before leaving the meth : "+accReq.getRequestType());
								
								accReq.setCashpoolTCode(bulkReq.getCashpoolTCode());
							    accReq.setSubtypeCode(getSubTypeCode(fileType)); //Other
							    targetList.add(accReq);
							}
						}catch(Exception e){
							MyBankLogger.logError(this, "Processing Account Request -> " + ExceptionUtils.getFullStackTrace(e));
							List<String> errorList = new ArrayList<String>();
							errorList.add("Exception in creating Account Request : " + e.getMessage());
							errorMap.put(bulkReq.getStgId(), errorList);
						}
					
				
			}
		}
	}

	private void verifyAndSetRequestType(BulkApprovalRequest bulkReq, AccountRequest accReqMDM, AccountRequest accReq) {
		
		if("Open".equalsIgnoreCase(bulkReq.getAccountStatus()) && "Closed".equalsIgnoreCase(accReqMDM.getRequestStatus())) {
			accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_OPEN);
		}else if("Acquired".equalsIgnoreCase(bulkReq.getAccountStatus())) {
			accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_ACQUIRED);
		}else if("Divested".equalsIgnoreCase(bulkReq.getAccountStatus())) {
			accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_DIVESTED);
		}else {
			accReq.setRequestType(ValidationConstants.ACCT_REQUEST_TYPE_MODIFY);
		}
		
	}

	//Remove end date for expired signers tagged to the closed tcode for reopening the tcode and prepare for activation
	private void prepareSignersForReopen(AccountRequest accReqMDM) {
		List<AccountSigner> signerList = accReqMDM.getSigners();
		if("Closed".equalsIgnoreCase(accReqMDM.getRequestStatus())) {
			signerList.forEach(signer->{
				if(AccountValidationUtils.getSignerLookupMap().containsKey(lookupService.getDisplayName(signer.getSignerType()))) {
					signer.setSignerEndDate(null);
				}
			});
		}
		accReqMDM.setSigners(signerList);
	}

	private void setBusSubBuss(AccountRequest accReq,AccountRequest accReqMDM,BulkApprovalRequest bulkReq,String fileType) {
    	
    	if(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY.equals(fileType) 
    			|| BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_OPEN.equals(fileType)) {
	    	if(StringUtils.isNotEmpty(bulkReq.getCompanyCode())) {
	    			getMDMDerivedBusiness(accReq,bulkReq);
			   }else {
				   getBusiness(accReq,bulkReq);
			   }
    	}else if(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC.equals(fileType)
                || BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL.equals(fileType)){
    		
    		if(StringUtils.isEmpty(bulkReq.getCompanyCode())) {
    			if(StringUtils.isNotEmpty(bulkReq.getBuCode())) {
    				getBusiness(accReq,bulkReq);
    				
    			}else {
    				accReq.setBuCode(accReqMDM.getBuCode());
    				accReq.setBussName(accReqMDM.getBussName());
    				accReq.setSubBusName(accReqMDM.getSubBusName());
    			}
    		}else {
    			getMDMDerivedBusiness(accReq,bulkReq);
    		}
    	}
    	
    	bulkReq.setBuCode(accReq.getBuCode());
    	bulkReq.setBussName(accReq.getBussName());
    	bulkReq.setSubBusiness(accReq.getSubBusName());
	}
	
    private PlatformInstance getPlatformInstance(String tCode) {
        Long platformInstanceId = accountService.getLastUpdatedPlatformInstance(tCode);
        if(null != platformInstanceId){
            PlatformInstance platformInstance = new PlatformInstance();
            platformInstance.setPlatformInstanceId(platformInstanceId);
            return platformInstance;
        }else{
            return null;
        }
    }

    private String getSubTypeCode(String fileType) {
        return BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL.equals(fileType)?"MODIFY_REASON_I":"MODIFY_REASON_O";
    }

    private void verifyAndPopulateGoldLeInfo(AccountRequest accReq, AccountRequest accReqMDM){
      if(null != StringUtils.trimToNull(approvalRequestMap.get(accReqMDM.gettCode()).getLeCode())){
        //set the values temporarily
          String response = this.bulkUploadService.getGoldLeNames(approvalRequestMap.get(accReqMDM.gettCode()).getLeCode());
             
          setLEDetails(accReq, response);
          
      }else{
          accReq.setLeName(accReqMDM.getLeName());
          accReq.setLeVersion(accReqMDM.getLeVersion());
      }
        
    }
    
    private void setLEDetails(AccountRequest accReq,String response){
		 if (null != StringUtils.trimToNull(response)) {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray data = jsonObject.getJSONArray("elements");
            if (data.length() > 0) {
                for (int i = 0; i < data.length(); i++) {
                    JSONObject obj = data.getJSONObject(i);
                    accReq.setLeName((String) obj.get("party_nm"));
                    accReq.setLeVersion((obj.get("version_num")).toString());
                }
            }
        }
	}

    private String getComponentCode(String componentCode, String leCode, String bussName) {
        List<MyBankLookup> lookupTypes = lookupService.getLovsByLookupType("COMPCODE_BUSINESS",
                ControllersConstants.DEFAULT_LOV_ORDER, ControllersConstants.DEFAULT_DIRECTION);

        Collection<String> businessListNames = lookupTypes.stream().map(lookup -> StringUtils.trimToEmpty(lookup.getDispname())).collect(Collectors.toList());

        if (businessListNames.contains(StringUtils.trimToEmpty(bussName)) && null == StringUtils.trimToNull(componentCode)
                && !StringUtils.isEmpty(leCode)) {
            return leCode;
        }
        return componentCode;
    }

    private String getMDMBankName(String bankId,String countryCode)  {
		String bankName = null;
		String response = this.bulkUploadService.getMDMBankDetails(bankId,countryCode);

		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() > 0) {
				JSONObject obj = elements.getJSONObject(0);
				bankName = (String) obj.get("bank_legal_name");
			}
		}
		return bankName;
	}

	

public String generateTcode(AccountRequest acctRequest,Map<Long, List<String>> errorMap){
	 MDMAccount mdmAcct =null;
     Object tCodeStr=null;
     String tcode=null;
     List<String> errList=null;
     
     mdmAcct=  mdmService.constructMDMAccount(acctRequest, MDM_ACCT_STATUS_INPROCESS);
     
	try {
		tCodeStr = mdmService.callMDMBankAccountCentralize(mdmAcct);
		if(tCodeStr!=null){
		      tcode = tCodeStr.toString();
		  
			}
			else{
				errList = new ArrayList<String>();
				errList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR+" - Error in TCode generation");
				errorMap.put(acctRequest.getStgId(),errList);
			}
	} catch (SystemException e) {
		MyBankLogger.logError(this, "BulkUploadProcessScheduler.generateTcode:" + e.getMessage(), e);
		errList = new ArrayList<String>();
		errList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR+" Unable to generate T-Code - "+e.getMessage());
		errorMap.put(acctRequest.getStgId(),errList);
	}catch (ValidationFailedException e){
		MyBankLogger.logError(this, "BulkUploadProcessScheduler.generateTcode:" + e.getMessage(), e);
		Errors a = e.getErrors();
		StringBuilder bldrStr = new StringBuilder();
		if(null !=a.getAllErrors()){
			for(ObjectError obj : a.getAllErrors()) {
				bldrStr.append(obj.getDefaultMessage()+".");
			}			
		}
		errList = new ArrayList<String>();
		errList.add(BulkApprovalConstants.BULK_UPLOAD_SYSTEM_ERR+" Unable to generate T-Code - "+bldrStr.toString());
		errorMap.put(acctRequest.getStgId(),errList);
	}
	
    return tcode;
}

private void updateFailureStatus(String failureReason){
	Date today=new Date();
	BulkApprovalRequest failedBulkApproval=null;
	FileUploadActivity fileUploadActivity =null;
	
	try{
	failedBulkApproval=new BulkApprovalRequest();
	failedBulkApproval.setStatusCode(BulkApprovalConstants.FILEUPLOADACT_FAILURE);
	failedBulkApproval.setFileUpldId(fileUpload.getFileUpldId());
	failedBulkApproval.setLastUpdateDate(today);
	failedBulkApproval.setLastUpdateUser(user.getSso());
	failedBulkApproval.setFailureReason(failureReason);
	
	bulkApprovalService.updateBulkApprovalStageRecord(failedBulkApproval);	
	

	fileUploadActivity = createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_FAILURE);

	fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
	
	fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_FAILURE);
	fileUpload.setLastUpdateDate(today);
	fileUpload.setLastUpdateUser(user.getSso());
	//Update fileUpload status as failure
	bulkApprovalService.updateFileUploadStatus(fileUpload, user);
	
	
	
   }catch(Exception e){
	   
	  MyBankLogger.logError(this, e.getMessage(), e);
		
	}
}
public void setDocument(  List<AccountDocument> documentList,String docUrl,String docType)throws SystemException{
	AccountDocument accountDocument=null;
	String fileId=null;

	if (null != StringUtils.trimToNull(docUrl)) {
		List<String> urlArr = new ArrayList<String>();

		if (docUrl.contains(BulkApprovalConstants.COMMA)) {
			urlArr.addAll(Arrays.asList(docUrl.split(BulkApprovalConstants.COMMA)));
		} else {
			urlArr.add(docUrl);
		}
		for (String url : urlArr) {
			accountDocument=new AccountDocument();	
			Map<String, String> map=null;
			try {
				map = StringHelper.splitQuery(new URL(url));
			    
				fileId = map.containsKey(BulkApprovalConstants.FILE_ID) ? map.get(BulkApprovalConstants.FILE_ID) : null;
		      }
		catch (UnsupportedEncodingException | MalformedURLException e) {
			throw new SystemException(e);
		} 
			accountDocument = bulkApprovalService.getMetadataForFile(fileId);
			accountDocument.setDocURL(url);
			accountDocument.setDocType(docType);
			documentList.add(accountDocument);
         }

		}
	
}

    private void updateInflightRequests(AccountRequest accountRequest) {
        if (BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL
                .equalsIgnoreCase(fileUpload.getUpldTypeCode()) && approvalRequestMap.containsKey(accountRequest.gettCode())) {
            BulkApprovalRequest approvalRequestFromUI = approvalRequestMap.get(accountRequest.gettCode());
            inflightRequestService.updateInflightRequests(createRequestForInflightUpdation(approvalRequestFromUI,accountRequest), fileUpload, accountRequest);
        }
    }

    private AccountRequest createRequestForInflightUpdation(BulkApprovalRequest approvalRequestFromUI, AccountRequest accReq) {
        AccountRequest accountRequest = new AccountRequest();
        accountRequest.settCode(approvalRequestFromUI.gettCode().toUpperCase());
        accountRequest.setRequestStatus(approvalRequestFromUI.getAccountStatus());
        accountRequest.setAccountType(approvalRequestFromUI.getAccountType());
        accountRequest.setAcctNumber(approvalRequestFromUI.getAccountNumber());
        accountRequest.setIban(approvalRequestFromUI.getIban());
        accountRequest.setLeCode(approvalRequestFromUI.getLeCode());
        accountRequest.setCountry(approvalRequestFromUI.getCountry());
        accountRequest.setCurrency(approvalRequestFromUI.getCurrency());
        accountRequest.setBankId(approvalRequestFromUI.getBankId());
        accountRequest.setRouteCode(approvalRequestFromUI.getRouteCode());
        accountRequest.setRouteCodeType(approvalRequestFromUI.getRouteCodeType());
        accountRequest.setBranchMDMID(approvalRequestFromUI.getBranchID());
        accountRequest.setBankClassification(approvalRequestFromUI.getBankClassification());
        List<AccountDocument> documentList = new ArrayList<AccountDocument>();
        
        setDocument(documentList, approvalRequestFromUI.getDocuments(), approvalRequestFromUI.getDocumentType());
        setDocument(documentList, approvalRequestFromUI.getBankConfirmation(),BulkApprovalConstants.BANK_CONFIRMATION );
        setDocument(documentList, approvalRequestFromUI.getSpbDocument(), BulkApprovalConstants.SPECIAL_PURPOSE_BANK);
        accountRequest.setDocuments(documentList);
        
        AccountComment ac = new AccountComment();
        ac.setComments(approvalRequestFromUI.getComments());
        ac.setCommentType(ValidationConstants.ACCOUNT_COMMENT_TYPE_REQUEST);

        List<AccountComment> commentList = new ArrayList<AccountComment>();
        commentList.add(ac);
        accountRequest.setComments(commentList);
        
        accountRequest.setCashpoolTCode(approvalRequestFromUI.getCashpoolTCode());
        accountRequest.setAccountTitle(approvalRequestFromUI.getAccountTitle());
        accountRequest.setBuCode(approvalRequestFromUI.getBuCode());
        if(StringUtils.isNotEmpty(approvalRequestFromUI.getCompanyCode()) || StringUtils.isNotEmpty(approvalRequestFromUI.getBuCode())) {
            accountRequest.setBussName(accReq.getBussName());
            accountRequest.setSubBusName(accReq.getSubBusName());
        }
        accountRequest.setCompanyCode(approvalRequestFromUI.getCompanyCode());
        accountRequest.setMeCode(approvalRequestFromUI.getMe());
        accountRequest.setAccountPurpose(approvalRequestFromUI.getAccountPurpose());
        accountRequest.setComponentCode(approvalRequestFromUI.getComponentCode());
        accountRequest.setProjectName(approvalRequestFromUI.getProjectName());
        accountRequest.setCoCodeRejectReason(approvalRequestFromUI.getCoCodeRejectReason());
        accountRequest.setPlatformInstance(getPlatformInstance(accountRequest.gettCode()));
        
        return accountRequest;
    }
    
    private User getRequester() {
        List<FileUploadActivity> activities = fileUploadActivityService.getFileUploadActivityDetailsById(fileUpload.getFileUpldId());
        if(!CollectionUtils.isEmpty(activities)){
            FileUploadActivity requestActivity = activities.stream()
                    .filter(requester -> BulkApprovalConstants.FILEUPLOADACT_SUBMITTED
                            .equalsIgnoreCase(requester.getStatusCode())).findFirst().get();
            User requester = new User();
            UserProfile profile = new UserProfile();
            List<UserRole> roles = new ArrayList<UserRole>();
            UserRole treasury = new UserRole();
            requester.setSso(requestActivity.getCreateUser());
            treasury.setMyBankRole(requestActivity.getUserRole());
            profile.setSso(requestActivity.getCreateUser());
            roles.add(treasury);
            profile.setRoles(roles);
            requester.setUserProfile(profile);
            
            return requester;
        }
        
        return null;
    }

    //Get company code response from company code service and derive bu code from the response
    private void getMDMDerivedBusiness(AccountRequest accReq,BulkApprovalRequest target){
    	HashMap<String, String> params = new HashMap<>();
    	StringBuilder filter = new StringBuilder();
		
    	filter.append("(");
  	   
		try {
			filter.append(UPPER_2 + MDMConstants.COMPANY_CODE + UPPER_1 + URLDecoder.decode(target.getCompanyCode(),MDMConstants.UTF_8) + "')");
		} catch (UnsupportedEncodingException e1) {
			MyBankLogger.logError(this, "Error in decoding company code : " + e1.getMessage());
			throw new BusinessException("Error in decoding company code : " + e1.getMessage());
		}
		
        filter.append(")");
    	params.put(FILTER_CONST, filter.toString());
          
        String jsonOutput = mdmService.callMDMDenodo(params, companyCodeUrl, HttpMethod.GET, true);
        String buCode = null;
        
        if (null != jsonOutput) {

        	Iterator<Object> itr = setJsonIterator(jsonOutput);
			try {
				while(itr.hasNext()) {
						JSONObject obj = (JSONObject) itr.next();
						buCode = StringHelper.getStringValue(obj.get(MDMConstants.ASSOCIATED_BU));
				}
			} catch (Exception e) {
				MyBankLogger.logError(this, e.getMessage());
				throw new BusinessException(e.getMessage());
			}
        }
        target.setBuCode(buCode);
		getBusiness(accReq,target);
		
    }
   
    //set bu code, business/sub-business from bu code response
    private void getBusiness(AccountRequest accReq,BulkApprovalRequest target){
    	
		String jsonOutput = mdmService.getBusinessFromBu(target.getBuCode(),true);
		
		if (null != jsonOutput) {

			Iterator<Object> itr = setJsonIterator(jsonOutput);
			try {
				while (itr.hasNext()) {
					JSONObject obj = (JSONObject) itr.next();

					accReq.setBuCode(StringHelper.getStringValue(obj.get(MDMConstants.BU_CODE)));
					accReq.setBussName(StringHelper.getStringValue(obj.get(MDMConstants.RPTLEVEL1__BU_DESCRIPTION)));
					accReq.setSubBusName(StringHelper.getStringValue(obj.get(MDMConstants.RPTLEVEL2__BU_DESCRIPTION)));
				} 
			} catch (Exception e) {
				MyBankLogger.logError(this, e.getMessage());
				throw new BusinessException(e.getMessage());
			}
			
		}
    }
    
    private Iterator<Object> setJsonIterator(String jsonOutput) {
    	  
    	JSONObject jsonObject = new JSONObject(jsonOutput);
		JSONArray data = jsonObject.getJSONArray(ELEMENTS);
	    
		if(null==data || data.length() == 0){
			return null;
		}
		
		return data.iterator();
    }

}