package com.ge.treasury.mybank.util.business;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import com.ge.treasury.mybank.util.business.constants.ValidationConstants;


public class JsonDateDeserializer extends JsonDeserializer<Date> {

 // ISO 8601
    DateFormat dateFormat = null;

    @Override
    public Date deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
            throws IOException, JsonProcessingException
    {
        try
        {
            if(jsonParser.getText().contains("-")) {
                dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            } else {
                dateFormat = new SimpleDateFormat(ValidationConstants.DATE_FORMAT, Locale.ENGLISH);
            }
            
            
            return dateFormat.parse(jsonParser.getText());
        }
        catch (ParseException e)
        {
            throw new JsonParseException("Could not parse date", jsonParser.getCurrentLocation(), e);
        }
    }

}
