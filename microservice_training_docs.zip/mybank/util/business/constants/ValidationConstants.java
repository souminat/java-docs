/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.constants;

/**
 * List of Constants needed for Validation
 * 
 * @author MyBank Dev Team
 * 
 */
public interface ValidationConstants {

    // Message to be showed if properties does not contain the error code
    public static final String INVALID_DEFAULT_MESSAGE = "Field is empty or value is invalid.";

    // Regex for match anything but |.*() to prevent sql insertion at search
    public static final String ANYTHING_BUT_REGEX = "^[^<<>|*/%>]+$";

    // Regex for Alphanumeric validation for criteria filters, allows more that
    // 1 value separated by comma
    public static final String ALPHANUMERIC_COMMA_REGEX = "^([ -_.()a-zA-Z0-9]+,?)+$";

    // Regex for Alphanumeric validation
    public static final String ALPHANUMERIC_REGEX = "^[-_.,;()a-zA-Z0-9 ]*$";

    // Date formats
    public static final String DATE_FORMAT = "dd MMM yyyy";
    public static final String DATE_TIME_FORMAT = "dd MMM yyyy HH:mm:ss aaa";
    public static final String MDMDATE_FORMAT = "yyyy-MM-dd";
    public static final String CREATEDATE_FORMAT = "EEE MMM dd HH:mm:ss zzzz yyyy";
    public static final String DBDATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSSSS";
    public static final String INFLIGHT_DATE_FORMAT = "MM/dd/YYYY";

    // General
    public static final String EMPTY_STRING = "";

    // Account status type lookup values
    public static final String ACCOUNT_STATUS_CANCELLED = "ACCTREQSTAT_CANCELLED";
    public static final String ACCOUNT_STATUS_PEND_TREASURY = "ACCTREQSTAT_PENDTREASURY";
    public static final String ACCOUNT_STATUS_PEND_BANKCONF = "ACCTREQSTAT_PENDBANKCONFM";
    public static final String ACCOUNT_STATUS_COMPLETED = "ACCTREQSTAT_COMPLETED";

    // Account comment type lookup values
    public static final String ACCOUNT_COMMENT_TYPE_REQUEST = "ACCTREQCOMMENTTYPE_REQUEST";

    // Account flag ischecked flag values
    public static final String FLAG_STATUS_CHECKED_NO = "N";
    public static final String FLAG_STATUS_CHECKED_YES = "Y";

    // Account flag values
    public static final String FLAG_STATUS_NO = "N";
    public static final String FLAG_STATUS_YES = "Y";

    // Object type to be obtained of lookup table needed for validations
    public static final String ACCT_REQUEST_STATUS = "ACCT_REQUEST_STATUS";
    public static final String ACCT_REQUEST_TYPE = "ACCT_REQUEST_TYPE";
    public static final String ACCT_REQUEST_DOCUMENT_TYPE = "ACCT_REQUEST_DOCUMENT_TYPE";
    public static final String ACCT_REQUEST_SIGNER_TYPE = "ACCT_REQUEST_SIGNER_TYPE";
    public static final String ACCT_REQUEST_COMMENT_TYPE = "ACCT_REQUEST_COMMENT_TYPE";
    public static final String ACCT_REQUEST_FLAG = "ACCT_REQUEST_FLAG";

    // Audit Microservice
    public static final String MYBANK_AUDIT_DOMAIN = "MyBank";
    public static final String MYBANK_AUDIT_ENTITY = "Account Request";
    public static final String MYBANK_AUDIT_PARENT_ADDED = "Added";
    public static final String MYBANK_AUDIT_PARENT_UPDATED = "Updated";
    public static final String MYBANK_AUDIT_PARENT_DELETED = "Deleted";

    // MDM Microservice
    public static final String MYBANK_MDM_REQUESTOR = "MyBank";
    public static final String MYBANK_MDM_ENTITY_BNKACCTCENTRALIZE = "BankAccountCentralize";
    public static final String MDM_ACCT_STATUS_OPEN = "Open";
    public static final String MDM_ACCT_STATUS_CLOSE = "Closed";
    public static final String MDM_ACCT_STATUS_DIVESTED = "Divested";
    public static final String MDM_ACCT_STATUS_ACQUIRED = "Acquired";
    public static final String MDM_ACCT_STATUS_INPROCESS = "InProcess";
    public static final String MDM_STATUS_RESPONSE = "SUCCESS";
    public static final String MDM_QUERY_PARAM = "requestData";

    // Signature card upload
    public static final String FILEUPLOAD_STATUS_UPLOADED = "FILEUPLOAD_STATUS_SUCCESS";
    public static final String ACCTREQDOCTYPE_SIGNRCARD = "ACCTREQDOCTYPE_SIGNRCARD";

    // Signature types
    public static final String ACCT_SIGNER_TYPE_SSO = "ACCTREQSIGNERTYPE_SSO";
    public static final String ACCT_SIGNER_TYPE_LEGAL_ENTITY = "ACCTREQSIGNERTYPE_LE";
    public static final String ACCT_SIGNER_TYPE_PERSONAL_CHOP = "ACCTREQSIGNERTYPE_PERSONCHOP";
    public static final String ACCT_SIGNER_TYPE_COMPANY_CHOP = "ACCTREQSIGNERTYPE_COMPCHOP";
    public static final String ACCT_SIGNER_TYPE_FACSIMILE = "ACCTREQSIGNERTYPE_FACSIMILE";

    // Account Request Types
    public static final String ACCT_REQUEST_TYPE_MODIFY = "ACCTREQTYPE_MODIFY";
    public static final String ACCT_REQUEST_TYPE_OPEN = "ACCTREQTYPE_OPEN";
    public static final String ACCT_REQUEST_TYPE_CLOSE = "ACCTREQTYPE_CLOSE";
    public static final String ACCT_REQUEST_TYPE_DIVESTED = "ACCTREQTYPE_DIVESTED";
    public static final String ACCT_REQUEST_TYPE_ACQUIRED = "ACCTREQTYPE_ACQUIRED";
	
	//Sub Type codes
	public static final String ACCT_REQ_SUB_TYPE_CPC = "MODIFY_REASON_CPC";

    // Account Request Users
    public static final String ACCT_REQUEST_USER_INITIATOR = "Business Initiator";
    public static final String ACCT_REQUEST_USER_TREASURY = "Treasury Services";
    public static final String ACCT_REQUEST_USER_TREASURY_DIVESTED = "Treasury Services Divested Businesses";
    public static final String ACCT_REQUEST_USER_INITIATOR_RO = "Business Read Only";
    public static final String ACCT_REQUEST_USER_TREASURY_RO = "Treasury Services Read Only";
    public static final String ACCT_REQUEST_USER_TREASURY_ADMIN = "Treasury Services Admin";
    public static final String ACCT_REQUEST_USER_FINANCE_ADMIN = "Finance Admin";

    // Fields
    public static final String ACCOUNT_STATUS = "requestStatus";

    // IDM (FineGrain) Microservice
    public static final String MYBANK_IDM_APPNAME = "MYBANK";
    public static final String MYBANK_IDM_STATUSACTIVE = "ACTIVE";
    public static final String MYBANK_IDM_STATUSRESPONSE = "SUCCESS";
    public static final String MYBANK_USERPROFILE_GENERIC_ERROR = "Unable to Get ACL User information";
    public static final String MYBANK_HRAPI_GENERIC_ERROR = "Unable to Get User Information from HR Api";

    // Strings to get from JSON
    public static final String JSON_GET_RESPONSEDATA = "responseData";
    public static final String JSON_GET_STATUS = "Status";
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String STATUS_FAILED = "FAILED";
    public static final String JSON_GET_MESSAGE = "Message";
    public static final String JSON_GET_TCODE = "tcode";
    public static final String JSON_GET_STATUS_OK = "OK 200";
    public static final String JSON_GET_DATA = "data";

    // Strings from Drools Service
    public static final String CASHPOOL_DROOLS = "CASHPOOLPROCODE_DROOLS";
    public static final String CASHPOOL_OUTPOOT = "CashpoolProcessOutput=";
    public static final String ACCOUNT_TYPE = "accountType";
    public static final String LECODE_TAX = "leCodeTax";
    public static final String LECODE = "leCode";
    public static final String COUNTRY = "country";
    public static final String CURRENCY = "currency";
    public static final String LE_COUNTRY = "leCountry";
    public static final String ACCTREQ_ID = "accReqId";
    public static final String REQUEST = "request";
    public static final String RESPONSE = "response";
    public static final String DROOLS_STATUS = "status";
    public static final String RESPONSE_DROOLS = "Response from Drools Engine ->";
    public static final String NO_RULES_FOUND = "No rules are found for this criteria";
    public static final String RESPONSE_NOT_FOUND = "No proper response found for the Drools request";
    public static final String DROOLS_ERROR = "Error caused on Drools trigger->";
    public static final String RESPONSE_FETCH_FAILED = "Unable to fetch response from Drools";
    
    // Regex for file extension validation
    public static final String CSV_REGEX = "^[^\\/:\"*?<>|]+(.csv|.CSV)$";
    public static final String JSON_GET_STATUS_MESSAGE = "statusMessage";
    public static final String SPB = "Special Purpose Bank";

    public static final String ACTIVE = "Active";

    public static final String INACTIVE = "Inactive";

	public static final String PROJECT_NOT_FOUND = "Invalid Project Name";

	public static final String DEAL_SUCCESS = "Deal Details Updated Successfully";
	
	public static final String DEAL_FAILURE = "Error in saving Deal Details - My Bank Request not Found.";
	
	public static final String DEAL_EXCEPTION = "Exception in saving Deal Details - ";
	
	public static final String MYBANK_MYFUNDING_SUCCESS = "SUCCESS";
	
	public static final String MYBANK_MYFUNDING_FAILURE = "FAILURE";
	
	public static final String MYBANK_MYFUNDING_EXCEPTION = "EXCEPTION";
	
	public static final String MYBANK_MYFUNDING_EXCEPTION_BLANK_HEADER = "headerLEId cannot be Blank / 'No Cashpool' not allowed";
	
	public static final String CASHPOOLPROCODE_RED = "CASHPOOLPROCODE_RED";
	
	public static final String CASHPOOLSTATCODE_SUBMITTED = "CASHPOOLSTATCODE_SUBMITTED";
}
