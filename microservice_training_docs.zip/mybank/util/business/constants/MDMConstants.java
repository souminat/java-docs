package com.ge.treasury.mybank.util.business.constants;

public class MDMConstants {

    private static final String S = "S";
    public static final String S0 = S + "0";
    public static final String S1 = S + "1";
    public static final String S2 = S + "2";
    public static final String S3 = S + "3";

    public static final String ACTIVE = "Active";
    public static final String CLOSED = "Closed";

    // Operators
    public static final String OPERATOR_EQUALS = "=";
    public static final String OPERATOR_GREATER_THAN = ">";
    public static final String OPERATOR_LESS_THAN = "lt";
    public static final String OPERATOR_LIKE = "like";
    public static final String OPERATOR_OR = "OR";
    public static final String OPERATOR_AND = "AND";
    public static final String OPERATOR_SPACE = " ";
    public static final String OPERATOR_COMMA = ",";
    
    public static final String IS_NOT_NULL = " is not null";
    
    // Order
    public static final String ORDER_ASCENDING = "asc";
    public static final String ORDER_DESCENDING = "desc";

    // Entity Names
    public static final String ENTITY_NAME_BANK_ACCOUNT_CENTRALIZE = "BankAccountCentralize";
    public static final String ENTITY_NAME_BANK_BRANCH = "Bank-Branch";
    public static final String ENTITY_NAME_BANK = "Bank";
    public static final String ENTITY_NAME_BUSINESS = "Business";
    public static final String ENTITY_NAME_LE = "LE";
    public static final String ENTITY_NAME_CURRENCY = "Currency";
    public static final String ENTITY_NAME_COUNTRY = "Country";
    public static final String ENTITY_NAME_ACCOUNT_TYPE = "AccountType";
    public static final String ENTITY_NAME_DOCUMENT_TYPE = "DocumentType";

    public static final String ENTITY_NAME_ACCOUNT_STATUS = "accountStatus";
    public static final String ENTITY_NAME_BUSSNAME = "bussName";
    public static final String ENTITY_NAME_TCODE = "tCode";
    public static final String ENTITY_NAME_BANKID = "bankId";
    public static final String ENTITY_NAME_IBAN = "iban";
    public static final String ENTITY_NAME_CNTRY = "country";
    public static final String ENTITY_NAME_CURR = "currency";
    public static final String ENTITY_NAME_LECODE = "leCode";

    // Requestor
    public static final String MY_BANK = "MyBank";

    public static final String CORE_ATTRIBUTES = "Core Attributes";
    public static final String DOCUMENT_ATTRIBUTES = "Document Attributes";
    public static final String SIGNATORY_ATTRIBUTES = "Signatory Attributes";
    public static final String CONTACT_ATTRIBUTES = "Contact Attributes";

    // Columns
    public static final String BANK_ACCOUNT_CENTRALIZE_REQUEST_ID = "RQST_ID";
    public static final String BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS = "ACCOUNT_STATUS";
    public static final String BANK_ACCOUNT_CENTRALIZE_SUB_BUSINESS_NAME = "SUB_BUSINESS_NAME";
    public static final String BANK_ACCOUNT_CENTRALIZE_BUSINESS_NAME = "BUSINESS_NAME";
    public static final String BANK_ACCOUNT_CENTRALIZE_T_CODE = "TCODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_BANK_MDM_ID = "BANK_MDM_ID";
    public static final String BANK_ACCOUNT_CENTRALIZE_IBAN = "IBAN";
    public static final String BANK_ACCOUNT_CENTRALIZE_COUNTRY_CODE = "COUNTRY_CODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_CURRENCY_CODE = "CURRENCY_CODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_GOLD_LE_CODE = "GOLD_LE_CODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_ACCT_TYPE_ID = "ACCT_TYPE_ID";
    public static final String BANK_ACCOUNT_CENTRALIZE_ACCOUNT_TYPE = "ACCT_TYPE";
    public static final String BANK_ACCOUNT_CENTRALIZE_ROUTE_CODE = "RTE_CODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_NATIONAL_BANK_ACCOUNT_NUMBER = "NATL_BANK_ACCT_NBR";
    public static final String BANK_ACCOUNT_CENTRALIZE_COMPANY_CODE = "COMPANY_CODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_ME_CODE = "ME_CODE";
    public static final String BANK_ACCOUNT_CENTRALIZE_ACCOUNT_PURPOSE = "acct_purp";

    public static final String BANK_BANK_LEGAL_NAME = "BANK_LEGAL_NAME";
    public static final String BANK_MDM_ID = "MDM_ID";
    public static final String BANK_BANK_COUNTRY_CODE = "BANK_COUNTRY_CODE";
    public static final String BANK_BANK_TYPE = "BANK_TYPE";
    public static final String BANK_BANK_STATUS = "BANK_STATUS";
    public static final String BANK_BANK_LONG_NAME = "BANK_LONG_NAME";

    public static final String BUSINESS_BUSINESS_ACCOUNT_GROUP = "BUS_ACCT_GRP";
    public static final String BUSINESS_SUBBUSINESS_ACCOUNT_GROUP = "SUB_BUS_ACCT_GRP";

    public static final String LE_PRIMARY_ALT_CODE = "PRIMRY_ALT_CODE";
    public static final String LE_PARTY_NM = "PARTY_NM";
    public static final String LE_PARTY_LONG_NM = "PARTY_LONG_NM";
    public static final String LE_PRIMRY_SCOURCE_SYSTEM = "PRIMRY_SRCE_SYS";
    public static final String LE_PARTY_STATUS = "PARTY_STATUS";
    public static final String ACTIVE_FLAG = "ACTV_FLAG";
    
    public static final String ACCOUNT_TYPE_STATUS = "STATUS";
    public static final String ACCOUNT_ACCOUNT_TYPE = "ACCT_TYPE";

    public static final String COUNTRY_COUNTRY_STATUS = "CNTRY_STATUS";
    public static final String COUNTRY_MDM_ID = "MDM_ID";
    public static final String CNTRY_DESC = "CNTRY_DESC";
    public static final String CNTRY_CODE = "cntry_iso_2_code";
    
    public static final String LE_COUNTRY_CODE = "country_formtn_iso_2_code";
    
    public static final String CURRENCY_CURRENCY_STATUS = "STATUS";
    public static final String MDM_CURRENCY_CODE = "CURR_CODE";
    public static final String CURR_DESC = "curr_desc";

    public static final String UPPER_2 = "UPPER(";
    public static final String UPPER_4 = " UPPER('";
    public static final String UPPER_1 = ") = UPPER('";
    public static final String UPPER_LIKE = ") like UPPER('%";
    public static final String FILTER_CONST = "$filter";
    public static final String START_INDEX = "$start_index";
    public static final String COUNT = "$count";
    public static final String VERSION_NUM = "VERSION_NUM";
    public static final String ELEMENTS = "elements";
    public static final String BUS_ACCT_GRP_STATUS = "BUS_ACCT_GRP_STATUS";
    public static final String SUB_BUS_ACCT_GRP_STATUS = "SUB_BUS_ACCT_GRP_STATUS";
    public static final String BUS_SBUS_REL_STATUS = "BUS_SBUS_REL_STATUS";
    public static final Object AND_STRING = " and ";
    public static final String TOTAL_COUNT_REQUIRED = "$totalCountRequired";
    public static final String SELECT="$select";
    public static final String COMPANY_CODE = "company_code";
    public static final String ASSOCIATED_BU = "associated_bu";
    public static final String COMPANY_DESCRIPTION = "description";
    public static final String ASSOCIATED_LE = "associated_le";
    public static final String BUSINESS_NAME = "business_name";
    public static final String RTE_CODE_TYPE = "RTE_CODE_TYPE";
    public static final String CC_ASSOCIATED_LE = "CC_ASSOCIATED_LE";
    public static final String CC_NAME = "CC_NAME";
    public static final String MDM_MARS = "MARS";
    public static final String UPPER_3 = ") like UPPER('%";
    public static final String PROJECT_NAME = "project_name";
    
    public static final String BU_CODE = "bu_code";
    public static final String BU_ENABLED = "BU_ENABLED";
    public static final String UTF_8 = "UTF-8";
    
    public static final String RPTLEVEL1__BU_DESCRIPTION = "rpt_level1_bu_description";
    public static final String RPTLEVEL2__BU_DESCRIPTION = "rpt_level2_bu_description";
    
    public static final String DRM_LVL = "drm_lvl";
    private MDMConstants() {
        throw new IllegalAccessError("Utility class");
    }
}
