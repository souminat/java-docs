/**
 * Copyright GE
 */


package com.ge.treasury.mybank.util.business.constants;
/** Contains the constants values for Bulk Approval methods

 * @author MyBank Dev Team
 * 
 */

public interface BulkApprovalConstants {
	
    public static final String API = "/api/acct/v1";
    public static final String BULK_APPROVAL_FILTER="/bulkApprovalFilter";
    public static final String BULK_APPROVALS="/bulkApprovals";
    public static final String BULK_APPROVAL_EXPORT="/bulkApprovalExport";
    public static final String BULK_APPROVAL_GET_UPLOAD="/bulkApprovalGetUpload";
    public static final String BULK_APPROVAL_FILTER_PAGINATION="/bulkApprovalFilterPagination";
    public static final String BULK_APPROVAL_APPROVED="/bulkApprovalApproved";
    public static final String BULK_APPROVAL_REJECT="/bulkApprovalRejected";
    public static final String PROCESS_APPROVAL="/processApproval";
    public static final String BULK_APPROVAL_PROCESS_ERROR="/bulkApprovalError";
    public static final String BULK_APPROVAL_PROCESS_ERROR_EXPORT="/bulkApprovalErrorExport";
    public static final String BULK_APPROVAL_PROCESS_SIGNER_ERROR_EXPORT="/bulkSignerErrorExport";
    
    //FILE UPLOAD ACTIVITY STATUS
    public static final String FILEUPLOADACT_SUBMITTED = "FILEUPLOADACT_SUBMITTED";
    public static final String FILEUPLOADACT_APPROVED = "FILEUPLOADACT_APPROVED";
    public static final String FILEUPLOADACT_REJECTED = "FILEUPLOADACT_REJECTED";
    public static final String FILEUPLOADACT_PROCESSING = "FILEUPLOADACT_PROCESSING";
    public static final String FILEUPLOADACT_SUCCESS = "FILEUPLOADACT_SUCCESS";
    public static final String FILEUPLOADACT_FAILURE = "FILEUPLOADACT_FAILURE";
    public static final String FILEUPLOADACT_PARTIAL = "FILEUPLOADACT_PARTIAL";
    public static final String FILEUPLOADACT_PNDG_APPROVAL = "FILEUPLOADACT_PNDG_APPROVAL";
    public static final String FILEUPLOADACT_VALIDATION_INPROCESS = "FILEUPLOADACT_VLDN_INPROCESS";
    public static final String FILEUPLOADACT_VALIDATION_FAILED = "FILEUPLOADACT_VLDN_FAILED";
    public static final String FILEUPLOADACT_OPEN_IN_PROCESS = "FILEUPLOADACT_OPEN_IN_PROCESS";
    public static final String FILEUPLOADACT_MODFY_IN_PROCESS = "FILEUPLOADACT_MODFY_IN_PROCESS";
    public static final String FILEUPLOADACT_CLOSE_IN_PROCESS = "FILEUPLOADACT_CLOSE_IN_PROCESS";
    
    
    public static final String BULK_UPLOAD_OPEN_TEMPLATE = "BULK_UPLOAD_OPEN";
    public static final String BULK_UPLOAD_CLOSE_TEMPLATE = "BULK_UPLOAD_CLOSE";
    public static final String BULK_UPLOAD_MODIFY_TEMPLATE = "BULK_UPLOAD_MODIFY";
    public static final String BULK_UPLOAD_MODIFY_INTERNAL_TEMPLATE = "BULK_UPLOAD_INTERNAL";
    public static final String BULK_UPLOAD_SIGNER_TEMPLATE = "BULK_UPLOAD_SIGNER";
    public static final String BULK_UPLOAD_FILE_TYPE_OPEN="FILE_UPLOAD_OPEN";
    public static final String BULK_UPLOAD_FILE_TYPE_CLOSE="FILE_UPLOAD_CLOSE";
    public static final String BULK_UPLOAD_FILE_TYPE_MODIFY="FILE_UPLOAD_MODIFY";
    public static final String BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC="FILE_UPLOAD_MODIFY_SPECIFIC";
    public static final String BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL="FILE_UPLOAD_MODIFY_INTERNAL";
    public static final String BULK_UPLOAD_FILE_TYPE_SIGNER="FILE_UPLOAD_SIGNER";
    
    public static final String BULK_UPLOAD_OPEN="OPEN";
    public static final String BULK_UPLOAD_CLOSE="CLOSE";
    public static final String BULK_UPLOAD_MODIFY="MODIFY_ALL";
    public static final String BULK_UPLOAD_MODIFY_INTERNAL="MODIFY_INTERNAL";
    public static final String BULK_UPLOAD_SIGNER="SIGNER";
    public static final String BULK_UPLOAD_MODIFY_SPECIFIC="MODIFY_SPECIFIC";
    public static final String BULK_UPLOAD_FAQ="UPLOAD_FAQ";
    public static final String BULK_UPLOAD_HELP_FAQ="FAQ";
    public static final String BULK_UPLOAD_HELP_REPORTS="Reports";
    public static final String BULK_UPLOAD_HELP_CONTACTS="Contacts";
    
    public static final String BULK_REQUEST_TYPE_MODIFY = "ACCTREQTYPE_MODIFY";
    public static final String BULK_REQUEST_TYPE_OPEN = "ACCTREQTYPE_OPEN";
    public static final String BULK_REQUEST_TYPE_CLOSE = "ACCTREQTYPE_CLOSE";
    
    public static final String BULK_UPLOAD_VALIDATION_ERR = "VAL_ERR: ";
    public static final String BULK_UPLOAD_SYSTEM_ERR = "SYS_ERR: ";
    public static final String SIGNER_ACTION_REMOVE="REMOVE";
    public static final String SIGNER_ACTION_ADD="ADD";
    public static final String SIGNER_ACTION_MODIFY="MODIFY";
    public static final String SIGNER_TYPE_SSO="SSO";
    public static final String SIGNER_TYPE_FACSIMILE="FACSIMILE";
    public static final String SIGNER_TYPE_COMPANY_CHOP="COMPANY CHOP";
    public static final String SIGNER_TYPE_PERSONAL_CHOP="PERSONAL CHOP";
    public static final String SIGNER_TYPE_NON_SSO="NON SSO";
    
    public static final String SIGNER_SUB_TYPE_ADDITION = "MODIFY_REASON_SA";
    public static final String SIGNER_SUB_TYPE_REMOVAL = "MODIFY_REASON_SR";
    
    public static final String TCODE="Tcode";
    public static final String T_CODE="T-code";
    public static final String ACCOUNT_OPEN="Account in Open State - cannot be put to Acquired state";
    public static final String ACCOUNT_DIVESTED="Account status cannot be modified to/From Divested state in Modify template";
    public static final String ACCOUNT_CLOSED = "Account is closed in MDM - Please enter Open account status for reopening tcode";
    public static final String ACCOUNT_NOT_EXIST="Account doen't exist in MDM";
    public static final String DUPLICATE_TCODE_MSG="Duplicate T-Code";
    public static final String TSA_STATUS_INACTIVE="TSA status for this project name is Inactive";
    public static final String ACCT_BANK_COUN_CURR="Account Number/Bank MDM ID/Bank Account Country/Bank Account Currency";
    public static final String DUPLICATE_ACCT_DETAILS_MSG="Duplicate Account Details";
    public static final String GOLD_ID="Gold ID";
    public static final String COMP_CODE="Component Code";
    public static final String ROUTE_CODE_COL="Route Code";
    public static final String BANK_COUNTRY_MSG="Bank Id is not associated with Bank Country";
    public static final String ROUTE_CODE_MSG="Route Code is not associated with Bank Id";
    public static final String ROUTE_CODE_TYPE_COL="Route Code Type";
    public static final String ROUTE_CODE_TYPE_MSG="Route Code Type is not associated with the Route Code and Bank Id";
    public static final String BRANCH_ID_COL="Branch ID";
    public static final String BRANCH_ID_MSG="Branch ID is not associated with Route Code / Route Type";
    public static final String BANK_MDM_ID="Bank MDM Id";
    public static final String DOCUMENTS="Documents";
    public static final String SPB_DOCUMENT="Supporting documentation for special purpose bank";
    public static final String DOCUMENT_TYPE="Document Type";
    public static final String DOCUMENT_TYPE_REQUIRED="This filed is required when there is a document present";
    public static final String DOCUMENTS_REQUIRED="This field is required when the Document Type is present";
    public static final String BANK_CONFIRMATION="Bank Confirmation";
    public static final String SPECIAL_PURPOSE_BANK="Special Purpose Bank";
    public static final String ALTERNATE_ACCT="Alternate Account";
    public static final String BU_CODE="Bu Code";
    public static final String BUSINESS="Business";
    public static final String SUB_BUSINESS="Sub Business";
    public static final String BUS_SUB_BUSINESS="Business - Sub Business";
    public static final String BANK_COUNTRY="Bank Account Country";
    public static final String BANK_CURRENCY="Bank Account Currency";
    public static final String INVALID="Invalid";
    public static final String INVALID_COMBINATION="Invalid Combination Of";
    public static final String USAGEOF = " Usage Of";
    public static final String FILE_ID="fileid";
    public static final String AND_OPERATOR="&";
    public static final String BLANK_SPACE=" ";
    public static final String COMMA=",";
    public static final String OTHER_DOCUMENTATION="Other Documentation";
    public static final String INFLIGHT_REQUEST_MSG="There is already an inflight request for this account. Please complete the pending request No.";
    public static final String SINGLE_DOCUMENT_MSG="Multiple URL is not allowed";
    public static final String MODIFY_TYPE_CPC="Cash pool connection";
    public static final String MODIFY_TYPE_CPD="Cash pool disconnection";
    public static final String MODIFY_TYPE_SA="Signer Addition";
    public static final String MODIFY_TYPE_SR="Signer Removal";
    public static final String MODIFY_TYPE_SC="Services change";
    public static final String MODIFY_TYPE_LC="LE change";
    public static final String MODIFY_TYPE_OTHER="Other";
    public static final String MODIFY_TYPE_INTERNAL="Internal";
    public static final String CO_CODE_PRESENT = "Company code already present. Company Code Reject Reason cannot be provided";
    public static final String COMPANY_CODE_RJCT_RSN_ABSENT = "Company Code Reject Reason present. You cannot select a company code";
    public static final String BU_CODE_PRESENT = "Please remove company code from template to provide BU Code";
    public static final String BU_CODE_INACTIVE = "BU Code is Inactive. Please enter an active BU Code";
    public static final String BU_CODE_ABSENT = "Company Code absent. You have to enter BU code";
    public static final String BUSS_INVALID = "Invalid BU/Company Code. Failed to check component code eligibility from business";
    
    public static final String SIGNER_SSO_COLUMN="Signer's SSO";
    public static final String SIGNER_START_DATE="Signer's Start Date";
    public static final String SIGNER_SSO_MSG="Signer's SSO cannot be blank";
    public static final String SIGNER_SSO_MSG_INV="Signer's SSO is Invalid";
    public static final String SIGNER_TYPE_COLUMN="Signer Type";
    public static final String SIGNER_NON_SSO="Signer Type - NON SSO";
    public static final String SSO_NON_EMPTY="This Signer cannot have an SSO";
    public static final String SIGNER_START_EXP_DOC_COLUMN="Signer's Start Date, Signer's Expire Date, Document";
    public static final String SIGNER_START_EXP_DOC_MSG="One of these fields is needed for Modify Action";
    public static final String ACC_POOL_TO_TCODE_COLUMN="account shall pool to T-Code";
    public static final String ACC_POOL_TO_TCODE_MSG="Invalid Account Shall Pool To";
    public static final String NO_CASH_POOL="no cash pool";
    public static final String MYBANK_BULK_UPLOAD_FILE="MyBank Bulk Upload File ";
    public static final String BULK_UPLOAD_TEMPLATE_VM="bulkUploadTemplate.vm";
    public static final String FILE_UPLOAD_STATUS_TEMPLATE_VM= "fileUploadStatusEmail.vm";
    public static final String ID=" ID:";
    public static final String APPROVED_MSG=" is Approved. Now Processing the File";
    public static final String UPLOADED_MSG=" is Uploaded";
    public static final String REJECTED_MSG=" is Rejected";
    public static final String PROCESSING_COMP_MSG=" Processing Complete. ";
    public static final String PROCESSED_SUCCESS_MSG=" Record(s) Processed Successfully";
    public static final String PROCESSED_FAILED_MSG=" Record(s) Failed in Processing";
    public static final String ALL="All ";
    public static final String OUT_OF=" out of ";
    public static final String COMPANY_CODE="Company Code";
    public static final String CO_CODE_REJECT_REASON="Company Code Reject Reason";
    public static final String COMPANY_CODE_ERROR_MSG="Company code is not associated with Gold Id: ";
    public static final String COMPONENT_CODE_ERROR_MSG="Component code is not associated with Gold Id: ";
    public static final String ME_COLUMN="ME";
    public static final String SIGNER_EXPIRE_DATE_COL="Signer's Expire Date";
    public static final String SIGNER_EXPIRE_DATE_MSG="Signer's Expire Date must not be earlier than Signer's Start Date";
    public static final String SPB_ERROR="This filed is required only when bank classifiation is Special Purpose Bank";
    public static final String SIGNER_EXPIRE_REMOVE_MSG="This filed is required only when signer's action is Remove";
    public static final String SIGNER_NON_SSO_SSO_FIELD="Signer's SSO field has to be empty if Signer Type is Non SSO/Company Chop/Fascimilie";
    public static final String SIGNER_START_DATE_FIELD_REMOVE="Signer's Start Date field has to be empty if Signer Action is Remove";
    public static final String COMBINATION_MSG="This combination is already exist";
    public static final String COMBINITAION_COLS="Account Number,Bank Account Country,Bank Account Currency,Bank MDM ID,Route code";
    
    
  
    public static final String FETCH_DATA_FAILED = "Unable to fetch data from MyBank Database, please contact system administrator";
	public static final String EXPORT_FAILED = "Failed to export bulkapprovals' request data in excel sheet";
    
}
