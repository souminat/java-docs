/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.constants;

/**
 * Contains the constants values for Controller methods
 * 
 * @author MyBank Dev Team
 * 
 */
public class ControllersConstants {

    // Default values for order by functionality
    public static final String DEFAULT_LOV_ORDER = "DISPLAY_ORDER";
    public static final String DEFAULT_ASC_DIRECTION = "ASC";
    public static final String DEFAULT_DIRECTION = "ASC";
    public static final String DEFAULT_LOV_LOOKUPTYPE_ORDER = "LOOKUP_TYPE,DISPLAY_ORDER";
    public static final String DEFAULT_LOV_LOOKUPCODE = "LOOKUP_CODE";

    // Pagination constants
    public static final String LIMIT_KEY = "limit";
    public static final String DIRECTION_KEY = "direction";
    public static final String ORDERBY_KEY = "orderBy";
    public static final String START_KEY = "start";
    public static final String MAX_ACCOUNTS_SIZE = "max_trades_size";

    // Resource Not Found constants
    public static final String ACCOUNTS_NOTFOUND = "Accounts Not Found";
    public static final String ACCOUNT_NOTFOUND = "Account Not Found";
    public static final String RECORD_NOTFOUND = "Record Not Found";

    /**
     * Case insensitive regex pattern for checking if a given string matches
     * "Business (Initiator or Read Only)"
     */
    public static final String IS_BUSINIESS_LEVEL_ROLE_REGEX = "^(B|b)(U|u)(S|s)(I|i)(N|n)(E|e)(S|s)(S|s)(E|e)*(S|s)*.*$";
    public static final String MDM_ERROR = "MDM ERROR: ";

    public static final String NEW_REQUEST_FAILED = "Failed to process new account request, please contact system administrator";
    public static final String FETCH_DATA_FAILED = "Unable to fetch data from MyBank Database, please contact system administrator";
    public static final String DETAILS_NOT_FOUND = null;

    private ControllersConstants() {
        throw new IllegalAccessError("Utility class");
    }

}
