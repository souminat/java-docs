/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.constants;

/**
 * List of Constants needed for Validation
 * 
 * @author MyBank Dev Team
 * 
 */
public interface FileUploadConstants {

    // Libraries properties
    public static final String XML_PARAM_FEATURE = "http://xml.org/sax/features/external-parameter-entities";
    public static final String XML_GEN_FEATURE = "http://xml.org/sax/features/external-general-entities";

    // XML Constants
    public static final String XML_VERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    public static final String CALLAPI_START = "<CALLAPI>";
    public static final String CALLAPI_END = "</CALLAPI>";
    public static final String PARAMETERS_START = "<PARAMETERS>";
    public static final String PARAMETERS_END = "</PARAMETERS>";
    public static final String METHOD_START = "<METHOD>";
    public static final String METHOD_END = "</METHOD>";
    public static final String FOLDER_ID_START = "<FOLDER_ID>";
    public static final String FOLDER_ID_END = "</FOLDER_ID>";
    public static final String FOLDER_NAME_START = "<FOLDER_NAME>";
    public static final String FOLDER_NAME_END = "</FOLDER_NAME>";
    public static final String FOLDER_TITLE_START = "<FOLDER_TITLE>";
    public static final String FOLDER_TITLE_END = "</FOLDER_TITLE>";
    public static final String PUBLIC_READ_START = "<PUBLIC_READ>";
    public static final String PUBLIC_READ_END = "</PUBLIC_READ>";
    public static final String PUBLIC_WRITE_START = "<PUBLIC_WRITE>";
    public static final String PUBLIC_WRITE_END = "</PUBLIC_WRITE>";
    public static final String INHERITANCE_START = "<INHERITANCE>";
    public static final String INHERITANCE_END = "</INHERITANCE>";
    public static final String FILE_NAME_START = "<FILE_NAME>";
    public static final String FILE_NAME_END = "</FILE_NAME>";
    public static final String FILE_TITLE_START = "<FILE_TITLE>";
    public static final String FILE_TITLE_END = "</FILE_TITLE>";
    public static final String FILE_PATH_START = "<FILE_PATH>";
    public static final String FILE_PATH_END = "</FILE_PATH>";
    public static final String FILE_ID_START = "<FILE_ID>";
    public static final String FILE_ID_END = "</FILE_ID>";
    public static final String DESCRIPTION_START = "<DESCRIPTION>";
    public static final String DESCRIPTION_END = "</DESCRIPTION>";
    public static final String EXPIRE_DATE_START = "<EXPIRE_DATE>";
    public static final String EXPIRE_DATE_END = "</EXPIRE_DATE>";
    public static final String METADATA_START = "<METADATA><FIELD><NAME><![CDATA[Document type]]></NAME><VALUE><![CDATA[";
    public static final String METADATA_FIELD1 = "]]></VALUE></FIELD><FIELD><NAME><![CDATA[User]]></NAME><VALUE><![CDATA[";
    public static final String METADATA_FIELD2 = "]]></VALUE></FIELD><FIELD><NAME><![CDATA[Timestamp]]></NAME><VALUE><![CDATA[";
    public static final String METADATA_FIELD3 = "]]></VALUE></FIELD><FIELD><NAME><![CDATA[Request Type]]></NAME><VALUE><![CDATA[";
    public static final String METADATA_FIELD4 = "]]></VALUE></FIELD><FIELD><NAME><![CDATA[Request ID]]></NAME><VALUE><![CDATA[";
    public static final String METADATA_END = "]]></VALUE></FIELD></METADATA>";
    public static final String ADD_VERSION_START = "<ADD_VERSION>";
    public static final String ADD_VERSION_END = "</ADD_VERSION>";
    public static final String RECURSIVE_START = "<RECURSIVE>";
    public static final String RECURSIVE_END = "</RECURSIVE>";

    // Libraries API methods
    public static final String UPLOAD_FILE_METHOD = "uploadFile";
    public static final String UPDATE_FILE_METHOD = "updateFile";
    public static final String DOWNLOAD_FILE_METHOD = "downloadFile";
    public static final String DELETE_FILE_METHOD = "deleteFile";
    public static final String CREATE_FOLDER_METHOD = "createSubFolder";
    public static final String SEARCH_FOLDER_METHOD = "searchFolderByTitle";
    public static final String GET_FILE_METADATA = "getFileMetaData";

    // Fail Constants
    public static final String UPLOAD_FAIL = "Failed to upload, ";
    public static final String UPDATE_FAIL = "Failed to update, ";
    public static final String DOWNLOAD_FAIL = "Failed to download the file, ";
    public static final String DELETE_FAIL = "Failed to delete the file, ";
    public static final String CREATE_FOLDER_FAIL = "Failed to create the subfolder, ";
    public static final String DOWNLOAD_METADATA_FAIL = "Failed to download the file METADATA, ";

    // General Constants
    public static final String RESULT = "RESULT";
    public static final String RESPONSE_STATUS = "RESPONSE_STATUS";
    public static final String RESPONSE_TEXT = "RESPONSE_TEXT";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";
    public static final String EXTENDED_RESPONSE = "EXTENDED_RESPONSE";
    public static final String FILE_ID = "FILE_ID";
    public static final String FILE_URL = "FILE_URL";
    public static final String ERROR_CODE = "ERROR_CODE";
    public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
    public static final String ERROR_51115 = "51115";
    public static final String ERROR_41142 = "41142";
    public static final String FILE_ALREADY_EXIST = "This file is already existing.";
    public static final String NAME_ALREADY_EXIST = "Logical Folder Creation Failure/Name Exists.";
    public static final String FILE_EXIST = "fileExist";
    public static final String NAME_EXIST = "Name Exists.";
    public static final String CONTACT_ADMIN = ". Please try again or contact system administrator";
    public static final boolean TRUE = true;
    public static final boolean FALSE = false;
    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String TREE = "tree";
    public static final String BRANCH = "branch";
    public static final String LEAF = "leaf";
    public static final String ID = "id";
    public static final String FID = "fid";
    public static final String CONTENT_DISPOSITION = "Content-Disposition";
    public static final String ATTACHMENT_FILENAME = "attachment; filename=";
    public static final String DOUBLE_SLASH = "\\";

    public static final String METADATA_LEAF_URL = "leafUrl";
    public static final String METADATA_LEAF_TEXT = "leafText";
    public static final String METADATA_FILE_EXT = "fileExt";
    public static final String METADATA_FIELD = "field";
    public static final String METADATA_NAME = "name";
    public static final String METADATA_VALUE = "value";
    public static final String METADATA_MODIFIED_ON = "modifiedOn";
    
    public static final String REQUEST_TYPE_OPEN = "ACCTREQTYPE_OPEN";
    public static final String REQUEST_TYPE_MODIFY = "ACCTREQTYPE_MODIFY";
    public static final String REQUEST_TYPE_CLOSE = "ACCTREQTYPE_CLOSE";
    public static final String OPEN = "open";
    public static final String MODIFY = "modify";
    public static final String CLOSE = "close";

    // Controller Constants
    public static final String API = "/api/acct/v1";
    public static final String FILEUPLOAD = "/FileUpload";
    public static final String FILEDELETE = "/FileUpload/delete";
    public static final String FILEDOWNLOAD = "/fileDownload";

    public static final String APPLICATIONID = "${mybank.gelib.applicationId}";
    public static final String USERID = "${mybank.gelib.app.userId}";
    public static final String PASSWORD = "${mybank.gelib.app.password}";
    public static final String LOCALDIRECTORY = "${mybank.gelib.localDirectory}";
    public static final String DEFAULTFOLDERID = "${mybank.gelib.defaultFolderId}";

    public static final String FILE = "file";
    public static final String FILEID = "fileId";
    public static final String FOLDERID = "folderId";
    public static final String FILENAME = "fileName";
    public static final String URL = "url";
    public static final String ACCTREQID = "acctReqID";
    public static final String DOCTYPE = "docType";
    public static final String REQUESTTYPE = "requestType";
    public static final String USER = "User";
    public static final String NULL_VALUE = "null";
    public static final String FILE_EXIST_MESSAGE = "File is already exist.";
    public static final String FILE_COPY = "Failed to copy the file.";
    public static final String NUM_ONE = "1";
    public static final String UPLOAD_FAIL_MESSAGE = "Failed to upload the file ";
    public static final String UPLOAD_SUCCESS_MESSAGE = "Successfully uploaded file => ";
    public static final String EMPTY_FILE = "because the file was empty.";
    public static final String EXTENSION = "Extension type of file ";
    public static final String NOT_CORRECT = "is not the correct one.";
    public static final String FILE_UPLOAD_ID = "File upload id ";
    public static final String CREATED = " created";
    public static final String UNABLE_DELETE = "Unable to delete the file.";
    public static final String ACC_ID = "Account Document id ";
    public static final String ACC_ID_DELETED = " deleted";
    public static final String ACC_ID_DOWLOADED = " dowloaded";
    public static final String UNABLE_DOWNLOAD = "	Unable to download the file ";
    public static final String FILE_NOT_EXIST = "File not exist.";
    public static final String FOLDER_NOT_FOUND = "Unable to get the folder ID.";
    public static final String FILE_NOT_FOUND = "Unable to get the file ID.";
    public static final String UNDERSCORE = "_";
    public static final String DOT = ".";
    public static final String FILE_NAME_DATE_FORMAT = "MM-dd-yyyy_HH-mm-ss";
    public static final String FILE_DELETED_SUCCESS = "File Deleted successfully.";
    
    public static final String FILE_NAME_BLACKLIST = "FILE_NAME_BLACKLIST";

}
