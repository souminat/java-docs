/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business;

import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;

import com.ge.treasury.mybank.util.web.ServerDetails;

/**
 * This class provides application info after reading manifest file.
 * 
 * @author MyBank Dev Team
 */
public class ApplicationVersionInfoBuilder implements InitializingBean {

    /* Build Version */
    public final String buildVersion = "Build-Version";

    /* Equals operator */
    private static final String EQUALS = " = ";

    /**
     * manifest Properties.
     */
    private Properties manifest;

    /**
     * Application Environment.
     */
    private String apparea;

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() {
        if (manifest == null) {
            throw new IllegalArgumentException(
                    "Must set Properties (ManiFest) on " + getClass());
        }
    }

    /**
     * Set Manifest properties.
     * 
     * @param manifest
     *            Properties
     */
    public void setManifest(Properties manifest) {
        this.manifest = manifest;
    }

    /**
     * Set Application Environment as String.
     * 
     * @param apparea
     *            String
     */
    public void setApparea(String apparea) {
        this.apparea = apparea;
    }

    /**
     * {@inheritDoc}
     */
    public String extendedPropertiesAsString() {
        StringBuilder ret = new StringBuilder();
        for (Object key : manifest.keySet()) {
            ret.append("\n ").append(key.toString()).append(EQUALS)
                    .append(manifest.get(key));
        }
        ret.append("\n Environment").append(EQUALS)
                .append(this.getEnvironment());
        ret.append("\n Hostname").append(EQUALS).append(ServerDetails.getServerHostName());
        return ret.toString();
    }

    /**
     * Gets the App environment (DEV, QA, PROD, etc).
     * 
     * @return the environment
     */
    public String getEnvironment() {
        return apparea;
    }

    /**
     * Gets the whole version string, major.minor.revision, e.g. 1.0.110
     * 
     * @return the version
     */
    public String getVersion() {
        StringBuilder ret = new StringBuilder();
        ret.append(this.buildVersion).append(EQUALS)
                .append(manifest.getProperty(this.buildVersion));
        return ret.toString();
    }
}
