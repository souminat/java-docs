package com.ge.treasury.mybank.util.business.notification;

import java.io.File;
import java.io.FileWriter;
import java.util.Map;

/**
 * @author MyBank Dev Team
 * 
 */
public interface Notification {

    /**
     * Send HTML Notification Email using VM template
     * 
     * @param mails
     * @param subject
     * @param body
     * @throws Exception
     */
    public void sendHtmlNotification(String mails, String subject,
            String vmFile, Map<String, String> tokenMap);
    
    public void sendHtmlNotificationWithAttachment(String mails, String subject,
            String vmFileName, Map<String, String> tokenMap,File goodFile,File errorFile,Exception ex);

}
