package com.ge.treasury.mybank.util.business;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * The MyBankLogger class is a genericLogger use to print logs in log file.
 * 
 * @author MyBank Dev Team
 * 
 */
public class MyBankLogger {

    private static Logger log;

    private MyBankLogger() {
        throw new IllegalAccessError("Utility class");
    }

    /**
     * Print info logger in log file.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     */
    public static void logInfo(Object object, String message) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isInfoEnabled()) {
            log.info(message);
        }
    }

    /**
     * Print debug logger in log file.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     */
    public static void logDebug(Object object, String message) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isDebugEnabled()) {
            log.debug(message);
        }
    }

    /**
     * Print info-start logger in log file.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     */
    public static void logStart(Object object, String message) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isInfoEnabled()) {
            log.info(message + " -Start");
        }
    }

    /**
     * Print info-end logger in log file.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     * 
     */
    public static void logEnd(Object object, String message) {
        log = LoggerFactory.getLogger(object.getClass());

        if (log.isInfoEnabled()) {
            log.info(message + " -End");
        }
    }

    /**
     * @param object
     * @param message
     * @param time
     *            - elapsed time
     */
    public static void logEnd(Object object, String message, long time) {
        log = LoggerFactory.getLogger(object.getClass());

        if (log.isInfoEnabled()) {
            log.info(message + " -End:" + time);
        }
    }

    /**
     * Print error logger in log file.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     * 
     */
    public static void logError(Object object, String msg, Exception error) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isErrorEnabled()) {
            log.error(msg, error);
        }
    }

    /**
     * Print error logger in log file.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     * 
     */
    public static void logError(Object object, String msg) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isErrorEnabled()) {
            log.error(msg);
        }
    }

    /**
     * Logs a message at trace level.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     *            the message to log.
     */
    public static void logTrace(Object object, String message) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isTraceEnabled()) {
            log.trace(message);
        }
    }

    /**
     * Logs a message at warn level.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param message
     *            the message to log.
     */
    public static void logWarn(Object object, String message) {

        log = LoggerFactory.getLogger(object.getClass());

        if (log.isWarnEnabled()) {
            log.warn(message);
        }
    }

    /**
     * Logs a message at info level for Performance.
     * 
     * @param object
     * @param userId
     * @param transactionId
     * @param method
     *            the message to log.
     * @param time
     *            the time to log.
     */
    public static void logPerf(Object object, String userId, String transactionId, String method, long time) {

        log = LoggerFactory.getLogger(object.getClass());
        MDC.put("userId", userId);
        MDC.put("transactionId", transactionId);

        if (log.isInfoEnabled()) {
            log.info(method + ":" + time);
        }
        MDC.remove("userId");
        MDC.remove("transactionId");

    }

    /**
     * Use to generate unique Transaction Id.
     * 
     * @return TransactionId
     */
    public static String getTransactionId() {
        return System.currentTimeMillis() + "" + System.nanoTime(); // sample
                                                                    // Trans
                                                                    // Id :
                                                                    // 1396441624783185640701218189
    }
}