/**
 * 
 */
package com.ge.treasury.mybank.util.business;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.ge.treasury.mybank.util.business.constants.ValidationConstants;

/**
 * @author MyBank Dev Team
 * 
 */
public class JsonDateSerializer extends JsonSerializer<Date> {

    @Override
    public void serialize(Date arg0, JsonGenerator arg1, SerializerProvider arg2)
            throws IOException, JsonProcessingException {
        DateFormat df = new SimpleDateFormat(ValidationConstants.DATE_FORMAT,
                Locale.ENGLISH);
        String formatedDate = "";
        if (arg0 != null) {
            formatedDate = df.format(arg0.getTime());
        }
        arg1.writeString(formatedDate);
    }

}
