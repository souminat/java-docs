/**
 * 
 */
package com.ge.treasury.mybank.util.business.exceptions;

import org.springframework.validation.Errors;

/**
 * @author MyBank Dev Team
 * 
 */
public class ValidationFailedException extends Exception {

    /**
	 * 
	 */
    private static final long serialVersionUID = -7207459716243992883L;
    private Errors errors;

    public ValidationFailedException(String message, Errors errors) {
        super(message);
        this.errors = errors;
    }

    public ValidationFailedException(Errors errors) {
        super();
        this.errors = errors;
    }

    /**
     * @return the error
     */
    public Errors getErrors() {
        return errors;
    }

    /**
     * @param error
     *            the error to set
     */
    public void setErrors(Errors errors) {
        this.errors = errors;
    }
}
