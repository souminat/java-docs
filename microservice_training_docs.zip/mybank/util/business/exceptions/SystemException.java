/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.exceptions;

import com.ge.treasury.mybank.util.business.exceptions.BusinessExceptionConstants;

/**
 * SystemException
 * 
 * @author MyBank Dev Team
 * 
 */
public class SystemException extends RuntimeException implements
        BusinessExceptionConstants {

    private static final long serialVersionUID = -6398244598919850159L;
    private int errorCode = SYSTEM_EXCEPTION_CODE;

    /**
     * Constructor with no arguments
     */
    public SystemException() {
        super();
    }

    /**
     * @param errorCode
     */
    public SystemException(int errorCode) {
        super();
        this.setErrorCode(errorCode);
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public SystemException(String message, Throwable cause,
            boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @param message
     * @param cause
     */
    public SystemException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public SystemException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public SystemException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor with only code and message as arguments
     * 
     * @param code
     * @param message
     */
    public SystemException(int code, String message) {
        super(message);
        errorCode = code;
    }

    /**
     * @return the errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
}
