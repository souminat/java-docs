/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.exceptions;

/**
 * BusinessServiceException for Service Exception
 * 
 * @author MyBank Dev Team
 * 
 */
public abstract class BusinessServiceException extends RuntimeException {

    private static final long serialVersionUID = 1272235521509711979L;

    public BusinessServiceException() {
        super();
    }

    public BusinessServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessServiceException(String message) {
        super(message);
    }

    public BusinessServiceException(Throwable cause) {
        super(cause);
    }
}
