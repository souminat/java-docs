/**
 * 
 */
package com.ge.treasury.mybank.util.business.exceptions;

/**
 * @author MyBank Dev Team
 * 
 */
/**
 * @author souminat
 *
 */
public class AllRightException extends Exception {

    /**
	 * 
	 */
    private static final long serialVersionUID = -1739740063299556052L;
    private final int errorCode = 0;
	
    public int getErrorCode() {
		return errorCode;
	}

}
