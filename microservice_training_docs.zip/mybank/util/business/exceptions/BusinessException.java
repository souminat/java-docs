/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.exceptions;

import com.ge.treasury.mybank.util.business.exceptions.BusinessExceptionConstants;

/**
 * BusinessException
 * 
 * @author MyBank Dev Team
 * 
 */
public class BusinessException extends RuntimeException implements
        BusinessExceptionConstants {

    private static final long serialVersionUID = -6398244598919850159L;

    private int errorCode = BUSINESS_ERROR_CODE;

    /**
     * Constructor with no arguments
     */
    public BusinessException() {
        super();
    }

    /**
     * Constructor with aruments
     * 
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public BusinessException(String message, Throwable cause,
            boolean enableSuppression, boolean writableStackTrace) {
    }

    /**
     * Constructor with only message and cause as arguments
     * 
     * @param message
     * @param cause
     */
    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructor with only message as argument
     * 
     * @param message
     */
    public BusinessException(String message) {
        super(message);
    }

    /**
     * Constructor with only code and message as arguments
     * 
     * @param code
     * @param message
     */
    public BusinessException(int code, String message) {
        super(message);
        errorCode = code;
    }

    /**
     * Constructor with only cause as argument
     * 
     * @param cause
     */
    public BusinessException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor with only errorCode as argument
     * 
     * @param errorCode
     */
    public BusinessException(int errorCode) {
        super();
        this.setErrorCode(errorCode);
    }

    /**
     * @return the errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public final void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

}
