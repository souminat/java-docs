/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.exceptions;

import com.ge.treasury.mybank.util.business.exceptions.BusinessExceptionConstants;

/**
 * DBException for DB errors
 * 
 * @author MyBank Dev Team
 * 
 */
public class DBException extends BusinessException implements
        BusinessExceptionConstants {
    private static final long serialVersionUID = -6071570021482451872L;

    /**
	 * 
	 */
    public DBException() {
        super();
    }

    /**
     * @param errorCode
     */
    public DBException(int errorCode) {
        super(errorCode);
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public DBException(String message, Throwable cause,
            boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @param message
     * @param cause
     */
    public DBException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public DBException(String message) {
        super(message);
        super.setErrorCode(DB_EXCEPTION_CODE);
    }

    /**
     * @param cause
     */
    public DBException(Throwable cause) {
        super(cause);
    }
}
