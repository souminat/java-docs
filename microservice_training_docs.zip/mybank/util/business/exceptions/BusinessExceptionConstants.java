/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.exceptions;

/**
 * Contains constants for error codes
 * 
 * @author MyBank Dev Team
 * 
 */
public interface BusinessExceptionConstants {
    // System id
    public static final String DEFAULT_SYSTEM_ID = "TRS";

    // Error code
    public static final int BUSINESS_ERROR_CODE = 100;
    public static final int ERROR_CODE = -1;

    static final int UNEXPECTED_RUNTIME_EXCEPTION = 50;
    static final int DB_EXCEPTION_CODE = 200;
    static final int NOT_FOUND_EXCEPTION_CODE = 201;
    static final int JSON_PARSE_ERROR = 300;
    static final int INVALID_FORMAT_MAPPING = 301;
    static final int SYSTEM_EXCEPTION_CODE = 310;

    static final int WORKFLOW_EXCEPTION_CODE = 400;
    static final int WORKFLOW_RULE_NOT_FOUND_EXCEPTION_CODE = 401;
}
