/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.exceptions;

/**
 * Authorization Exception for User Validations
 * 
 * @author MyBank Dev Team
 * 
 */
public class AuthorizationException extends BusinessException implements
        BusinessExceptionConstants {
    
    private static final long serialVersionUID = -6398244598919850159L;

    /**
     * Constructor with no arguments
     */
    public AuthorizationException() {
        super();
    }

    /**
     * @param errorCode
     */
    public AuthorizationException(int errorCode) {
        super();
        this.setErrorCode(errorCode);
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public AuthorizationException(String message, Throwable cause,
            boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @param message
     * @param cause
     */
    public AuthorizationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public AuthorizationException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public AuthorizationException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor with only code and message as arguments
     * 
     * @param code
     * @param message
     */
    public AuthorizationException(int code, String message) {
        super(message);
    }

}
