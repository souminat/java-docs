/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.corems.AuditAttributes;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;

/**
 * Utility class for OldValue/NewValue functionality
 * 
 * @author MyBank Dev Team
 * 
 */
public class AuditHelper {

	private static final String SIGNERS = "signers";
	private static final String DOCUMENTS = "documents";
	private static final String FLAGS = "flags";
	private static final String CASHPOOL_PROCESS = "cashPoolProcesses";
	private static final String PLATFORM_INSTANCE = "platformInstance";

	static String[] attributeParent = new String[] { SIGNERS, DOCUMENTS, FLAGS,
			CASHPOOL_PROCESS,PLATFORM_INSTANCE };
	static String[] attributeIgnored = new String[] { "recordCount",
			"comments", "accountStatus" };

	private AuditHelper() {
		throw new IllegalAccessError("Utility class");
	}

	/**
	 * Returns an array of String obtained from String
	 * 
	 * @param strObject
	 * @return
	 */
	public static String[] obtainAttributeFromString(String strObject) {
		String[] attributes = null;

		// Validates ignored
		for (int i = 0; i < attributeIgnored.length; i++) {
			if (strObject.contains(attributeIgnored[i])) {
				return new String[0];
			}
		}

		// Validates if it is a parent attribute
		for (int i = 0; i < attributeParent.length; i++) {
			if (strObject.contains(attributeParent[i].concat("="))) {
				attributes = new String[] { attributeParent[i], strObject };
				break;
			}
		}

		if (attributes == null) {
			attributes = strObject.split("=");
		}

		return attributes;
	}

	/**
	 * Returns a list of AuditAttributes with new value and old value
	 * 
	 * @param oldList
	 * @param newList
	 * @return
	 * newObj.getFlags() != null
							&& StringUtils.isNotEmpty(newObj.getFlags().toString()) && !newObj
		.getFlags().isEmpty()
		oldObj.getFlags() != null
		&& StringUtils.isNotEmpty(oldObj.getFlags().toString()) && !oldObj
									.getFlags().isEmpty())
		oldValue.getOldValue() != null
							&& !oldValue.getOldValue().isEmpty()
		oldValue.getOldValue() != null
								&& !oldValue.getOldValue().isEmpty()
	 * @throws IOException 
	 * @throws JsonMappingException 
		
	 */
	public static List<AuditAttributes> obtainCompleteList(
			List<AuditAttributes> oldList, List<AuditAttributes> newList,
			String oldStatus, String newStatus, AccountRequest oldObj, AccountRequest newObj) throws JsonMappingException, IOException {

		Map<String, AuditAttributes> auxMap = null;
		List<AuditAttributes> completeAuditList = null;
		AuditAttributes auxObj = null;
		AuditAttributes flagObj = null;
		String tempValue = "";
		String tempOldValue = "";
		boolean isThere = false;
		if (newList != null) {
			for (AuditAttributes newValue : newList) {
			    isThere = false;
				if (auxMap == null) {
					auxMap = new HashMap<String, AuditAttributes>();
				}

				auxObj = new AuditAttributes();
				auxObj.setAttributeName(newValue.getAttributeName());
				boolean skipLoop = updateNestedObjects(newValue,newObj,oldObj,auxMap);

				// for audit new flags

				if (newValue.getAttributeName().toString().contains(FLAGS)) {
					if ((StringUtils.isNotEmpty(StringHelper.getStringValue(newObj.getFlags())))
							&& (StringUtils.isNotEmpty(StringHelper.getStringValue(oldObj.getFlags())))) {
						
						for (AccountFlag newFlag : newObj.getFlags()) {
							for (AccountFlag oldFlag : oldObj.getFlags()) {
								if (checkAuditFlags(newFlag, oldFlag)) {
									Map<String, String> newFlagMap = new HashMap<>();
									Map<String, String> oldFlagMap = new HashMap<>();
									String oldComments = "";
									String newComments = "";
									flagObj = new AuditAttributes();
									if (newFlag.getFlagCmment() == null) {
										newComments = "null";
									} else {
										newComments = newFlag.getFlagCmment();
									}
									newFlagMap.put("flagCmment", newComments);
									newFlagMap.put("isFlagChecked",
											newFlag.getIsFlagChecked());
									tempValue = newFlagMap.toString();

									if (oldFlag.getFlagCmment() == null) {
										oldComments = "null";
									} else {
										oldComments = oldFlag.getFlagCmment();
									}
									oldFlagMap.put("flagCmment", oldComments);
									oldFlagMap.put("isFlagChecked",
											oldFlag.getIsFlagChecked());
									tempOldValue = oldFlagMap.toString();

									flagObj.setAttributeName(newFlag
											.getFlagCode());
									flagObj.setNewValue(tempValue);
									flagObj.setOldValue(tempOldValue);
									isThere = true;
									auxMap.put(flagObj.getAttributeName(),
											flagObj);

								}
							}
						}
					} else {
						for (AccountFlag newFlag : newObj.getFlags()) {
							if ((newFlag.getIsFlagChecked()
									.contains(ValidationConstants.FLAG_STATUS_CHECKED_YES))) {
								Map<String, String> newFlagMap = new HashMap<>();
								flagObj = new AuditAttributes();
								newFlagMap.put("flagCmment",
										newFlag.getFlagCmment());
								newFlagMap.put("isFlagChecked",
										newFlag.getIsFlagChecked());

								tempValue = newFlagMap.toString();
								flagObj.setAttributeName(newFlag.getFlagCode());
								flagObj.setNewValue(tempValue);
								flagObj.setOldValue("");
								isThere = true;
								auxMap.put(flagObj.getAttributeName(), flagObj);
							}
						}
					}
					skipLoop = true;
				}
				if(skipLoop){
                    continue;
                }
				/*for (int i = 0; i < attributeParent.length; i++) {
					if (auxObj.getAttributeName().equals(attributeParent[i])
							&& !(auxObj.getAttributeName().toString()
									.contains(FLAGS))
							&& !(auxObj.getAttributeName().toString()
									.contains(CASHPOOL_PROCESS))) {
						if (newValue.getNewValue() != null
								&& !newValue.getNewValue().isEmpty()
								&& !(newValue.getNewValue().trim())
										.endsWith("=null")
								&& !(newValue.getNewValue().trim())
										.endsWith("=[]")) {
							auxObj.setNewValue(ValidationConstants.MYBANK_AUDIT_PARENT_ADDED
									+ " "
									+ auxObj.getAttributeName()
									+ " "
									+ tempValue);
						}
						isThere = true;
						break;
					}
				}*/
				if (!isThere) {
					/*if (auxObj.getAttributeName().toString().contains(FLAGS)
							|| auxObj.getAttributeName().toString()
									.contains(CASHPOOL_PROCESS)) {
						auxObj.setOldValue("");
					} else*/
						auxObj.setNewValue(newValue.getNewValue());
				}
				if (auxObj.getNewValue() != null) {
					auxObj.setOldValue("");
					auxMap.put(auxObj.getAttributeName(), auxObj);

				}
			}
		}

		if (oldList != null) {
			for (AuditAttributes oldValue : oldList) {
				isThere = false;
				if (auxMap == null) {
					auxMap = new HashMap<String, AuditAttributes>();
				}
				auxObj = new AuditAttributes();
				String attName = oldValue.getAttributeName();

				for (int i = 0; i < attributeParent.length; i++) {
					if (attName.equals(attributeParent[i])) {
						isThere = true;
						break;
					}
				}
				// Add ssoUser or fileName when signers or documents and if
				if (auxMap.containsKey(attName)) {
					auxObj = auxMap.get(attName);
					/*if (attName.toString().contains(SIGNERS) && (StringUtils.isNotEmpty(ssoUser) && ssoUser != null)) {
							tempValue = " - " + ssoUser;
					}
					if (attName.toString().contains(DOCUMENTS) && (StringUtils.isNotEmpty(fileName) && fileName != null)) {
							tempValue = " - " + fileName;
					}*/
					
                    if (attName.toString().contains(CASHPOOL_PROCESS) || attName.toString().contains(SIGNERS)
                            || attName.toString().contains(DOCUMENTS) || attName.toString().equals(PLATFORM_INSTANCE)) {
                        continue;
                    }

					/*if (isThere
							&& StringUtils.isNotEmpty(oldValue.getOldValue())
							&& !(oldValue.getOldValue().trim())
									.endsWith("=null")
							&& !(oldValue.getOldValue().trim()).endsWith("=[]")) {
						auxObj.setOldValue("");
						auxObj.setNewValue(ValidationConstants.MYBANK_AUDIT_PARENT_UPDATED
								+ " " + attName + tempValue);

					} else if (!isThere) {*/
						auxObj.setOldValue(oldValue.getOldValue());
					/*}*/
				} else {
					if (attName.toString().contains(FLAGS)) {
						auxObj.setNewValue("");
					} else {
						auxObj.setAttributeName(attName);
						/*if (isThere
								&& StringUtils.isNotEmpty(oldValue.getOldValue())
								&& !(oldValue.getOldValue().trim())
										.endsWith("=null")
								&& !(oldValue.getOldValue().trim())
										.endsWith("=[]")) {
							auxObj.setOldValue("");
							auxObj.setNewValue(ValidationConstants.MYBANK_AUDIT_PARENT_DELETED
									+ " " + attName + tempValue);
						} else*/ if (!isThere || attName.toString().equals(PLATFORM_INSTANCE)) {
							auxObj.setOldValue(oldValue.getOldValue());
							auxObj.setNewValue("");
						}
					}
				}
				if (auxObj.getOldValue() != null) {
					auxMap.put(attName, auxObj);
				}
			}
		}

		if (auxMap != null) {
			// Remove this after approval flow is complete
			if (!auxMap.containsKey(ValidationConstants.ACCOUNT_STATUS) && (null != oldStatus || null != newStatus)) {
				auxObj = new AuditAttributes();
				auxObj.setAttributeName(ValidationConstants.ACCOUNT_STATUS);
				auxObj.setOldValue(oldStatus);
				auxObj.setNewValue(newStatus);
				auxMap.put(ValidationConstants.ACCOUNT_STATUS, auxObj);
			}
			completeAuditList = new ArrayList<AuditAttributes>();
			for (String key : auxMap.keySet()) {
				auxObj = new AuditAttributes();
				auxObj = auxMap.get(key);
				completeAuditList.add(auxObj);
			}
		}
		return completeAuditList;
	}
	
    private static boolean updateNestedObjects(AuditAttributes newValue, AccountRequest newObj, AccountRequest oldObj,
            Map<String, AuditAttributes> auxMap) throws JsonMappingException, IOException {
        if (newValue.getAttributeName().toString().contains(SIGNERS)) {
            updateSignersAttributes(newObj, oldObj, auxMap);
            return true;

        } else if (newValue.getAttributeName().toString().contains(DOCUMENTS)) {

            updateDocumentAttributes(newObj, oldObj, auxMap);
            return true;
        } else if (newValue.getAttributeName().toString().contains(CASHPOOL_PROCESS)) {
            updateCashPoolAttributes(newObj, oldObj, auxMap);
            return true;
        }else if (newValue.getAttributeName().toString().equals(PLATFORM_INSTANCE)) {
            updatePlatFormInstance(newObj, oldObj, auxMap);
            return true;
        } else {
            return false;
        }
    }

    private static void updatePlatFormInstance(AccountRequest newObj, AccountRequest oldObj,
            Map<String, AuditAttributes> auxMap) throws JsonMappingException, IOException {
        ObjectMapper platformJson = new ObjectMapper();
        AuditAttributes auxObj = new AuditAttributes();
        auxObj.setAttributeName(PLATFORM_INSTANCE);
        auxObj.setOldValue(null == oldObj.getPlatformInstance() ? "" : platformJson.writeValueAsString(oldObj.getPlatformInstance()));
        auxObj.setNewValue(null == newObj.getPlatformInstance() ? "" : platformJson.writeValueAsString(newObj.getPlatformInstance()));
        auxMap.put(PLATFORM_INSTANCE, auxObj);
    }
    
    private static void updateDocumentAttributes(AccountRequest newObj, AccountRequest oldObj,
            Map<String, AuditAttributes> auxMap) throws JsonMappingException, IOException {

        ObjectMapper documents = new ObjectMapper();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ValidationConstants.DATE_FORMAT,Locale.ENGLISH);
        documents.setDateFormat(simpleDateFormat);
        List<Long> documentIds = CollectionUtils.isEmpty(oldObj.getDocuments()) ? null
                : oldObj.getDocuments().stream().map(AccountDocument::getDocId).collect(Collectors.toList());

        List<AccountDocument> accountDocuments = CollectionUtils
                .isEmpty(
                        newObj.getDocuments())
                                ? null
                                : newObj.getDocuments().stream()
                                        .filter(document -> CollectionUtils.isEmpty(documentIds)
                                                || !documentIds.contains(document.getDocId()))
                                        .collect(Collectors.toList());

        AuditAttributes auxObj = new AuditAttributes();
        auxObj.setAttributeName(DOCUMENTS);
        auxObj.setOldValue("");
        auxObj.setNewValue(
                CollectionUtils.isEmpty(accountDocuments) ? "" : documents.writeValueAsString(accountDocuments));
        auxMap.put(DOCUMENTS, auxObj);

    }

    private static void updateSignersAttributes(AccountRequest newObj, AccountRequest oldObj,
            Map<String, AuditAttributes> auxMap) throws JsonMappingException, IOException{

        ObjectMapper signers = new ObjectMapper();
        if (!CollectionUtils.isEmpty(oldObj.getSigners()) || !CollectionUtils.isEmpty(newObj.getSigners())) {
            AuditAttributes auxObj = new AuditAttributes();
            auxObj.setAttributeName(SIGNERS);
            
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ValidationConstants.DATE_FORMAT,Locale.ENGLISH);
            signers.setDateFormat(simpleDateFormat);
            auxObj.setOldValue(CollectionUtils.isEmpty(oldObj.getSigners()) ? ""
                    : signers.writeValueAsString(oldObj.getSigners()));
            auxObj.setNewValue(CollectionUtils.isEmpty(newObj.getSigners()) ? ""
                    : signers.writeValueAsString(newObj.getSigners()));
            auxMap.put(SIGNERS, auxObj);
        }

    }

    private static void updateCashPoolAttributes(AccountRequest newObj,
			AccountRequest oldObj, Map<String, AuditAttributes> auxMap) {

		AuditAttributes auxObj = null;
		if (null != newObj.getCashPoolProcesses()
				&& !CollectionUtils.isEmpty(newObj.getCashPoolProcesses())) {
			for (CashPoolProcess cashPoolProcessNew : newObj
					.getCashPoolProcesses()) {
				CashPoolProcess cashPoolProcessOld = getExistingCashpoolValues(
						cashPoolProcessNew, oldObj.getCashPoolProcesses());

				Map<String, String> newCashPoolMap = new HashMap<>();
				newCashPoolMap.put("cashPoolProcessCode", String
						.valueOf(cashPoolProcessNew.getCashPoolProcessCode()));
				newCashPoolMap.put("cashPoolStatusCode", String
						.valueOf(cashPoolProcessNew.getCashPoolStatusCode()));
				newCashPoolMap.put("myFundingDealId", String
                        .valueOf(cashPoolProcessNew.getMyFundingDealId()));

				Map<String, String> oldCashPoolMap = new HashMap<>();
				if (null != cashPoolProcessOld) {
                    oldCashPoolMap.put("cashPoolProcessCode",
                            String.valueOf(cashPoolProcessOld.getCashPoolProcessCode()));
                    oldCashPoolMap.put("cashPoolStatusCode",
                            String.valueOf(cashPoolProcessOld.getCashPoolStatusCode()));
                    oldCashPoolMap.put("myFundingDealId", String.valueOf(cashPoolProcessNew.getMyFundingDealId()));
				}

				auxObj = new AuditAttributes();
				auxObj.setAttributeName(CASHPOOL_PROCESS);
				auxObj.setOldValue(oldCashPoolMap.isEmpty() ? ""
						: oldCashPoolMap.toString());
				auxObj.setNewValue(newCashPoolMap.toString());
				auxMap.put(CASHPOOL_PROCESS, auxObj);
			}
		}
	}

	private static CashPoolProcess getExistingCashpoolValues(
			CashPoolProcess cashPoolProcessNew,
			List<CashPoolProcess> cashPoolProcesses) {
		if (!CollectionUtils.isEmpty(cashPoolProcesses)) {
			for (CashPoolProcess cashPoolProcess : cashPoolProcesses) {
				if (cashPoolProcessNew.getCashPoolProcessId().equals(
						cashPoolProcess.getCashPoolProcessId())) {
					return cashPoolProcess;
				}
			}
		}
		return null;
	}


	/**
	 * (newFlag.getIsFlagChecked().contains(
						ValidationConstants.FLAG_STATUS_CHECKED_YES) && oldFlag
						.getIsFlagChecked().contains(
								ValidationConstants.FLAG_STATUS_CHECKED_NO))
						|| (newFlag.getIsFlagChecked().contains(
								ValidationConstants.FLAG_STATUS_CHECKED_NO) && oldFlag
								.getIsFlagChecked()
								.contains(
										ValidationConstants.FLAG_STATUS_CHECKED_YES)) || ((newFlag
						.getIsFlagChecked().contains(
								ValidationConstants.FLAG_STATUS_CHECKED_YES) && oldFlag
						.getIsFlagChecked().contains(
								ValidationConstants.FLAG_STATUS_CHECKED_YES)) && (!newFlag
						.getFlagCmment().equals(oldFlag.getFlagCmment()))))
	 */
	private static boolean checkAuditFlags(AccountFlag newFlag,
			AccountFlag oldFlag) {
		if (newFlag.getFlagCode().equals(oldFlag.getFlagCode())
				&& (checkFlagStatus(newFlag, oldFlag))) {
			return true;
		} else {
			return false;
		}
	}
	
	private static boolean checkFlagStatus(AccountFlag newFlag,
			AccountFlag oldFlag){
		if(newFlag.getIsFlagChecked().contains(
				ValidationConstants.FLAG_STATUS_CHECKED_YES) && oldFlag
				.getIsFlagChecked().contains(
						ValidationConstants.FLAG_STATUS_CHECKED_NO)){
			return true;
		}else if(newFlag.getIsFlagChecked().contains(
				ValidationConstants.FLAG_STATUS_CHECKED_NO) && oldFlag
				.getIsFlagChecked()
				.contains(
						ValidationConstants.FLAG_STATUS_CHECKED_YES)){
			return true;
		}else if((newFlag
				.getIsFlagChecked().contains(
						ValidationConstants.FLAG_STATUS_CHECKED_YES) && oldFlag
				.getIsFlagChecked().contains(
						ValidationConstants.FLAG_STATUS_CHECKED_YES)) && (!StringUtils.defaultString(newFlag
				.getFlagCmment()).equals(StringUtils.defaultString(oldFlag.getFlagCmment())))){
			return true;
		}else{
			return false;
		}
	}

}

