/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.validations;

/**
 * Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface MessageValidator {

    /**
     * Returns the message resolved from properties file
     * 
     * @param errorCode
     * @param param
     * @return
     */
    public String validateMessage(String errorCode, Object[] param);

}
