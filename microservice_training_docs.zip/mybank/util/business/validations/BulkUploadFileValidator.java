package com.ge.treasury.mybank.util.business.validations;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ELEMENTS;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.helper.FileUploadHelper;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadValidationService;
import com.ge.treasury.mybank.business.user.service.impl.UserProfileService;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.BulkUploadError;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;

@Component
public class BulkUploadFileValidator implements BulkApprovalConstants,
		ValidationConstants {

	@Value("${mybank.gelib.doc.pattern}")
	private String docUrlPattern;

	@Value("${mdm.ms.account}")
	private String accountUrl;

	@Value("${mdm.ms.accountCore}")
	private String accountCoreUrl;

	private static final String ERROR_DECODE_URL = "Error in Decoding URL";

	@Autowired
	private AccountRequestService accountService;

	@Autowired
	private BulkUploadService bulkUploadService;

	@Autowired
	private BulkApprovalService bulkApprovalService;

	@Autowired
	MyBankLookupService lookupService;

	@Autowired
	private UserProfileService userProfileService;
	
	@Autowired
	private BulkUploadValidationService bulkUploadValidationService;

	private String errorMsg = "";
	private String value = "";
	private String column = "";
	
	private static final List<String> MODIFY_FUNCTIONALITY = new ArrayList<String>();
	
	static{
	    MODIFY_FUNCTIONALITY.add(BULK_UPLOAD_FILE_TYPE_MODIFY);
	    MODIFY_FUNCTIONALITY.add(BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC);
	    MODIFY_FUNCTIONALITY.add(BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL);
	}

	public void validateMDMData(Map<String, Set<String>> duplicateCheckMap,
			BulkApprovalRequest account, FileUpload fileUpload,
			List<BulkUploadError> errorList, int row)
			throws Exception {

        boolean isModifyOrSpecfic = MODIFY_FUNCTIONALITY.contains(fileUpload.getUpldTypeCode());

		FileUploadHelper
				.trimReflective((BulkApprovalRequest)account);

		AccountRequest accReqMDM = isModifyOrSpecfic ? accountService
				.findAccountFromMDMforModify(account.gettCode(),
						accountCoreUrl, false) : null;
				
        if (BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC.equalsIgnoreCase(fileUpload.getUpldTypeCode())
                || BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL.equals(fileUpload.getUpldTypeCode())) {
   
		    // Validate Duplicate TCode
            if (isTcodeDuplicate(duplicateCheckMap, account)) {
                column = TCODE;
                errorMsg = DUPLICATE_TCODE_MSG;
                value = account.gettCode();
                addError(account.gettCode(), fileUpload, errorList, row,
                        column, errorMsg, value);
            }
			
            //check if tcode is closed then account status should be open from modify-specific template
            if(MDM_ACCT_STATUS_CLOSE.equals(accReqMDM.getRequestStatus())
					&& ((!MDM_ACCT_STATUS_OPEN.equalsIgnoreCase(account.getAccountStatus()) 
					&& BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC.equals(fileUpload.getUpldTypeCode())) || BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL.equals(fileUpload.getUpldTypeCode()))) {
            	column = TCODE;
                errorMsg = ACCOUNT_CLOSED;
                value = account.gettCode();
            	addError(account.gettCode(), fileUpload, errorList, row,
            			column, errorMsg, value);
            }
            
            //Validate company code/company code reject reason value combination
			
            //This code executes only for Modify Specific fields
			
            //Following code will create a list of attributes - valuedAttributes - which are not Null (means user added)
            List<String> valuedAttributes = getValuedAttributes(account);
            
            MyBankLogger.logInfo(this, "Total Attributes added by the user " + valuedAttributes);
            
            //Bucket Lists - High level categories where attributes are placed in respective validation buckets
            Map<String,String> highLevelCategories= getHighLevelBuckets();
            
            //validationsToBePerformed - list of validations performed for that record based on buckets
            Set<String> validationsToBePerformed = validationRequired(highLevelCategories,valuedAttributes);
            
            MyBankLogger.logInfo(this, "Validations to be performed - " + validationsToBePerformed.toString());

            bulkUploadValidationService.setRowNumber(row);
            bulkUploadValidationService.setUpldTypeCode(fileUpload.getUpldTypeCode());
            for (String methodName : validationsToBePerformed) {
                Method methodBothParam = ReflectionUtils.findMethod(BulkUploadValidationService.class, methodName,
                        new Class[] {BulkApprovalRequest.class,AccountRequest.class});
                Method methodSingleParam = ReflectionUtils.findMethod(BulkUploadValidationService.class, methodName,
                        new Class[] {BulkApprovalRequest.class});
                if (null != methodBothParam) {
                    List<BulkUploadError> error = (List<BulkUploadError>) ReflectionUtils.invokeMethod(methodBothParam,
                            bulkUploadValidationService, new Object[] { account, accReqMDM });
                    errorList.addAll(error);
                } else {
                    List<BulkUploadError> error = (List<BulkUploadError>) ReflectionUtils.invokeMethod(methodSingleParam,
                            bulkUploadValidationService, new Object[] { account });
                    errorList.addAll(error);
                }
            }

            fileUpload.setBulkUploadError(errorList);
			
			
		} else{
			if(null!=accReqMDM && "Closed".equalsIgnoreCase(accReqMDM.getRequestStatus())) {
				accReqMDM = null;
			}
			
			// Validate Project Name
			validateProjectName(fileUpload, account, errorList, row);
			
			//This code executes only for open, Modify All, close templates
			if (!BULK_UPLOAD_FILE_TYPE_OPEN.equals(fileUpload.getUpldTypeCode())) {
			boolean modifyForDivested = isModifyOrSpecfic
					&& null != accReqMDM
					&& MDM_ACCT_STATUS_DIVESTED.equalsIgnoreCase(accReqMDM
							.getRequestStatus());
			
			validateTcode(duplicateCheckMap, modifyForDivested, fileUpload, account, errorList, row);

		}
			if (isModifyOrSpecfic) {
				// Validate account status in modify template
				validateAccountStatus(accReqMDM, fileUpload, account, errorList, row);
			}

			if ((BULK_UPLOAD_FILE_TYPE_OPEN.equals(fileUpload.getUpldTypeCode()))
					&& isAccountNumberDuplicate(duplicateCheckMap, account)) {
				column = ACCT_BANK_COUN_CURR;
				errorMsg = DUPLICATE_ACCT_DETAILS_MSG;
				value = account.getAccountNumber() + " / " + account.getBankId()
						+ " / " + account.getCountry() + " / "
						+ account.getCurrency();
				addError(account.gettCode(), fileUpload, errorList, row, column,
						errorMsg, value);
			}

			if (!BULK_UPLOAD_FILE_TYPE_CLOSE.equals(fileUpload.getUpldTypeCode())) {
				
				//Validate Bu Code
				validateBuCode(fileUpload, account, errorList, row);
				
				if (!StringUtils.isEmpty(account.getLeCode())) {
					String response = bulkUploadService.validateLE(account
							.getLeCode());

					getCompCodeForBusiness(accReqMDM,response, fileUpload, account, errorList, row);
				}

				// Validate Bank MDM Id
				validateBankMDMId(accReqMDM, fileUpload, account, errorList, row);

				// Validate Route Code and Route Type
				validateRouteDetails(fileUpload, account, errorList, row);
				
				// Validate BranchID
				validateBranchId(fileUpload, account, errorList, row);
				
				// Validate account shall pool to T-Code
				validateCashpoolTcode(fileUpload, account, errorList, row);

				//Validate Company Code
				validateCompanyCode(fileUpload, account, errorList, row);
				
				// Validate ME
				validateME(fileUpload, account, errorList, row);

				validateBankClassification(fileUpload, account, errorList, row);
				
				AccountRequest accountRequest = getAccountCombinations(account);
				// Validate Account Combination
				validateAccountCombination(accountRequest, fileUpload, account, errorList, row);
			}

			// Validate Documents
			validateDocuments(fileUpload, account, errorList, row);

			// Validate Bank Confirmation
			validateBankConfirmation(fileUpload, account, errorList, row);
			
		}

		
		

	}

	
	private void validateProjectName(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row) throws JSONException, ParseException{
		if(!StringUtils.isEmpty(account.getProjectName())){
			String status = bulkUploadService.validateProjectName(account.getProjectName());

			if (ValidationConstants.PROJECT_NOT_FOUND.equals(status)) {
					column = TCODE;
					errorMsg = ValidationConstants.PROJECT_NOT_FOUND;
					value = account.getProjectName();
					addError(account.gettCode(), fileUpload, errorList, row,
							column, errorMsg, value);
			}
		}
	}
	
	private void validateTcode(Map<String, Set<String>> duplicateCheckMap,boolean modifyForDivested,FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		// Validate Duplicate TCode
		if (isTcodeDuplicate(duplicateCheckMap, account)) {
			column = TCODE;
			errorMsg = DUPLICATE_TCODE_MSG;
			value = account.gettCode();
			addError(account.gettCode(), fileUpload, errorList, row,
					column, errorMsg, value);
		}

		// Validate In flight TCode
		Long accountRequestId = isTcodeInflightRequest(account);
		if (null != accountRequestId) {
			column = TCODE;
			errorMsg = INFLIGHT_REQUEST_MSG + BLANK_SPACE
					+ accountRequestId;
			value = account.gettCode();
			addError(account.gettCode(), fileUpload, errorList, row,
					column, errorMsg, value);
		}

		if (!StringUtils.isEmpty(account.gettCode()) && !modifyForDivested
				&& !bulkUploadService.isValidTCode(account.gettCode())) {
			column = TCODE;
			errorMsg = INVALID + BLANK_SPACE + TCODE;
			value = account.gettCode();
			addError(account.gettCode(), fileUpload, errorList, row,
					column, errorMsg, value);
		}
	}
	
	private void validateAccountStatus(AccountRequest accReqMDM,FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (accReqMDM != null) {
			if (MDM_ACCT_STATUS_OPEN.equals(accReqMDM.getRequestStatus())
					&& MDM_ACCT_STATUS_ACQUIRED.equals(account
							.getAccountStatus())) {
				column = TCODE;
				errorMsg = ACCOUNT_OPEN;
				value = account.gettCode();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			} else if (isModifyDivested(accReqMDM, account)) {
				column = TCODE;
				errorMsg = ACCOUNT_DIVESTED;
				value = account.gettCode();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			}
		} else {
			column = TCODE;
			errorMsg = ACCOUNT_NOT_EXIST;
			value = account.gettCode();
			addError(account.gettCode(), fileUpload, errorList, row,
					column, errorMsg, value);
		}
	}
	
	private void getCompCodeForBusiness(AccountRequest accReqMDM,String response,FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		
		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray data = jsonObject.getJSONArray("elements");
			
			if (data.length() == 0) {
				column = GOLD_ID;
				errorMsg = INVALID + BLANK_SPACE + GOLD_ID;
				value = account.getLeCode();
				addError(account.gettCode(), fileUpload, errorList,
						row, column, errorMsg, value);
			} else {
				JSONObject obj = data.getJSONObject(0);
				List<MyBankLookup> lookupTypes = lookupService.getLovsByLookupType("COMPCODE_BUSINESS",
	                    ControllersConstants.DEFAULT_LOV_ORDER, ControllersConstants.DEFAULT_DIRECTION);

	            Collection<String> businessListNames = lookupTypes.stream().map(lookup -> StringUtils.trimToEmpty(lookup.getDispname())).collect(Collectors.toList());


				if (null != StringUtils.trimToNull(account
						.getComponentCode())
						&& !businessListNames.contains(StringUtils.trimToEmpty(getBusinessName(accReqMDM, fileUpload, account)))) {
					checkCompCodeEligibility(accReqMDM, fileUpload, account, errorList, row);
				}

				getComponentCodes(lookupTypes, obj, fileUpload, account, errorList, row);

			}
		}
		
		
		
	}
	
	private void checkCompCodeEligibility(AccountRequest accReqMDM,FileUpload fileUpload,BulkApprovalRequest account, 
			List<BulkUploadError> errorList, int row) {
		if(StringUtils.isEmpty(getBusinessName(accReqMDM, fileUpload, account))) {
			column = COMP_CODE;
			errorMsg = BUSINESS + BUSS_INVALID;
			value = account.getComponentCode();
			addError(account.gettCode(), fileUpload, errorList,
					row, column, errorMsg, value);
		}else {
			column = COMP_CODE;
			errorMsg = INVALID + USAGEOF + BLANK_SPACE
					+ COMP_CODE;
			value = account.getComponentCode();
			addError(account.gettCode(), fileUpload, errorList,
					row, column, errorMsg, value);
		}
}
	
	private String getBusinessName(AccountRequest accReqMDM,FileUpload fileUpload,BulkApprovalRequest account) {
		return StringUtils.equals(BULK_UPLOAD_FILE_TYPE_OPEN,fileUpload.getUpldTypeCode()) ? 
											StringUtils.defaultString(account.getBussName()) : StringUtils.defaultIfEmpty(account.getBussName(), accReqMDM.getBussName());	
	}
	
	private void getComponentCodes(List<MyBankLookup> lookupTypes,JSONObject obj,FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		
		for (MyBankLookup lookup : lookupTypes) {
			if (lookup.getDispname().equalsIgnoreCase(
					account.getBussName())) {
				JSONArray componentCodeArray = obj
						.getJSONArray("component_codes");
				List<String> compCodeList = new ArrayList<String>();
				if (componentCodeArray.length() > 0) {
					for (int i = 0; i < componentCodeArray
							.length(); i++) {
						JSONObject o = componentCodeArray
								.getJSONObject(i);
						compCodeList.add((String) o
								.get("component_code"));
					}
				}

				if (!StringUtils.isEmpty(account
						.getComponentCode())
						&& !compCodeList.contains(StringUtils.upperCase(account
								.getComponentCode()))) {
					column = COMP_CODE;
					errorMsg = INVALID + BLANK_SPACE
							+ COMP_CODE;
					value = account.getComponentCode();
					addError(account.gettCode(), fileUpload,
							errorList, row, column, errorMsg,
							value);
				}
			}
		}
	}
	
	private void validateBankMDMId(AccountRequest accReqMDM,FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (null != account && !StringUtils.isEmpty(account.getBankId())) {
			String response = bulkUploadService.getMDMBankDetails(
					account.getBankId(), null);
			boolean validMdmId = false;
			if (null != StringUtils.trimToNull(response)) {
				JSONObject jsonObject = new JSONObject(response);
				JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
				if (null != elements && elements.length() == 0) {
					column = BANK_MDM_ID;
					errorMsg = INVALID + BLANK_SPACE + BANK_MDM_ID;
					value = account.getBankId();
					addError(account.gettCode(), fileUpload, errorList,
							row, column, errorMsg, value);
				} else {
					validMdmId = true;
				}
			}
			String country = getCountry(account, accReqMDM);
			if (null != account && (validMdmId
					&& !isCountryBankMdmValid(account.getBankId(), country))) {
				column = BANK_MDM_ID;
				errorMsg = BANK_COUNTRY_MSG;
				value = account.getBankId();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			}
		}
	}
	
	private void validateBankClassification(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (!StringUtils.isEmpty(account.getSpbDocument())) {
			if (!SPB.equalsIgnoreCase(account.getBankClassification())) {
				column = SPB_DOCUMENT;
				errorMsg = SPB_ERROR;
				value = account.getSpbDocument();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			}
			if (!isValidURL(account.getSpbDocument())) {
				column = SPB_DOCUMENT;
				errorMsg = INVALID + BLANK_SPACE + DOCUMENTS;
				value = account.getSpbDocument();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			} else {
				String errorMessage = verifyValidDocument(account
						.getSpbDocument());
				if (null != errorMessage) {
					column = SPB_DOCUMENT;
					errorMsg = INVALID.concat(BLANK_SPACE)
							.concat(DOCUMENTS).concat(BLANK_SPACE)
							.concat(errorMessage);
					value = account.getSpbDocument();
					addError(account.gettCode(), fileUpload, errorList,
							row, column, errorMsg, value);
				}
			}
		}
	}
	
	private void validateAccountCombination(AccountRequest accountRequest,FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (accountRequest != null) {
			column = COMBINITAION_COLS;
			errorMsg = COMBINATION_MSG + BLANK_SPACE
					+ accountRequest.getAcctReqID();
			value = account.getAccountNumber() + "," + account.getCountry()
					+ "," + account.getCurrency() + ","
					+ account.getBankId() + "," + account.getRouteCode();
			addError(account.gettCode(), fileUpload, errorList, row,
					column, errorMsg, value);
		}

	}
	
	
	private void validateCompanyCode(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row) throws UnsupportedEncodingException{

		// Validate Company Code
		if (!StringUtils.isEmpty(account.getCompanyCode()) && !bulkUploadService.isValidCompanyCode(account.getLeCode(),
				account.getCompanyCode())) {
				column = COMPANY_CODE;
				errorMsg = COMPANY_CODE_ERROR_MSG + account.getLeCode();
				value = account.getCompanyCode();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			
		}

	}
	
	private void validateME(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row) throws UnsupportedEncodingException {
		// Validate ME
		if (!StringUtils.isEmpty(account.getMe()) && !isValidMECode(account.getMe())) {
					column = ME_COLUMN;
					errorMsg = INVALID + BLANK_SPACE + ME_COLUMN;
					value = account.getMe();
					addError(account.gettCode(), fileUpload, errorList, row,
								column, errorMsg, value);
					
		}

	}
	
	private void validateBuCode(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row) {
		
		String buCode = null;
		if(StringUtils.isNotEmpty(account.getCompanyCode())) {
			buCode = bulkUploadService.validateCoCodeBuCombination(account.getCompanyCode());
			
		}else {
			buCode = account.getBuCode();	
		}		
		
		if(StringUtils.isNotEmpty(buCode)) {
			String response = bulkUploadService.validateBuCode(buCode);
			
			if(null != StringUtils.trimToNull(response)) {
				 JSONObject jsonObject = new JSONObject(response);
				 JSONArray data = jsonObject.getJSONArray(ELEMENTS);
		         
		         if(null== data || data.length() == 0) {
		        	 column = BU_CODE;
		        	 errorMsg = INVALID + BLANK_SPACE + BU_CODE;
		        	 value = buCode;
		        	 addError(account.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
		         }else {
		        	 setBussSubBuss(data, account);
		         }
			}
		}
	}
	//Set business sub-business from on BU code response
	private void setBussSubBuss(JSONArray data, BulkApprovalRequest account) {
		  Iterator<Object> itr = data.iterator();
	   	  try {
				while (itr.hasNext()) {
					JSONObject obj = (JSONObject) itr.next();
					account.setBussName(StringHelper.getStringValue(obj.get(MDMConstants.RPTLEVEL1__BU_DESCRIPTION)));
					account.setSubBusiness(StringHelper.getStringValue(obj.get(MDMConstants.RPTLEVEL2__BU_DESCRIPTION)));
				} 
			} catch (Exception e) {
					MyBankLogger.logError(this, "Error while fetching report level 1/level 2 description : " + e.getMessage());
					throw new BusinessException("Error while fetching report level 1/level 2 description : " + e.getMessage());
		 } 
	}
	
	private void validateDocuments(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (!StringUtils.isEmpty(account.getDocumentType()) && StringUtils.isEmpty(account.getDocuments())) {
				column = DOCUMENTS;
				errorMsg = DOCUMENTS_REQUIRED;
				value = account.getDocuments();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
		}

		if (!StringUtils.isEmpty(account.getDocuments())) {
			if (StringUtils.isEmpty(account.getDocumentType())) {

				column = DOCUMENT_TYPE;
				errorMsg = DOCUMENT_TYPE_REQUIRED;
				value = account.getDocumentType();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);

			}
			if (!isValidURL(account.getDocuments())) {
				column = DOCUMENTS;
				errorMsg = INVALID + BLANK_SPACE + DOCUMENTS;
				value = account.getDocuments();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			} else {
				String errorMessage = verifyValidDocument(account
						.getDocuments());
				if (null != errorMessage) {
					column = DOCUMENTS;
					errorMsg = INVALID.concat(BLANK_SPACE).concat(DOCUMENTS)
							.concat(BLANK_SPACE).concat(errorMessage);
					value = account.getDocuments();
					addError(account.gettCode(), fileUpload, errorList, row,
							column, errorMsg, value);
				}
			}
		}
	}
	
	private void validateBankConfirmation(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (!StringUtils.isEmpty(account.getBankConfirmation())) {
			if (!isValidURL(account.getBankConfirmation())) {
				column = BANK_CONFIRMATION;
				errorMsg = INVALID + BLANK_SPACE + BANK_CONFIRMATION;
				value = account.getBankConfirmation();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			} else {
				String errorMessage = verifyValidDocument(account
						.getBankConfirmation());
				if (null != errorMessage) {
					column = BANK_CONFIRMATION;
					errorMsg = INVALID.concat(BLANK_SPACE).concat(DOCUMENTS)
							.concat(BLANK_SPACE).concat(errorMessage);
					value = account.getBankConfirmation();
					addError(account.gettCode(), fileUpload, errorList, row,
							column, errorMsg, value);
				}
			}
		}
	}
	
	private void validateRouteDetails(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row) throws UnsupportedEncodingException{
		// Validate Route Code
		if (!StringUtils.isEmpty(account.getRouteCode()) && !isValidRouteCodeDetails(account.getBankId(),
				account.getRouteCode())) {
				column = ROUTE_CODE_COL;
				errorMsg = ROUTE_CODE_MSG;
				value = account.getRouteCode();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			
		}
		// Validate Route Code Type
		if (!StringUtils.isEmpty(account.getRouteCodeType()) && !isValidRouteCodeType(account.getBankId(),
				account.getRouteCodeType())) {
				column = ROUTE_CODE_TYPE_COL;
				errorMsg = ROUTE_CODE_TYPE_MSG;
				value = account.getRouteCodeType();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			
		}
	}
	
	private void validateBranchId(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row) throws UnsupportedEncodingException{
		if (!StringUtils.isEmpty(account.getBranchID()) && !isValidBranchID(account.getBankId(),
				account.getRouteCode(), account.getRouteCodeType(),
				account.getBranchID())) {
				column = BRANCH_ID_COL;
				errorMsg = BRANCH_ID_MSG;
				value = account.getBranchID();
				addError(account.gettCode(), fileUpload, errorList, row,
						column, errorMsg, value);
			
		}
	}
	
	private void validateCashpoolTcode(FileUpload fileUpload,BulkApprovalRequest account,
			List<BulkUploadError> errorList, int row){
		if (!StringUtils.isEmpty(account.getCashpoolTCode())) {
			if (NO_CASH_POOL.equalsIgnoreCase(account.getCashpoolTCode())) {
				account.setCashpoolTCode(null);
			} else {
				if (!bulkUploadService.isValidTCode(account
						.getCashpoolTCode())) {
					column = ACC_POOL_TO_TCODE_COLUMN;
					errorMsg = ACC_POOL_TO_TCODE_MSG;
					value = account.getCashpoolTCode();
					addError(account.gettCode(), fileUpload, errorList,
							row, column, errorMsg, value);
				}
			}
		}
	}
	
	private List<String> getValuedAttributes(BulkApprovalRequest account) throws IllegalAccessException {
	    List<String> valuedAttributes = new ArrayList<String>();
        for (Field field : account.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            String name = field.getName();
            Object valueFromUi = field.get(account);
            if(null!=valueFromUi && !("".equalsIgnoreCase(String.valueOf(valueFromUi))) && !"serialVersionUID".equalsIgnoreCase(name)){
                 valuedAttributes.add(name);
            }
        }
        return valuedAttributes;
    }

    private Set<String> validationRequired(Map<String, String> highLevelCategories, List<String> valuedAttributes) {

	    Set<String> validationsToBePerformed = new HashSet<String>();
	    for(String attr : valuedAttributes) {
            
            Iterator<Entry<String, String>> it = highLevelCategories.entrySet().iterator();
            while (it.hasNext()) {
               Map.Entry<String,String> pair = it.next();
               String key = String.valueOf(pair.getKey());
               String valueAttribute = String.valueOf(pair.getValue());
               List<String> valueList = Arrays.asList(StringUtils.split(valueAttribute,","));
               if(valueList.contains(attr)){
                   validationsToBePerformed.add(key);
               }
               
            }
            
        }
        return validationsToBePerformed;
    }

    private Map<String, String> getHighLevelBuckets() {
	    List<MyBankLookup> highLevelBuckets = lookupService.getLovsByLookupType("MODIFY_SPECIFIC_BUCKETS",
                ControllersConstants.DEFAULT_LOV_ORDER, ControllersConstants.DEFAULT_DIRECTION);
        //Bucket Lists - High level categories where attributes are placed in respective validation buckets
        Map<String,String> highLevelCategories= new HashMap<String, String>();
        highLevelCategories = highLevelBuckets.stream()
        					.map(lookUp->lookUp.getDispname().split(":")).collect(Collectors.toMap(dispName->dispName[0],dispName->dispName[1]));
       
        return highLevelCategories;
    }

    public String verifyValidDocument(String docUrl) {

		try {
			Map<String, String> map = StringHelper.splitQuery(new URL(docUrl));
			bulkApprovalService.getMetadataForFile(map.get(FILE_ID));
		} catch (BusinessException be) {
			MyBankLogger.logError(this, ERROR_DECODE_URL + be.getMessage(), be);
			return be.getMessage();
		} catch (UnsupportedEncodingException | MalformedURLException e) {
			MyBankLogger.logError(this, ERROR_DECODE_URL + e.getMessage(), e);
		}
		return null;
	}

	private String getCountry(BulkApprovalRequest account,
			AccountRequest accReqMDM) {
		return StringUtils.trimToNull(account.getCountry()) == null ? (null != accReqMDM ? accReqMDM
				.getCountry().toUpperCase() : null)
				: account.getCountry().toUpperCase();
	}

	public boolean isCountryBankMdmValid(String bankId, String country) {
		String response = bulkUploadService.getMDMBankDetails(bankId, country);
		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() != 0) {
				return true;
			}
		}
		return false;
	}

	public boolean isModifyDivested(AccountRequest accReqMDM,
			BulkApprovalRequest account) {
		if (!MDM_ACCT_STATUS_DIVESTED.equalsIgnoreCase(accReqMDM
				.getRequestStatus())
				&& MDM_ACCT_STATUS_DIVESTED.equals(account.getAccountStatus())) {
			return true;
		} else if (MDM_ACCT_STATUS_DIVESTED.equalsIgnoreCase(accReqMDM
				.getRequestStatus())
				&& !MDM_ACCT_STATUS_DIVESTED.equalsIgnoreCase(account
						.getAccountStatus())) {
			return true;
		}
		return false;
	}

	public boolean isValidRouteCodeDetails(String bankId, String code)
			throws UnsupportedEncodingException {
		boolean isValid = true;
		String response = bulkUploadService.fetchRouteCodeDetails(bankId, code);
		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() == 0) {
				isValid = false;
			}
		}
		return isValid;

	}

	public boolean isValidRouteCodeType(String bankId, String code)
			throws UnsupportedEncodingException {
		boolean isValid = true;
		String response = bulkUploadService.fetchRouteCodeType(bankId, code);
		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() == 0) {
				isValid = false;
			}
		}
		return isValid;

	}

	public boolean isValidBranchID(String bankId, String routeCode,
			String routeType, String branchId) throws UnsupportedEncodingException {
		boolean isValid = true;
		String response = bulkUploadService.fetchBankBranchDetails(bankId,
				routeCode, routeType, branchId);
		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() == 0) {
				isValid = false;
			}
		}
		return isValid;

	}

	public boolean isValidMECode(String code) throws UnsupportedEncodingException {
		boolean isValid = true;
		String response = bulkUploadService.fetchMEDetails(code);
		if (null != StringUtils.trimToNull(response)) {
			JSONObject jsonObject = new JSONObject(response);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() == 0) {
				isValid = false;
			}
		}
		return isValid;

	}

	public boolean isValidURL(String docUrl) {
		boolean isValidUrl = true;

		if (null != StringUtils.trimToNull(docUrl)) {
			List<String> urlArr = new ArrayList<String>();

			if (docUrl.contains(COMMA)) {
				urlArr.addAll(Arrays.asList(docUrl.split(COMMA)));
			} else {
				urlArr.add(docUrl);
			}
			// http://librariesstage.ge.com/download?fileid=3000447466908031&entity_id=3001072281031&sid=31
			// Validate if file ID present
			for (String url : urlArr) {
				if (url.contains(docUrlPattern)) {
					isValidUrl = isFileIdPresent(isValidUrl, url);
				} else {
					isValidUrl = false;
				}
			}
		}
		return isValidUrl;
	}

	private boolean isFileIdPresent(boolean isValidUrl,String url){
		boolean isValid = isValidUrl;
		try {
			Map<String, String> map = StringHelper
					.splitQuery(new URL(url));
			if (map.containsKey(FILE_ID)) {
				if (null == StringUtils
						.trimToNull(map.get(FILE_ID))) {
					isValid = false;
				}
			} else {
				isValid = false;
			}
		} catch (UnsupportedEncodingException
				| MalformedURLException e) {
			MyBankLogger.logError(this,
					ERROR_DECODE_URL + e.getMessage(), e);
		}
		return isValid;
	}
	
	public boolean isInvalidBusinessOrSubBusiness(Set<String> list,
			String value) {
		String mdmData = "";
		if (!CollectionUtils.isEmpty(list)) {
			for (String str : list) {
				if (str.equalsIgnoreCase(value)) {
					mdmData = str;
					break;
				}
			}
		}

		return StringUtils.isEmpty(mdmData);
	}

	private void addError(String tCode, FileUpload fileUpload,
			List<BulkUploadError> errorList, int row, String column,
			String errorMsg, String value) {
		BulkUploadError error = new BulkUploadError();

		error.setError(errorMsg);
		error.setValue(value);
		error.setRow(Integer.toString(row));
		error.setColumn(column);
		error.settCode(tCode);

		errorList.add(error);
		fileUpload.setBulkUploadError(errorList);
	}

	private boolean isTcodeDuplicate(
			Map<String, Set<String>> duplicateCheckList,
			BulkApprovalRequest record) {

		return duplicateCheck(duplicateCheckList.get("tCode"),
				record.gettCode());
	}

	
	public Long isTcodeInflightRequest(BulkApprovalRequest record) {

		return accountService.getPendingCloseOrModifyByTcode(record.gettCode());
	}

	private AccountRequest getAccountCombinations(BulkApprovalRequest request) {
		AccountRequest accReq = null;
		Map<String, Object> searchMap = null;
		searchMap = new HashMap<String, Object>();
		searchMap.put("acctNumber", request.getAccountNumber());
		searchMap.put("tCode", request.gettCode());
		searchMap.put("bankId", request.getBankId());
		searchMap.put("routeCode", request.getRouteCode());
		searchMap.put("country", request.getCountry());
		searchMap.put("currency", request.getCurrency());
		searchMap.put("statusComplete", "ACCTREQSTAT_COMPLETED");
		searchMap.put("reqModify", "ACCTREQTYPE_MODIFY");
		searchMap.put("reqClose", "ACCTREQTYPE_CLOSE");
		searchMap.put("reqOpen", "ACCTREQSTAT_OPEN");
		accReq = bulkUploadService.searchAccountByCombination(searchMap);

		return accReq;
	}

	private boolean isAccountNumberDuplicate(
			Map<String, Set<String>> duplicateCheckList,
			BulkApprovalRequest record) {
		StringBuilder accountValidation = new StringBuilder();
		if (record.getAccountNumber() != null) {
			accountValidation = accountValidation.append(record
					.getAccountNumber().trim());
		}
		if (record.getBankId() != null) {
			accountValidation = accountValidation.append(record.getBankId()
					.trim());
		}
		if (record.getCountry() != null) {
			accountValidation = accountValidation.append(record.getCountry()
					.trim());
		}
		if (record.getCurrency() != null) {
			accountValidation = accountValidation.append(record.getCurrency()
					.trim());
		}
		return duplicateCheck(duplicateCheckList.get("openAccountValidation"),
				accountValidation.toString());
	}

	private boolean duplicateCheck(Set<String> duplicateSet, String value) {
		boolean isDuplicate = false;
		if (value != null && !duplicateSet.add(value)) {
				isDuplicate = true;
		}
		return isDuplicate;
	}

	public void validateSignerData(BulkAccountSigner signer,
			FileUpload fileUpload, List<BulkUploadError> errorList, int row) throws ParseException {
	
		//Check if tcode is in inflight state
		BulkApprovalRequest bulkReq = new BulkApprovalRequest();
		bulkReq.settCode(signer.gettCode());
		Long accountRequestId = isTcodeInflightRequest(bulkReq);
		boolean isValidTcode = bulkUploadService.isValidTCode(signer.gettCode());
		
		if (null != accountRequestId) {
			column = T_CODE;
			errorMsg = INFLIGHT_REQUEST_MSG + BLANK_SPACE
					+ accountRequestId;
			value = signer.gettCode();
			addError(signer.gettCode(), fileUpload, errorList, row,
					column, errorMsg, value);
		}
		// Validate Documents
		validateDocsForSigners(signer, fileUpload, errorList, row);
		
		if (SIGNER_ACTION_MODIFY.equalsIgnoreCase(signer.getSignerAction()) && StringUtils.isEmpty(signer.getSignerStartDate())
				&& StringUtils.isEmpty(signer.getSignerEndDate()) && StringUtils.isEmpty(signer.getDocURL())) {
			column = SIGNER_START_EXP_DOC_COLUMN;
			errorMsg = SIGNER_START_EXP_DOC_MSG;
			value = signer.getSignerStartDate() + signer.getSignerEndDate() + signer.getDocURL();
			addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
		}
		
		if (!StringUtils.isEmpty(signer.gettCode()) && !isValidTcode) {
			column = T_CODE;
			errorMsg = INVALID + BLANK_SPACE + T_CODE;
			value = signer.gettCode();
			addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
		}
		if (!StringUtils.isEmpty(signer.getSignerEndDate()) && !SIGNER_ACTION_REMOVE.equalsIgnoreCase(signer.getSignerAction())) {
			
				column = SIGNER_EXPIRE_DATE_COL;
				errorMsg = SIGNER_EXPIRE_REMOVE_MSG;
				value = signer.getSignerEndDate();
				addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
			
		}
		
		if (!StringUtils.isEmpty(signer.getSignerStartDate()) && SIGNER_ACTION_REMOVE.equalsIgnoreCase(signer.getSignerAction())) {
			
			column = SIGNER_START_DATE;
			errorMsg = SIGNER_START_DATE_FIELD_REMOVE;
			value = signer.getSignerStartDate();
			addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
		
		}
		
		if ((signer.getSignerType().equalsIgnoreCase(SIGNER_TYPE_NON_SSO) || signer.getSignerType().equalsIgnoreCase(SIGNER_TYPE_FACSIMILE) || signer.getSignerType().equalsIgnoreCase(SIGNER_TYPE_COMPANY_CHOP)) && !StringUtils.isEmpty(signer.getSsoId())) {
			
			column = SIGNER_SSO_COLUMN;
			errorMsg = SIGNER_NON_SSO_SSO_FIELD;
			value = signer.getSsoId();
			addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
		
	}
		
        if (isValidTcode) {
            // Validate signer removal when start date is empty
            validateSignerRemoval(signer, fileUpload, errorList, row);
        }

        // Check if end date is before start date
        validateDateForSigners(signer, fileUpload, errorList, row);

        // Check if Signer SSO is valid
        validateSignerSso(signer, fileUpload, errorList, row);
		
		
	}

	private void validateDocsForSigners(BulkAccountSigner signer,FileUpload fileUpload,
			List<BulkUploadError> errorList, int row){
		if (!StringUtils.isEmpty(signer.getDocURL())) {
			if (!isValidURL(signer.getDocURL())) {
				column = DOCUMENTS;
				errorMsg = INVALID + BLANK_SPACE + DOCUMENTS;
				value = signer.getDocURL();
				addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
			}else{
			    String errorMessage = verifyValidDocument(signer.getDocURL());
                if(null != errorMessage){
                    column = DOCUMENTS;
                    errorMsg = INVALID.concat(BLANK_SPACE).concat(DOCUMENTS).concat(BLANK_SPACE).concat(errorMessage);
                    value = signer.getDocURL();
                    addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
                }
			}
	}
	}
	
	private void validateSignerRemoval(BulkAccountSigner signer,FileUpload fileUpload,
			List<BulkUploadError> errorList, int row) throws ParseException{
		if(null != signer && (StringUtils.isEmpty(signer.getSignerStartDate()) && !StringUtils.isEmpty(signer.getSignerEndDate()))){
			AccountRequest accReqMDM = accountService.findAccountFromMDMforModify(signer.gettCode(), accountUrl,false);
			
			List<AccountSigner> siList = (null != accReqMDM && !"Closed".equalsIgnoreCase(accReqMDM.getRequestStatus()))? accReqMDM.getSigners() : null;
			String lookupType = "";
			for(AccountSigner signers : siList){
					
				if(AccountValidationUtils.getSignerLookupMap().containsKey(signer.getSignerType().toUpperCase())){
					lookupType = AccountValidationUtils.getSignerLookupMap().get(signer.getSignerType().toUpperCase());
				}
					
					if(signers.getSignerName().equals(signer.getSignerName()) && signers.getSignerType().equals(lookupType)){
						
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
						DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
						Date startDate = sdf.parse(dateFormat.format(signers.getSignerStartDate()));
						Date endDate = sdf.parse(signer.getSignerEndDate());
						
						isEndDateValid(signer, fileUpload, errorList, row, startDate, endDate);
					}
			}
		}
	}
	
	private void validateDateForSigners(BulkAccountSigner signer,FileUpload fileUpload,
			List<BulkUploadError> errorList, int row) throws ParseException{
		if (!StringUtils.isEmpty(signer.getSignerStartDate()) && !StringUtils.isEmpty(signer.getSignerEndDate())) {

			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Date startDate = sdf.parse(signer.getSignerStartDate());
			Date endDate = sdf.parse(signer.getSignerEndDate());
			
			isEndDateValid(signer, fileUpload, errorList, row, startDate, endDate);

		}
	}
	
	private void isEndDateValid(BulkAccountSigner signer,FileUpload fileUpload,
			List<BulkUploadError> errorList, int row,Date startDate,Date endDate){
		if (endDate.before(startDate)) {
			column = SIGNER_EXPIRE_DATE_COL;
			errorMsg = SIGNER_EXPIRE_DATE_MSG;
			value = signer.getSignerEndDate();
			addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);
		}
	}
	
	private void validateSignerSso(BulkAccountSigner signer,FileUpload fileUpload,
			List<BulkUploadError> errorList, int row){
		if((SIGNER_TYPE_SSO.equalsIgnoreCase(signer.getSignerType())
				|| SIGNER_TYPE_PERSONAL_CHOP.equalsIgnoreCase(signer.getSignerType()))
				&& !SIGNER_ACTION_REMOVE.equalsIgnoreCase(signer.getSignerAction())){
			boolean isValid = isSignerSSOValid(signer.getSsoId());
			if(!isValid){
				column = SIGNER_SSO_COLUMN;
				errorMsg = SIGNER_SSO_MSG_INV;
				value = signer.getSsoId();
				addError(signer.gettCode(), fileUpload, errorList, row, column, errorMsg, value);				
			}
		}
	}
	
	private boolean isSignerSSOValid(String sso) {
		boolean isValid = false;
		String requestorUserJson = "";

		if ("".equalsIgnoreCase(StringUtils.trimToEmpty(sso))) {
			return false;
		}

		try {
			requestorUserJson = userProfileService.userLookUp(sso);
			if (null != requestorUserJson) {
				JSONObject requestorUserJsonObject = new JSONObject(
						requestorUserJson);
				Integer ssoId = requestorUserJsonObject.getInt("sso");
				if (ssoId > 0) {
					return true;
				}
			}
		} catch (Exception e) {
			MyBankLogger.logError(this, "Signer SSO for validation Not Found "
					+ e.getMessage(), e);
		}

		return isValid;
	}
	
	
      
}
