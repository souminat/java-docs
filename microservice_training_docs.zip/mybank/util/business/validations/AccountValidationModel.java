/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.validations;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author MyBank Dev Team
 * 
 */
public class AccountValidationModel {

    private List<Validation> validations = new ArrayList<Validation>();

    /**
     * @return the validations
     */
    public List<Validation> getValidations() {
        return validations;
    }

    /**
     * @param validations
     *            the validations to set
     */
    public void setValidations(List<Validation> validations) {
        this.validations = validations;
    }

}
