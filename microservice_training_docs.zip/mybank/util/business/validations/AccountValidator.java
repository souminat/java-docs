/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.validations;

import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;

/**
 * Validation Class to obtain errors in the Account Request attributes
 * 
 * @author MyBank Dev Team
 * 
 */
@Component
public class AccountValidator implements Validator {
    // Constants to max number of characters
    final Integer MAX_ACCT_TYPE = 30;
    final Integer MAX_COMMENT_LENGTH = 1500;
    final Integer MAX_ACCT_TITTLE_LENGTH = 250;
    final Integer MAX_SIGNER_NAME_LENGTH = 250;
    final Integer MAX_MDM_LENAME_LENGTH = 250;
    final String ACCOUNT_STATUS_PEND_BANKCONF = "ACCTREQSTAT_PENDBANKCONFM";
    final String ACCOUNT_REQTYPE_OPEN = "ACCTREQTYPE_OPEN";
    final String ACCOUNT_REQTYPE_CLOSE = "ACCTREQTYPE_CLOSE";
    final String ACCOUNT_REQTYPE_MODIFY = "ACCTREQTYPE_MODIFY";
    final String ACCOUNT_STATUS_COMPLETED = "ACCTREQSTAT_COMPLETED";
    private static final String VAL_FIELD_EMPTY = "validation.field.empty";
    private static final String VAL_FIELD_NOTVALID = "validation.field.notvalid";
    private static final String VAL_FIELD_LENGHT = "validation.field.lenght";
    
    private static final String COMPANY_CODE = "companyCode";
    private static final String BU_CODE = "buCode";
    private static final String BANK_MDM_ID = "bankId";
    private static final String BRANCH_MDM_ID = "branchMDMID";
    private static final String LE_CODE = "leCode";
    private static final String ME_CODE = "companyCode";
    private static final String ROUTING_CODE = "routeCode";
    private static final String ACCOUNT_TYPE = "accountType";
    private static final String COUNTRY_CODE = "country";
    private static final String CURRENCY_CODE = "currency";
    private static final String COMPONENT_CODE = "componentCode";
    
    // Services needed
    AccountRequestService accRequestService;
    MyBankLookupService lookupService;
    MessageValidator messageValidator;
    private MDMService mdmService;
    private boolean inflightValidationRequired = true;

    // Criteria lookup validation
    String listLookupParam = null;
    List<MyBankLookup> lookupTypes = null;

    /**
     * Set services needed in validation
     * 
     * @param accRequestService
     * @param messageValidator
     * @param lookupService
     */
    @Autowired
    public AccountValidator(AccountRequestService accRequestService,
            MyBankLookupService lookupService,
            MessageValidator messageValidator, MDMService mdmService) {
        super();
        this.accRequestService = accRequestService;
        this.lookupService = lookupService;
        this.messageValidator = messageValidator;
        this.mdmService = mdmService;
    }

    /**
	 * 
	 */
    public AccountValidator() {
        super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.validation.Validator#supports(java.lang.Class)
     */
    public boolean supports(Class<?> clazz) {
        return AccountRequest.class.equals(clazz);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.validation.Validator#validate (java.lang.Object,
     * org.springframework.validation.Errors)
     */
    public void validate(Object target, Errors errors) {
        MyBankLogger.logDebug(this, "Starting Account Request Validation");
        AccountRequest accountRequest = (AccountRequest) target;

        this.pendingCloseOrModifyByTcode(errors, accountRequest);

        this.checkIfRequestModifiedByAnother(errors, accountRequest);

        this.obtainLookupData();

        this.validateAccountData(errors, accountRequest);

        this.validateMDMData(errors, accountRequest);

        this.validateFlagsData(errors, accountRequest);

        this.validateCommentsData(errors, accountRequest);

        this.validateSignersData(errors, accountRequest);

        this.validateDocumentsData(errors, accountRequest);
        
        if(!checkIfReqTypeClose(accountRequest.getRequestType())){
            this.checkIfCoCodeorBuCodeInactive(errors, accountRequest);
        }

        MyBankLogger.logDebug(this, "Ending Account Request Validation");
    }

    /**
     * Validate account data
     * 
     * @param errors
     * @param accountRequest
     */
    private void validateAccountData(Errors errors,
            AccountRequest accountRequest) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "requestType",
                "requestType", messageValidator.validateMessage(
                        VAL_FIELD_EMPTY, new Object[] { "Request Type" }));
        if (accountRequest.getRequestType() != null
                && !accountRequest.getRequestType().isEmpty()) {
            AccountValidationUtils.rejectIfIdNotContainedInLovs(errors,
                    ValidationConstants.ACCT_REQUEST_TYPE, lookupTypes,
                    accountRequest.getRequestType(), "requestType",
                    messageValidator.validateMessage(VAL_FIELD_NOTVALID,
                            new Object[] { "Request Type" }));
        }

        if (accountRequest.getRequestStatus() != null
                && accountRequest.getRequestStatus().equals(
                        ACCOUNT_STATUS_PEND_BANKCONF)) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountTitle",
                    "accountTitle", messageValidator.validateMessage(
                            VAL_FIELD_EMPTY, new Object[] { "Account Title" }));
            if (accountRequest.getAccountTitle() != null
                    && !accountRequest.getAccountTitle().isEmpty() && accountRequest.getAccountTitle().length() > MAX_ACCT_TITTLE_LENGTH) {
                    errors.rejectValue("accountTitle", "accountTitle",
                            messageValidator.validateMessage(VAL_FIELD_LENGHT,
                                    new Object[] { MAX_ACCT_TITTLE_LENGTH }));
            }
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountType",
                    "accountType", messageValidator.validateMessage(
                            VAL_FIELD_EMPTY, new Object[] { "Account Type" }));

        }
        if (accountRequest.gettCode() != null
                && !accountRequest.gettCode().isEmpty()) {
            if (accountRequest.getAcctReqID() != null) {
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "bankId",
                        "bankId", messageValidator.validateMessage(
                                VAL_FIELD_EMPTY,
                                new Object[] { "Bank - MDM ID" }));
            }
            if (accountRequest.getBankId() != null
                    && !accountRequest.getBankId().isEmpty()) {

                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "bankName",
                        "bankName", messageValidator
                                .validateMessage(VAL_FIELD_EMPTY,
                                        new Object[] { "Bank - Name" }));
            }
        }
        if ((accountRequest.getRequestType().equals(ACCOUNT_REQTYPE_OPEN))
                && (accountRequest.getRequestStatus().equals(
                        ACCOUNT_STATUS_PEND_BANKCONF) || (accountRequest
                        .getRequestStatus().equals(ACCOUNT_STATUS_COMPLETED)))
                && (accountRequest.gettCode() == null || accountRequest
                        .gettCode().isEmpty())) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "tCode", "tCode",
                    messageValidator.validateMessage(VAL_FIELD_EMPTY,
                            new Object[] { "T-code" }));
        }
    }

    /**
     * Validate MDM data
     * 
     * @param errors
     * @param accountRequest
     */
    private void validateMDMData(Errors errors, AccountRequest accountRequest) {

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "leCode", "leCode",
                messageValidator.validateMessage(VAL_FIELD_EMPTY,
                        new Object[] { "Gold Id" }));

        if (accountRequest.getLeCode() != null
                && !accountRequest.getLeCode().isEmpty()) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "leName",
                    "leName", messageValidator.validateMessage(VAL_FIELD_EMPTY,
                            new Object[] { "LE Name" }));
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "leVersion",
                    "leVersion", messageValidator.validateMessage(
                            VAL_FIELD_EMPTY, new Object[] { "LE Version" }));

        }

        if (accountRequest.getLeName() != null
                && !accountRequest.getLeName().isEmpty() && (accountRequest.getLeName().length() > MAX_MDM_LENAME_LENGTH)) {
                errors.rejectValue("leName", "leName", messageValidator
                        .validateMessage(VAL_FIELD_LENGHT,
                                new Object[] { MAX_MDM_LENAME_LENGTH }));
        }

        
        if (StringUtils.isEmpty(accountRequest.getCompanyCode()) && StringUtils.isEmpty(accountRequest.getBuCode())) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, COMPANY_CODE,
            		COMPANY_CODE, messageValidator.validateMessage(VAL_FIELD_EMPTY,
                            new Object[] { "Company Code/Bu" }));

        }
        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "country", "country",
                messageValidator.validateMessage(VAL_FIELD_EMPTY,
                        new Object[] { "Bank Account Country" }));

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currency",
                "currency", messageValidator.validateMessage(VAL_FIELD_EMPTY,
                        new Object[] { "Bank Account Currency" }));
        
        checkForInactiveFields(errors, accountRequest);
		
        MyBankLogger.logDebug(this, "Ending MDM Validation");

    }

    private void checkForInactiveFields(Errors errors, AccountRequest accountRequest) {
    	 if(!mdmService.validateBankBranchStatus(accountRequest.getBankId(), accountRequest.getCountry(), "BANK")){
         	errors.rejectValue(BANK_MDM_ID, 
         			BANK_MDM_ID, "Bank MDM ID " + accountRequest.getBankId() + " is inactive/invalid");
         }
         if(!mdmService.validateBankBranchStatus(accountRequest.getBranchMDMID(), accountRequest.getCountry(), "BANK BRANCH")){
         	errors.rejectValue(BRANCH_MDM_ID, 
         			BRANCH_MDM_ID, "Branch MDM ID" + accountRequest.getBranchMDMID() + " is inactive/invalid");
         }
         if(!mdmService.validateCountryCodeStatus(accountRequest))
         {
         	errors.rejectValue(COUNTRY_CODE, 
         			COUNTRY_CODE, "Country Code " + accountRequest.getCountry() + " is inactive/invalid");
         }
         if(!mdmService.validateCurrencyCodeStatus(accountRequest)){
         	errors.rejectValue(CURRENCY_CODE, 
         			CURRENCY_CODE, "Currency Code " + accountRequest.getCurrency() + " is inactive/invalid");
         }
         JSONArray jarray = mdmService.getMDMRouteDetails(accountRequest);
         if (null == jarray) {
         	errors.rejectValue(ROUTING_CODE, 
         			ROUTING_CODE, "Routing " + accountRequest.getRouteCode() + " is inactive/invalid or not mapped with bank MDM ID");
         }
         
         JSONArray arr = mdmService.getMDMLEDetails(accountRequest);
         
         if(arr.length()==0){
         	errors.rejectValue(LE_CODE, 
         			LE_CODE, "Gold LE Code " + accountRequest.getLeCode() + " is inactive/invalid");
         }
         if(StringUtils.isNotEmpty(accountRequest.getComponentCode()) && !mdmService.validateComponentCode(accountRequest))
         {
         		errors.rejectValue(COMPONENT_CODE, 
         				COMPONENT_CODE, "Component code " + accountRequest.getComponentCode() + " is inactive/not mapped with gold LE code");
         }
         if(!mdmService.validateMeCodeStatus(accountRequest)){
         	errors.rejectValue(ME_CODE, 
         			ME_CODE, "ME Code " + accountRequest.getBankId() + " is inactive/invalid");
         }
         if(!mdmService.validateAccountTypeStatus(accountRequest)){
         	errors.rejectValue(ACCOUNT_TYPE, 
         			ACCOUNT_TYPE, "Account Type " + accountRequest.getBankId() + " is inactive/invalid");
         }

	}

	/**
     * Validate flags
     * 
     * @param errors
     * @param accountRequest
     */
    private void validateFlagsData(Errors errors, AccountRequest accountRequest) {
        if (accountRequest.getFlags() != null) {
            int index = 0;
            for (AccountFlag flag : accountRequest.getFlags()) {
                if (flag.getFlagCode() != null) {
                    AccountValidationUtils.rejectIfIdNotContainedInLovs(errors,
                            ValidationConstants.ACCT_REQUEST_FLAG, lookupTypes,
                            flag.getFlagCode(),
                            "flags[" + index + "].flagCode", messageValidator
                                    .validateMessage(VAL_FIELD_NOTVALID,
                                            new Object[] { "Flag Code" }));
                }
                // Clean comment in case user previously give it
                if (flag.getIsFlagChecked() != null
                        && flag.getIsFlagChecked().equals(
                                ValidationConstants.FLAG_STATUS_CHECKED_NO)) {
                    flag.setFlagCmment("");
                }
                index++;
            }
        }
    }

    /**
     * Validate Signers
     * 
     * @param errors
     * @param accountRequest
     */
    private void validateSignersData(Errors errors,
            AccountRequest accountRequest) {
        if (accountRequest.getSigners() != null) {
            int index = 0;
            for (AccountSigner signer : accountRequest.getSigners()) {
                if (signer.getSignerType() == null
                        || signer.getSignerType().isEmpty()) {
                    errors.rejectValue("signers[" + index + "].signerType",
                            "signers[" + index + "].signerType",
                            messageValidator.validateMessage(VAL_FIELD_EMPTY,
                                    new Object[] { "Signer Type" }));
                } else {
                    AccountValidationUtils.rejectIfIdNotContainedInLovs(errors,
                            ValidationConstants.ACCT_REQUEST_SIGNER_TYPE,
                            lookupTypes, signer.getSignerType(), "signers["
                                    + index + "].signerType", messageValidator
                                    .validateMessage(VAL_FIELD_NOTVALID,
                                            new Object[] { "Signer Type" }));
                }
                if (signer.getSignerName() == null
                        || signer.getSignerName().isEmpty()) {
                    errors.rejectValue("signers[" + index + "].signerName",
                            "signers[" + index + "].signerName",
                            messageValidator.validateMessage(VAL_FIELD_EMPTY,
                                    new Object[] { "Signer Name" }));
                }

                if (signer.getSignerName() != null
                        && !signer.getSignerName().isEmpty() && (signer.getSignerName().length() > MAX_SIGNER_NAME_LENGTH)) {
                        errors.rejectValue(
                                "signers[" + index + "].signerName",
                                "signers[" + index + "].signerName",
                                messageValidator
                                        .validateMessage(
                                                VAL_FIELD_LENGHT,
                                                new Object[] { MAX_SIGNER_NAME_LENGTH }));
                }
                if (accountRequest.getRequestStatus().equalsIgnoreCase(
                        ACCOUNT_STATUS_PEND_BANKCONF) && (signer.getDocName() == null || signer.getDocName().isEmpty())) {
                        errors.rejectValue("signers[" + index + "].docName",
                                "signers[" + index + "].docName",
                                messageValidator.validateMessage(
                                        VAL_FIELD_EMPTY,
                                        new Object[] { "Signer Card" }));
                }

                index++;
            }
        }
    }

    /**
     * Validate Documents
     * 
     * @param errors
     * @param accountRequest
     * accountRequest.gettCode() != null
                            && !accountRequest.gettCode().isEmpty()
       accountRequest.gettCode() != null
                            && !accountRequest.gettCode().isEmpty()
     */
    private void validateDocumentsData(Errors errors,
            AccountRequest accountRequest) {
        if (accountRequest.getDocuments() != null) {
            int index = 0;
            for (AccountDocument document : accountRequest.getDocuments()) {
                if (document.getDocName() == null
                        || document.getDocName().isEmpty()) {
                    if (document.getDocType().contains("Bank Confirmation")
                            && accountRequest.getRequestStatus().equals(
                                    ACCOUNT_STATUS_PEND_BANKCONF)) {
                        errors.rejectValue("documents[" + index + "].docName",
                                "documents[" + index + "].docName",
                                messageValidator.validateMessage(
                                        VAL_FIELD_EMPTY,
                                        new Object[] { "Bank Confirmation" }));

                    }
                    if (document.getDocType().contains("Business Confirmation")) {
                        errors.rejectValue(
                                "documents[" + index + "].docName",
                                "documents[" + index + "].docName",
                                messageValidator
                                        .validateMessage(
                                                VAL_FIELD_EMPTY,
                                                new Object[] { "Business Confirmation" }));
                    }
                    if (document.getDocType().contains(
                            "ICF Disconnection Confirmation")
                            && accountRequest.getRequestType().equals(
                                    ACCOUNT_REQTYPE_CLOSE)
                            && StringUtils.isNotEmpty(accountRequest.gettCode())
                            && accountRequest.getCashpoolLeCode() != null
                            && accountRequest.getCashpoolTCode() != null) {
                        errors.rejectValue(
                                "documents[" + index + "].docName",
                                "documents[" + index + "].docName",
                                messageValidator
                                        .validateMessage(
                                                VAL_FIELD_EMPTY,
                                                new Object[] { "ICF Disconnection Confirmation" }));
                    }
                    if (document.getDocType().contains(
                            "Business Disconnection Confirm")
                            && accountRequest.getRequestType().equals(
                                    ACCOUNT_REQTYPE_CLOSE)
                            && StringUtils.isNotEmpty(accountRequest.gettCode())
                            && accountRequest.getCashpoolLeCode() != null
                            && accountRequest.getCashpoolTCode() != null) {
                        errors.rejectValue(
                                "documents[" + index + "].docName",
                                "documents[" + index + "].docName",
                                messageValidator
                                        .validateMessage(
                                                VAL_FIELD_EMPTY,
                                                new Object[] { "Business Disconnection Confirm" }));

                    }

                }
                index++;
            }
        }
    }

    /**
     * Validate Comments
     * 
     * @param errors
     * @param accountRequest
     * accountRequest.getComments() == null || accountRequest
                .getComments().isEmpty()
     */
    private void validateCommentsData(Errors errors,
            AccountRequest accountRequest) {
        if ((StringUtils.isEmpty(accountRequest.getComments().toString()))
                && accountRequest.getAcctReqID() == null
                && (accountRequest.getRequestType()
                        .equals(ACCOUNT_REQTYPE_OPEN)
                        || accountRequest.getRequestType().equals(
                                ACCOUNT_REQTYPE_MODIFY) || accountRequest
                        .getRequestType().equals(ACCOUNT_REQTYPE_CLOSE))) {
            errors.rejectValue("comments", "comments", messageValidator
                    .validateMessage(VAL_FIELD_EMPTY,
                            new Object[] { "Comments" }));
        } else {
            int index = 0;
            for (AccountComment comment : accountRequest.getComments()) {
                if (comment.getCommentType() == null
                        || comment.getCommentType().isEmpty()) {
                    errors.rejectValue("comments[" + index + "].commentType",
                            "comments[" + index + "].commentType",
                            messageValidator.validateMessage(VAL_FIELD_EMPTY,
                                    new Object[] { "Comment Type" }));
                } else {
                    AccountValidationUtils.rejectIfIdNotContainedInLovs(errors,
                            ValidationConstants.ACCT_REQUEST_COMMENT_TYPE,
                            lookupTypes, comment.getCommentType(), "comments["
                                    + index + "].commentType", messageValidator
                                    .validateMessage(VAL_FIELD_NOTVALID,
                                            new Object[] { "Comment Type" }));
                }
                if (comment.getComments() == null
                        || comment.getComments().isEmpty()) {
                    errors.rejectValue("comments[" + index + "].comments",
                            "comments[" + index + "].comments",
                            messageValidator.validateMessage(VAL_FIELD_EMPTY,
                                    new Object[] { "Comments" }));
                } else if (comment.getComments().length() > MAX_COMMENT_LENGTH) {
                    errors.rejectValue("comments[" + index + "].comments",
                            "comments[" + index + "].comments",
                            messageValidator.validateMessage(VAL_FIELD_LENGHT,
                                    new Object[] { MAX_COMMENT_LENGTH }));
                }
                index++;
            }
        }
    }
    /**
     * Check whether company code/bu code present is inactive in MDM for an open/modify request
     */
    private void checkIfCoCodeorBuCodeInactive(Errors errors,
            AccountRequest accountRequest) {
    	String response = null;
    	boolean fieldVal = false;
    	if(StringUtils.isNotEmpty(accountRequest.getCompanyCode())) {
    		fieldVal = true;
    		User user = new User();
    		user.setUserProfile(new UserProfile());
    		response = mdmService.getFilterCompanyCodes(user, accountRequest.getLeCode(), 
    									accountRequest.getCompanyCode(), true);
    	}else {
    		response = mdmService.getBusinessFromBu(accountRequest.getBuCode(), true);
    	}
    	
    	if(StringUtils.isNotEmpty(response)) {
    		JSONObject obj = new JSONObject(response);
    		JSONArray data = obj.getJSONArray("elements");
    		if(null == data || data.length() ==0) {
    			if(fieldVal) {
    				errors.rejectValue(COMPANY_CODE, 
    						COMPANY_CODE, "Company Code " + accountRequest.getCompanyCode() + " is inactive/invalid");
    			}else {
    				errors.rejectValue(BU_CODE, 
        					BU_CODE, "BU Code " + accountRequest.getBuCode() + " is inactive");
    			}
    		}else if(fieldVal && (null != data || data.length() !=0)) {
    			checkCoCodeBuCombination(accountRequest, data, errors);
    		}
    	}
    	
    }

    private boolean checkIfReqTypeClose(String reqType) {
    	return StringUtils.equals(reqType, ACCOUNT_REQTYPE_CLOSE);
    }
    
    private void checkCoCodeBuCombination(AccountRequest accReq,JSONArray data, Errors errors) {
    	String buCode = null;
    	Iterator<Object> itr = data.iterator();
		 try {
 				while (itr.hasNext()) {
 					JSONObject obj = (JSONObject) itr.next();

 					buCode = StringHelper.getStringValue(obj.get(MDMConstants.ASSOCIATED_BU));
 					checkIfBuCodeActive(buCode, accReq, errors);
 					
 					if(!buCode.equalsIgnoreCase(accReq.getBuCode())) {
 						errors.rejectValue(COMPANY_CODE, COMPANY_CODE, "BU Code " + accReq.getBuCode() 
						+ " is not associated with company code " + accReq.getCompanyCode());
 					}
 				} 
 			} catch (Exception e) {
 				MyBankLogger.logError(this, "Error in fetching bu code : " + e.getMessage());
 				throw new BusinessException("Error in fetching bu code : " + e.getMessage());
 			}
    } 
    
    private void checkIfBuCodeActive(String buCode, AccountRequest accReq,Errors errors) {
    	String response = mdmService.getBusinessFromBu(buCode, checkIfReqTypeClose(accReq.getRequestType())?false : true);
    	JSONObject obj = new JSONObject(response);
		JSONArray data = obj.getJSONArray("elements");
		
		if(null == data || data.length() == 0) {
			errors.rejectValue(BU_CODE, 
					BU_CODE, "BU Code " + accReq.getBuCode() + " is inactive");
		}
    }
    /**
     * Obtain Lookup data
     */
    private void obtainLookupData() {
        // List of Object types needed for validations
        listLookupParam = AccountValidationUtils.obtainListOfObjTypes();

        try {
            lookupTypes = lookupService.getLovsByLookupType(listLookupParam,
                    ControllersConstants.DEFAULT_LOV_ORDER,
                    ControllersConstants.DEFAULT_DIRECTION);
        } catch (DBException e) {
            MyBankLogger.logError(this, e.getMessage(), e);
        }
    }

    private void pendingCloseOrModifyByTcode(Errors errors,
            AccountRequest accountRequest) {
        if ("ACCTREQTYPE_MODIFY".equalsIgnoreCase(accountRequest
                .getRequestType())
                || "ACCTREQTYPE_CLOSE".equalsIgnoreCase(accountRequest
                        .getRequestType())) {
            try {

                if (accountRequest.getAcctReqID() == null && isInflightValidationRequired()) {
                    Long id = accRequestService
                            .getPendingCloseOrModifyByTcode(accountRequest
                                    .gettCode());
                    if (id != null) {
                        errors.reject(
                                "BusinessException",
                                "There is already an inflight request for this account. Please complete the pending request No."
                                        + id);
                    }
                }
                if (!errors.hasErrors()
                        && !mdmService.isAccountValid(accountRequest.gettCode())) {
                    errors.reject("BusinessException",
                            "Account is not open/acquired/divested or does not exist.");
                }
                
            } catch (DBException e) {
                MyBankLogger.logError(this, e.getMessage(),e);
            } catch (SystemException e) {
            	MyBankLogger.logError(this, e.getMessage(),e);
			} catch (Exception e) {
				MyBankLogger.logError(this, e.getMessage(),e);
			}
        }
    }

    private void checkIfRequestModifiedByAnother(Errors errors,
            AccountRequest accountRequest) {
        if (accountRequest.getRequestType().equalsIgnoreCase(
                ValidationConstants.ACCT_REQUEST_TYPE_OPEN) ||
                accountRequest.getRequestType().equalsIgnoreCase(
                        ValidationConstants.ACCT_REQUEST_TYPE_CLOSE) ||
                        accountRequest.getRequestType().equalsIgnoreCase(
                                ValidationConstants.ACCT_REQUEST_TYPE_MODIFY)) {
            try {

                if (accountRequest.getAcctReqID() != null) {
                    LastUpdatedDetails lastUpdatedDetails = accRequestService
                            .getLastUpdatedDetails(accountRequest
                                    .getAcctReqID());

                    if (!errors.hasErrors()
                            && lastUpdatedDetails.getLastUpdatedDate() != null
                            && accountRequest.getLastUpdateDate() != null
                            && (lastUpdatedDetails.getLastUpdatedDate())
                                    .after(accountRequest.getLastUpdateDate())) {
                        errors.reject(
                                "BusinessException",
                                "Request has been modified by another user: "
                                        + lastUpdatedDetails
                                                .getLastUpdatedUser());
                    }
                }
            } catch (DBException e) {
                MyBankLogger.logError(this, e.getMessage(), e);
            }
        }
    }

    public boolean isInflightValidationRequired() {
        return inflightValidationRequired;
    }

    public void setInflightValidationRequired(boolean inflightValidationRequired) {
        this.inflightValidationRequired = inflightValidationRequired;
    }
    

}
