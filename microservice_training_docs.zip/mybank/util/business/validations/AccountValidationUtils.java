package com.ge.treasury.mybank.util.business.validations;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.validation.Errors;

import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;

/**
 * Validation util for Account Request
 * 
 * @author MyBank Dev team
 * 
 */
public class AccountValidationUtils implements ValidationConstants {

    private static final Map<String,String> REQUEST_TYPE_MDM_MAP = new HashMap<String,String>();
    
    private static final Map<String,String> FILE_TYPE_BULK_MAP = new HashMap<String,String>();
    
    private static final Map<String,String> ACCOUNT_STATUS_REQUEST_TYPE_MAP = new HashMap<String,String>();
    
    private static final Map<String,String> SIGNER_LOOKUP_MAP = new HashMap<String,String>();
    
    private static final Map<String,String> UPLOAD_TYPE_MAP = new HashMap<String,String>();
    
    private AccountValidationUtils() {
        throw new IllegalAccessError("Utility class");
    }

    static{
        REQUEST_TYPE_MDM_MAP.put("OPEN", MDM_ACCT_STATUS_OPEN);
        REQUEST_TYPE_MDM_MAP.put(ACCT_REQUEST_TYPE_OPEN, MDM_ACCT_STATUS_OPEN);
        
        REQUEST_TYPE_MDM_MAP.put("MODIFY", MDM_ACCT_STATUS_OPEN);
        REQUEST_TYPE_MDM_MAP.put(ACCT_REQUEST_TYPE_MODIFY, MDM_ACCT_STATUS_OPEN);
        
        REQUEST_TYPE_MDM_MAP.put("CLOSE", MDM_ACCT_STATUS_CLOSE);
        REQUEST_TYPE_MDM_MAP.put(ACCT_REQUEST_TYPE_CLOSE, MDM_ACCT_STATUS_CLOSE);
        
        REQUEST_TYPE_MDM_MAP.put("DIVESTED", MDM_ACCT_STATUS_DIVESTED);
        REQUEST_TYPE_MDM_MAP.put(ACCT_REQUEST_TYPE_DIVESTED, MDM_ACCT_STATUS_DIVESTED);
		
		REQUEST_TYPE_MDM_MAP.put("ACQUIRED", MDM_ACCT_STATUS_ACQUIRED);
        REQUEST_TYPE_MDM_MAP.put(ACCT_REQUEST_TYPE_ACQUIRED, MDM_ACCT_STATUS_ACQUIRED);
        
        ACCOUNT_STATUS_REQUEST_TYPE_MAP.put("OPEN", ACCT_REQUEST_TYPE_OPEN);
        ACCOUNT_STATUS_REQUEST_TYPE_MAP.put("CLOSED", ACCT_REQUEST_TYPE_CLOSE);
        ACCOUNT_STATUS_REQUEST_TYPE_MAP.put("DIVESTED", ACCT_REQUEST_TYPE_DIVESTED);
        ACCOUNT_STATUS_REQUEST_TYPE_MAP.put("ACQUIRED", ACCT_REQUEST_TYPE_ACQUIRED);
        
        FILE_TYPE_BULK_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_OPEN, MDM_ACCT_STATUS_ACQUIRED + "," + MDM_ACCT_STATUS_OPEN);
        FILE_TYPE_BULK_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY, MDM_ACCT_STATUS_OPEN + "," + MDM_ACCT_STATUS_ACQUIRED + "," + MDM_ACCT_STATUS_DIVESTED);
        FILE_TYPE_BULK_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC, MDM_ACCT_STATUS_OPEN + "," + MDM_ACCT_STATUS_ACQUIRED + "," + MDM_ACCT_STATUS_DIVESTED);
        FILE_TYPE_BULK_MAP.put(BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_CLOSE, MDM_ACCT_STATUS_DIVESTED);
        
        SIGNER_LOOKUP_MAP.put(BulkApprovalConstants.SIGNER_TYPE_SSO, "ACCTREQSIGNERTYPE_SSO");
        SIGNER_LOOKUP_MAP.put(BulkApprovalConstants.SIGNER_TYPE_FACSIMILE, "ACCTREQSIGNERTYPE_FACSIMILE");
        SIGNER_LOOKUP_MAP.put(BulkApprovalConstants.SIGNER_TYPE_PERSONAL_CHOP, "ACCTREQSIGNERTYPE_PERSONCHOP");
        SIGNER_LOOKUP_MAP.put(BulkApprovalConstants.SIGNER_TYPE_COMPANY_CHOP, "ACCTREQSIGNERTYPE_COMPCHOP");
        SIGNER_LOOKUP_MAP.put(BulkApprovalConstants.SIGNER_TYPE_NON_SSO, "ACCTREQSIGNERTYPE_NON-SSO");  
        
        UPLOAD_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_OPEN, BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_OPEN);
        UPLOAD_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_CLOSE, BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_CLOSE);
        UPLOAD_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_MODIFY, BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY);
        UPLOAD_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_MODIFY_INTERNAL, BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_INTERNAL);
        UPLOAD_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_MODIFY_SPECIFIC, BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_MODIFY_SPECIFC);
        UPLOAD_TYPE_MAP.put(BulkApprovalConstants.BULK_UPLOAD_SIGNER, BulkApprovalConstants.BULK_UPLOAD_FILE_TYPE_SIGNER);

    }

    /**
     * Obtains the list of Object types needed for lookup Validations
     * 
     * @return
     */
    public static String obtainListOfObjTypes() {
        // List of Object types needed for validations
        StringBuilder listParam = new StringBuilder();

        listParam.append(ValidationConstants.ACCT_REQUEST_STATUS + ",");
        listParam.append(ValidationConstants.ACCT_REQUEST_TYPE + ",");
        listParam.append(ValidationConstants.ACCT_REQUEST_DOCUMENT_TYPE + ",");
        listParam.append(ValidationConstants.ACCT_REQUEST_SIGNER_TYPE + ",");
        listParam.append(ValidationConstants.ACCT_REQUEST_COMMENT_TYPE + ",");
        listParam.append(ValidationConstants.ACCT_REQUEST_FLAG);

        return listParam.toString();
    }

    /**
     * Rejects if date field is in a no valid format.
     * 
     * @param errors
     * @param dateToValidate
     */
    public static boolean rejectIfFormatDateNotValid(Errors errors,
            String dateToValidate, String fieldName, String errorCode) {
        SimpleDateFormat sdf = new SimpleDateFormat(
                ValidationConstants.DATE_FORMAT, Locale.ENGLISH);
        sdf.setLenient(false);

        try {
            // if not valid, it will throw ParseException
            sdf.parse(dateToValidate);
        } catch (ParseException e) {
            errors.rejectValue(fieldName, fieldName, errorCode);
            return false;
        }
        return true;
    }

    /**
     * Rejects if a specific Lookup code is not contained in a list of codes.
     * 
     * @param errors
     * @param lookupType
     * @param lovCodes
     * @param code
     * @param fieldName
     * @param errorCode
     * @return
     */
    public static boolean rejectIfIdNotContainedInLovs(Errors errors,
            String lookupType, List<MyBankLookup> lovCodes, String code,
            String fieldName, String errorCode) {
        boolean found = false;
        if (lovCodes != null) {
            for (MyBankLookup currlov : lovCodes) {
                if (currlov.getLookupType().equals(lookupType) && (currlov.getLookupCode().equals(code))) {
                        found = true;
                        break;
                }
            }
        }
        if (!found) {
            errors.rejectValue(fieldName, fieldName, errorCode);
        }
        return found;
    }
    
    public static Map<String,String> getRequestTypeMDMMap(){
        return REQUEST_TYPE_MDM_MAP;
    }
    
    public static Map<String,String> getFileTypeBulkMap(){
        return FILE_TYPE_BULK_MAP;
    }
    
    public static Map<String,String> getSignerLookupMap(){
        return SIGNER_LOOKUP_MAP;
    }
    public static Map<String,String> getAccountStatusRequestTypeMap(){
        return ACCOUNT_STATUS_REQUEST_TYPE_MAP;
    }
    
    public static Map<String,String> getUploadTypeMap(){
        return UPLOAD_TYPE_MAP;
    }
    
}
