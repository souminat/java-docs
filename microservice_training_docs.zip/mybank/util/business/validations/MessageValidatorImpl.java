/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.validations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.util.business.constants.ValidationConstants;

/**
 * Validate message to obtain error / validation / informative message
 * 
 * @author MyBank Dev Team
 * 
 */
@Component
public class MessageValidatorImpl implements MessageValidator {

    @Autowired
    MessageSource messageSource;

    /*
     * Returns the message resolved from properties file (non-Javadoc)
     * 
     * @see com.ge.treasury.ngtrs.business.validations.MessageValidatorService#
     * validateMessage (java.lang.String, java.lang.Object[])
     */
    @Override
    public String validateMessage(String errorCode, Object[] param) {
        return messageSource.getMessage(errorCode, param,
                ValidationConstants.INVALID_DEFAULT_MESSAGE, null);
    }

}
