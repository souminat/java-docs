/**
 * Copyright GE
 */
package com.ge.treasury.mybank.util.business.validations;

/**
 * 
 * @author MyBank Dev Team
 * 
 */
public class Validation {

    /**
	 * 
	 */
    private static final long serialVersionUID = 5679485034264540446L;
    private String fieldname;
    private String validationMessage;

    /**
     * @return the fieldname
     */
    public String getFieldname() {
        return fieldname;
    }

    /**
     * @param fieldname
     *            the fieldname to set
     */
    public void setFieldname(String fieldname) {
        this.fieldname = fieldname;
    }

    /**
     * @return the validationMessage
     */
    public String getValidationMessage() {
        return validationMessage;
    }

    /**
     * @param validationMessage
     *            the validationMessage to set
     */
    public void setValidationMessage(String validationMessage) {
        this.validationMessage = validationMessage;
    }

}
