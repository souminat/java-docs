package com.ge.treasury.mybank.util.business;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Utility methods used for String
 * 
 * @author MyBank Dev Team
 * 
 */
public class StringHelper {
	
	private StringHelper() {
		throw new IllegalAccessError("Utility class");
	}

    /**
     * Obtains string array from String separated by comma and add another
     * element if it is necessary
     * 
     * @return
     */
    public static String[] obtainArrayFromString(String original,
            String lastElement) {
        String[] elements = original.split(",");
        if (lastElement == null) {
            return elements;
        } else {
            String[] result = new String[elements.length + 1];
            for (int i = 0; i < elements.length; i++) {
                result[i] = elements[i];
            }
            result[result.length - 1] = lastElement;
            return result;
        }
    }

    /**
     * Obtains string value adding ''
     * 
     * @return
     */
    public static String obtainSearchString(String original) {
        StringBuilder result = new StringBuilder();
        String[] elements = original.split(",");
        for (int i = 0; i < elements.length; i++) {
            if (!(i == elements.length - 1)) {
                result.append("'" + elements[i].trim() + "',");
            } else {
                result.append("'" + elements[i].trim() + "'");
            }
        }
        return result.toString();
    }
    
	public static Map<String, String> splitQuery(URL url) throws UnsupportedEncodingException {
		Map<String, String> query_pairs = new LinkedHashMap<String, String>();
		String query = url.getQuery();
		String[] pairs = query.split("&");
		for (String pair : pairs) {
			int idx = pair.indexOf("=");
			query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"),
					URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
		}
		return query_pairs;
	}
	
	/**
     * Returns null if object data is empty, else it will return the string representation of object
     * 
     * @param data
     * @return
     */
    public static synchronized String getStringValue(Object data) {
        return "null".equalsIgnoreCase(String.valueOf(data)) ? null : String.valueOf(data);
    }
}
