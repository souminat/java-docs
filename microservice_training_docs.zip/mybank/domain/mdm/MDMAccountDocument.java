package com.ge.treasury.mybank.domain.mdm;

import java.io.Serializable;

/**
 * @author MyBank Dev Team
 * 
 */
public class MDMAccountDocument implements Serializable {

    /*
     * DOCUMENT_ID, DOCUMENT_TYPE_CODE, DOCUMENT_NAME, FOLDER_ID, FILE_ID,
     * DOC_URL, ACCOUNT_REQUEST_ID, CREATE_TIMESTAMP, CREATE_USER,
     * LAST_UPDATE_TIMESTAMP, LAST_UPDATE_USER
     */

    /**
	 * 
	 */
    private static final long serialVersionUID = -5254909085802111084L;

    private String docType;
    private String docName;
    private Long folderId;
    private Long fileId;
    private String docURL;

    /**
     * @param docType
     * @param docName
     * @param folderId
     * @param fileId
     * @param docURL
     */
    public MDMAccountDocument(String docType, String docName, Long folderId,
            Long fileId, String docURL) {
        super();
        this.docType = docType;
        this.docName = docName;
        this.folderId = folderId;
        this.fileId = fileId;
        this.docURL = docURL;

    }

    /**
	 * 
	 */
    public MDMAccountDocument() {
    	//No arg constructor
    }

    /**
     * @return the docName
     */
    public String getDocName() {
        return docName;
    }

    /**
     * @param docName
     *            the docName to set
     */
    public void setDocName(String docName) {
        this.docName = docName;
    }

    /**
     * @return the docType
     */
    public String getDocType() {
        return docType;
    }

    /**
     * @param docType
     *            the docType to set
     */
    public void setDocType(String docType) {
        this.docType = docType;
    }

    /**
     * @return the docURL
     */
    public String getDocURL() {
        return docURL;
    }

    /**
     * @param docURL
     *            the docURL to set
     */
    public void setDocURL(String docURL) {
        this.docURL = docURL;
    }

    /**
     * @return the folderId
     */
    public Long getFolderId() {
        return folderId;
    }

    /**
     * @param folderId
     *            the folderId to set
     */
    public void setFolderId(Long folderId) {
        this.folderId = folderId;
    }

    /**
     * @return the fileId
     */
    public Long getFileId() {
        return fileId;
    }

    /**
     * @param fileId
     *            the fileId to set
     */
    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

}
