/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

/**
 * @author MyBank Dev Team
 * 
 */
public class ResponseObjects {

    private String responseList;

    /**
	 * 
	 */
    public ResponseObjects() {
        super();
    }

    /**
     * @param attribute
     */
    public ResponseObjects(String attribute) {
        super();
        this.setResponseList(attribute);
    }

    /**
     * @return the responseList
     */
    public String getResponseList() {
        return responseList;
    }

    /**
     * @param responseList
     *            the responseList to set
     */
    public void setResponseList(String responseList) {
        this.responseList = responseList;
    }

}
