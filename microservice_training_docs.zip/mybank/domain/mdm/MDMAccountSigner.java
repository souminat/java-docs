/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author MyBank Dev Team
 * 
 */
public class MDMAccountSigner implements Serializable {

    /*
     * DB FIELDS SIGNER_ID, SSO_ID, SIGNER_TYPE_CODE, SIGNER_NAME,
     * SIGNER_START_DATE, SIGNER_END_DATE, ACCOUNT_REQUEST_ID, CREATE_TIMESTAMP,
     * CREATE_USER, LAST_UPDATE_TIMESTAMP, LAST_UPDATE_USER, DOCUMENT_ID,
     * IS_ACTIVE
     */
    private static final long serialVersionUID = -1591384172103505728L;

    private Long signerId;
    private String ssoId;
    private String signerType;
    private String signerName;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL, using = com.ge.treasury.mybank.util.business.JsonDateSerializer.class)
    private Date signerStartDate;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL, using = com.ge.treasury.mybank.util.business.JsonDateSerializer.class)
    private Date signerEndDate;

    // SignatureCard fields
    private String docType;
    private String docName;
    private BigInteger folderId;
    private BigInteger fileId;
    private String docURL;
    private Long docId;

    /**
     * @param ssoId
     * @param signerType
     * @param signerName
     * @param signerStartDate
     * @param signerEndDate
     * @param acctReqID
     * @param signatureCard
     * public MDMAccountSigner(String ssoId, String signerType, String signerName, Date signerStartDate,
            Date signerEndDate, String docType, String docName, BigInteger folderId, BigInteger fileId, String docURL) {
        super();
        this.ssoId = ssoId;
        this.signerType = signerType;
        this.signerName = signerName;
        this.signerStartDate = signerStartDate;
        this.signerEndDate = signerEndDate;
        this.docType = docType;
        this.docName = docName;
        this.folderId = folderId;
        this.fileId = fileId;
        this.docURL = docURL;
    }
     */
 

    public MDMAccountSigner() {
        // No arg constructor
    }

    /**
     * @return the signerId
     */
    public Long getSignerId() {
        return signerId;
    }

    /**
     * @param signerId
     *            the signerId to set
     */
    public void setSignerId(Long signerId) {
        this.signerId = signerId;
    }

    /**
     * @return the ssoId
     */
    public String getSsoId() {
        return ssoId;
    }

    /**
     * @param ssoId
     *            the ssoId to set
     */
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    /**
     * @return the signerType
     */
    public String getSignerType() {
        return signerType;
    }

    /**
     * @param signerType
     *            the signerType to set
     */
    public void setSignerType(String signerType) {
        this.signerType = signerType;
    }

    /**
     * @return the signerName
     */
    public String getSignerName() {
        return signerName;
    }

    /**
     * @param signerName
     *            the signerName to set
     */
    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    /**
     * @return the signerStartDate
     */
    public Date getSignerStartDate() {
        return signerStartDate;
    }

    /**
     * @param signerStartDate
     *            the signerStartDate to set
     */
    public void setSignerStartDate(Date signerStartDate) {
        this.signerStartDate = signerStartDate;
    }

    /**
     * @return the signerEndDate
     */
    public Date getSignerEndDate() {
        return signerEndDate;
    }

    /**
     * @param signerEndDate
     *            the signerEndDate to set
     */
    public void setSignerEndDate(Date signerEndDate) {
        this.signerEndDate = signerEndDate;
    }

    /**
     * /**
     * 
     * @return the docType
     */
    public String getDocType() {
        return docType;
    }

    /**
     * @param docType
     *            the docType to set
     */
    public void setDocType(String docType) {
        this.docType = docType;
    }

    /**
     * @return the docName
     */
    public String getDocName() {
        return docName;
    }

    /**
     * @param docName
     *            the docName to set
     */
    public void setDocName(String docName) {
        this.docName = docName;
    }

    /**
     * @return the folderId
     */
    public BigInteger getFolderId() {
        return folderId;
    }

    /**
     * @param folderId
     *            the folderId to set
     */
    public void setFolderId(BigInteger folderId) {
        this.folderId = folderId;
    }

    /**
     * @return the fileId
     */
    public BigInteger getFileId() {
        return fileId;
    }

    /**
     * @param fileId
     *            the fileId to set
     */
    public void setFileId(BigInteger fileId) {
        this.fileId = fileId;
    }

    /**
     * @return the docURL
     */
    public String getDocURL() {
        return docURL;
    }

    /**
     * @param docURL
     *            the docURL to set
     */
    public void setDocURL(String docURL) {
        this.docURL = docURL;
    }

    /**
     * @return the docId
     */
    public Long getDocId() {
        return docId;
    }

    /**
     * @param docId
     *            the docId to set
     */
    public void setDocId(Long docId) {
        this.docId = docId;
    }

}
