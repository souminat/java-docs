/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

/**
 * @author MyBank Dev Team
 * 
 */
public class SearchCriteriaList {

    private String setName;
    private String attribute;
    private String operator;
    private String value;

    /**
	 * 
	 */
    public SearchCriteriaList() {
        super();
    }

    /**
     * @param setName
     * @param attribute
     * @param operator
     * @param value
     */
    public SearchCriteriaList(String setName, String attribute,
            String operator, String value) {
        super();
        this.setName = setName;
        this.attribute = attribute;
        this.operator = operator;
        this.value = value;
    }

    /**
     * @return the setName
     */
    public String getSetName() {
        return setName;
    }

    /**
     * @param setName
     *            the setName to set
     */
    public void setSetName(String setName) {
        this.setName = setName;
    }

    /**
     * @return the attribute
     */
    public String getAttribute() {
        return attribute;
    }

    /**
     * @param attribute
     *            the attribute to set
     */
    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    /**
     * @return the operator
     */
    public String getOperator() {
        return operator;
    }

    /**
     * @param operator
     *            the operator to set
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

}
