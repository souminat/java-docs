/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author MyBank Dev Team
 * 
 */
public class SearchCriteria extends MDMBaseSearchCriteria {

    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private ResponseObjects responseObjects;

    /**
	 * 
	 */
    public SearchCriteria() {
        super();
    }

    /**
     * @param entityName
     * @param requestor
     * @param searchCriteriaList
     * @param searchRule
     * @param sort
     * @param pagination
     */
    public SearchCriteria(ResponseObjects responseObjects) {

        this.responseObjects = responseObjects;
    }

    /**
     * @return the responseObjects
     */
    public ResponseObjects getResponseObjects() {
        return responseObjects;
    }

    /**
     * @param responseObjects
     *            the responseObjects to set
     */
    public void setResponseObjects(ResponseObjects responseObjects) {
        this.responseObjects = responseObjects;
    }

}
