/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

import java.io.Serializable;
import java.util.List;

/**
 * @author MyBank Dev Team
 * 
 */
public class MDMAccount implements Serializable {

    private static final long serialVersionUID = -5794189275505330648L;

    private String tCode;
    private String acctReqID;
    private String acctNumber;
    private String accountStatus;
    private String buCode;
    private String busName;
	private String subBusName;
    private String accountType;
    private String acctTitle;
    private String leCode;
    private String leVersion;
    private String country;
    private String currency;
    private String bankId;
    private String iban;
    private String cashpoolTCode;
    private String routeCode;
    private String routeCodeType;
    private String branchId;
    private String cashPoolGoldCode;
    private String componentCode;
    private String companyCode;
    private String meCode;
    private String networkType;
    private String accountPurpose;
    private String acctOpenDate;
    private String acctClosedDate;
    private String projectName;
    private String cashPoolRejectReason;
    private String cocodeNotUseReason;

	// Signers
    private List<MDMAccountSigner> signers;
    // Documents
    private List<MDMAccountDocument> documents;

    public MDMAccount() {
        super();
    }
    
    public String getBuCode() {
		return buCode;
	}

	public void setBuCode(String buCode) {
		this.buCode = buCode;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}
    
    public String getSubBusName() {
        return subBusName;
    }

    public void setSubBusName(String subBusName) {
        this.subBusName = subBusName;
    }

    /**
     * @return the tCode
     */
    public String gettCode() {
        return tCode;
    }

    /**
     * @param tCode
     *            the tCode to set
     */
    public void settCode(String tCode) {
        this.tCode = tCode;
    }

    /**
     * @return the leCode
     */
    public String getLeCode() {
        return leCode;
    }

    /**
     * @param leCode
     *            the leCode to set
     */
    public void setLeCode(String leCode) {
        this.leCode = leCode;
    }

    /**
     * @return the accountStatus
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * @param accountStatus
     *            the accountStatus to set
     */
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    /**
     * @return the accountType
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * @param accountType
     *            the accountType to set
     */
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    /**
     * @return the leVersion
     */
    public String getLeVersion() {
        return leVersion;
    }

    /**
     * @param leVersion
     *            the leVersion to set
     */
    public void setLeVersion(String leVersion) {
        this.leVersion = leVersion;
    }

    /**
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country
     *            the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the bankId
     */
    public String getBankId() {
        return bankId;
    }

    /**
     * @param bankId
     *            the bankId to set
     */
    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    /**
     * @return the acctReqID
     */
    public String getAcctReqID() {
        return acctReqID;
    }

    /**
     * @param acctReqID
     *            the acctReqID to set
     */
    public void setAcctReqID(String acctReqID) {
        this.acctReqID = acctReqID;
    }

    /**
     * @return the acctNumber
     */
    public String getAcctNumber() {
        return acctNumber;
    }

    /**
     * @param acctNumber
     *            the acctNumber to set
     */
    public void setAcctNumber(String acctNumber) {
        this.acctNumber = acctNumber;
    }

    /**
     * @return the iban
     */
    public String getIban() {
        return iban;
    }

    /**
     * @param iban
     *            the iban to set
     */
    public void setIban(String iban) {
        this.iban = iban;
    }

    /**
     * @return the cashpoolTCode
     */
    public String getCashpoolTCode() {
        return cashpoolTCode;
    }

    /**
     * @param cashpoolTCode
     *            the cashpoolTCode to set
     */
    public void setCashpoolTCode(String cashpoolTCode) {
        this.cashpoolTCode = cashpoolTCode;
    }

    /**
     * @return the routeCode
     */
    public String getRouteCode() {
        return routeCode;
    }

    /**
     * @param routeCode
     *            the routeCode to set
     */
    public void setRouteCode(String routeCode) {
        this.routeCode = routeCode;
    }

    /**
     * @return the routeCodeType
     */
    public String getRouteCodeType() {
        return routeCodeType;
    }

    /**
     * @param routeCodeType
     *            the routeCodeType to set
     */
    public void setRouteCodeType(String routeCodeType) {
        this.routeCodeType = routeCodeType;
    }

    /**
     * @return the branchId
     */
    public String getBranchId() {
        return branchId;
    }

    /**
     * @param branchId
     *            the branchId to set
     */
    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    /**
     * @return the cashPoolGoldCode
     */
    public String getCashPoolGoldCode() {
        return cashPoolGoldCode;
    }

    /**
     * @param cashPoolGoldCode
     *            the cashPoolGoldCode to set
     */
    public void setCashPoolGoldCode(String cashPoolGoldCode) {
        this.cashPoolGoldCode = cashPoolGoldCode;
    }

    /**
     * @return the signers
     */
    public List<MDMAccountSigner> getSigners() {
        return signers;
    }

    /**
     * @param signers
     *            the signers to set
     */
    public void setSigners(List<MDMAccountSigner> signers) {
        this.signers = signers;
    }

    /**
     * @return the documents
     */
    public List<MDMAccountDocument> getDocuments() {
        return documents;
    }

    /**
     * @param documents
     *            the documents to set
     */
    public void setDocuments(List<MDMAccountDocument> documents) {
        this.documents = documents;
    }

    /**
     * @return the accountTitle
     */
    public String getAcctTitle() {
        return acctTitle;
    }

    /**
     * @param accountTitle
     *            the accountTitle to set
     */
    public void setAcctTitle(String acctTitle) {
        this.acctTitle = acctTitle;
    }

    /**
     * @return the componentCode
     */
    public String getComponentCode() {
        return componentCode;
    }

    /**
     * @param componentCode
     *            the componentCode to set
     */
    public void setComponentCode(String componentCode) {
        this.componentCode = componentCode;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getMeCode() {
        return meCode;
    }

    public void setMeCode(String meCode) {
        this.meCode = meCode;
    }

    public String getNetworkType() {
        return networkType;
    }

    public void setNetworkType(String networkType) {
        this.networkType = networkType;
    }

    public String getAccountPurpose() {
        return accountPurpose;
    }

    public void setAccountPurpose(String accountPurpose) {
        this.accountPurpose = accountPurpose;
    }

    public String getAcctOpenDate() {
        return acctOpenDate;
    }

    public void setAcctOpenDate(String acctOpenDate) {
        this.acctOpenDate = acctOpenDate;
    }

    public String getAcctClosedDate() {
        return acctClosedDate;
    }

    public void setAcctClosedDate(String acctClosedDate) {
        this.acctClosedDate = acctClosedDate;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getCashPoolRejectReason() {
        return cashPoolRejectReason;
    }

    public void setCashPoolRejectReason(String cashPoolRejectReason) {
        this.cashPoolRejectReason = cashPoolRejectReason;
    }
    
	public String getCocodeNotUseReason() {
		return cocodeNotUseReason;
	}

	public void setCocodeNotUseReason(String cocodeNotUseReason) {
		this.cocodeNotUseReason = cocodeNotUseReason;
	}

}
