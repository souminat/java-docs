package com.ge.treasury.mybank.domain.mdm;

import java.util.ArrayList;
import java.util.List;

public class MdmSearchCriteriaRule {

    private String attribute;
    private String operator;
    private List<String> value = new ArrayList<String>();

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public List<String> getValue() {
        return value;
    }

    public void setValue(List<String> value) {
        this.value = value;
    }
}
