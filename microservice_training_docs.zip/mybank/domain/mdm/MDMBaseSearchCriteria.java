/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author MyBank Dev Team
 * 
 */
public class MDMBaseSearchCriteria {

    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private String entityName;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private String requestor;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private List<SearchCriteriaList> searchCriteriaList;

    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private String searchRule;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private List<Sort> sort;

    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
    private Pagination pagination;

    /**
	 * 
	 */
    public MDMBaseSearchCriteria() {
        super();
    }

    /**
     * @param entityName
     * @param requestor
     * @param searchCriteriaList
     * @param searchRule
     * @param sort
     * @param pagination
     */
    public MDMBaseSearchCriteria(String entityName, String requestor,
            List<SearchCriteriaList> searchCriteriaList, String searchRule,
            List<Sort> sort, Pagination pagination) {
        super();
        this.entityName = entityName;
        this.requestor = requestor;
        this.searchCriteriaList = searchCriteriaList;
        this.searchRule = searchRule;
        this.sort = sort;
        this.pagination = pagination;
    }

    /**
     * @return the entityName
     */
    public String getEntityName() {
        return entityName;
    }

    /**
     * @param entityName
     *            the entityName to set
     */
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    /**
     * @return the requestor
     */
    public String getRequestor() {
        return requestor;
    }

    /**
     * @param requestor
     *            the requestor to set
     */
    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    /**
     * @return the searchCriteriaList
     */
    public List<SearchCriteriaList> getSearchCriteriaList() {
        return searchCriteriaList;
    }

    /**
     * @param searchCriteriaList
     *            the searchCriteriaList to set
     */
    public void setSearchCriteriaList(
            List<SearchCriteriaList> searchCriteriaList) {
        this.searchCriteriaList = searchCriteriaList;
    }

    /**
     * @return the searchRule
     */
    public String getSearchRule() {
        return searchRule;
    }

    /**
     * @param searchRule
     *            the searchRule to set
     */
    public void setSearchRule(String searchRule) {
        this.searchRule = searchRule;
    }

    /**
     * @return the sort
     */
    public List<Sort> getSort() {
        return sort;
    }

    /**
     * @param sort
     *            the sort to set
     */
    public void setSort(List<Sort> sort) {
        this.sort = sort;
    }

    /**
     * @return the pagination
     */
    public Pagination getPagination() {
        return pagination;
    }

    /**
     * @param pagination
     *            the pagination to set
     */
    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

}
