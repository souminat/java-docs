package com.ge.treasury.mybank.domain.mdm;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(using = MdmSearchCriteriaSerializer.class)
public class MdmSearchCriteria {

    private String entityName;
    private String requestor;
    private List<Sort> sort;
    private List<MdmSearchCriteriaRule> searchCriteriaList;
    private String responseAttributes;
    private Integer pageStart;
    private Integer pageIncrement;

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getRequestor() {
        return requestor;
    }

    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    public List<Sort> getSort() {
        return sort;
    }

    public void setSort(List<Sort> sort) {
        this.sort = sort;
    }

    public List<MdmSearchCriteriaRule> getSearchCriteriaList() {
        return searchCriteriaList;
    }

    public void setSearchCriteriaList(
            List<MdmSearchCriteriaRule> searchCriteriaList) {
        this.searchCriteriaList = searchCriteriaList;
    }

    public String getResponseAttributes() {
        return responseAttributes;
    }

    public void setResponseAttributes(String responseAttributes) {
        this.responseAttributes = responseAttributes;
    }

    public Integer getPageStart() {
        return pageStart;
    }

    public void setPageStart(Integer pageStart) {
        this.pageStart = pageStart;
    }

    public Integer getPageIncrement() {
        return pageIncrement;
    }

    public void setPageIncrement(Integer pageIncrement) {
        this.pageIncrement = pageIncrement;
    }
}
