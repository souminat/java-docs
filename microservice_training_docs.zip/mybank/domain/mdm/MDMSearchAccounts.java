package com.ge.treasury.mybank.domain.mdm;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MDMSearchAccounts implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -7758510594095535633L;
    
    private String subBusName;
    private String bussName;
    private String accountStatus;
    private String tCode;
    private String bankId;
    private String iban;
    private String country;
    private String currency;
    private String leCode;
    private String routeCode;
    private String accountType;
    private String acctNumber;
    private Integer limit;
    private Integer start;
    private boolean forTCode;
    private String accountPurpose;
    private String companyCode;
    private String meCode;
    private boolean isCore;
    private String buCode;
    
    public String getSubBusName() {
        return subBusName;
    }
    public void setSubBusName(String subBusName) {
        this.subBusName = subBusName;
    }
    public String getBussName() {
        return bussName;
    }
    public void setBussName(String bussName) {
        this.bussName = bussName;
    }
    public String getAccountStatus() {
        return accountStatus;
    }
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }
    public String gettCode() {
        return tCode;
    }
    public void settCode(String tCode) {
        this.tCode = tCode;
    }
    public String getBankId() {
        return bankId;
    }
    public void setBankId(String bankId) {
        this.bankId = bankId;
    }
    public String getIban() {
        return iban;
    }
    public void setIban(String iban) {
        this.iban = iban;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getLeCode() {
        return leCode;
    }
    public void setLeCode(String leCode) {
        this.leCode = leCode;
    }
    public String getRouteCode() {
        return routeCode;
    }
    public void setRouteCode(String routeCode) {
        this.routeCode = routeCode;
    }
    public String getAccountType() {
        return accountType;
    }
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    public String getAcctNumber() {
        return acctNumber;
    }
    public void setAcctNumber(String acctNumber) {
        this.acctNumber = acctNumber;
    }
    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }
    public Integer getStart() {
        return start;
    }
    public void setStart(Integer start) {
        this.start = start;
    }
    public boolean isForTCode() {
        return forTCode;
    }
    public void setForTCode(boolean forTCode) {
        this.forTCode = forTCode;
    }
    public String getAccountPurpose() {
        return accountPurpose;
    }
    public void setAccountPurpose(String accountPurpose) {
        this.accountPurpose = accountPurpose;
    }
    public String getCompanyCode() {
        return companyCode;
    }
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
    public String getMeCode() {
        return meCode;
    }
    public void setMeCode(String meCode) {
        this.meCode = meCode;
    }
	public boolean getIsCore() {
		return isCore;
	}
	public void setIsCore(boolean isCore) {
		this.isCore = isCore;
	}
	
	public void setBuCode(String buCode) {
        this.buCode = buCode;
    }
	
	public String getBuCode() {
        return buCode;
    }
}
