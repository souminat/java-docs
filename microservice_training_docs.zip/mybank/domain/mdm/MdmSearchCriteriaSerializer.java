package com.ge.treasury.mybank.domain.mdm;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

public class MdmSearchCriteriaSerializer extends
        JsonSerializer<MdmSearchCriteria> {

    @Override
    public void serialize(MdmSearchCriteria value, JsonGenerator jgen,
            SerializerProvider provider) throws IOException,
            JsonProcessingException {
        StringBuilder sBuffer = new StringBuilder();
        AtomicInteger aInt = new AtomicInteger();
        jgen.writeStartObject();
        if (value.getEntityName() != null) {
            jgen.writeStringField("entityName", value.getEntityName());
        }
        if (value.getRequestor() != null) {
            jgen.writeStringField("requestor", value.getRequestor());
        }
        if (value.getSearchCriteriaList() != null) {
            jgen.writeArrayFieldStart("searchCriteriaList");
            for (MdmSearchCriteriaRule rule : value.getSearchCriteriaList()) {
                String ruleName = "S" + aInt.getAndIncrement();
                if (sBuffer.length() == 0) {
                    sBuffer.append(ruleName);
                } else {
                    sBuffer.append(" AND " + ruleName);
                }
                jgen.writeStartObject();
                jgen.writeStringField("setName", ruleName);
                jgen.writeStringField("attribute", rule.getAttribute());
                jgen.writeStringField("operator", rule.getOperator());
                if ("IN".equalsIgnoreCase(rule.getOperator())) {
                    jgen.writeArrayFieldStart("valueList");
                    for (String ruleValue : rule.getValue()) {
                        jgen.writeString(ruleValue);
                    }
                    jgen.writeEndArray();
                } else {
                    jgen.writeStringField("value", rule.getValue().get(0));
                }
                jgen.writeEndObject();
            }
            jgen.writeEndArray();
        }
        if (value.getSort() != null) {
            jgen.writeArrayFieldStart("sort");
            for (Sort sort : value.getSort()) {
                jgen.writeObject(sort);
            }
            jgen.writeEndArray();
        }
        if (sBuffer.length() != 0) {
            jgen.writeStringField("searchRule", sBuffer.toString());
        }
        if (value.getPageStart() != null && value.getPageIncrement() != null) {
            jgen.writeFieldName("pagination");
            jgen.writeStartObject();
            jgen.writeNumberField("start", value.getPageStart());
            jgen.writeNumberField("increment", value.getPageIncrement());
            jgen.writeEndObject();
        }
        if (value.getResponseAttributes() != null) {
            jgen.writeFieldName("responseObjects");
            jgen.writeStartObject();
            jgen.writeStringField("responseList", value.getResponseAttributes());
            jgen.writeEndObject();
        }
        jgen.writeEndObject();
    }

}
