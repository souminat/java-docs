/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

/**
 * @author MyBank Dev Team
 * 
 */
public class Sort {

    private String attribute;
    private String order;

    /**
	 * 
	 */
    public Sort() {
        super();
    }

    /**
     * @param attribute
     * @param order
     */
    public Sort(String attribute, String order) {
        super();
        this.attribute = attribute;
        this.order = order;
    }

    /**
     * @return the attribute
     */
    public String getAttribute() {
        return attribute;
    }

    /**
     * @param attribute
     *            the attribute to set
     */
    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }

    /**
     * @param order
     *            the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }

}
