/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

/**
 * @author MyBank Dev Team
 * 
 */
public class MDMBaseAccount {

    private static final long serialVersionUID = -5794189275505330648L;

    private String entityName;
    private String requestor;
    private MDMAccount bankAccountInformation;

    public MDMBaseAccount() {
        super();
    }

    /**
     * @return the entityName
     */
    public String getEntityName() {
        return entityName;
    }

    /**
     * @param entityName
     *            the entityName to set
     */
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    /**
     * @return the requestor
     */
    public String getRequestor() {
        return requestor;
    }

    /**
     * @param requestor
     *            the requestor to set
     */
    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    /**
     * @return the bankAccountInformation
     */
    public MDMAccount getBankAccountInformation() {
        return bankAccountInformation;
    }

    /**
     * @param bankAccountInformation2
     *            the bankAccountInformation to set
     */
    public void setBankAccountInformation(MDMAccount bankAccountInformation) {
        this.bankAccountInformation = bankAccountInformation;
    }

}
