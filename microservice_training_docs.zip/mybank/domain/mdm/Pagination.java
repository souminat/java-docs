/**
 * 
 */
package com.ge.treasury.mybank.domain.mdm;

/**
 * @author MyBank Dev Team
 * 
 */
public class Pagination {

    private int start;
    private int increment;

    /**
	 * 
	 */
    public Pagination() {
        super();
    }

    /**
     * @param start
     * @param increment
     */
    public Pagination(int start, int increment) {
        super();
        this.start = start;
        this.increment = increment;
    }

    /**
     * @return the start
     */
    public int getStart() {
        return start;
    }

    /**
     * @param start
     *            the start to set
     */
    public void setStart(int start) {
        this.start = start;
    }

    /**
     * @return the increment
     */
    public int getIncrement() {
        return increment;
    }

    /**
     * @param increment
     *            the increment to set
     */
    public void setIncrement(int increment) {
        this.increment = increment;
    }

}
