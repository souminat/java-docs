package com.ge.treasury.mybank.domain.corems;

import java.util.Date;
import java.util.List;

public class Audit {

    private String userSSO;
    private String userRole;
    private String domain;
    private String domainKey;
    private String entity;
    private String auditJSON;
    private List<AuditAttributes> JSONAudit;
    private Date tms;
    private String tmsString;

    /**
     * @return the userSSO
     */
    public String getUserSSO() {
        return userSSO;
    }

    public String getTmsString() {
		return tmsString;
	}

	public void setTmsString(String tmsString) {
		this.tmsString = tmsString;
	}

	/**
     * @param userSSO
     *            the userSSO to set
     */
    public void setUserSSO(String userSSO) {
        this.userSSO = userSSO;
    }

    /**
     * @return the domain
     */
    public String getDomain() {
        return domain;
    }

    /**
     * @param domain
     *            the domain to set
     */
    public void setDomain(String domain) {
        this.domain = domain;
    }

    /**
     * @return the domainKey
     */
    public String getDomainKey() {
        return domainKey;
    }

    /**
     * @param domainKey
     *            the domainKey to set
     */
    public void setDomainKey(String domainKey) {
        this.domainKey = domainKey;
    }

    /**
     * @return the entity
     */
    public String getEntity() {
        return entity;
    }

    /**
     * @param entity
     *            the entity to set
     */
    public void setEntity(String entity) {
        this.entity = entity;
    }

    /**
     * @return the jSONAudit
     */
    public List<AuditAttributes> getJSONAudit() {
        return JSONAudit;
    }

    /**
     * @param jSONAudit
     *            the jSONAudit to set
     */
    public void setJSONAudit(List<AuditAttributes> jSONAudit) {
        JSONAudit = jSONAudit;
    }

    /**
     * @return the tms
     */
    public Date getTms() {
        return tms;
    }

    /**
     * @param tms
     *            the tms to set
     */
    public void setTms(Date tms) {
        this.tms = tms;
    }

    /**
     * @return the userRole
     */
    public String getUserRole() {
        return userRole;
    }

    /**
     * @param userRole
     *            the userRole to set
     */
    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    /**
     * @return the auditJSON
     */
    public String getAuditJSON() {
        return auditJSON;
    }

    /**
     * @param auditJSON
     *            the auditJSON to set
     */
    public void setAuditJSON(String auditJSON) {
        this.auditJSON = auditJSON;
    }

}
