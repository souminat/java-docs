package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.validator.constraints.NotBlank;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MyFundingRequest implements Serializable {

    private static final long serialVersionUID = 5722205551509214454L;

    @NotBlank(message = "myBankRequestId is Mandatory")
    private String myBankRequestId;

    @NotBlank(message = "leId is Mandatory")
    private String leId;

    @NotBlank(message = "leName is Mandatory")
    private String leName;

    @NotBlank(message = "Country is Mandatory")
    private String leCountry;

    @NotBlank(message = "leRegulatedEntity is Mandatory")
    private String leRegulatedEntity;

    @NotBlank(message = "leBusinessType is Mandatory")
    private String leBusinessType;

    private String leCompanyCode; //Optional
    
    private String leBusinessUnit; //Optional
    
    private String tCode; //Optional
    
    private String tCodeCurrency; //Optional
    
    @NotBlank(message = "comments is Mandatory")
    private String comments;
    
    private List<MyFundingHeaderLE> headerLEIds;
    
    private String myBankRequester;
    
    private String cashPoolCategory;
    
    public MyFundingRequest() {
        // No arg constructor
    }
    
    
    /**
     *  public MyFundingRequest(String myBankRequestId, String leId, String leName, String leCountry,
            String leRegulatedEntity, String leBusinessType, String leCompanyCode, String leBusinessUnit, String tCode,
            String tCodeCurrency, String comments, List<MyFundingHeaderLE> headerLEIds, String myBankRequester,String cashPoolCategory) {
        super();
        this.myBankRequestId = myBankRequestId;
        this.leId = leId;
        this.leName = leName;
        this.leCountry = leCountry;
        this.leRegulatedEntity = leRegulatedEntity;
        this.leBusinessType = leBusinessType;
        this.leCompanyCode = leCompanyCode;
        this.leBusinessUnit = leBusinessUnit;
        this.tCode = tCode;
        this.tCodeCurrency = tCodeCurrency;
        this.comments = comments;
        this.headerLEIds = headerLEIds;
        this.myBankRequester = myBankRequester;
        this.cashPoolCategory=cashPoolCategory;
       
    }

     *
     */
   
    public String getMyBankRequestId() {
        return myBankRequestId;
    }

    public void setMyBankRequestId(String myBankRequestId) {
        this.myBankRequestId = myBankRequestId;
    }

    public String getLeId() {
        return leId;
    }

    public void setLeId(String leId) {
        this.leId = leId;
    }

    public String getLeName() {
        return leName;
    }

    public void setLeName(String leName) {
        this.leName = leName;
    }

    public String getLeCountry() {
        return leCountry;
    }

    public void setLeCountry(String leCountry) {
        this.leCountry = leCountry;
    }

    public String getLeRegulatedEntity() {
        return leRegulatedEntity;
    }

    public void setLeRegulatedEntity(String leRegulatedEntity) {
        this.leRegulatedEntity = leRegulatedEntity;
    }

    public String getLeBusinessType() {
        return leBusinessType;
    }

    public void setLeBusinessType(String leBusinessType) {
        this.leBusinessType = leBusinessType;
    }

    public String getLeCompanyCode() {
        return leCompanyCode;
    }

    public void setLeCompanyCode(String leCompanyCode) {
        this.leCompanyCode = leCompanyCode;
    }

    public String getLeBusinessUnit() {
        return leBusinessUnit;
    }

    public void setLeBusinessUnit(String leBusinessUnit) {
        this.leBusinessUnit = leBusinessUnit;
    }

    public String gettCode() {
        return tCode;
    }

    public void settCode(String tCode) {
        this.tCode = tCode;
    }

    public String gettCodeCurrency() {
        return tCodeCurrency;
    }

    public void settCodeCurrency(String tCodeCurrency) {
        this.tCodeCurrency = tCodeCurrency;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<MyFundingHeaderLE> getHeaderLEIds() {
        return headerLEIds;
    }

    public void setHeaderLEIds(List<MyFundingHeaderLE> headerLEIds) {
        this.headerLEIds = headerLEIds;
    }

    public String getMyBankRequester() {
        return myBankRequester;
    }

    public void setMyBankRequester(String myBankRequester) {
        this.myBankRequester = myBankRequester;
    }
    

    public String getCashPoolCategory() {
		return cashPoolCategory;
	}

	public void setCashPoolCategory(String cashPoolCategory) {
		this.cashPoolCategory = cashPoolCategory;
	}
	

	
	@Override
    public String toString() {
        return "MyFundingRequest [myBankRequestId=" + myBankRequestId + ", leId=" + leId + ", leName=" + leName
                + ", leCountry=" + leCountry + ", leRegulatedEntity=" + leRegulatedEntity + ", leBusinessType="
                + leBusinessType + ", leCompanyCode=" + leCompanyCode + ", leBusinessUnit=" + leBusinessUnit
                + ", tCode=" + tCode + ", tCodeCurrency=" + tCodeCurrency + ", comments=" + comments + ", headerLEIds="
                + headerLEIds + ", myBankRequester=" + myBankRequester + ", getMyBankRequestId()="
                + getMyBankRequestId() + ", getLeId()=" + getLeId() + ", getLeName()=" + getLeName()
                + ", getLeCountry()=" + getLeCountry() + ", getLeRegulatedEntity()=" + getLeRegulatedEntity()
                + ", getLeBusinessType()=" + getLeBusinessType() + ", getLeCompanyCode()=" + getLeCompanyCode()
                + ", getLeBusinessUnit()=" + getLeBusinessUnit() + ", gettCode()=" + gettCode()
                + ", gettCodeCurrency()=" + gettCodeCurrency() + ", getComments()=" + getComments()
                + ", getHeaderLEIds()=" + getHeaderLEIds() + ", getMyBankRequester()=" + getMyBankRequester()
                + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
                + "]";
    }

}
