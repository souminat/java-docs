package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MyFundingResponse implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -359643956900044316L;
    private String message;
    private String status;
    private MyFundingDetail dealDetail;
    private CashPoolProcess cashPoolProcess;

    public MyFundingResponse() {
        // No arg constructor
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public MyFundingDetail getDealDetail() {
        return dealDetail;
    }

    public void setDealDetail(MyFundingDetail dealDetail) {
        this.dealDetail = dealDetail;
    }

    public CashPoolProcess getCashPoolProcess() {
        return cashPoolProcess;
    }

    public void setCashPoolProcess(CashPoolProcess cashPoolProcess) {
        this.cashPoolProcess = cashPoolProcess;
    }

    @Override
    public String toString() {
        return "MyFundingResponse [message=" + message + ", status=" + status + ", dealDetail=" + dealDetail + "]";
    }

}
