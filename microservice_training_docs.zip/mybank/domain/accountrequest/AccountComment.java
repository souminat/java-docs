package com.ge.treasury.mybank.domain.accountrequest;

/**
 * @author MyBank Dev Team
 * 
 */
public class AccountComment extends BaseDomainObject {
    /**
	 * 
	 */
    private static final long serialVersionUID = 300581987150815649L;

    /*
     * COMMENT_ID, COMMENT_TYPE, SSO_ID, ROLE, ACCOUNT_REQUEST_ID, COMMENTS,
     * CREATE_TIMESTAMP, CREATE_USER
     */
    private Long commentId;
    private String commentType;
    private String ssoId;
    private String role;
    private Long acctRequestId;
    private String comments;
    private String createUserName;

    /**
     * @param commentType
     * @param ssoId
     * @param role
     * @param acctRequestId
     * @param comments
     */
    public AccountComment(String commentType, String ssoId, String role,
            Long acctRequestId, String comments) {
        super();
        this.commentType = commentType;
        this.ssoId = ssoId;
        this.role = role;
        this.acctRequestId = acctRequestId;
        this.comments = comments;
    }

    public AccountComment() {
    	//No arg constructor
    }

    /**
     * @return the commentId
     */
    public Long getCommentId() {
        return commentId;
    }

    /**
     * @param commentId
     *            the commentId to set
     */
    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    /**
     * @return the commentType
     */
    public String getCommentType() {
        return commentType;
    }

    /**
     * @param commentType
     *            the commentType to set
     */
    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    /**
     * @return the ssoId
     */
    public String getSsoId() {
        return ssoId;
    }

    /**
     * @param ssoId
     *            the ssoId to set
     */
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    /**
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * @param role
     *            the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * @return the acctRequestId
     */
    public Long getAcctRequestId() {
        return acctRequestId;
    }

    /**
     * @param acctRequestId
     *            the acctRequestId to set
     */
    public void setAcctRequestId(Long acctRequestId) {
        this.acctRequestId = acctRequestId;
    }

    /**
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @param comments
     *            the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @return the createUserName
     */
    public String getCreateUserName() {
        return createUserName;
    }

    /**
     * @param createUserName
     *            the createUserName to set
     */
    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

}
