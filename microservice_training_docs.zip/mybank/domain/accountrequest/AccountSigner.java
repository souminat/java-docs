/**
 * 
 */
package com.ge.treasury.mybank.domain.accountrequest;

import java.math.BigInteger;
import java.util.Date;

import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author MyBank Dev Team
 * 
 */
public class AccountSigner extends BaseDomainObject {

    /*
     * DB FIELDS SIGNER_ID, SSO_ID, SIGNER_TYPE_CODE, SIGNER_NAME,
     * SIGNER_START_DATE, SIGNER_END_DATE, ACCOUNT_REQUEST_ID, CREATE_TIMESTAMP,
     * CREATE_USER, LAST_UPDATE_TIMESTAMP, LAST_UPDATE_USER, DOCUMENT_ID,
     * IS_ACTIVE
     */
    /**
	 * 
	 */
    private static final long serialVersionUID = -1591384172103505728L;

    private Long signerId;
    private String ssoId;
    private String signerType;
    private String signerName;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL,
    using=com.ge.treasury.mybank.util.business.JsonDateSerializer.class)
    @JsonDeserialize(using=com.ge.treasury.mybank.util.business.JsonDateDeserializer.class)
    private Date signerStartDate;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL,
    using=com.ge.treasury.mybank.util.business.JsonDateSerializer.class)
    @JsonDeserialize(using=com.ge.treasury.mybank.util.business.JsonDateDeserializer.class)
    private Date signerEndDate;
    private Long acctReqID;
    private String isActive;

    // SignatureCard fields
    private String docName;
    private BigInteger folderId;
    private BigInteger fileId;
    private String docURL;

    /**
     * @param ssoId
     * @param signerType
     * @param signerName
     * @param signerStartDate
     * @param signerEndDate
     * @param acctReqID
     * @param signatureCard
     */
    public AccountSigner(String ssoId, String signerType, String signerName,
            Date signerStartDate, Date signerEndDate, Long acctReqID,
            String isActive, String docName,
            BigInteger folderId, BigInteger fileId, String docURL) {
        super();
        this.ssoId = ssoId;
        this.signerType = signerType;
        this.signerName = signerName;
        this.signerStartDate = signerStartDate;
        this.signerEndDate = signerEndDate;
        this.acctReqID = acctReqID;
        this.isActive = isActive;
        this.docName = docName;
        this.folderId = folderId;
        this.fileId = fileId;
        this.docURL = docURL;
    }

    public AccountSigner(Long signerId, String ssoId, String signerType,
			String signerName, Date signerStartDate, Date signerEndDate,
			Long acctReqID, String isActive, String docName,
			BigInteger folderId, BigInteger fileId, String docURL) {
		super();
		this.signerId = signerId;
		this.ssoId = ssoId;
		this.signerType = signerType;
		this.signerName = signerName;
		this.signerStartDate = signerStartDate;
		this.signerEndDate = signerEndDate;
		this.acctReqID = acctReqID;
		this.isActive = isActive;
		this.docName = docName;
		this.folderId = folderId;
		this.fileId = fileId;
		this.docURL = docURL;
	}

	public AccountSigner() {
		//No arg constructor
    }

    /**
     * @return the signerId
     */
    public Long getSignerId() {
        return signerId;
    }

    /**
     * @param signerId
     *            the signerId to set
     */
    public void setSignerId(Long signerId) {
        this.signerId = signerId;
    }

    /**
     * @return the ssoId
     */
    public String getSsoId() {
        return ssoId;
    }

    /**
     * @param ssoId
     *            the ssoId to set
     */
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    /**
     * @return the signerType
     */
    public String getSignerType() {
        return signerType;
    }

    /**
     * @param signerType
     *            the signerType to set
     */
    public void setSignerType(String signerType) {
        this.signerType = signerType;
    }

    /**
     * @return the signerName
     */
    public String getSignerName() {
        return signerName;
    }

    /**
     * @param signerName
     *            the signerName to set
     */
    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    /**
     * @return the signerStartDate
     */
    public Date getSignerStartDate() {
        return signerStartDate;
    }

    /**
     * @param signerStartDate
     *            the signerStartDate to set
     */
    public void setSignerStartDate(Date signerStartDate) {
        this.signerStartDate = signerStartDate;
    }

    /**
     * @return the signerEndDate
     */
    public Date getSignerEndDate() {
        return signerEndDate;
    }

    /**
     * @param signerEndDate
     *            the signerEndDate to set
     */
    public void setSignerEndDate(Date signerEndDate) {
        this.signerEndDate = signerEndDate;
    }

    /**
     * @return the acctReqID
     */
    public Long getAcctReqID() {
        return acctReqID;
    }

    /**
     * @param acctReqID
     *            the acctReqID to set
     */
    public void setAcctReqID(Long acctReqID) {
        this.acctReqID = acctReqID;
    }

    /**
     * @return the isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     * @param isActive
     *            the isActive to set
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    /**
     * @return the docName
     */
    public String getDocName() {
        return docName;
    }

    /**
     * @param docName
     *            the docName to set
     */
    public void setDocName(String docName) {
        this.docName = docName;
    }

    /**
     * @return the folderId
     */
    public BigInteger getFolderId() {
        return folderId;
    }

    /**
     * @param folderId
     *            the folderId to set
     */
    public void setFolderId(BigInteger folderId) {
        this.folderId = folderId;
    }

    /**
     * @return the fileId
     */
    public BigInteger getFileId() {
        return fileId;
    }

    /**
     * @param fileId
     *            the fileId to set
     */
    public void setFileId(BigInteger fileId) {
        this.fileId = fileId;
    }

    /**
     * @return the docURL
     */
    public String getDocURL() {
        return docURL;
    }

    /**
     * @param docURL
     *            the docURL to set
     */
    public void setDocURL(String docURL) {
        this.docURL = docURL;
    }

    
}
