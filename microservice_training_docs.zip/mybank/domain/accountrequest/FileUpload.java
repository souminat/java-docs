package com.ge.treasury.mybank.domain.accountrequest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.treasury.mybank.domain.FileUploadActivity;

public class FileUpload extends BaseDomainObject {

	private static final long serialVersionUID = 1646408737164086871L;
	private Long fileUpldId;
	private String upldStatusCode;
	private String upldTypeCode;
	private Long errorRecordCount;
	private Long totalCount;
	private String fileName;
	private String upldUserSSO;
	private String checksumOfFile;
	private String uploadedFile;
	private String uploadedFileJString;
	private String comments;
	@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL, using = com.ge.treasury.mybank.util.business.JsonDateTimeSerializer.class)
	private Date lastUpdated;

	private Integer recordCount;
	private boolean isValidAccess;
	private String upldStatusDisplayName;
	private transient List<BulkUploadError> bulkUploadError = new ArrayList<BulkUploadError>();
	private List<FileUploadActivity> activities = new ArrayList<FileUploadActivity>();
    private String successFile;
    private String errorFile;
    private boolean errorFileFlag;
    private boolean successFileFlag;
    private Long acceptedCount;
    private Long rejectedCount;
	public FileUpload(Long fileUpldId) {
		super();
		this.fileUpldId = fileUpldId;
	}

	public FileUpload() {
		super();
	}

	/**
	 * @return the fileUpldId
	 */
	public Long getFileUpldId() {
		return fileUpldId;
	}

	/**
	 * @param fileUpldId
	 *            the fileUpldId to set
	 */
	public void setFileUpldId(Long fileUpldId) {
		this.fileUpldId = fileUpldId;
	}

	/**
	 * @return the upldStatusCode
	 */
	public String getUpldStatusCode() {
		return upldStatusCode;
	}

	/**
	 * @param upldStatusCode
	 *            the upldStatusCode to set
	 */
	public void setUpldStatusCode(String upldStatusCode) {
		this.upldStatusCode = upldStatusCode;
	}

	/**
	 * @return the upldTypeCode
	 */
	public String getUpldTypeCode() {
		return upldTypeCode;
	}

	/**
	 * @param upldTypeCode
	 *            the upldTypeCode to set
	 */
	public void setUpldTypeCode(String upldTypeCode) {
		this.upldTypeCode = upldTypeCode;
	}

	/**
	 * @return the errorRecordCount
	 */
	public Long getErrorRecordCount() {
		return errorRecordCount;
	}

	/**
	 * @param errorRecordCount
	 *            the errorRecordCount to set
	 */
	public void setErrorRecordCount(Long errorRecordCount) {
		this.errorRecordCount = errorRecordCount;
	}

	/**
	 * @return the totalCount
	 */
	public Long getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount
	 *            the totalCount to set
	 */
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the upldUserSSO
	 */
	public String getUpldUserSSO() {
		return upldUserSSO;
	}

	/**
	 * @param upldUserSSO
	 *            the upldUserSSO to set
	 */
	public void setUpldUserSSO(String upldUserSSO) {
		this.upldUserSSO = upldUserSSO;
	}

	/**
	 * @return the checksumOfFile
	 */
	public String getChecksumOfFile() {
		return checksumOfFile;
	}

	/**
	 * @param checksumOfFile
	 *            the checksumOfFile to set
	 */
	public void setChecksumOfFile(String checksumOfFile) {
		this.checksumOfFile = checksumOfFile;
	}

	/**
	 * @return the uploadedFile
	 */
	public String getUploadedFile() {
		return uploadedFile;
	}

	/**
	 * @param uploadedFile
	 *            the uploadedFile to set
	 */
	public void setUploadedFile(String uploadedFile) {
		this.uploadedFile = uploadedFile;
	}

	/**
	 * @return the uploadedFileJString
	 */
	public String getUploadedFileJString() {
		return uploadedFileJString;
	}

	/**
	 * @param uploadedFileJString
	 *            the uploadedFileJString to set
	 */
	public void setUploadedFileJString(String uploadedFileJString) {
		this.uploadedFileJString = uploadedFileJString;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public List<BulkUploadError> getBulkUploadError() {
		return bulkUploadError;
	}

	public void setBulkUploadError(List<BulkUploadError> bulkUploadError) {
		this.bulkUploadError = bulkUploadError;
	}

	public boolean isValidAccess() {
		return isValidAccess;
	}

	public void setValidAccess(boolean isValidAccess) {
		this.isValidAccess = isValidAccess;
	}

	public String getUpldStatusDisplayName() {
		return upldStatusDisplayName;
	}

	public void setUpldStatusDisplayName(String upldStatusDisplayName) {
		this.upldStatusDisplayName = upldStatusDisplayName;
	}

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public List<FileUploadActivity> getActivities() {
		return activities;
	}

	public void setActivities(List<FileUploadActivity> activities) {
		this.activities = activities;
	}

	public String getSuccessFile() {
		return successFile;
	}

	public void setSuccessFile(String successFile) {
		this.successFile = successFile;
	}

	public String getErrorFile() {
		return errorFile;
	}

	public void setErrorFile(String errorFile) {
		this.errorFile = errorFile;
	}

	public boolean isErrorFileFlag() {
		return errorFileFlag;
	}

	public void setErrorFileFlag(boolean errorFileFlag) {
		this.errorFileFlag = errorFileFlag;
	}

	public boolean isSuccessFileFlag() {
		return successFileFlag;
	}

	public void setSuccessFileFlag(boolean successFileFlag) {
		this.successFileFlag = successFileFlag;
	}

	public Long getAcceptedCount() {
		return acceptedCount;
	}

	public void setAcceptedCount(Long acceptedCount) {
		this.acceptedCount = acceptedCount;
	}

	public Long getRejectedCount() {
		return rejectedCount;
	}

	public void setRejectedCount(Long rejectedCount) {
		this.rejectedCount = rejectedCount;
	}
	
  
}
