package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MyFundingDetail implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -1506721934758369693L;
    private String myBankRequestId;
    private String myFundingDealId;
    private String dealName;
    private String dealCreatedDate;

    public MyFundingDetail() {
        // No arg constructor
    }

    public String getMyBankRequestId() {
        return myBankRequestId;
    }

    public void setMyBankRequestId(String myBankRequestId) {
        this.myBankRequestId = myBankRequestId;
    }

    public String getMyFundingDealId() {
        return myFundingDealId;
    }

    public void setMyFundingDealId(String myFundingDealId) {
        this.myFundingDealId = myFundingDealId;
    }

    public String getDealName() {
        return dealName;
    }

    public void setDealName(String dealName) {
        this.dealName = dealName;
    }

    public String getDealCreatedDate() {
        return dealCreatedDate;
    }

    public void setDealCreatedDate(String dealCreatedDate) {
        this.dealCreatedDate = dealCreatedDate;
    }

    @Override
    public String toString() {
        return "MyFundingDetail [myBankRequestId=" + myBankRequestId + ", myFundingDealId=" + myFundingDealId
                + ", dealName=" + dealName + ", dealCreatedDate=" + dealCreatedDate + "]";
    }

}
