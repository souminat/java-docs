package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;

public class MyFundingHeaderLE implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 6113442306327812249L;

    private String leId;
    private String leName;

    public MyFundingHeaderLE() {
        // No arg constructor
    }

    public MyFundingHeaderLE(String leId, String leName) {
        super();
        this.leId = leId;
        this.leName = leName;
    }

    public String getLeId() {
        return leId;
    }

    public void setLeId(String leId) {
        this.leId = leId;
    }

    public String getLeName() {
        return leName;
    }

    public void setLeName(String leName) {
        this.leName = leName;
    }

    @Override
    public String toString() {
        return "MyFundingHeaderLE [leId=" + leId + ", leName=" + leName + "]";
    }

}
