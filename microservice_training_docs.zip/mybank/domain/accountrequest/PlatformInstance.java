package com.ge.treasury.mybank.domain.accountrequest;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class PlatformInstance extends BaseDomainObject {

    /**
     * 
     */
    private static final long serialVersionUID = 3114193616131335157L;
    
    private Long platformInstanceId;
    private String platformName;
    private String instance;
    private String bankId;
    private String status;
    
    public Long getPlatformInstanceId() {
        return platformInstanceId;
    }
    public void setPlatformInstanceId(Long platformInstanceId) {
        this.platformInstanceId = platformInstanceId;
    }
    public String getPlatformName() {
        return platformName;
    }
    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }
    public String getInstance() {
        return instance;
    }
    public void setInstance(String instance) {
        this.instance = instance;
    }
    public String getBankId() {
        return bankId;
    }
    public void setBankId(String bankId) {
        this.bankId = bankId;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    
}
