/**
 * Copyright GE
 */
package com.ge.treasury.mybank.domain.accountrequest;

import java.util.List;
import java.util.Map;

/**
 * @author MyBank Development Team
 * 
 */
public class AccountRequestValidator {

    private AccountRequest accRequest;
    private Map<Integer, List<AccountRequestValidation>> mapError;

    /**
     * @return the accRequest
     */
    public AccountRequest getAccRequest() {
        return accRequest;
    }

    /**
     * @param accRequest
     *            the accRequest to set
     */
    public void setAccRequest(AccountRequest accRequest) {
        this.accRequest = accRequest;
    }

    /**
     * @return the mapError
     */
    public Map<Integer, List<AccountRequestValidation>> getMapError() {
        return mapError;
    }

    /**
     * @param mapError
     *            the mapError to set
     */
    public void setMapError(
            Map<Integer, List<AccountRequestValidation>> mapError) {
        this.mapError = mapError;
    }

}
