/**
 * 
 */
package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Contains attributes base for all the DB attributes in the package
 * 
 * @author MyBank Dev Team
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class BaseDomainObject implements Serializable {

    private static final long serialVersionUID = -1512474379787198L;

    private String lastUpdateUser;
    private Date lastUpdateDate;
    @JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL, using = com.ge.treasury.mybank.util.business.JsonDateSerializer.class)
    private Date createDate;
    private String createUser;

    /**
     * @return the lastUpdateUser
     */
    public String getLastUpdateUser() {
        return lastUpdateUser;
    }

    /**
     * @param lastUpdateUser
     *            the lastUpdateUser to set
     */
    public void setLastUpdateUser(String lastUpdateUser) {
        this.lastUpdateUser = lastUpdateUser;
    }

    /**
     * @return the lastUpdateDate
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * @param lastUpdateDate
     *            the lastUpdateDate to set
     */
    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    /**
     * @return the createDate
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate
     *            the createDate to set
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * @return the createUser
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * @param createUser
     *            the createUser to set
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

}
