/**
 * 
 */

package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;
import java.util.Date;

/**
 * @author MyBank Dev Team
 * 
 */
public class LastUpdatedDetails implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1615661846255156018L;

    private String lastUpdatedUser;
    private Date lastUpdatedDate;


    /**
     * @return the lastUpdatedUser
     */
    public String getLastUpdatedUser() {
        return lastUpdatedUser;
    }

    /**
     * @param lastUpdatedUser
     *            the lastUpdatedUser to set
     */
    public void setLastUpdatedUser(String lastUpdatedUser) {
        this.lastUpdatedUser = lastUpdatedUser;
    }

    /**
     * @return the lastUpdatedDate
     */
    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * @param lastUpdatedDate
     *            the lastUpdatedDate to set
     */
    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

}
