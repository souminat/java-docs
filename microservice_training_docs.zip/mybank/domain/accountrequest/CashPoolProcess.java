package com.ge.treasury.mybank.domain.accountrequest;

/**
 * @author MyBank Dev Team
 * 
 */
public class CashPoolProcess extends BaseDomainObject {
    
    /**
     * 
     */
    private static final long serialVersionUID = -1934676033161660351L;
    
    private Long cashPoolProcessId;
    private Long acctRequestId;
    private String tcodeParticipant;
    private String cashPoolProcessCode;
    private String cashPoolStatusCode;
    private Long myFundingDealId;
    private String cashPoolRequest;
    private String cashPoolHeaderLe;
    private String cashPoolComments;
    private String cashPoolCategory;
    private String cashPoolCurrency;
    private String cashPoolLeCode;
    
    
   
	public String getCashPoolCategory() {
		return cashPoolCategory;
	}
	public void setCashPoolCategory(String cashPoolCategory) {
		this.cashPoolCategory = cashPoolCategory;
	}
	public String getCashPoolCurrency() {
		return cashPoolCurrency;
	}
	public void setCashPoolCurrency(String cashPoolCurrency) {
		this.cashPoolCurrency = cashPoolCurrency;
	}
	public String getCashPoolLeCode() {
		return cashPoolLeCode;
	}
	public void setCashPoolLeCode(String cashPoolLeCode) {
		this.cashPoolLeCode = cashPoolLeCode;
	}
	public String getCashPoolComments() {
		return cashPoolComments;
	}
	public void setCashPoolComments(String cashPoolComments) {
		this.cashPoolComments = cashPoolComments;
	}
	
	public CashPoolProcess() {
		super();
	}
	public Long getCashPoolProcessId() {
        return cashPoolProcessId;
    }
    public void setCashPoolProcessId(Long cashPoolProcessId) {
        this.cashPoolProcessId = cashPoolProcessId;
    }
    public Long getAcctRequestId() {
        return acctRequestId;
    }
    public void setAcctRequestId(Long acctRequestId) {
        this.acctRequestId = acctRequestId;
    }
    public String getTcodeParticipant() {
        return tcodeParticipant;
    }
    public void setTcodeParticipant(String tcodeParticipant) {
        this.tcodeParticipant = tcodeParticipant;
    }
    public String getCashPoolProcessCode() {
        return cashPoolProcessCode;
    }
    public void setCashPoolProcessCode(String cashPoolProcessCode) {
        this.cashPoolProcessCode = cashPoolProcessCode;
    }
    public String getCashPoolStatusCode() {
        return cashPoolStatusCode;
    }
    public void setCashPoolStatusCode(String cashPoolStatusCode) {
        this.cashPoolStatusCode = cashPoolStatusCode;
    }
    public Long getMyFundingDealId() {
        return myFundingDealId;
    }
    public void setMyFundingDealId(Long myFundingDealId) {
        this.myFundingDealId = myFundingDealId;
    }
    public String getCashPoolRequest() {
        return cashPoolRequest;
    }
    public void setCashPoolRequest(String cashPoolRequest) {
        this.cashPoolRequest = cashPoolRequest;
    }
	public String getCashPoolHeaderLe() {
		return cashPoolHeaderLe;
	}
	public void setCashPoolHeaderLe(String cashPoolHeaderLe) {
		this.cashPoolHeaderLe = cashPoolHeaderLe;
	}
   
    
    

}
