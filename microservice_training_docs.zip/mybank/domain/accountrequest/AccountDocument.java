package com.ge.treasury.mybank.domain.accountrequest;

import java.math.BigInteger;

/**
 * @author MyBank Dev Team
 * 
 */
public class AccountDocument extends BaseDomainObject {

    /*
     * DOCUMENT_ID, DOCUMENT_TYPE_CODE, DOCUMENT_NAME, FOLDER_ID, FILE_ID,
     * DOC_URL, ACCOUNT_REQUEST_ID, CREATE_TIMESTAMP, CREATE_USER,
     * LAST_UPDATE_TIMESTAMP, LAST_UPDATE_USER
     */

    /**
	 * 
	 */
    private static final long serialVersionUID = -5254909085802111084L;
    private Long docId;
    private String docType;
    private String docName;
    private BigInteger folderId;
    private BigInteger fileId;
    private String docURL;
    private Long acctReqID;
    private String isActive;
    private String modifiedOn;

    /**
     * @param docType
     * @param docName
     * @param folderId
     * @param fileId
     * @param docURL
     * @param acctReqID
     */
    public AccountDocument(String docType, String docName, BigInteger folderId,
            BigInteger fileId, String docURL, Long acctReqID) {
        super();
        this.docType = docType;
        this.docName = docName;
        this.folderId = folderId;
        this.fileId = fileId;
        this.docURL = docURL;
        this.acctReqID = acctReqID;
    }

    /**
	 * 
	 */
    public AccountDocument() {
    	//No arg constructor
    }

    /**
     * @return the docId
     */
    public Long getDocId() {
        return docId;
    }

    /**
     * @param docId
     *            the docId to set
     */
    public void setDocId(Long docId) {
        this.docId = docId;
    }

    /**
     * @return the docName
     */
    public String getDocName() {
        return docName;
    }

    /**
     * @param docName
     *            the docName to set
     */
    public void setDocName(String docName) {
        this.docName = docName;
    }

    /**
     * @return the docType
     */
    public String getDocType() {
        return docType;
    }

    /**
     * @param docType
     *            the docType to set
     */
    public void setDocType(String docType) {
        this.docType = docType;
    }

    /**
     * @return the docURL
     */
    public String getDocURL() {
        return docURL;
    }

    /**
     * @param docURL
     *            the docURL to set
     */
    public void setDocURL(String docURL) {
        this.docURL = docURL;
    }

    /**
     * @return the folderId
     */
    public BigInteger getFolderId() {
        return folderId;
    }

    /**
     * @param folderId
     *            the folderId to set
     */
    public void setFolderId(BigInteger folderId) {
        this.folderId = folderId;
    }

    /**
     * @return the fileId
     */
    public BigInteger getFileId() {
        return fileId;
    }

    /**
     * @param fileId
     *            the fileId to set
     */
    public void setFileId(BigInteger fileId) {
        this.fileId = fileId;
    }

    /**
     * @return the acctReqID
     */
    public Long getAcctReqID() {
        return acctReqID;
    }

    /**
     * @param acctReqID
     *            the acctReqID to set
     */
    public void setAcctReqID(Long acctReqID) {
        this.acctReqID = acctReqID;
    }

    /**
     * @return the isActive
     */
    public String getIsActive() {
        return isActive;
    }

    /**
     * @param isActive
     *            the isActive to set
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((docName == null) ? 0 : docName.hashCode());
		result = prime * result + ((docType == null) ? 0 : docType.hashCode());
		result = prime * result + ((docURL == null) ? 0 : docURL.hashCode());
		result = prime * result + ((fileId == null) ? 0 : fileId.hashCode());
		result = prime * result + ((folderId == null) ? 0 : folderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountDocument other = (AccountDocument) obj;
		if (docName == null) {
			if (other.docName != null)
				return false;
		} else if (!docName.equals(other.docName))
			return false;
		if (docType == null) {
			if (other.docType != null)
				return false;
		} else if (!docType.equals(other.docType))
			return false;
		if (docURL == null) {
			if (other.docURL != null)
				return false;
		} else if (!docURL.equals(other.docURL))
			return false;
		if (fileId == null) {
			if (other.fileId != null)
				return false;
		} else if (!fileId.equals(other.fileId))
			return false;
		if (folderId == null) {
			if (other.folderId != null)
				return false;
		} else if (!folderId.equals(other.folderId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AccountDocument [docId=" + docId + ", docType=" + docType + ", docName=" + docName + ", folderId="
				+ folderId + ", fileId=" + fileId + ", docURL=" + docURL + ", acctReqID=" + acctReqID + ", isActive="
				+ isActive + ", modifiedOn=" + modifiedOn + "]";
	}
	
	
    
}
