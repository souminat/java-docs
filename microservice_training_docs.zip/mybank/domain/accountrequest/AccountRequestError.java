package com.ge.treasury.mybank.domain.accountrequest;

public class AccountRequestError extends BaseDomainObject {

    private static final long serialVersionUID = 1646408737164086871L;

    private Long tradeRequestErrorId;
    private Long tradeRequestId;
    private String errorMessage;

    public AccountRequestError() {
        super();
    }

    /**
     * @return the tradeRequestErrorId
     */
    public Long getTradeRequestErrorId() {
        return tradeRequestErrorId;
    }

    /**
     * @param tradeRequestErrorId
     *            the tradeRequestErrorId to set
     */
    public void setTradeRequestErrorId(Long tradeRequestErrorId) {
        this.tradeRequestErrorId = tradeRequestErrorId;
    }

    /**
     * @return the tradeRequestId
     */
    public Long getTradeRequestId() {
        return tradeRequestId;
    }

    /**
     * @param tradeRequestId
     *            the tradeRequestId to set
     */
    public void setTradeRequestId(Long tradeRequestId) {
        this.tradeRequestId = tradeRequestId;
    }

    /**
     * @return the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage
     *            the errorMessage to set
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
