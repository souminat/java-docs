/**
 * 
 */
package com.ge.treasury.mybank.domain.accountrequest;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.treasury.mybank.util.business.constants.ValidationConstants;

/**
 * @author MyBank Dev Team
 * 
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AccountRequest extends BaseDomainObject implements ValidationConstants {

    /*
     * DB Columns names ACCOUNT_REQUEST_ID, MDM_BUSINESS_ACCT_GRP, MDM_LE_CODE,
     * MDM_LE_NAME, MDM_LE_VERSION, ACCOUNT_REQUEST_TYPE_CODE,
     * ACCOUNT_REQUEST_STATUS_CODE, MDM_ACCOUNT_COUNTRY, MDM_ACCOUNT_CURRENCY,
     * MDM_ACCOUNT_BANK_NAME, MDM_ACCOUNT_BRANCH_NAME, ACCOUNT_NUMBER, IBAN,
     * IS_ACCOUNT_CASHPOOL, T_CODE, CREATE_TIMESTAMP, CREATE_USER,
     * LAST_UPDATE_TIMESTAMP, LAST_UPDATE_USER, ACCOUNT_TITLE, MDM_ACCOUNT_TYPE,
     * MDM_SUB_BUSINESS_NAME, MDM_LE_ID, MDM_BANK_ID, MDM_CASHPOOL_TCODE,
     * MDM_CASHPOOL_LE_CODE, MDM_COMPONENT_CODE, MDM_TCODE_ALTERNATE
     */
    private static final long serialVersionUID = -5794189275505330648L;

    private Long acctReqID;
    private String requestType;
    private String accountType;
    private String accountTitle;
    private String requestStatus;
    private String acctNumber;
    private String projectName;
    private String iban;
    private String tCode;

    // MDM data set
    private String subBusName;
    private String leCode;

    private String leName;
    private String leVersion;
    private String currency;
    private String country;
    private String bankName;
    private String componentCode;
    private String mdmTcodeAlternate;

    private String isBankAcctReserved;

    private String buCode;
    private String bussName;
    private String bankId;
    private String cashpoolTCode;
    private String cashpoolLeCode;
    private String routeCode;
    private String routeCodeType;
    private String countryName;
    private String currencyName;
    private String branchMDMID;
    private String subtypeCode;

    private String assignedToSso;
    private String assignedToName;

    private String cashPoolRejectReason;
    private String cashPoolProcessCode;

    private List<CashPoolProcess> cashPoolProcesses;

    // Flags
    private List<AccountFlag> flags;

    // Signers
    private List<AccountSigner> signers;

    // Documents
    private List<AccountDocument> documents;

    // Comments
    private List<AccountComment> comments;

    // Other fields
    private Integer recordCount;
    private String multipleUserValidationCheck;

    private Long stgId;
    private String meCode;
    private String companyCode;
    private String accountPurpose;
    private String bankClassification;

    private String acctOpenDate;
    private String acctClosedDate;
    private String channelResponse;
    private String cashPoolCategory;
    private String cashPoolHeaderLeCode;
    private String coCodeRejectReason;
    private PlatformInstance platformInstance;
    
    
    /**
     *  public AccountRequest(Long acctReqID, String requestType, String accountType, String accountTitle,
            String requestStatus, String acctNumber, String iban, String tCode, String subBusName, String leCode,
            String leName, String leVersion, String currency, String country, String bankName, String componentCode,
            String isBankAcctReserved, String bussName, String bankId, String cashpoolTCode, String cashpoolLeCode,
            String routeCode, String routeCodeType, String countryName, String currencyName, String branchMDMID,
            List<AccountFlag> flags, List<AccountSigner> signers, List<AccountDocument> documents,
            List<AccountComment> comments) {
        super();
        this.acctReqID = acctReqID;
        this.requestType = requestType;
        this.accountType = accountType;
        this.accountTitle = accountTitle;
        this.requestStatus = requestStatus;
        this.acctNumber = acctNumber;
        this.iban = iban;
        this.tCode = tCode;
        this.subBusName = subBusName;
        this.leCode = leCode;
        this.leName = leName;
        this.leVersion = leVersion;
        this.currency = currency;
        this.country = country;
        this.bankName = bankName;
        this.componentCode = componentCode;
        this.isBankAcctReserved = isBankAcctReserved;
        this.bussName = bussName;
        this.bankId = bankId;
        this.cashpoolTCode = cashpoolTCode;
        this.cashpoolLeCode = cashpoolLeCode;
        this.routeCode = routeCode;
        this.routeCodeType = routeCodeType;
        this.countryName = countryName;
        this.currencyName = currencyName;
        this.branchMDMID = branchMDMID;
        this.flags = flags;
        this.signers = signers;
        this.documents = documents;
        this.comments = comments;
    }
     *
     */

    /**
     * @return the acctReqID
     */
    public Long getAcctReqID() {
        return acctReqID;
    }

    /**
     * Don't actually use. For UX quick fix
     * 
     * @deprecated
     * @param acctStatus
     */
    @JsonProperty("accountStatus")
    @Deprecated
    public void setAccountStatus(String acctStatus) {
        this.requestStatus = acctStatus;
    }

    /**
     * Don't actually use, for UX quick fix
     * 
     * @deprecated
     * @return
     */
    @JsonProperty("accountStatus")
    @Deprecated
    public String getAccountStatus() {
        return requestStatus;
    }

    /**
     * @param acctReqID
     *            the acctReqID to set
     */
    public void setAcctReqID(Long acctReqID) {
        this.acctReqID = acctReqID;
    }

    /**
     * @return the requestType
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * @return the accountType
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * @param accountType
     *            the accountType to set
     */
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    /**
     * @return the accountTitle
     */
    public String getAccountTitle() {
        return accountTitle;
    }

    /**
     * @param accountTitle
     *            the accountTitle to set
     */
    public void setAccountTitle(String accountTitle) {
        this.accountTitle = accountTitle;
    }

    /**
     * @return the requestStatus
     */
    public String getRequestStatus() {
        return requestStatus;
    }

    /**
     * @param requestStatus
     *            the requestStatus to set
     */
    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    /**
     * @return the acctNumber
     */
    public String getAcctNumber() {
        return acctNumber;
    }

    /**
     * @param acctNumber
     *            the acctNumber to set
     */
    public void setAcctNumber(String acctNumber) {
        this.acctNumber = acctNumber;
    }

    /**
     * @return the iban
     */
    public String getIban() {
        return iban;
    }

    /**
     * @param iban
     *            the iban to set
     */
    public void setIban(String iban) {
        this.iban = iban;
    }

    /**
     * @return the tCode
     */
    public String gettCode() {
        return tCode;
    }

    /**
     * @param tCode
     *            the tCode to set
     */
    public void settCode(String tCode) {
        this.tCode = tCode;
    }

    /**
     * @return the subBusName
     */
    public String getSubBusName() {
        return subBusName;
    }

    /**
     * @param subBusName
     *            the subBusName to set
     */
    public void setSubBusName(String subBusName) {
        this.subBusName = subBusName;
    }

    /**
     * @return the leCode
     */
    public String getLeCode() {
        return StringUtils.upperCase(leCode);
    }

    /**
     * @param leCode
     *            the leCode to set
     */
    public void setLeCode(String leCode) {
        this.leCode = leCode;
    }

    /**
     * @return the leName
     */
    public String getLeName() {
        return leName;
    }

    /**
     * @param leName
     *            the leName to set
     */
    public void setLeName(String leName) {
        this.leName = leName;
    }

    /**
     * @return the leVersion
     */
    public String getLeVersion() {
        return leVersion;
    }

    /**
     * @param leVersion
     *            the leVersion to set
     */
    public void setLeVersion(String leVersion) {
        this.leVersion = leVersion;
    }

    /**
     * @return the currency
     */
    public String getCurrency() {
        return StringUtils.upperCase(currency);
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return StringUtils.upperCase(country);
    }

    /**
     * @param country
     *            the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the bankName
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * @param bankName
     *            the bankName to set
     */
    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    /**
     * @return the componentCode
     */
    public String getComponentCode() {
        return StringUtils.upperCase(componentCode);
    }

    /**
     * @param componentCode
     *            the componentCode to set
     */
    public void setComponentCode(String componentCode) {
        this.componentCode = componentCode;
    }

    /**
     * 
     * @return the mdmTcodeAlternate
     */
    public String getMdmTcodeAlternate() {
        return mdmTcodeAlternate;
    }

    /**
     * 
     * @param mdmTcodeAlternate
     *            the mdmTcodeAlternate to set
     */
    public void setMdmTcodeAlternate(String mdmTcodeAlternate) {
        this.mdmTcodeAlternate = mdmTcodeAlternate;
    }

    
    /**
     * @return the buCode
     */
    public String getBuCode() {
		return buCode;
	}
    /**
     * @param buCode
     *            the buCode to set
     */
	public void setBuCode(String buCode) {
		this.buCode = buCode;
	}

	/**
     * @return the bussName
     */
    public String getBussName() {
        return bussName;
    }

    /**
     * @param bussName
     *            the bussName to set
     */
    public void setBussName(String bussName) {
        this.bussName = bussName;
    }

    /**
     * @return the bankId
     */
    public String getBankId() {
        return StringUtils.upperCase(bankId);
    }

    /**
     * @param bankId
     *            the bankId to set
     */
    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    /**
     * @return the cashpoolTCode
     */
    public String getCashpoolTCode() {
        return cashpoolTCode;
    }

    /**
     * @param cashpoolTCode
     *            the cashpoolTCode to set
     */
    public void setCashpoolTCode(String cashpoolTCode) {
        this.cashpoolTCode = cashpoolTCode;
    }

    /**
     * @return the cashpoolLeCode
     */
    public String getCashpoolLeCode() {
        return cashpoolLeCode;
    }

    /**
     * @param cashpoolLeCode
     *            the cashpoolLeCode to set
     */
    public void setCashpoolLeCode(String cashpoolLeCode) {
        this.cashpoolLeCode = cashpoolLeCode;
    }

    /**
     * @return the routeCode
     */
    public String getRouteCode() {
        return routeCode;
    }

    /**
     * @param routeCode
     *            the routeCode to set
     */
    public void setRouteCode(String routeCode) {
        this.routeCode = routeCode;
    }

    /**
     * @return the routeCodeType
     */
    public String getRouteCodeType() {
        return routeCodeType;
    }

    /**
     * @param routeCodeType
     *            the routeCodeType to set
     */
    public void setRouteCodeType(String routeCodeType) {
        this.routeCodeType = routeCodeType;
    }

    /**
     * @return the countryName
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * @param countryName
     *            the countryName to set
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    /**
     * @return the currencyName
     */
    public String getCurrencyName() {
        return currencyName;
    }

    /**
     * @param currencyName
     *            the currencyName to set
     */
    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    /**
     * @return the branchMDMID
     */
    public String getBranchMDMID() {
        return StringUtils.upperCase(branchMDMID);
    }

    /**
     * @param branchMDMID
     *            the branchMDMID to set
     */
    public void setBranchMDMID(String branchMDMID) {
        this.branchMDMID = branchMDMID;
    }

    /**
     * @return the flags
     */
    public List<AccountFlag> getFlags() {
        return flags;
    }

    /**
     * @param flags
     *            the flags to set
     */
    public void setFlags(List<AccountFlag> flags) {
        this.flags = flags;
    }

    /**
     * @return the signers
     */
    public List<AccountSigner> getSigners() {
        return signers;
    }

    /**
     * @param signers
     *            the signers to set
     */
    public void setSigners(List<AccountSigner> signers) {
        this.signers = signers;
    }

    /**
     * @return the documents
     */
    public List<AccountDocument> getDocuments() {
        return documents;
    }

    /**
     * @param documents
     *            the documents to set
     */
    public void setDocuments(List<AccountDocument> documents) {
        this.documents = documents;
    }

    /**
     * @return the comments
     */
    public List<AccountComment> getComments() {
        return comments;
    }

    /**
     * @param comments
     *            the comments to set
     */
    public void setComments(List<AccountComment> comments) {
        this.comments = comments;
    }

    /**
     * @return the recordCount
     */
    public Integer getRecordCount() {
        return recordCount;
    }

    /**
     * @param recordCount
     *            the recordCount to set
     */
    public void setRecordCount(Integer recordCount) {
        this.recordCount = recordCount;
    }

    public Long getStgId() {
        return stgId;
    }

    public void setStgId(Long stgId) {
        this.stgId = stgId;
    }

    public String getMeCode() {
        return StringUtils.upperCase(meCode);
    }

    public void setMeCode(String meCode) {
        this.meCode = meCode;
    }

    public String getCompanyCode() {
        return StringUtils.upperCase(companyCode);
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    @Override
    public String toString() {
        return "AccountRequest [acctReqID=" + acctReqID + ", requestType=" + requestType + ", accountType="
                + accountType + ", accountTitle=" + accountTitle + ", requestStatus=" + requestStatus + ", acctNumber="
                + acctNumber + ", projectName=" + projectName + ", iban=" + iban + ", tCode=" + tCode + ", subBusName="
                + subBusName + ", leCode=" + leCode + ", leName=" + leName + ", leVersion=" + leVersion + ", currency="
                + currency + ", country=" + country + ", bankName=" + bankName + ", componentCode=" + componentCode
                + ", mdmTcodeAlternate=" + mdmTcodeAlternate + ", isBankAcctReserved=" + isBankAcctReserved
                + ", bussName=" + bussName + ", bankId=" + bankId + ", cashpoolTCode=" + cashpoolTCode
                + ", cashpoolLeCode=" + cashpoolLeCode + ", routeCode=" + routeCode + ", routeCodeType=" + routeCodeType
                + ", countryName=" + countryName + ", currencyName=" + currencyName + ", branchMDMID=" + branchMDMID
                + ", subtypeCode=" + subtypeCode + ", assignedToSso=" + assignedToSso + ", assignedToName="
                + assignedToName + ", cashPoolRejectReason=" + cashPoolRejectReason + ", cashPoolProcessCode="
                + cashPoolProcessCode + ", cashPoolProcesses=" + cashPoolProcesses + ", flags=" + flags + ", signers="
                + signers + ", documents=" + documents + ", comments=" + comments + ", recordCount=" + recordCount
                + ", multipleUserValidationCheck=" + multipleUserValidationCheck + ", stgId=" + stgId + ", meCode="
                + meCode + ", companyCode=" + companyCode + ", accountPurpose=" + accountPurpose
                + ", bankClassification=" + bankClassification + ", acctOpenDate=" + acctOpenDate + ", acctClosedDate="
                + acctClosedDate + "]";
    }

    /**
     * @return the isBankAcctReserved
     */
    public String getIsBankAcctReserved() {
        return isBankAcctReserved;
    }

    /**
     * @param isBankAcctReserved
     *            the isBankAcctReserved to set
     */
    public void setIsBankAcctReserved(String isBankAcctReserved) {
        this.isBankAcctReserved = isBankAcctReserved;
    }

    /**
     * @return the multipleUserValidationCheck
     */
    public String getMultipleUserValidationCheck() {
        return multipleUserValidationCheck;
    }

    /**
     * @param multipleUserValidationCheck
     *            the multipleUserValidationCheck to set
     */
    public void setMultipleUserValidationCheck(String multipleUserValidationCheck) {
        this.multipleUserValidationCheck = multipleUserValidationCheck;
    }

    /**
     * 
     * @param subtypeCode
     *            the subtypeCode to set
     */
    public void setSubtypeCode(String subtypeCode) {
        this.subtypeCode = subtypeCode;
    }

    /**
     * 
     * @return
     */
    public String getSubtypeCode() {
        return subtypeCode;
    }

    public String getAssignedToSso() {
        return assignedToSso;
    }

    public void setAssignedToSso(String assignedToSso) {
        this.assignedToSso = assignedToSso;
    }

    public String getAssignedToName() {
        return assignedToName;
    }

    public void setAssignedToName(String assignedToName) {
        this.assignedToName = assignedToName;
    }

    public AccountRequest() {
        super();
    }

    public AccountRequest(Long acctReqID) {
        super();
        this.acctReqID = acctReqID;
    }

    public String getAccountPurpose() {
        return accountPurpose;
    }

    public void setAccountPurpose(String accountPurpose) {
        this.accountPurpose = accountPurpose;
    }

    public String getBankClassification() {
        return bankClassification;
    }

    public void setBankClassification(String bankClassification) {
        this.bankClassification = bankClassification;
    }

    public String getAcctOpenDate() {
        return acctOpenDate;
    }

    public void setAcctOpenDate(String acctOpenDate) {
        this.acctOpenDate = acctOpenDate;
    }

    public String getAcctClosedDate() {
        return acctClosedDate;
    }

    public void setAcctClosedDate(String acctClosedDate) {
        this.acctClosedDate = acctClosedDate;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public List<CashPoolProcess> getCashPoolProcesses() {
        return cashPoolProcesses;
    }

    public void setCashPoolProcesses(List<CashPoolProcess> cashPoolProcesses) {
        this.cashPoolProcesses = cashPoolProcesses;
    }

    public String getCashPoolRejectReason() {
        return cashPoolRejectReason;
    }

    public void setCashPoolRejectReason(String cashPoolRejectReason) {
        this.cashPoolRejectReason = cashPoolRejectReason;
    }

    public String getCashPoolProcessCode() {
        return cashPoolProcessCode;
    }

    public void setCashPoolProcessCode(String cashPoolProcessCode) {
        this.cashPoolProcessCode = cashPoolProcessCode;
    }

    public String getChannelResponse() {
        return channelResponse;
    }

    public void setChannelResponse(String channelResponse) {
        this.channelResponse = channelResponse;
    }

	public String getCashPoolCategory() {
		return cashPoolCategory;
	}

	public void setCashPoolCategory(String cashPoolCategory) {
		this.cashPoolCategory = cashPoolCategory;
	}

	public String getCashPoolHeaderLeCode() {
		return cashPoolHeaderLeCode;
	}

	public void setCashPoolHeaderLeCode(String cashPoolHeaderLeCode) {
		this.cashPoolHeaderLeCode = cashPoolHeaderLeCode;
	}

	public String getCoCodeRejectReason() {
		return coCodeRejectReason;
	}

	public void setCoCodeRejectReason(String coCodeRejectReason) {
		this.coCodeRejectReason = coCodeRejectReason;
	}

    public PlatformInstance getPlatformInstance() {
        return platformInstance;
    }
    
    public Long getPlatformInstanceId() {
        return null == platformInstance ? null:platformInstance.getPlatformInstanceId();
    }

    public void setPlatformInstance(PlatformInstance platformInstance) {
        this.platformInstance = platformInstance;
    }

}
