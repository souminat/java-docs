package com.ge.treasury.mybank.domain.accountrequest;

public class FileUploadParameters {

    private String responseText;
    private String responseStatus;
    private String fileID;
    private String fileURL;
    private String propertiesURL;
    private String errorCode;
    private String errorMessage;
    private boolean isFileDownloaded;

    /**
     * @return the responseText
     */
    public String getResponseText() {
        return responseText;
    }

    /**
     * @return the errorCode
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * @param responseText
     *            the responseText to set
     */
    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }

    /**
     * @return the responseStatus
     */
    public String getResponseStatus() {
        return responseStatus;
    }

    /**
     * @param responseStatus
     *            the responseStatus to set
     */
    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    /**
     * @return the fileID
     */
    public String getFileID() {
        return fileID;
    }

    /**
     * @param fileID
     *            the fileID to set
     */
    public void setFileID(String fileID) {
        this.fileID = fileID;
    }

    /**
     * @return the fileURL
     */
    public String getFileURL() {
        return fileURL;
    }

    /**
     * @param fileURL
     *            the fileURL to set
     */
    public void setFileURL(String fileURL) {
        this.fileURL = fileURL;
    }

    /**
     * @return the propertiesURL
     */
    public String getPropertiesURL() {
        return propertiesURL;
    }

    /**
     * @param propertiesURL
     *            the propertiesURL to set
     */
    public void setPropertiesURL(String propertiesURL) {
        this.propertiesURL = propertiesURL;
    }

    /**
     * @return the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage
     *            the errorMessage to set
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * @return the isFileDownloaded
     */
    public boolean isFileDownloaded() {
        return isFileDownloaded;
    }

    /**
     * @param isFileDownloaded
     *            the isFileDownloaded to set
     */
    public void setFileDownloaded(boolean isFileDownloaded) {
        this.isFileDownloaded = isFileDownloaded;
    }

}
