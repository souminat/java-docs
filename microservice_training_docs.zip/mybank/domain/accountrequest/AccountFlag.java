/**
 * 
 */
package com.ge.treasury.mybank.domain.accountrequest;

/**
 * @author MyBank Dev Team
 * 
 */
public class AccountFlag extends BaseDomainObject {

    /*
     * ACCOUNT_REQUEST_ID, ACCOUNT_FLAG_CODE, FLAG_COMMENT, DELETE_FLAG
     * CREATE_TIMESTAMP, CREATE_USER, LAST_UPDATE_TIMESTAMP, LAST_UPDATE_USER
     */

    /**
	 * 
	 */
    private static final long serialVersionUID = -1553091647196501701L;
    private Long acctReqID;
    private String flagCode;
    private String flagCmment;
    private String isFlagChecked;

    /**
     * @param acctReqID
     * @param flagCode
     * @param flagCmment
     * @param deleteFlag
     */
    public AccountFlag(Long acctReqID, String flagCode, String flagCmment,
            String isFlagChecked) {
        super();
        this.acctReqID = acctReqID;
        this.flagCode = flagCode;
        this.flagCmment = flagCmment;
        this.isFlagChecked = isFlagChecked;
    }

    /**
	 * 
	 */
    public AccountFlag() {
    	//No arg constructor
    }

    /**
     * @return the acctReqID
     */
    public Long getAcctReqID() {
        return acctReqID;
    }

    /**
     * @param acctReqID
     *            the acctReqID to set
     */
    public void setAcctReqID(Long acctReqID) {
        this.acctReqID = acctReqID;
    }

    /**
     * @return the flagCode
     */
    public String getFlagCode() {
        return flagCode;
    }

    /**
     * @param flagCode
     *            the flagCode to set
     */
    public void setFlagCode(String flagCode) {
        this.flagCode = flagCode;
    }

    /**
     * @return the flagCmment
     */
    public String getFlagCmment() {
        return flagCmment;
    }

    /**
     * @param flagCmment
     *            the flagCmment to set
     */
    public void setFlagCmment(String flagCmment) {
        this.flagCmment = flagCmment;
    }

    /**
     * @return the isFlagChecked
     */
    public String getIsFlagChecked() {
        return isFlagChecked;
    }

    /**
     * @param isFlagChecked
     *            the isFlagChecked to set
     */
    public void setIsFlagChecked(String isFlagChecked) {
        this.isFlagChecked = isFlagChecked;
    }

}
