/**
 * Copyright GE
 */
package com.ge.treasury.mybank.domain.accountrequest;

/**
 * @author MyBank Development Team
 * 
 */
public class AccountRequestValidation {

    private String fieldname;
    private String validationMessage;

    /**
     * @return the fieldname
     */
    public String getFieldname() {
        return fieldname;
    }

    /**
     * @param fieldname
     *            the fieldname to set
     */
    public void setFieldname(String fieldname) {
        this.fieldname = fieldname;
    }

    /**
     * @return the validationMessage
     */
    public String getValidationMessage() {
        return validationMessage;
    }

    /**
     * @param validationMessage
     *            the validationMessage to set
     */
    public void setValidationMessage(String validationMessage) {
        this.validationMessage = validationMessage;
    }

}
