/**
 * 
 */
package com.ge.treasury.mybank.domain.accountrequest;

/**
 * Contains attributes according LOOKUP table in DB
 * 
 * @author MyBank Dev team
 * 
 */
public class MyBankLookup extends BaseDomainObject {

    /*
     * LOOKUP_CODE VARCHAR2(30 BYTE) LOOKUP_TYPE VARCHAR2(100 BYTE) DISPLAY_NAME
     * VARCHAR2(100 BYTE) DISPLAY_ORDER NUMBER(9,0) DESCRIPTION VARCHAR2(250
     * BYTE) IS_ACTIVE CHAR(1 BYTE) IS_MANDANTORY CHAR(1 BYTE) CREATE_TIMESTAMP
     * TIMESTAMP(6) CREATE_USER VARCHAR2(50 BYTE) LAST_UPDATE_TIMESTAMP
     * TIMESTAMP(6) LAST_UPDATE_USER VARCHAR2(50 BYTE)
     */
    private static final long serialVersionUID = -2215375268655712118L;

    private String lookupCode;
    private String lookupType;
    private String dispname;
    private String disporder;
    private String desc;
    private String isActiv;
    private String isMandt;


    /**
     * @return the lookupCode
     */
    public String getLookupCode() {
        return lookupCode;
    }

    /**
     * @param lookupCode
     *            the lookupCode to set
     */
    public void setLookupCode(String lookupCode) {
        this.lookupCode = lookupCode;
    }

    /**
     * @return the lookupType
     */
    public String getLookupType() {
        return lookupType;
    }

    /**
     * @param lookupType
     *            the lookupType to set
     */
    public void setLookupType(String lookupType) {
        this.lookupType = lookupType;
    }

    /**
     * @return the dispname
     */
    public String getDispname() {
        return dispname;
    }

    /**
     * @param dispname
     *            the dispname to set
     */
    public void setDispname(String dispname) {
        this.dispname = dispname;
    }

    /**
     * @return the disporder
     */
    public String getDisporder() {
        return disporder;
    }

    /**
     * @param disporder
     *            the disporder to set
     */
    public void setDisporder(String disporder) {
        this.disporder = disporder;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc
     *            the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the isActiv
     */
    public String getIsActiv() {
        return isActiv;
    }

    /**
     * @param isActiv
     *            the isActiv to set
     */
    public void setIsActiv(String isActiv) {
        this.isActiv = isActiv;
    }

    /**
     * @return the isMandt
     */
    public String getIsMandt() {
        return isMandt;
    }

    /**
     * @param isMandt
     *            the isMandt to set
     */
    public void setIsMandt(String isMandt) {
        this.isMandt = isMandt;
    }

}
