package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.hibernate.validator.constraints.NotBlank;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MyFundingInRequest implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -4353971165354135008L;

    @NotNull(message = "myBankRequestId is Mandatory")
    @Pattern(regexp = "[0-9]+", message = "myBankRequestId must be a numeric value")
    private String myBankRequestId;

    @NotNull(message = "myFundingDealId is Mandatory")
    @Pattern(regexp = "[0-9]+", message = "myFundingDealId must be a numeric value")
    private String myFundingDealId;

    @NotBlank(message = "myFundingStatus is Mandatory")
    private String myFundingStatus;

    // @NotBlank(message = "headerLEId is Mandatory")
    private String headerLEId;

    private String comments;

    public MyFundingInRequest() {
        // No arg constructor
    }

    public String getMyBankRequestId() {
        return myBankRequestId;
    }

    public void setMyBankRequestId(String myBankRequestId) {
        this.myBankRequestId = myBankRequestId;
    }

    public String getMyFundingDealId() {
        return myFundingDealId;
    }

    public void setMyFundingDealId(String myFundingDealId) {
        this.myFundingDealId = myFundingDealId;
    }

    public String getMyFundingStatus() {
        return myFundingStatus;
    }

    public void setMyFundingStatus(String myFundingStatus) {
        this.myFundingStatus = myFundingStatus;
    }

    public String getHeaderLEId() {
        return headerLEId;
    }

    public void setHeaderLEId(String headerLEId) {
        this.headerLEId = headerLEId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "MyFundingInRequest [myBankRequestId=" + myBankRequestId + ", myFundingDealId=" + myFundingDealId
                + ", myFundingStatus=" + myFundingStatus + ", headerLEId=" + headerLEId + ", comments=" + comments
                + ", getMyBankRequestId()=" + getMyBankRequestId() + ", getMyFundingDealId()=" + getMyFundingDealId()
                + ", getMyFundingStatus()=" + getMyFundingStatus() + ", getHeaderLEId()=" + getHeaderLEId()
                + ", getComments()=" + getComments() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
                + ", toString()=" + super.toString() + "]";
    }

}
