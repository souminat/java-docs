package com.ge.treasury.mybank.domain.accountrequest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MDMDetails implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4182015186199284169L;
	private List<String> countires = new ArrayList<String>();
	private List<String> currency = new ArrayList<String>();
	private Set<String> businessList = new HashSet<String>();
	private Set<String> subBusinessList = new HashSet<String>();
	private List<String> leVersionList = new ArrayList<String>();
	private List<String> leCodeList = new ArrayList<String>();
	private List<String> leNameList = new ArrayList<String>();
	private Set<String> routeCodeList = new HashSet<String>();
	private Set<String> routeTypeList = new HashSet<String>();
	private Set<String> bankMdmIdList = new HashSet<String>();
	private Map<String, String> branchMdmIdNameList = new HashMap<String, String>();
	private Set<String> branchMdmIdList = new HashSet<String>();
	private Map<String, String> countryList = new HashMap<String, String>();
	private Set<String> meCodeList = new HashSet<String>();
	
	//attribute to validate combination
	private Map<String,List<String>> busSubBusCombination = new HashMap<String,List<String>>();

	public Map<String, String> getBranchMdmIdNameList() {
		return branchMdmIdNameList;
	}

	public void setBranchMdmIdNameList(Map<String, String> branchMdmIdNameList) {
		this.branchMdmIdNameList = branchMdmIdNameList;
	}

	public List<String> getCountires() {
		return countires;
	}

	public void setCountires(List<String> countires) {
		this.countires = countires;
	}

	public List<String> getCurrency() {
		return currency;
	}

	public void setCurrency(List<String> currency) {
		this.currency = currency;
	}

	public Set<String> getBusinessList() {
		return businessList;
	}

	public void setBusinessList(Set<String> businessList) {
		this.businessList = businessList;
	}

	public Set<String> getSubBusinessList() {
		return subBusinessList;
	}

	public void setSubBusinessList(Set<String> subBusinessList) {
		this.subBusinessList = subBusinessList;
	}

	public List<String> getLeVersionList() {
		return leVersionList;
	}

	public void setLeVersionList(List<String> leVersionList) {
		this.leVersionList = leVersionList;
	}

	public List<String> getLeCodeList() {
		return leCodeList;
	}

	public void setLeCodeList(List<String> leCodeList) {
		this.leCodeList = leCodeList;
	}

	public List<String> getLeNameList() {
		return leNameList;
	}

	public void setLeNameList(List<String> leNameList) {
		this.leNameList = leNameList;
	}

	public Set<String> getRouteCodeList() {
		return routeCodeList;
	}

	public void setRouteCodeList(Set<String> routeCodeList) {
		this.routeCodeList = routeCodeList;
	}

	public Set<String> getRouteTypeList() {
		return routeTypeList;
	}

	public void setRouteTypeList(Set<String> routeTypeList) {
		this.routeTypeList = routeTypeList;
	}

	public Set<String> getBankMdmIdList() {
		return bankMdmIdList;
	}

	public void setBankMdmIdList(Set<String> bankMdmIdList) {
		this.bankMdmIdList = bankMdmIdList;
	}

	public Set<String> getBranchMdmIdList() {
		return branchMdmIdList;
	}

	public void setBranchMdmIdList(Set<String> branchMdmIdList) {
		this.branchMdmIdList = branchMdmIdList;
	}

	public Map<String, String> getCountryList() {
		return countryList;
	}

	public void setCountryList(Map<String, String> countryList) {
		this.countryList = countryList;
	}

	public Set<String> getMeCodeList() {
		return meCodeList;
	}

	public void setMeCodeList(Set<String> meCodeList) {
		this.meCodeList = meCodeList;
	}

	public Map<String, List<String>> getBusSubBusCombination() {
		return busSubBusCombination;
	}

	public void setBusSubBusCombination(Map<String, List<String>> busSubBusCombination) {
		this.busSubBusCombination = busSubBusCombination;
	}
	

}
