package com.ge.treasury.mybank.domain;

import com.ge.treasury.mybank.domain.accountrequest.BaseDomainObject;

public class FileUploadActivity extends BaseDomainObject {

	private static final long serialVersionUID = 7881971108060627387L;

	private Long fileUpldActivityId;
	private Long fileUpldId;
	private String statusCode;
	private String comments;
	private String userRole;
	
	public Long getFileUpldActivityId() {
		return fileUpldActivityId;
	}

	public void setFileUpldActivityId(Long fileUpldActivityId) {
		this.fileUpldActivityId = fileUpldActivityId;
	}

	public Long getFileUpldId() {
		return fileUpldId;
	}

	public void setFileUpldId(Long fileUpldId) {
		this.fileUpldId = fileUpldId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	
}
