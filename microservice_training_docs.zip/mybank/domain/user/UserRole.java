/**
 * Copyright GE
 */
package com.ge.treasury.mybank.domain.user;

/**
 * Contains attributes for UserRole
 * 
 * @author MyBank Dev Team
 * 
 */
public class UserRole {
    private String myBankRole;
    private String business;
    private String subBusiness;
    private String statusRole;

    /**
     * @return the myBankRole
     */
    public String getMyBankRole() {
        return myBankRole;
    }

    /**
     * @param myBankRole
     *            the myBankRole to set
     */
    public void setMyBankRole(String myBankRole) {
        this.myBankRole = myBankRole;
    }

    /**
     * @return the business
     */
    public String getBusiness() {
        return business;
    }

    /**
     * @param business
     *            the business to set
     */
    public void setBusiness(String business) {
        this.business = business;
    }

    /**
     * @return the subBusiness
     */
    public String getSubBusiness() {
        return subBusiness;
    }

    /**
     * @param subBusiness
     *            the subBusiness to set
     */
    public void setSubBusiness(String subBusiness) {
        this.subBusiness = subBusiness;
    }

    /**
     * @return the statusRole
     */
    public String getStatusRole() {
        return statusRole;
    }

    /**
     * @param statusRole
     *            the statusRole to set
     */
    public void setStatusRole(String statusRole) {
        this.statusRole = statusRole;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UserRole [myBankRole=" + myBankRole + ", business=" + business
                + ", subBusiness=" + subBusiness + ", statusRole=" + statusRole
                + "]";
    }

}
