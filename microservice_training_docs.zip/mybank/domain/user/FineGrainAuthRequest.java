/**
 * Copyright GE
 */
package com.ge.treasury.mybank.domain.user;

/**
 * Domain to call FineGrainAuth Service to obtain user profile information
 * 
 * @author MyBank Dev Team
 * 
 */
public class FineGrainAuthRequest {

    private String sso;
    private String appName;
    private String status;
    private String message;
    private String filtercriteria;
    private String filterValue;
    private String role;

    /**
     * @return the sso
     */
    public String getSso() {
        return sso;
    }

    /**
     * @param sso
     *            the sso to set
     */
    public void setSso(String sso) {
        this.sso = sso;
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName
     *            the appName to set
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     *            the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the filtercriteria
     */
    public String getFiltercriteria() {
        return filtercriteria;
    }

    /**
     * @param filtercriteria
     *            the filtercriteria to set
     */
    public void setFiltercriteria(String filtercriteria) {
        this.filtercriteria = filtercriteria;
    }

    /**
     * @return the filterValue
     */
    public String getFilterValue() {
        return filterValue;
    }

    /**
     * @param filterValue
     *            the filterValue to set
     */
    public void setFilterValue(String filterValue) {
        this.filterValue = filterValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "FineGrainAuthRequest [sso=" + sso + ", appName=" + appName
                + ", status=" + status + ", message=" + message
                + ", filtercriteria=" + filtercriteria + ", filterValue="
                + filterValue + "]";
    }

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
