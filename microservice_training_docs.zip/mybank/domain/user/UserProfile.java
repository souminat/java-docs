/**
 * Copyright GE
 */
package com.ge.treasury.mybank.domain.user;

import java.io.Serializable;
import java.util.List;

/**
 * Domain class that contains all the attributes from IDM microservice
 * 
 * @author MyBank Dev Team
 * 
 */
public class UserProfile implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -6822296429705869919L;
    
    private String sso;
    private String name;
    private String appName;
    private transient List<UserRole> roles;

    public UserProfile() {
    	//No arg constructor
    }

    public UserProfile(String sso, String appName, List<UserRole> roles, String name) {
        super();
        this.sso = sso;
        this.appName = appName;
        this.roles = roles;
        this.name = name;
    }

    /**
     * @return the sso
     */
    public String getSso() {
        return sso;
    }

    /**
     * @param sso
     *            the sso to set
     */
    public void setSso(String sso) {
        this.sso = sso;
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName
     *            the appName to set
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * @return the roles
     */
    public List<UserRole> getRoles() {
        return roles;
    }

    /**
     * @param roles
     *            the roles to set
     */
    public void setRoles(List<UserRole> roles) {
        this.roles = roles;
    }
    
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UserProfile [sso=" + sso + ", name=" + name + ", appName=" + appName + ", roles=" + roles + "]";
    }
}
