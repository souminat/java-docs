/**
 * Copyright GE
 */

package com.ge.treasury.mybank.domain.user;

import java.util.List;

import com.ge.treasury.mybank.domain.accountrequest.BaseDomainObject;

/**
 * User attributes
 * 
 * @author MyBank Dev Team
 * 
 */
public class User extends BaseDomainObject {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1615661846255156018L;

    private Long userId;
    private String sso;
    private String lastName;
    private String firstName;
    private String phone;
    private String emailId;
    private String effectiveDate;
    private String status;
    private List<String> ldapRolesList;
    // From IDM microservice
    private UserProfile userProfile;

    public User() {
    	//No arg constructor
    }

    public User(String sso, String lastName, String firstName, String emailId) {
        super();
        this.sso = sso;
        this.lastName = lastName;
        this.firstName = firstName;
        this.emailId = emailId;
    }

    /**
     * @return the userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * @return the sso
     */
    public String getSso() {
        return sso;
    }

    /**
     * @param sso
     *            the sso to set
     */
    public void setSso(String sso) {
        this.sso = sso;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone
     *            the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId
     *            the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the effectiveDate
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * @param effectiveDate
     *            the effectiveDate to set
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the ldapRolesList
     */
    public List<String> getLdapRolesList() {
        return ldapRolesList;
    }

    /**
     * @param ldapRolesList
     *            the ldapRolesList to set
     */
    public void setLdapRolesList(List<String> ldapRolesList) {
        this.ldapRolesList = ldapRolesList;
    }

    /**
     * @return the userProfile
     */
    public UserProfile getUserProfile() {
        return userProfile;
    }

    /**
     * @param userProfile
     *            the userProfile to set
     */
    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

}