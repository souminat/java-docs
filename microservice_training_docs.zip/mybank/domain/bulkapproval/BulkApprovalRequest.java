package com.ge.treasury.mybank.domain.bulkapproval;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.treasury.mybank.domain.accountrequest.BaseDomainObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class BulkApprovalRequest extends BaseDomainObject {

	/*
     FILE_UPLD_STG_ACCOUNT_ID  , FILE_UPLOAD_ID  , ACCOUNT_REQUEST_ID , STATUS_CODE  
, FAILURE_REASON  , ACCOUNT_STATUS_CODE  , ACCOUNT_OPEN_DATE , ACCOUNT_TYPE_TYPE  
, MDM_COMPANY_CODE  , MDM_ME_CODE  , MDM_COMPONENT_CODE  , ACCOUNT_PURPOSE  , ACCOUNT_NUMBER 
, IBAN  , MDM_LE_CODE  , MDM_ACCOUNT_COUNTRY , MDM_ACCOUNT_CURRENCY , MDM_BANK_ID  , MDM_ROUTING_CODE  
, MDM_ROUTING_CODE_TYPE , BANK_CLASSIFICATION  , MDM_CASHPOOL_TCODE  , ACCOUNT_TITLE  , MDM_BUSINESS_NAME  
, MDM_SUB_BUSINESS_NAME  , TSA_NAME  , PROJECT_NAME  , COMMENTS  , DOCUMENTS_URL  , BANK_CONFIRMATION_URL  
, MDM_TCODE  , LAST_UPDATE_USER  , LAST_UPDATE_TIMESTAMP  , CREATE_TIMESTAMP  , CREATE_USER
     */
	private static final long serialVersionUID = 6031864938663388366L;
	
	    private String accountStatus;
    	private Date accountOpenDate1;	
	    private String accountOpenDate;
		private String accountType;
		private String companyCode ;
		private String me;
		private String iban;
		private String componentCode;
		private String accountPurpose ;
		private String accountNumber;
		private String leCode;
		private String country;
		private String currency;
		private String bankId;
		private String routeCode;
		private String routeCodeType;
		private String bankClassification;
		private String cashpoolTCode;
		private String accountTitle;
		private String buCode;
		private String bussName;
		private String subBusiness;
		private String projectName;
		private String comments;
		private String documents;
		private String bankConfirmation;
		private Long fileUpldId;
		private String statusCode;
		private Long stgId;
		private String failureReason;
		private String tCode;
		private Long accountReqId;
	    private String accountCloseDate;
	    private Date accountCloseDate1;
	    private String requestType;
	    
	    private String statusCodeDisplayName;
	    private String documentType;
	    private String spbDocument;
	    private String branchID;
	    private String coCodeRejectReason;
	    
	    
		public String getBranchID() {
			return StringUtils.upperCase(branchID);
		}
		public void setBranchID(String branchID) {
			this.branchID = branchID;
		}
		public String getSpbDocument() {
			return spbDocument;
		}
		public void setSpbDocument(String spbDocument) {
			this.spbDocument = spbDocument;
		}
		public String getDocumentType() {
			return documentType;
		}
		public void setDocumentType(String documentType) {
			this.documentType = documentType;
		}
		public String getRequestType() {
			return requestType;
		}
		public void setRequestType(String requestType) {
			this.requestType = requestType;
		}
		public Date getAccountCloseDate1() {
			return accountCloseDate1;
		}
		public void setAccountCloseDate1(Date accountCloseDate1) {
			this.accountCloseDate1 = accountCloseDate1;
		}
		public String getAccountCloseDate() {
			return accountCloseDate;
		}
		public void setAccountCloseDate(String accountCloseDate) {
			this.accountCloseDate = accountCloseDate;
		}
		public Long getAccountReqId() {
			return accountReqId;
		}
		public void setAccountReqId(Long accountReqId) {
			this.accountReqId = accountReqId;
		}
		public String getAccountStatus() {
			return accountStatus;
		}
		public void setAccountStatus(String accountStatus) {
			this.accountStatus = accountStatus;
		}
		public Date getAccountOpenDate1() {
			return accountOpenDate1;
		}
		public void setAccountOpenDate1(Date accountOpenDate1) {
			this.accountOpenDate1 = accountOpenDate1;
		}
		public String getAccountOpenDate() {
			return accountOpenDate;
		}
		public void setAccountOpenDate(String accountOpenDate) {
			this.accountOpenDate = accountOpenDate;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public String getCompanyCode() {
			return StringUtils.upperCase(companyCode);
		}
		public void setCompanyCode(String companyCode) {
			this.companyCode = companyCode;
		}
		public String getMe() {
			return StringUtils.upperCase(me);
		}
		public void setMe(String me) {
			this.me = me;
		}
		public String getIban() {
			return iban;
		}
		public void setIban(String iban) {
			this.iban = iban;
		}
		public String getComponentCode() {
			return StringUtils.upperCase(componentCode);
		}
		public void setComponentCode(String componentCode) {
			this.componentCode = componentCode;
		}
		public String getAccountPurpose() {
			return accountPurpose;
		}
		public void setAccountPurpose(String accountPurpose) {
			this.accountPurpose = accountPurpose;
		}
		public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getLeCode() {
			return StringUtils.upperCase(leCode);
		}
		public void setLeCode(String leCode) {
			this.leCode = leCode;
		}
		public String getCountry() {
			return StringUtils.upperCase(country);
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getCurrency() {
			return StringUtils.upperCase(currency);
		}
		public void setCurrency(String currency) {
			this.currency = currency;
		}
		public String getBankId() {
			return StringUtils.upperCase(bankId);
		}
		public void setBankId(String bankId) {
			this.bankId = bankId;
		}
		public String getRouteCode() {
			return routeCode;
		}
		public void setRouteCode(String routeCode) {
			this.routeCode = routeCode;
		}
		public String getRouteCodeType() {
			return routeCodeType;
		}
		public void setRouteCodeType(String routeCodeType) {
			this.routeCodeType = routeCodeType;
		}
		public String getBankClassification() {
			return bankClassification;
		}
		public void setBankClassification(String bankClassification) {
			this.bankClassification = bankClassification;
		}
		public String getCashpoolTCode() {
			return cashpoolTCode;
		}
		public void setCashpoolTCode(String cashpoolTCode) {
			this.cashpoolTCode = cashpoolTCode;
		}
		public String getAccountTitle() {
			return accountTitle;
		}
		public void setAccountTitle(String accountTitle) {
			this.accountTitle = accountTitle;
		}
		public String getBuCode() {
			return buCode;
		}
		public void setBuCode(String buCode) {
			this.buCode = buCode;
		}
		public String getBussName() {
			return bussName;
		}
		public void setBussName(String bussName) {
			this.bussName = bussName;
		}
		public String getSubBusiness() {
			return subBusiness;
		}
		public void setSubBusiness(String subBusiness) {
			this.subBusiness = subBusiness;
		}
		public String getProjectName() {
			return projectName;
		}
		public void setProjectName(String projectName) {
			this.projectName = projectName;
		}
		public String getComments() {
			return comments;
		}
		public void setComments(String comments) {
			this.comments = comments;
		}
		public String getDocuments() {
			return documents;
		}
		public void setDocuments(String documents) {
			this.documents = documents;
		}
		public String getBankConfirmation() {
			return bankConfirmation;
		}
		public void setBankConfirmation(String bankConfirmation) {
			this.bankConfirmation = bankConfirmation;
		}
		public Long getFileUpldId() {
			return fileUpldId;
		}
		public void setFileUpldId(Long fileUpldId) {
			this.fileUpldId = fileUpldId;
		}
		public String getStatusCode() {
			return statusCode;
		}
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}
		public Long getStgId() {
			return stgId;
		}
		public void setStgId(Long stgId) {
			this.stgId = stgId;
		}
		public String getFailureReason() {
			return failureReason;
		}
		public void setFailureReason(String failureReason) {
			this.failureReason = failureReason;
		}
		public String gettCode() {
			return tCode;
		}
		public void settCode(String tCode) {
			this.tCode = tCode;
		}
		public String getStatusCodeDisplayName() {
			return statusCodeDisplayName;
		}
		public void setStatusCodeDisplayName(String statusCodeDisplayName) {
			this.statusCodeDisplayName = statusCodeDisplayName;
		}
		public String getCoCodeRejectReason() {
			return coCodeRejectReason;
		}
		public void setCoCodeRejectReason(String coCodeRejectReason) {
			this.coCodeRejectReason = coCodeRejectReason;
		}
		
		public BulkApprovalRequest(){
			super();
		}
		public BulkApprovalRequest(Long stgId){
			super();
			this.stgId=stgId;
			
		}
		@Override
		public String toString() {
			return "BulkApprovalRequest [accountStatus=" + accountStatus
					+ ", accountOpenDate1=" + accountOpenDate1
					+ ", accountOpenDate=" + accountOpenDate + ", accountType="
					+ accountType + ", companyCode=" + companyCode + ", me="
					+ me + ", iban=" + iban + ", componentCode="
					+ componentCode + ", accountPurpose=" + accountPurpose
					+ ", accountNumber=" + accountNumber + ", leCode=" + leCode
					+ ", country=" + country + ", currency=" + currency
					+ ", bankId=" + bankId + ", routeCode=" + routeCode
					+ ", routeCodeType=" + routeCodeType
					+ ", bankClassification=" + bankClassification
					+ ", cashpoolTCode=" + cashpoolTCode + ", accountTitle="
					+ accountTitle + ", bussName=" + bussName
					+ ", subBusiness=" + subBusiness + ", projectName="
					+ projectName + ", comments=" + comments + ", documents="
					+ documents + ", bankConfirmation=" + bankConfirmation
					+ ", fileUpldId=" + fileUpldId + ", statusCode="
					+ statusCode + ", stgId=" + stgId + ", failureReason="
					+ failureReason + ", tCode="
					+ tCode + ", accountReqId=" + accountReqId
					+ ", accountCloseDate=" + accountCloseDate
					+ ", accountCloseDate1=" + accountCloseDate1
					+ ", requestType=" + requestType
					+ ", statusCodeDisplayName=" + statusCodeDisplayName
					+ ", documentType=" + documentType + ", spbDocument="
					+ spbDocument + ", branchID=" + branchID + "]";
		}
		
		/**
		 * public BulkApprovalRequest(Date accountOpenDate1,String accountStatus,
				String accountOpenDate, String accountType, String companyCode,
				String me, String iban, String componentCode,
				String accountPurpose, String accountNumber, String leCode,
				String country, String currency, String bankId,
				String routeCode, String routeCodeType,
				String bankClassification, String cashpoolTCode,
				String accountTitle, String bussName, String subBusiness,
				String projectName, String comments, String documents,
				String bankConfirmation, Long fileUpldId, String statusCode,
				Long stgId, String failureReason, String tsaName, String tCode,Long accountReqId,String accountCloseDate) {
			super();
			this.accountOpenDate1=accountOpenDate1;
			this.accountStatus = accountStatus;
			this.accountOpenDate = accountOpenDate;
			this.accountType = accountType;
			this.companyCode = companyCode;
			this.me = me;
			this.iban = iban;
			this.componentCode = componentCode;
			this.accountPurpose = accountPurpose;
			this.accountNumber = accountNumber;
			this.leCode = leCode;
			this.country = country;
			this.currency = currency;
			this.bankId = bankId;
			this.routeCode = routeCode;
			this.routeCodeType = routeCodeType;
			this.bankClassification = bankClassification;
			this.cashpoolTCode = cashpoolTCode;
			this.accountTitle = accountTitle;
			this.bussName = bussName;
			this.subBusiness = subBusiness;
			this.projectName = projectName;
			this.comments = comments;
			this.documents = documents;
			this.bankConfirmation = bankConfirmation;
			this.fileUpldId = fileUpldId;
			this.statusCode = statusCode;
			this.stgId = stgId;
			this.failureReason = failureReason;
			this.tsaName = tsaName;
			this.tCode = tCode;
			this.accountReqId= accountReqId;
			this.accountCloseDate=accountCloseDate;
		}
		 *
		 */
		
		
		

}
