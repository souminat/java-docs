/**
 * 
 */
package com.ge.treasury.mybank.domain.bulkapproval;

import java.math.BigInteger;
import java.util.Date;

import com.ge.treasury.mybank.domain.accountrequest.BaseDomainObject;

/**
 * @author MyBank Dev Team
 * 
 */
public class BulkAccountSigner extends BaseDomainObject {
	      
              
	               
        
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tCode;
	 private String signerAction;
	 private String signerType;
	 private String signerName;
     private String ssoId;
     private String signerStartDate;
     private String signerEndDate;
     private Date signerStartDate1;
     private Date signerEndDate1;
     private Long acctReqID;
     private String docURL;
     private Long stgId;
     private Long fileUploadId;
     private String docName;
     private BigInteger folderId;
     private BigInteger fileId;
     private Long signerId;
     private String status;
     private String failureReason;
    
   
    public String getSignerAction() {
		return signerAction;
	}

	public void setSignerAction(String signerAction) {
		this.signerAction = signerAction;
	}

	public String gettCode() {
		return tCode;
	}
	
	 public void settCode(String tCode) {
			this.tCode = tCode;
		}

   
	public String getSsoId() {
        return ssoId;
    }

   
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

   
    public String getSignerType() {
        return signerType;
    }

    
    public void setSignerType(String signerType) {
        this.signerType = signerType;
    }

  
    public String getSignerName() {
        return signerName;
    }

  
    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

 
    public String getSignerStartDate() {
        return signerStartDate;
    }

   
    public void setSignerStartDate(String signerStartDate) {
        this.signerStartDate = signerStartDate;
    }

   
    public String getSignerEndDate() {
        return signerEndDate;
    }

  
    public void setSignerEndDate(String signerEndDate) {
        this.signerEndDate = signerEndDate;
    }

    
    public Long getAcctReqID() {
        return acctReqID;
    }

   
    public void setAcctReqID(Long acctReqID) {
        this.acctReqID = acctReqID;
    }


    public String getDocURL() {
        return docURL;
    }

   
    public void setDocURL(String docURL) {
        this.docURL = docURL;
    }

	public Long getFileUploadId() {
		return fileUploadId;
	}

	public void setFileUploadId(Long fileUploadId) {
		this.fileUploadId = fileUploadId;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public BigInteger getFolderId() {
		return folderId;
	}

	public void setFolderId(BigInteger folderId) {
		this.folderId = folderId;
	}

	public BigInteger getFileId() {
		return fileId;
	}

	public void setFileId(BigInteger fileId) {
		this.fileId = fileId;
	}

	public Long getSignerId() {
		return signerId;
	}

	public void setSignerId(Long signerId) {
		this.signerId = signerId;
	}

	public Long getStgId() {
		return stgId;
	}

	public void setStgId(Long stgId) {
		this.stgId = stgId;
	}

	public Date getSignerStartDate1() {
		return signerStartDate1;
	}

	public void setSignerStartDate1(Date signerStartDate1) {
		this.signerStartDate1 = signerStartDate1;
	}

	public Date getSignerEndDate1() {
		return signerEndDate1;
	}

	public void setSignerEndDate1(Date signerEndDate1) {
		this.signerEndDate1 = signerEndDate1;
	}

	public BulkAccountSigner() {
    	super();
    }

	public BulkAccountSigner(Long stgId) {
		super();
		this.stgId = stgId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

	@Override
	public String toString() {
		return "BulkAccountSigner [tCode=" + tCode + ", signerAction="
				+ signerAction + ", signerType=" + signerType + ", signerName="
				+ signerName + ", ssoId=" + ssoId + ", signerStartDate="
				+ signerStartDate + ", signerEndDate=" + signerEndDate
				+ ", signerStartDate1=" + signerStartDate1
				+ ", signerEndDate1=" + signerEndDate1 + ", acctReqID="
				+ acctReqID + ", docURL=" + docURL + ", stgId=" + stgId
				+ ", fileUploadId=" + fileUploadId + ", docName=" + docName
				+ ", folderId=" + folderId + ", fileId=" + fileId
				+ ", signerId=" + signerId
				+ ", status=" + status + ", failureReason=" + failureReason
				+ "]";
	}
	
	

}
