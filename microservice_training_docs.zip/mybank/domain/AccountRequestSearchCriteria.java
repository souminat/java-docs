package com.ge.treasury.mybank.domain;

import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import com.ge.treasury.mybank.util.business.constants.ValidationConstants;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountRequestSearchCriteria {

    public static final String ALL_PENDING_REQUESTS = "ACCTREQSTAT_ALLPENDING";
    public static final String ALL_REQUESTS = "ACCTREQSTAT_ALL";

    private String country;
    private String flag;
    private String tCode;
    private String requestType;
    private String accountTitle;
    private Integer start;
    private String orderBy;
    private String bankName;
    private Set<String> accountStatus;
    private String bankId;
    private String acctNumber;
    private String acctReqID;
    private String iban;
    private Integer limit;
    private Set<String> subBusName;
    private String currency;
    private String leName;
    private String leCode;
    private String leVersion;
    private Set<String> bussName;
    private String direction;
    private Integer max_trade_size;
    private String subtypeCode;
    private String assignedToSso;
    private String assignedToName;
    private String companyCode;
    private String meCode;
    private String accountPurpose;
    private String bankClassification;
    private String coCodeRejectReason;
    private String buCode;
    
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String gettCode() {
        return tCode;
    }

    public void settCode(String tCode) {
        this.tCode = tCode;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getAccountTitle() {
        return accountTitle;
    }

    public void setAccountTitle(String accountTitle) {
        this.accountTitle = accountTitle;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }
    
    @JsonProperty("requestStatus")
    public Set<String> getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(Set<String> accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getAcctNumber() {
        return acctNumber;
    }

    public void setAcctNumber(String acctNumber) {
        this.acctNumber = acctNumber;
    }

    public String getAcctReqID() {
        return acctReqID;
    }

    public void setAcctReqID(String acctReqID) {
        this.acctReqID = acctReqID;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Set<String> getSubBusName() {
        return subBusName;
    }

    public void setSubBusName(Set<String> subBusName) {
        this.subBusName = subBusName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getLeName() {
        return leName;
    }

    public void setLeName(String leName) {
        this.leName = leName;
    }

    public String getLeCode() {
        return leCode;
    }

    public void setLeCode(String leCode) {
        this.leCode = leCode;
    }

    public String getLeVersion() {
        return leVersion;
    }

    public void setLeVersion(String leVersion) {
        this.leVersion = leVersion;
    }

    public Set<String> getBussName() {
        return bussName;
    }

    public void setBussName(Set<String> bussName) {
        this.bussName = bussName;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Integer getMax_trade_size() {
        return max_trade_size;
    }

    public void setMax_trade_size(Integer max_trade_size) {
        this.max_trade_size = max_trade_size;
    }
    
    /**
     * 
     * @param subtypeCode
     */
    public void setSubtypeCode(String subtypeCode) {
        this.subtypeCode = subtypeCode;
    }
    
    /**
     * 
     * @return
     */
    public String getSubtypeCode() {
        return subtypeCode;
    }
    
    public String getAssignedToSso() {
		return assignedToSso;
	}

	public void setAssignedToSso(String assignedToSso) {
		this.assignedToSso = assignedToSso;
	}

	public String getAssignedToName() {
		return assignedToName;
	}

	public void setAssignedToName(String assignedToName) {
		this.assignedToName = assignedToName;
	}

    public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getMeCode() {
		return meCode;
	}

	public void setMeCode(String meCode) {
		this.meCode = meCode;
	}

	public String getAccountPurpose() {
		return accountPurpose;
	}

	public void setAccountPurpose(String accountPurpose) {
		this.accountPurpose = accountPurpose;
	}

	
	public String getBankClassification() {
		return bankClassification;
	}

	public void setBankClassification(String bankClassification) {
		this.bankClassification = bankClassification;
	}

	public String getCoCodeRejectReason() {
		return coCodeRejectReason;
	}

	public void setCoCodeRejectReason(String coCodeRejectReason) {
		this.coCodeRejectReason = coCodeRejectReason;
	}
	
	public void setBuCode(String buCode) {
        this.buCode = buCode;
    }
	
	public String getBuCode() {
        return buCode;
    }

	@SuppressWarnings("unchecked")
    public Map<String, Object> toMap() {
        if (accountStatus != null && accountStatus.iterator().hasNext()) {
            String status = accountStatus.iterator().next();
            if (ALL_PENDING_REQUESTS.equalsIgnoreCase(status)) {
                accountStatus.clear();
                this.accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
                this.accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
            } else if (ALL_REQUESTS.equalsIgnoreCase(status)) {
                accountStatus.clear();
                this.accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
                this.accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
                this.accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_CANCELLED);
                this.accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
            }
        }
        ObjectMapper mapper = new ObjectMapper()
                .setSerializationInclusion(Inclusion.NON_EMPTY);
        return mapper.convertValue(this, Map.class);
    }
}
