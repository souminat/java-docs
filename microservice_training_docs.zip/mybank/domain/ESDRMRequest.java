package com.ge.treasury.mybank.domain;

public class ESDRMRequest {
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
