package com.ge.treasury.mybank.domain;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BulkApprovalSearchCriteria {
	private Integer start;
	private Integer limit;
	private Integer max_trade_size;
	private String direction;
	private String orderBy;
	private Long fileUpldId;
	private String upldStatusCode;
	private String upldTypeCode;
	private Long errorRecordCount;
	private Long totalCount;
	private String fileName;
	private String upldUserSSO;
	private String checksumOfFile;
	private String uploadedFile;
	private String uploadedFileJString;
	private String comments;
	@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL, using = com.ge.treasury.mybank.util.business.JsonDateTimeSerializer.class)
	private Date lastUpdated;

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public Long getFileUpldId() {
		return fileUpldId;
	}

	public void setFileUpldId(Long fileUpldId) {
		this.fileUpldId = fileUpldId;
	}

	public String getUpldStatusCode() {
		return upldStatusCode;
	}

	public void setUpldStatusCode(String upldStatusCode) {
		this.upldStatusCode = upldStatusCode;
	}

	public String getUpldTypeCode() {
		return upldTypeCode;
	}

	public void setUpldTypeCode(String upldTypeCode) {
		this.upldTypeCode = upldTypeCode;
	}

	public Long getErrorRecordCount() {
		return errorRecordCount;
	}

	public void setErrorRecordCount(Long errorRecordCount) {
		this.errorRecordCount = errorRecordCount;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getUpldUserSSO() {
		return upldUserSSO;
	}

	public void setUpldUserSSO(String upldUserSSO) {
		this.upldUserSSO = upldUserSSO;
	}

	public String getChecksumOfFile() {
		return checksumOfFile;
	}

	public void setChecksumOfFile(String checksumOfFile) {
		this.checksumOfFile = checksumOfFile;
	}

	public String getUploadedFile() {
		return uploadedFile;
	}

	public void setUploadedFile(String uploadedFile) {
		this.uploadedFile = uploadedFile;
	}

	public String getUploadedFileJString() {
		return uploadedFileJString;
	}

	public void setUploadedFileJString(String uploadedFileJString) {
		this.uploadedFileJString = uploadedFileJString;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Integer getStart() {
		return start;
	}

	public void setStart(Integer start) {
		this.start = start;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public Integer getMax_trade_size() {
		return max_trade_size;
	}

	public void setMax_trade_size(Integer max_trade_size) {
		this.max_trade_size = max_trade_size;
	}

}
