package com.ge.treasury.mybank.domain;

import java.io.Serializable;
import java.util.List;

public class PaginatedResultList<T> implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -4414455806731455477L;

    int totalRecords;

    String requestQueryString;

    transient List<T> resultList;

    /**
     * @return the totalRecords
     */
    public int getTotalRecords() {
        return totalRecords;
    }

    /**
     * @param totalRecords
     *            the totalRecords to set
     */
    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    /**
     * @return the requestQueryString
     */
    public String getRequestQueryString() {
        return requestQueryString;
    }

    /**
     * @param requestQueryString
     *            the requestQueryString to set
     */
    public void setRequestQueryString(String requestQueryString) {
        this.requestQueryString = requestQueryString;
    }

    /**
     * @return the resultList
     */
    public List<T> getResultList() {
        return resultList;
    }

    /**
     * @param resultList
     *            the resultList to set
     */
    public void setResultList(List<T> resultList) {
        this.resultList = resultList;
    }
}