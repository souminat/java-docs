package com.ge.treasury.mybank.dataaccess.platforminstance.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.PlatformInstanceMapper;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
/**
 * Contains the details of Platform Instance mapping
 * 
 * @author MyBank Development Team
 * 
 */
@Component
public class PlatformInstanceDaoImpl implements PlatformInstanceDao {
    
    @Autowired
    private PlatformInstanceMapper platformInstanceMapper;

    @Override
    public List<PlatformInstance> getAllPlatformInstance() {
        try {
            MyBankLogger.logDebug(this, "PlatformInstanceMapper.getAllPlatformInstance method start");
            return platformInstanceMapper.getAllPlatformInstance();
        } catch (Exception ex) {
            MyBankLogger.logError(this,
                    "PlatformInstanceMapper.getAllPlatformInstance: " + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Platform Instance information (all). For more "
                            + "information please check the log file.");
        }
    }

}
