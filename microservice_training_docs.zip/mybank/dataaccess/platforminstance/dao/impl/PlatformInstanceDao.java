package com.ge.treasury.mybank.dataaccess.platforminstance.dao.impl;

import java.util.List;

import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;

public interface PlatformInstanceDao {
    
    List<PlatformInstance> getAllPlatformInstance();

}
