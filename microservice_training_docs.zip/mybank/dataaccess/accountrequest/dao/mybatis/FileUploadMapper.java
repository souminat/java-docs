package com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;

public interface FileUploadMapper {

	/**
	 * Insert File Upload
	 * 
	 * @param fileUpload
	 * @return
	 */
	int insertFileUpload(@Param("fileUpload") FileUpload fileUpload);

	FileUpload getFileUploadById(@Param("fileUploadId") Long fileUploadId);

	FileUpload getFileUploadDetails(@Param("fileUploadId") Long fileUploadId);

	List<FileUpload> loadProcessingQueueSortBy(@Param("bulkApprovalSearch") BulkApprovalSearchCriteria bulkApprovalSearch);

	
	List<FileUpload> getApprovalExportData(@Param("searchCriteria") BulkApprovalSearchCriteria searchCriteria);

	List<FileUpload> getFileUploadByFilter(@Param("searchCriteria") BulkApprovalSearchCriteria searchCriteria);
	
	Long fetchFileUploadNextSeq();
	
	int insertBulkApprovalRecord(@Param("acct") BulkApprovalRequest acct);

	int updateBulkApprovalStageRecord(@Param("acct") BulkApprovalRequest acct);
	
	int insertFileUploadActivity(@Param("fileUploadActivity") FileUploadActivity fileUploadActivity);

	List<FileUploadActivity> getFileUploadActivityDetailsById(@Param("fileUploadId") Long uploadId);

	int updateFileUploadStatus(@Param("fileUpload") FileUpload fileUpload);
	
	int updateFileUploadRecord(@Param("fileUpload") FileUpload fileUpload);

	List<BulkApprovalRequest> getFileUploadStagingDetails(@Param("bulkApprovalRequest") BulkApprovalRequest bulkApprovalRequest);

		
	int insertSignersToStaging(@Param("bulkAccountSigner")BulkAccountSigner bulkAccountSigner);
	
	int updateSignersToStaging(@Param("bulkAccountSigner")BulkAccountSigner bulkAccountSigner);
	List<BulkAccountSigner> getSignerStagingDetails(@Param("bulkAccountSigner") BulkAccountSigner bulkAccountSigner);
	
}
