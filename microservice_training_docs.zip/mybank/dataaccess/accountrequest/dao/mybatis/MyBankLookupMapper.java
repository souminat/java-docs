/**
 * 
 */
package com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;

/**
 * @author MyBank Dev Team
 * 
 */
public interface MyBankLookupMapper {

    /**
     * Calls getAllLov method in mapper xml
     * 
     * @param orderBy
     * @param direction
     * @return List<Lov>
     */
    List<MyBankLookup> getAllLov(@Param("orderBy") String orderBy,
            @Param("direction") String direction);

    /**
     * Calls getLovsByLookupType method in mapper xml
     * 
     * @param lookupType
     * @param orderBy
     * @param direction
     * @return List<Lov>
     */
    List<MyBankLookup> getLovsByLookupType(
            @Param("lookupType") String lookupType,
            @Param("orderBy") String orderBy,
            @Param("direction") String direction);

    /**
     * Calls getLovsByLookupTypeList method in mapper xml
     * 
     * @param lookupTypes
     * @param orderBy
     * @param direction
     * @return List<Lov>
     */
    List<MyBankLookup> getLovsByLookupTypeList(
            @Param("lookupTypes") List<String> lookupTypes,
            @Param("orderBy") String orderBy,
            @Param("direction") String direction);

    /**
     * Get DisplayName- sending lookup Code
     * 
     * @param code
     * @return
     */
    String getDisplayName(@Param("code") String code);
    
    String getLookupCode(@Param("code") String code);


}
