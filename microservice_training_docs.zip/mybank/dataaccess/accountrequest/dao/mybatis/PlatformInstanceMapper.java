package com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis;

import java.util.List;

import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;

public interface PlatformInstanceMapper {

    List<PlatformInstance> getAllPlatformInstance();
}
