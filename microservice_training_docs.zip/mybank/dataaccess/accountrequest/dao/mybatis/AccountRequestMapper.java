/**
 * 
 */
package com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;

/**
 * @author MyBank Dev Team
 * 
 */
public interface AccountRequestMapper {

    /**
     * Calls insertAccountRequest method in mapper xml
     * 
     * @param accRequest
     * @return int
     */
    int insertAccountRequest(@Param("accRequest") AccountRequest accRequest);

    /**
     * Calls insertComment method in mapper xml
     * 
     * @param comment
     * @return
     */
    int insertComment(@Param("comment") AccountComment comment);

    /**
     * Calls insertSigner method in mapper xml
     * 
     * @param signer
     * @return
     */
    int insertSigner(@Param("signer") AccountSigner signer);

    /**
     * Calls insertCashPoolProcess method in mapper xml
     * 
     * @param cashPoolProcess
     * @return
     */
    int insertCashPoolProcess(@Param("cashPool") CashPoolProcess cashPoolProcess);

    
    int updateCashPoolProcess(@Param("cashPoolReq") CashPoolProcess cashPoolReq);

    /**
     * Calls searchAccountRequests method in mapper xml
     * 
     * @param start
     * @param limit
     * @param direction
     * @param orderBy
     * @param maxTradesSize
     * @return List<AccountRequest>
     */
    List<AccountRequest> searchAccountRequests(@Param("searchMap") Map<String, Object> searchMap);

    int searchPendingAccountRequests();

    /**
     * Calls updateAccountRequest method in mapper xml
     * 
     * @param accRequest
     */
    void updateAccountRequest(@Param("accRequest") AccountRequest accRequest);

    /**
     * 
     * @param acctReqID
     * @return
     */
    AccountRequest searchAccountRequest(@Param("acctReqID") Long acctReqID);

    /**
     * Calls insertFlag method in mapper xml
     * 
     * @param flag
     * @return
     */
    int insertFlag(@Param("flag") AccountFlag flag);

    /**
     * Calls updateFlag method in mapper xml
     * 
     * @param flag
     * @return
     */
    int updateFlag(@Param("flag") AccountFlag flag);

    /**
     * Calls insertDocument method in mapper xml
     * 
     * @param document
     * @return
     */
    int insertDocument(@Param("document") AccountDocument document);

    /**
     * Calls updateSigner in mapper xml
     * 
     * @param signer
     */
    int updateDocument(@Param("accDocument") AccountDocument document);

    void updateSigner(@Param("accSigner") AccountSigner signer);

    List<AccountSigner> searchAccountSignersBulk(@Param("accSigner") AccountSigner signer);

    /**
     * Calls searchAccountDocuments to get updated documents record
     * 
     * @param acctReqID
     *
     */
    List<AccountDocument> searchAccountDocuments(@Param("accDoc") AccountDocument document);

    AccountDocument getDocumentByFileId(@Param("fileID") String fileId);

    /**
     * Calls getLastUpdatedTimeStamp in mapper xml
     * 
     * @param acctReqID
     */

    LastUpdatedDetails getLastUpdatedDetails(@Param("acctReqID") Long acctReqID);

    /**
     * 
     * @param tCode
     * @return
     */
    List<AccountComment> getCommentsByTcode(@Param("tCode") String tCode);

    /**
     * 
     * @param tCode
     * @return
     */
    String getRequestIdByTcode(@Param("tCode") String tCode);

    /**
     * 
     * @param acctReqId
     * @param tCode
     * @return
     */
    Long getPendingCloseOrModifyByTcode(@Param("tCode") String tCode);

    /**
     * 
     * @param acctReqID
     * @return
     */
    String getSubfolderID(@Param("acctReqID") Long acctReqID);

    List<AccountFlag> searchActiveAccountFlags(@Param("ACCOUNT_REQUEST_ID") Long acctReqID);

    AccountRequest searchActiveAccountRequest(@Param("ACCOUNT_REQUEST_ID") Long acctReqID);

    /**
     * Calls getAllDocuments in mapper xml
     * 
     * @param acctReqID
     */
    List<AccountDocument> getAllDocuments(String acctReqID);

    List<AccountRequest> getExportData(@Param("searchMap") Map<String, Object> searchMap);

    void assignRequestToUser(@Param("accRequest") AccountRequest account);

    AccountRequest searchAccountByCombination(@Param("searchMap") Map<String, Object> searchMap);

    AccountRequest searchAccountRequestsForClose(@Param("searchMap") Map<String, Object> searchMap);
    
       
    List<CashPoolProcess> searchCashPoolProcessByRequestID (@Param("requestid")String requestid);
    
    List<CashPoolProcess> searchCashPoolProcessCommon(@Param("cashPoolProcess")CashPoolProcess cashPoolProcess);
    
    
    Long getLastUpdatedPlatformInstance(@Param("tCode") String tCode);

    List<Map<String, String>> getBusSubbus(@Param("code") String code);

    List<Map<String, String>> getBuCodes(@Param("code") String code);
}
