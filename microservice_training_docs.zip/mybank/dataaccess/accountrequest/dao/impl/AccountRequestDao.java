package com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl;

import java.util.List;
import java.util.Map;

import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface AccountRequestDao {

    /**
     * Inserts Account Request given data into DB and returns the same Account
     * Request just inserted
     * 
     * @param accRequest
     * @return
     * @throws DBException
     */
    public AccountRequest saveAccountRequest(User user,
            AccountRequest accRequest);

    /**
     * Inserts Comments given data into DB and returns the same inserted
     * 
     * @param comment
     * @return
     * @throws DBException
     */
    public AccountComment saveComment(User user, AccountComment comment);

    /**
     * Inserts Signers given data into DB and returns the same inserted
     * 
     * @param signer
     * @return
     * @throws DBException
     */
    public AccountSigner saveSigner(User user, AccountSigner signer);
	
	/**
     * Inserts CashPool process given data into DB and returns the same inserted
     * 
     * @param cashPoolProcess
     * @return
     * @throws DBException
     */
    public CashPoolProcess saveCashPoolProcess(User user, CashPoolProcess cashPoolProcess);

    /**
     * Inserts Flag given data into DB and returns the same inserted
     * 
     * @param flag
     * @return
     * @throws DBException
     */
    public AccountFlag saveAccountFlag(User user, AccountFlag flag);

    /**
     * Method to save the Account Documents
     * 
     * @param document
     * @return
     * @throws DBException
     */
    public AccountDocument saveAccountDocument(User user,
            AccountDocument document);

    /**
     * 
     * @param user
     * @param searchMap
     * @param start
     * @param limit
     * @param direction
     * @param orderBy
     * @param maxTradesSize
     * @return
     * @throws DBException
     */
    public List<AccountRequest> findAccounts(User user,
            Map<String, Object> searchMap);
    
    public int getPendingRequests();

    /**
     * Method to Update the Account Request
     * 
     * @param accRequest
     * @throws DBException
     */
    public AccountRequest updateAccountRequest(User user,
            AccountRequest accRequest);
    
    /**
    * Method to search the Account Request Flags
    * 
    * @param accRequest
    * @throws DBException
    */
   public List<AccountFlag> searchAccountFlags(long acctReqID);
  
   public AccountRequest searchAccountRequest(long acctReqID);
    
    /**
     * Method to Update the Account Flag
     * 
     * @param flag
     * @return
     * @throws DBException
     */
    public AccountFlag updateAccountFlag(User user, AccountFlag flag);

    /**
     * Method to Get individual accounts
     * 
     * @param user
     * @param searchMap
     * @return
     * @throws DBException
     */
    public AccountRequest findAccount(User user, Map<String, Object> searchMap);

    /**
     * Method to Update individual signers
     * 
     * @param accSigner
     * @throws DBException
     */
    public void updateAccountSigner(User user, AccountSigner accSigner);

    /**
     * Method to get Last Updated Timestamp for particular request
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    public LastUpdatedDetails getLastUpdatedDetails(Long acctReqID);

    /**
     * 
     * @param tCode
     * @return
     * @throws DBException
     */
    public List<AccountComment> getCommentsByTcode(String tCode);

    /**
     * 
     * @param tCode
     * @return
     * @throws DBException
     */
    public String getRequestIdByTcode(String tCode) ;

    /**
     * 
     * @param acctReqId
     * @param tCode
     * @return
     * @throws DBException
     */
    public Long getPendingCloseOrModifyByTcode(String tCode) ;

    /**
     * 
     * @param acctReqID
     * @return
     * @throws DBException
     */
    public String getSubFolderID(long acctReqID) ;
    
    public List<AccountRequest> getExportData(Map<String, Object> searchMap);

    public Boolean assignRequestToUser(AccountRequest account);
    
    public List<AccountSigner> findSignerById(AccountSigner acctSigner);

    public AccountDocument getDocumentByFileId(String fileId) ;
    
	public AccountDocument updateDocument(User user, AccountDocument document);
	
	
	public List<CashPoolProcess> searchCashPoolProcessByRequestID (String requestId);

	public List<CashPoolProcess> selectCashPoolProcess(CashPoolProcess cashPoolProcess);

	public int updateCashPoolProcessData(CashPoolProcess cashPoolReq);
	
	
	/**
	 * Get the platform instance for a given tcode.
	 * This is required to retain the platform instance for the given tcode.
	 * 
	 * @param tCode
	 * @return
	 */
	Long getLastUpdatedPlatformInstance(String tCode);

	List<Map<String, String>> getBusSubbus(String code);

    List<Map<String, String>> getBuCodes(String code);
}
