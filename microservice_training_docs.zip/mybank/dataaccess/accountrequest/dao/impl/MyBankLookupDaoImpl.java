package com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.MyBankLookupMapper;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.BusinessExceptionConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Contains the implementation of MyBankLookupDao methods
 * 
 * @author MyBank Development Team
 * 
 */
@Component
public class MyBankLookupDaoImpl implements MyBankLookupDao,
        BusinessExceptionConstants {

    @Autowired
    private MyBankLookupMapper lovMapper;

    /**
     * @return the lovMapper
     */
    public MyBankLookupMapper getLovMapper() {
        return lovMapper;
    }

    /**
     * @param lovMapper
     *            the lovMapper to set
     */
    public void setLovMapper(MyBankLookupMapper lovMapper) {
        this.lovMapper = lovMapper;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.MyBankLookupDao
     * #getAllLov(java.lang.String, java.lang.String)
     */
    @Override
    public List<MyBankLookup> getAllLov(String orderBy, String direction)
            throws DBException {
        try {
            MyBankLogger.logDebug(this, "LovMapper.getAllLov method start");
            return lovMapper.getAllLov(orderBy, direction);
        } catch (Exception ex) {
            MyBankLogger.logError(this,
                    "LovMapper.getAllLov: " + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Lookup information (all). For more "
                            + "information please check the log file.");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.MyBankLookupDao
     * #getLovsByLookupTypeList(java.util.List, java.lang.String,
     * java.lang.String)
     */
    @Override
    public List<MyBankLookup> getLovsByLookupTypeList(List<String> lookupTypes,
            String orderBy, String direction) throws DBException {
        try {
            MyBankLogger.logDebug(this,
                    "LovMapper.getLovsByLookupTypeList method start");
            return lovMapper.getLovsByLookupTypeList(lookupTypes, orderBy,
                    direction);
        } catch (Exception ex) {
            MyBankLogger.logError(this, "LovMapper.getLovsByLookupTypeList: "
                    + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Lookup information (by type list). For more "
                            + "information please check the log file.");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.MyBankLookupDao
     * #getLovsByLookupType(java.lang.String, java.lang.String,
     * java.lang.String)
     */
    @Override
    public List<MyBankLookup> getLovsByLookupType(String lookupType,
            String orderBy, String direction) throws DBException {
        try {
            MyBankLogger.logDebug(this,
                    "LovMapper.getLovsByLookupType method start");
            return lovMapper
                    .getLovsByLookupType(lookupType, orderBy, direction);
        } catch (Exception ex) {
            MyBankLogger.logError(this,
                    "LovMapper.getLovsByLookupType: " + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Lookup information (by type). For more "
                            + "information please check the log file.");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.MyBankLookupDao
     * #getDisplayName(java.lang.String)
     */
    @Override
    public String getDisplayName(String code) throws DBException {
        try {
            MyBankLogger
                    .logDebug(this, "LovMapper.getDisplayName method start");
            return lovMapper.getDisplayName(code);
        } catch (Exception ex) {
            MyBankLogger.logError(this,
                    "LovMapper.getDisplayName: " + ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get DisplayName Lookup information (by type). For more "
                            + "information please check the log file.");
        }
    }
    
    @Override
	public String getLookupCode(String code) throws DBException {
		 try {
	            MyBankLogger
	                    .logDebug(this, "LovMapper.getLookupCode method start");
	            return lovMapper.getLookupCode(code);
	        } catch (Exception ex) {
	            MyBankLogger.logError(this,
	                    "LovMapper.getLookupCode: " + ex.getMessage(), ex);
	            throw new DBException(
	                    "Unable to get LookupCode Lookup information (by type). For more "
	                            + "information please check the log file.");
	        }
	}

}
