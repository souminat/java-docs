package com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl;

import java.util.List;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Interface class that has the following methods.
 * 
 * @author MyBank Dev Team
 * 
 */
public interface MyBankLookupDao {

    /**
     * Get all lookup data from db in a specific order and direction
     * 
     * @param orderBy
     * @param direction
     * @return List<Lov>
     */
    public List<MyBankLookup> getAllLov(String orderBy, String direction)
            throws DBException;

    /**
     * Get a list of lookup data from db by a list of lookup types in a specific
     * order and direction
     * 
     * @param lookupTypes
     * @param orderBy
     * @param direction
     * @return
     */
    public List<MyBankLookup> getLovsByLookupTypeList(List<String> lookupTypes,
            String orderBy, String direction) throws DBException;

    /**
     * Get a list of lookup data from db by a specific lookup type in a specific
     * order and direction
     * 
     * @param lookupType
     * @param orderBy
     * @param direction
     * @return
     * @throws DBException
     */
    public List<MyBankLookup> getLovsByLookupType(String lookupType,
            String orderBy, String direction) throws DBException;

    /**
     * Get DisplayName
     * 
     * @param code
     * @return
     * @throws DBException
     */
    public String getDisplayName(String code) throws DBException;
    
    public String getLookupCode(String code) throws DBException;

}
