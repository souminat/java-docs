package com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.dataaccess.accountrequest.dao.mybatis.AccountRequestMapper;
import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.AccountFlag;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.AccountSigner;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.BusinessExceptionConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * Contains the implementation of AccountRequestDao methods
 * 
 * @author MyBank Development Team
 * 
 */
@Component
public class AccountRequestDaoImpl implements AccountRequestDao,
        BusinessExceptionConstants {

    @Autowired
    private AccountRequestMapper accountMapper;

    /*
     * Inserts Account Request given data into DB and returns the same Request
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #saveAccountRequest(com.ge.treasury.mybank.domain.accountrequest.
     * AccountRequest, com.ge.treasury.mybank.domain.accountrequest.User)
     */
    @Override
    public AccountRequest saveAccountRequest(User user,
            AccountRequest accRequest) {

        try {
            accRequest.setCreateDate(new Date());
            accRequest.setCreateUser(user.getUserProfile().getSso());
            accRequest.setLastUpdateDate(new Date());
            accRequest.setLastUpdateUser(user.getUserProfile().getSso());
            accountMapper.insertAccountRequest(accRequest);

        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to save account information (Account Request). For more "
                            + "information please check the log file.");
        }
        return accRequest;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #findAccounts (com.ge.treasury.mybank.domain.accountrequest.User,
     * java.util.Map)
     */
    @Override
    public List<AccountRequest> findAccounts(User user,
            Map<String, Object> searchMap) {

        return accountMapper.searchAccountRequests(searchMap);
    }
    
    @Override
    public int getPendingRequests() {

        return accountMapper.searchPendingAccountRequests();
    }

    /*
     * Inserts Comments (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #saveComments(com.ge.treasury.mybank.domain.accountrequest.Comment)
     */
    @Override
    public AccountComment saveComment(User user, AccountComment comment) {
        try {
            comment.setCreateDate(new Date());
            comment.setCreateUser(user.getUserProfile().getSso());
            accountMapper.insertComment(comment);

        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to save comments (on Comments table). For more "
                            + "information please check the log file.");
        }
        return comment;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #saveSigner(com.ge.treasury.mybank.domain.accountrequest.AccountSigner)
     */
    @Override
    public AccountSigner saveSigner(User user, AccountSigner signer) {
        try {
            signer.setCreateDate(new Date());
            signer.setCreateUser(user.getUserProfile().getSso());
            signer.setLastUpdateDate(new Date());
            signer.setLastUpdateUser(user.getUserProfile().getSso());

            accountMapper.insertSigner(signer);

        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to save signer (on Signer table). For more "
                            + "information please check the log file.");
        }
        return signer;
    }
	
	/* (non-Javadoc)
     * @see com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao#saveCashPoolProcess(com.ge.treasury.mybank.domain.user.User, com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess)
     */
    @Override
    public CashPoolProcess saveCashPoolProcess(User user, CashPoolProcess cashPoolProcess){
        try {
            cashPoolProcess.setCreateDate(new Date());
            cashPoolProcess.setCreateUser(user.getUserProfile().getSso());
            cashPoolProcess.setLastUpdateDate(new Date());
            cashPoolProcess.setLastUpdateUser(user.getUserProfile().getSso());

            accountMapper.insertCashPoolProcess(cashPoolProcess);

        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to save cash pool information (on CashPoolProcess table). For more "
                            + "information please check the log file.");
        }
        return cashPoolProcess;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #updateAccountRequest(com.ge.treasury.mybank.domain.accountrequest.
     * AccountRequest)
     */
    @Override
    public AccountRequest updateAccountRequest(User user,
            AccountRequest accRequest) {
        try {
            accRequest.setLastUpdateDate(new Date());
            accRequest.setLastUpdateUser(user.getUserProfile().getSso());
            accountMapper.updateAccountRequest(accRequest);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to save account information (Account Request). For more information please check the log file.");
        }
        return accRequest;
    }
    
    
    @Override
    public List<AccountFlag> searchAccountFlags(long acctReqID)
    {
        try {
            return accountMapper.searchActiveAccountFlags(acctReqID);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException("Unable to save account flags (on Cancel Request). For more information please check the log file.");
        }
    }
    
    @Override
    public AccountRequest searchAccountRequest(long acctReqID)
    {
        try {
            return accountMapper.searchActiveAccountRequest(acctReqID);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException("Unable to save account flags (on Cancel Request). For more information please check the log file.");
        }
    }

    /*
     * Method to Get individual accounts (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #findAccount (com.ge.treasury.mybank.domain.accountrequest.User,
     * java.util.Map)
     */
    @Override
    public AccountRequest findAccount(User user, Map<String, Object> searchMap) {

        searchMap.put("start", "1");
        searchMap.put("limit", "1");

        List<AccountRequest> accountRequestList = this.findAccounts(user,
                searchMap);

        AccountRequest result = null;

        if (!accountRequestList.isEmpty()) {
            result = accountRequestList.get(0);
        }

        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #saveFlag(com.ge.treasury.mybank.domain.accountrequest.AccountFlag)
     */
    @Override
    public AccountFlag saveAccountFlag(User user, AccountFlag flag) {
        try {
            flag.setCreateDate(new Date());
            flag.setCreateUser(user.getUserProfile().getSso());
            flag.setLastUpdateDate(new Date());
            flag.setLastUpdateUser(user.getUserProfile().getSso());

            accountMapper.insertFlag(flag);

        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to save flag information (Account Flag). For more "
                            + "information please check the log file.");
        }
        return flag;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #
     * updateAccountFlag(com.ge.treasury.mybank.domain.accountrequest.AccountFlag
     * )
     */
    @Override
    public AccountFlag updateAccountFlag(User user, AccountFlag flag) {
        try {
            flag.setLastUpdateDate(new Date());
            flag.setLastUpdateUser(user.getUserProfile().getSso());
            accountMapper.updateFlag(flag);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to Update account flag information. For more information please check the log file.");
        }
        return flag;
    }

    /*
     * 
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #saveDocument
     * (com.ge.treasury.mybank.domain.accountrequest.AccountDocument)
     */
    @Override
    public AccountDocument saveAccountDocument(User user,
            AccountDocument document) {

        try {
            document.setCreateDate(new Date());
            document.setCreateUser(user.getUserProfile().getSso());
            document.setLastUpdateDate(new Date());
            document.setLastUpdateUser(user.getUserProfile().getSso());

            accountMapper.insertDocument(document);

        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException("Unable to save document. For more "
                    + "information please check the log file.");
        }
        return document;
    }

    /*
     * Method to Update individual signers (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #updateAccountSigner
     * (com.ge.treasury.mybank.domain.accountrequest.AccountSigner)
     */
    @Override
    public void updateAccountSigner(User user, AccountSigner acctSigner) {
        try {
            acctSigner.setLastUpdateDate(new Date());
            acctSigner.setLastUpdateUser(user.getUserProfile().getSso());
            accountMapper.updateSigner(acctSigner);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to Update account signer information. For more information please check the log file.");
        }
    }

    @Override
    public List<AccountSigner> findSignerById(AccountSigner acctSigner) {
        try {
            return accountMapper.searchAccountSignersBulk(acctSigner);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to Update account signer information. For more information please check the log file.");
        }
    }
    
    /*
     * DAO Method to get Last Updated TimeStamp for particular Request
     * (non-Javadoc)
     * 
     * @see
     * com.ge.treasury.mybank.dataaccess.accountrequest.dao.impl.AccountRequestDao
     * #getLastUpdatedTimeStamp (java.lang.Long)
     */
    @Override
    public LastUpdatedDetails getLastUpdatedDetails(Long acctReqID) {
        LastUpdatedDetails lastUpdatedDetails = null;
        try {
            if (acctReqID != null)
                lastUpdatedDetails = accountMapper
                        .getLastUpdatedDetails(acctReqID);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Last Updated TimeStamp. For more information please check the log file.");
        }
        return lastUpdatedDetails;
    }

    @Override
    public List<AccountComment> getCommentsByTcode(String tCode) {
        List<AccountComment> comments = new ArrayList<AccountComment>();
        try {
            if (tCode != null)
                comments = accountMapper.getCommentsByTcode(tCode);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get comments. For more information please check the log file.");
        }
        return comments;
    }

    @Override
    public String getRequestIdByTcode(String tCode) {
        String requestId = null;
        try {
            if (tCode != null)
                requestId = accountMapper.getRequestIdByTcode(tCode);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get Request ID. For more information please check the log file.");
        }
        return requestId;
    }

    @Override
    public Long getPendingCloseOrModifyByTcode(String tCode) {
        try {
            return accountMapper.getPendingCloseOrModifyByTcode(tCode);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException("Unable to get count");
        }
    }

    @Override
    public String getSubFolderID(long acctReqID) {
        try {
            return accountMapper.getSubfolderID(acctReqID);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException("Unable to get the folder ID");
        }
    }
    
    @Override
    public List<AccountRequest> getExportData(Map<String, Object> searchMap) {
        return accountMapper.getExportData(searchMap);
    }

	@Override
	public Boolean assignRequestToUser(AccountRequest account) {
		accountMapper.assignRequestToUser(account);
		return true;
	}

	@Override
	public AccountDocument updateDocument(User user, AccountDocument document) {
		
	   try{
		  document.setCreateDate(new Date());
          document.setCreateUser(user.getUserProfile().getSso());
          document.setLastUpdateDate(new Date());
          document.setLastUpdateUser(user.getUserProfile().getSso());
          accountMapper.updateDocument(document);
	   }
	   catch (Exception ex) {
         MyBankLogger.logError(this, ex.getMessage(), ex);
         throw new DBException("Unable to save document. For more "
                 + "information please check the log file.");
     }
     return document;
}

	@Override
	public AccountDocument getDocumentByFileId(String fileId) {
		  try {
	            return accountMapper.getDocumentByFileId(fileId);
	        } catch (Exception ex) {
	            MyBankLogger.logError(this, ex.getMessage(), ex);
	            throw new DBException(
	                    "Unable to fetch document record. For more information please check the log file.");
	        }
	}


	@Override
	public int updateCashPoolProcessData(CashPoolProcess cashPoolReq) {
	    try {
	        return accountMapper.updateCashPoolProcess(cashPoolReq);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to update cash pool process record. For more information please check the log file.");
        }
	}
	
	
	
	@Override
	public List<CashPoolProcess> searchCashPoolProcessByRequestID (String requestId){
		return accountMapper.searchCashPoolProcessByRequestID(requestId);
	}
	
	@Override
	public List<CashPoolProcess> selectCashPoolProcess(CashPoolProcess cashPoolProcess){
		return accountMapper.searchCashPoolProcessCommon(cashPoolProcess);
	}
	
	@Override
    public Long getLastUpdatedPlatformInstance(String tCode) {
        try {
            return accountMapper.getLastUpdatedPlatformInstance(tCode);
        } catch (Exception ex) {
            MyBankLogger.logError(this, ex.getMessage(), ex);
            throw new DBException(
                    "Unable to get the platform instance data for the given tcode. For more information please check the log file.");
        }
    }

    @Override
    public List<Map<String, String>> getBusSubbus(String code) {
        return accountMapper.getBusSubbus(code);
    }

    @Override
    public List<Map<String, String>> getBuCodes(String code) {
        return accountMapper.getBuCodes(code);
    }

}
