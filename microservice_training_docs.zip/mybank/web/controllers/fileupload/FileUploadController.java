package com.ge.treasury.mybank.web.controllers.fileupload;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadService;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.FileUploadParameters;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.web.SanatizedServletRequest;
import com.ge.treasury.mybank.web.controllers.BaseController;

@Controller
@RequestMapping(FileUploadConstants.API)
public class FileUploadController extends BaseController implements
        FileUploadConstants {

    @Autowired
    FileUploadService fileUploadService;

    @Value(APPLICATIONID)
    private String applicationId;
    @Value(USERID)
    private String defaultUserId;
    @Value(PASSWORD)
    private String applicationPassword;
    @Value(LOCALDIRECTORY)
    private String localDirectory;
    @Value(DEFAULTFOLDERID)
    private String defaultFolderId;
    @Value("#{'${mybank.gelib.mimetype.whitelist}'.split(';')}")
    private List<String> mimeWhiteList;
    @Value("#{'${mybank.gelib.extension.whitelist}'.split(';')}")
    private List<String> extensionWhiteList;
    
    @Autowired
    MyBankLookupService lookupservice;

    /**
     * Method to upload a specific file into GE library
     * 
     * @param file
     * @param acctReqID
     * @param docType
     * @param requestType
     * @return - Returns AccountDocument
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws BusinessException
     * @throws ValidationFailedException 
     */
    @RequestMapping(value = FILEUPLOAD, method = RequestMethod.POST)
    public @ResponseBody
    AccountDocument postFileUpload(HttpServletRequest request,
            @RequestParam(FILE) final MultipartFile file,
            @RequestParam(ACCTREQID) final String acctReqID,
            @RequestParam(DOCTYPE) final String docType,
            @RequestParam(REQUESTTYPE) final String requestType)
            throws ValidationFailedException {
    	
    	SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
        if (!mimeWhiteList.contains(file.getContentType()) 
                || !extensionWhiteList.contains(FilenameUtils
                        .getExtension((FilenameUtils.normalize(file.getOriginalFilename()))
                                .toLowerCase()))) {
            
            BindingResult errors = new BeanPropertyBindingResult(file,
                    "file");
            errors.reject("file.mimetype.rejected", "File is not in an acceptable format");
           	throw new ValidationFailedException(errors);
        }

        User user = (User) request.getSession().getAttribute(USER);
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();
        
        MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request
               .getRequestURL().toString()), 0L);
        
        AccountDocument accountDocument = new AccountDocument();
        String name = FilenameUtils.getName(FilenameUtils.normalize(file.getOriginalFilename()));
        String fileNameBlackList = this.lookupservice.getDisplayName(FILE_NAME_BLACKLIST);
        Pattern special = Pattern.compile("[".concat(fileNameBlackList).concat("]"));
        Matcher hasSpecial = special.matcher(name);

        if(hasSpecial.find()){
        	BindingResult errors = new BeanPropertyBindingResult(file,
        			"file");
        	errors.reject("file.mimetype.rejected", "File name should not contain charecters ".concat(fileNameBlackList.replaceAll(".(?=.)", "$0 ")));
        	throw new ValidationFailedException(errors);
        }

        try {
        	if (name != null) {
        		if (!file.isEmpty()) {
        			accountDocument = processFile(name, file, acctReqID, docType, requestType, user);
        		} else {
        			MyBankLogger.logError(this, UPLOAD_FAIL_MESSAGE + name
        					+ EMPTY_FILE);
        			throw new BusinessException(UPLOAD_FAIL_MESSAGE + name
        					+ EMPTY_FILE);
        		}
        	} else {
        		MyBankLogger.logError(this, EXTENSION + name + NOT_CORRECT);
        		throw new BusinessException(EXTENSION + name + NOT_CORRECT);
        	}
        } catch(BusinessException be){
        	throw new BusinessException(be.getMessage(),be);
        }
        catch(Exception e){
        	throw new SystemException("Unable to upload the file due to internal error : "+e.getMessage(),e);
        }

        if (accountDocument != null) {
        	MyBankLogger.logPerf(this, userId, transactionId, FILE_UPLOAD_ID
        			+ accountDocument.getDocId() + CREATED,
        			System.currentTimeMillis() - startTime);
        }
        return accountDocument;

    }

    private AccountDocument processFile(String name,MultipartFile file,final String acctReqID, final String docType,final String requestType,User user){
    	AccountDocument accountDocument = new AccountDocument();
    	FileUploadParameters response = null;
    	try {
            String updatedFileName = FilenameUtils.removeExtension(FilenameUtils.normalize(name))
                    + UNDERSCORE
                    + fileUploadService.dateFormatter(FILE_NAME_DATE_FORMAT) + DOT
                    + FilenameUtils.getExtension(name);

            
            String orginalName = FilenameUtils.normalize(file.getOriginalFilename());
        	String filePath = localDirectory+orginalName;
        	File destination = new File(filePath);
       	    file.transferTo(destination);
       	    
            String subFolderID = null;
            File source = new File(destination.getAbsolutePath());
            File dest = new File(localDirectory + updatedFileName);
            deleteLocalFile(source, dest, destination);
            
            if (acctReqID.equals(NULL_VALUE)) {
                accountDocument.setDocName(updatedFileName);
                accountDocument.setDocURL(dest.getAbsolutePath());
                accountDocument
                        .setDocType(ValidationConstants.ACCTREQDOCTYPE_SIGNRCARD);
                accountDocument.setFileId(new BigInteger(NUM_ONE));
                accountDocument.setFolderId(new BigInteger(NUM_ONE));
            } else {
                // Call libraries api instead of service
                subFolderID = fileUploadService.findSubFolder(
                        acctReqID.toString(), defaultFolderId,
                        defaultUserId, applicationId,
                        applicationPassword);
                if (subFolderID == null || subFolderID.isEmpty()) {
                    subFolderID = fileUploadService.createSubFolder(
                            acctReqID.toString(), defaultFolderId,
                            defaultUserId, applicationId,
                            applicationPassword);
                }
                response = fileUploadService.uploadFile(
                        acctReqID.toString(), docType,
                        requestType, user.getSso(), updatedFileName , subFolderID,
                        dest.getAbsolutePath());
                if (response.getErrorMessage() != null
                        && response.getErrorMessage()
                                .equals(FILE_EXIST)) {
                 
                    MyBankLogger.logError(this, UPLOAD_FAIL_MESSAGE + name);
                    throw new BusinessException(FILE_EXIST_MESSAGE);
                }
                if (response != null && response.getFileID() != null) {
                    accountDocument.setDocName(updatedFileName);
                    accountDocument.setDocURL(response.getFileURL());
                    accountDocument.setFileId(new BigInteger(response
                            .getFileID()));
                    accountDocument.setFolderId(new BigInteger(
                            subFolderID));
                }                    
               boolean isFileDeleted =  fileUploadService.deleteLocalFile(dest);
                if(isFileDeleted)
                	 MyBankLogger.logInfo(this, FILE_DELETED_SUCCESS);
                else
                	 MyBankLogger.logInfo(this, UNABLE_DELETE);
            }

            MyBankLogger.logDebug(this, UPLOAD_SUCCESS_MESSAGE + name);
        } catch (IOException e) {
            MyBankLogger.logError(this, UPLOAD_FAIL_MESSAGE + name
                    + " => " + e.getMessage());
            throw new BusinessException(UPLOAD_FAIL_MESSAGE + name
                    + " => " + e.getMessage(), e);
        }
		return accountDocument;
    }
    
    private void deleteLocalFile(File source,File dest,File destination){
    	 try {
             FileUtils.copyFile(source, dest);
             boolean isTempFileDeleted = fileUploadService.deleteLocalFile(new File(destination.getAbsolutePath()));
             if(isTempFileDeleted)
             	 MyBankLogger.logInfo(this, FILE_DELETED_SUCCESS);
             else
             	 MyBankLogger.logInfo(this, UNABLE_DELETE);
         } catch (IOException e) {
             MyBankLogger.logError(this, FILE_COPY);
             throw new BusinessException(FILE_COPY, e);
         }
    }
    /**
     * Method to delete specific file from a given folder
     * 
     * @param folderId
     * @param fileId
     * @param fileName
     * @return - Returns true if delete is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws BusinessException
     * @throws UnsupportedEncodingException 
     */
    @RequestMapping(value = FILEDELETE, method = RequestMethod.GET)
    public @ResponseBody
    Boolean cancelFileUpload(HttpServletRequest request,
            @RequestParam(FILEID) final String fileId,
            @RequestParam(FOLDERID) final String folderId,
            @RequestParam(FILENAME) final String fileName) throws UnsupportedEncodingException{

    	SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
        String fileName1 = FilenameUtils.normalize(fileName);
    	User user = (User) request.getSession().getAttribute(USER);
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request
                .getRequestURL().toString()), 0L);
        Boolean isAccountDocumentDeleted;
        if (fileId.equals(NUM_ONE)) {
            Path path = Paths.get(localDirectory + URLDecoder.decode(fileName1, "UTF-8"));

            try {
                if (Files.deleteIfExists(path.toAbsolutePath())) {
                    return true;
                } else {
                    throw new BusinessException(FILE_NOT_EXIST);
                }
            } catch (IOException | BusinessException e) {
                throw new BusinessException(e.getMessage(), e);
            } catch(Exception e){
            	throw new SystemException("Unable to delete file due to internal error : "+ e.getMessage(),e);
            }
        } else {
            try {
                isAccountDocumentDeleted = fileUploadService.deleteFile(user,
                        folderId, fileId, defaultUserId, applicationId,
                        applicationPassword);
                if (!isAccountDocumentDeleted) {
                    throw new BusinessException(UNABLE_DELETE);
                }
            } catch (BusinessException e) {
                throw new BusinessException(e.getMessage(),e);
            }catch(Exception e){
            	throw new SystemException("Unable to delete file due to internal error : "+ e.getMessage(),e);
            }
        }
        MyBankLogger.logPerf(this, userId, transactionId, ACC_ID + fileId
                + ACC_ID_DELETED, System.currentTimeMillis() - startTime);

        return isAccountDocumentDeleted;

    }

    /**
     * Method downloads specific file from GE library onto given folder
     * location.
     * 
     * @param fileId
     * @param fileName
     * @return - Returns FileUploadParameters
     * @throws UnsupportedEncodingException 
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(value = FILEDOWNLOAD, method = RequestMethod.GET)
    public @ResponseBody
    FileUploadParameters downloadUploadedFile(HttpServletRequest request,
            HttpServletResponse response,
            @RequestParam(FILEID) final String fileId,
            @RequestParam(FILENAME) String fileName1) throws UnsupportedEncodingException {
        
        
    	String newFileName1 = FilenameUtils.normalize(fileName1);
        
        String fileName = FilenameUtils.getName(URLDecoder.decode(newFileName1,"UTF-8"));
        
        User user = (User) request.getSession().getAttribute(USER);
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        
        long startTime = System.currentTimeMillis();
        FileUploadParameters fileUploadParameters = new FileUploadParameters();
        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);
        Boolean isAccountDocumentDownloaded;
        if (fileId.equals(NUM_ONE)) {
            try {
            	fileUploadService.downloadFileByOutputStream(response, fileName,
				        localDirectory);
			} catch (IOException e) {
				MyBankLogger.logError(this,"Failed to download file by output stream : "+e);
				throw new SystemException("Failed to download file by output stream : "+e.getMessage());
			}
        } else {
            try {
                isAccountDocumentDownloaded = fileUploadService
                        .downloadFileById(fileId, fileName, localDirectory,
                                defaultUserId, applicationId,
                                applicationPassword);
                if (!isAccountDocumentDownloaded) {
                    throw new BusinessException(UNABLE_DOWNLOAD + fileName);
                } else {
                    fileUploadService.downloadFileByOutputStream(response,
                            fileName, localDirectory);
                }
                fileUploadParameters
                        .setFileDownloaded(isAccountDocumentDownloaded);
                fileUploadParameters.setFileURL(localDirectory + fileName);
                File file = new File(localDirectory + fileName);
                boolean isFileDeleted = fileUploadService.deleteLocalFile(file);
                if(isFileDeleted)
               	 MyBankLogger.logInfo(this, FILE_DELETED_SUCCESS);
               else
               	 MyBankLogger.logInfo(this, UNABLE_DELETE);
            } catch (IOException | BusinessException e) {
                throw new BusinessException(e.getMessage(),e);
            }catch(Exception e){
            	throw new SystemException("Unable to download file due to internal error : "+ e.getMessage(),e);
            }
        }
        MyBankLogger.logPerf(this, userId, transactionId, ACC_ID + fileId
                + ACC_ID_DOWLOADED, System.currentTimeMillis() - startTime);
        return fileUploadParameters;
    }

    /**
     * @return the applicationId
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * @param applicationId
     *            the applicationId to set
     */
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    /**
     * @return the defaultUserId
     */
    public String getDefaultUserId() {
        return defaultUserId;
    }

    /**
     * @param defaultUserId
     *            the defaultUserId to set
     */
    public void setDefaultUserId(String defaultUserId) {
        this.defaultUserId = defaultUserId;
    }

    /**
     * @return the applicationPassword
     */
    public String getApplicationPassword() {
        return applicationPassword;
    }

    /**
     * @param applicationPassword
     *            the applicationPassword to set
     */
    public void setApplicationPassword(String applicationPassword) {
        this.applicationPassword = applicationPassword;
    }

    /**
     * @return the defaultFolderId
     */
    public String getDefaultFolderId() {
        return defaultFolderId;
    }

    /**
     * @param defaultFolderId
     *            the defaultFolderId to set
     */
    public void setDefaultFolderId(String defaultFolderId) {
        this.defaultFolderId = defaultFolderId;
    }

    /**
     * @return the localDirectory
     */
    public String getLocalDirectory() {
        return localDirectory;
    }

    /**
     * @param localDirectory
     *            the localDirectory to set
     */
    public void setLocalDirectory(String localDirectory) {
        this.localDirectory = localDirectory;
    }

}
