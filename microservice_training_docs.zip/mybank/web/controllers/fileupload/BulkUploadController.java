package com.ge.treasury.mybank.web.controllers.fileupload;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.beanio.BeanReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;

import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.helper.FileUploadHelper;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadActivityService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadService;
import com.ge.treasury.mybank.config.CacheService;
import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.AccountDocument;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.StringHelper;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.constants.FileUploadConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.validations.AccountValidationUtils;
import com.ge.treasury.mybank.util.business.validations.BulkUploadFileValidator;
import com.ge.treasury.mybank.util.web.BulkUploadFileScheduler;
import com.ge.treasury.mybank.util.web.CSVFileReader;
import com.ge.treasury.mybank.util.web.SanatizedServletRequest;
import com.ge.treasury.mybank.web.controllers.BaseController;

@Controller
@RequestMapping(BulkApprovalConstants.API)
public class BulkUploadController extends BaseController implements BulkApprovalConstants {

	@Value("${mybank.url.openRequest}")
	private String openTemplate;

	@Value("${mybank.url.modifyRequest}")
	private String modifyTemplate;
	
	@Value("${mybank.url.modifyInternalRequest}")
    private String modifyInternalTemplate;

	@Value("${mybank.url.closeRequest}")
	private String closeTemplate;
	
	@Value("${mybank.random.seed}")
	private long seedInitializer;

	@Value("${mybank.url.signerRequest}")
	private String signerTemplate;

	@Value("${mybank.url.faq}")
	private String faq;
	
	@Value("${mybank.gelib.applicationId}")
    private String applicationId;
    @Value("${mybank.gelib.app.userId}")
    private String defaultUserId;
    @Value("${mybank.gelib.app.password}")
    private String applicationPassword;
    @Value("${mybank.gelib.localDirectory}")
    private String localDirectory;


	@Autowired
	BulkUploadService bulkUploadService;

	@Autowired
	FileUploadActivityService fileUploadActivityService;
	
	@Autowired
	BulkUploadFileValidator bulkUploadFileValidator;
	
	@Autowired
	CacheService cacheService;

	@Autowired
	BulkApprovalService bulkApprovalService;
	
	@Autowired
    FileUploadService fileUploadService;
	
	 
	@RequestMapping(value = "/checkCache", method = RequestMethod.GET)
		public void checkCache(HttpServletRequest request){
		cacheService.fetchLookUpData();
	 }
	
	
	/**
	 * Save raw file to DB
	 * 
	 * @param request
	 * @param file
	 * @return
	 * @throws IOException 
	 * @throws Exception 
	 */
	@RequestMapping(value = "/bulkUpload", method = RequestMethod.POST)
	public @ResponseBody FileUpload postFileUpload(HttpServletRequest request,
			@RequestParam("file") final MultipartFile file,
			@RequestParam("uploadType") String fileUploadType) throws IOException{
		
		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);		
		User user = (User) request.getSession().getAttribute("User");
		String userId = user.getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);
		
		
		ExecutorService executor = Executors.newFixedThreadPool(5);
		
		SecureRandom random = new SecureRandom();
		random.setSeed(seedInitializer);
		BeanReader reader = null;
		FileInputStream fis = null;
		BufferedOutputStream stream = null;
		try {
		File serverFile = new File(FilenameUtils.normalize(file.getOriginalFilename())+random.nextDouble());
		byte[] bytes = file.getBytes();
		file.getInputStream();
		stream = new BufferedOutputStream(new FileOutputStream(serverFile));
		stream.write(bytes);
		stream.close();
				
		Runnable worker = null;
			
			FileUpload fileUpload = new FileUpload();
			if (!file.isEmpty()) {
				fileUpload.setFileName(FilenameUtils.normalize(file.getOriginalFilename()));
				
				if(AccountValidationUtils.getUploadTypeMap().containsKey(fileUploadType)){
				    fileUpload.setUpldTypeCode(AccountValidationUtils.getUploadTypeMap().get(fileUploadType));
				}
				
				//calculate lines
				long recordCount = 0;
				fis = new FileInputStream(serverFile);
				reader = CSVFileReader.readCSVFromStream(fis, fileUpload.getUpldTypeCode());
				Object record = null;
				while ((record = reader.read()) != null) {
					recordCount++;
				}
				fis.close();
				fileUpload.setTotalCount(recordCount);
				fileUpload.setUploadedFile(FileUploadHelper.fileToClob(serverFile));
				
				fileUpload = bulkUploadService.createFileUpload(fileUpload, null, user,BulkApprovalConstants.FILEUPLOADACT_VALIDATION_INPROCESS);
				
				FileUploadActivity fileUploadActivity = 
						createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_VALIDATION_INPROCESS);
				
				MyBankLogger.logDebug(this, "Inserting Record in File Upload Activity for => " + fileUpload.getFileUpldId());
				fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
				
				worker = new BulkUploadFileScheduler(serverFile, fileUploadType, bulkUploadFileValidator, 
						user, bulkApprovalService,fileUploadActivityService,fileUpload);
				executor.submit(worker);
			}else{
				MyBankLogger.logError(this, "Failed to upload " + FilenameUtils.normalize(file.getOriginalFilename()) + " because the file was empty.");
				throw new BusinessException("Failed to upload " + FilenameUtils.normalize(file.getOriginalFilename()) + " because the file was empty.");
			}
		} catch(DBException dbe){
			throw new DBException("Unable to upload Bulk File : "+dbe.getMessage(),dbe);
		}catch(BusinessException be){
			throw new BusinessException(be.getMessage(),be);
		}
		catch (Exception e) {
				throw new SystemException("Failed upload file due to internal error : "+e.getMessage(),e);
		}finally{
			reader.close();
			IOUtils.closeQuietly(fis);
			IOUtils.closeQuietly(stream);
			file.getInputStream().close();
			executor.shutdown();
		}

		return new FileUpload();
	}


	/**
	 * Obtain File Upload Record(s), The request can contain the following
	 * parameters.
	 * 
	 * @param request
	 * @param columnName
	 * @param orderBy
	 * @return - FileUpload Records
	 */
	@RequestMapping(value = "/bulkUpload", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK) // 200
	public @ResponseBody List<FileUpload> getFileUpload(HttpServletRequest request,
			@RequestParam("columnName") String columnName, @RequestParam("orderBy") String orderBy) throws DBException {
		User user = (User) request.getSession().getAttribute("User");
		List<FileUpload> fileUploadResponseSort = null;
		BulkApprovalSearchCriteria bulkApprovalSearch = new BulkApprovalSearchCriteria();
		try {
			bulkApprovalSearch.setOrderBy(columnName);
			bulkApprovalSearch.setDirection(orderBy);
			
			if("Finance Admin".equals(user.getUserProfile().getRoles().get(0).getMyBankRole())) {
				bulkApprovalSearch.setUpldTypeCode("FILE_UPLOAD_MODIFY_INTERNAL");
			}
			fileUploadResponseSort = bulkUploadService.loadProcessingQueueSortBy(bulkApprovalSearch);
			
			MyBankLogger.logDebug(this, "Processing queue loaded successfully ");
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Failed to retrieve Bulk file details " + dbe.getMessage(),dbe);
		}catch(Exception e){
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Failed to get Bulk uploaded file details due to internal error : "+e.getMessage(),e);
		}


		return fileUploadResponseSort;
	}

	/**
	 * Download the bulk upload Templates, The request can contain the following
	 * parameters. To do search: File upload.
	 * 
	 * @param request
	 */
	@RequestMapping(value = "/bulkDownload", method = RequestMethod.GET)
	public @ResponseBody void downloadUploadedFile(@RequestParam("fileId") String fileId,@RequestParam("fileType") String fileType, HttpServletRequest request,
			HttpServletResponse response) throws DBException, BusinessException {
		String fileName = null;
		ByteArrayInputStream bis = null;
		String headerValue = null;
		String headerKey = "Content-Disposition";
		
		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String newFileid = paramsSanitizer.getParameter(fileId);
		byte fileData[] =null;
		try {
			FileUpload fileUpload = bulkUploadService.downLoadFile(Long.parseLong(newFileid));
			MyBankLogger.logDebug(this, "After calling downloadFile=> ");
			fileName = fileUpload.getFileName();
			response.setContentType("application/text");
		
            if("SUCCESS".equals(fileType)){
            	fileData = fileUpload.getSuccessFile().getBytes();
            	
            	fileName =StringUtils.substringBeforeLast(fileName, ".")+"_accepted.csv";
            }
            else if("ERROR".equals(fileType)){
            	fileData=fileUpload.getErrorFile().getBytes();
            	fileName =StringUtils.substringBeforeLast(fileName, ".")+"_rejected.csv";
			
            }
            else {
            	fileData = fileUpload.getUploadedFile().getBytes();
            }
			bis = new ByteArrayInputStream(fileData);

			byte[] buf = new byte[1024];
			headerValue = String.format("attachment; filename=\"%s\"", fileName);
            response.setHeader(headerKey, headerValue);
			writeToFile(response, bis, buf, fileName);
			
		} catch(DBException dbe){
			throw new DBException("Failed to downloaded the uploaded Bulk File : "+BulkApprovalConstants.FETCH_DATA_FAILED,dbe);
		}
		
		catch (BusinessException be) {
			throw new BusinessException(be.getMessage(),be);
		}catch(Exception e){
			throw new SystemException("Failed to download file due to some internal error : "+e.getMessage(),e);
		}
	}

	private void writeToFile(HttpServletResponse response,ByteArrayInputStream bis,byte[] buf,String fileName){
		int len;
		try {
			while ((len = bis.read(buf)) > 0) {

				response.getOutputStream().write(buf, 0, len);
				
			}
		
	} catch (IOException e) {
		MyBankLogger.logError(this, e.getMessage(), e);
		throw new BusinessException("Failed to download the file " + fileName + " => " + e.getMessage());
	} catch (DBException dbe) {
		MyBankLogger.logError(this, dbe.getMessage(), dbe);
		throw new DBException(dbe.getMessage());
	} finally {
		closeByteArrayInputStream(bis, response);

	}
	}
	
	private void closeByteArrayInputStream(ByteArrayInputStream bis,HttpServletResponse response){
		try {
			bis.close();

		} catch (IOException e) {
			MyBankLogger.logError(this, e.getMessage(), e);
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
		} finally {
			try {
				bis.close();
			} catch (IOException e) {
				MyBankLogger.logError(this, e.getMessage(), e);
			}


			try {
				response.getOutputStream().flush();
			} catch (IOException e) {
				MyBankLogger.logError(this, e.getMessage(), e);
			}
				
			}
	}
	
	@RequestMapping(value = "/bulkDownloadTemplate", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody void downloadTemplate(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("type") String type, @RequestParam("url") String url){
		String templateUrl = null;

		switch (type) {
		case BULK_UPLOAD_OPEN:
			templateUrl = openTemplate;
			break;
		case BULK_UPLOAD_MODIFY:
			templateUrl = modifyTemplate;
			break;
		case BULK_UPLOAD_MODIFY_INTERNAL:
            templateUrl = modifyInternalTemplate;
            break;
		case BULK_UPLOAD_CLOSE:
			templateUrl = closeTemplate;
			break;
		case BULK_UPLOAD_SIGNER:
			templateUrl = signerTemplate;
			break;
		case BULK_UPLOAD_FAQ:
			templateUrl = faq;
			break;
		case BULK_UPLOAD_HELP_FAQ:
			templateUrl = url;
			break;
		case BULK_UPLOAD_HELP_REPORTS:
			templateUrl = url;
			break;
		case BULK_UPLOAD_HELP_CONTACTS:
			templateUrl = url;
			break;
		default:
			break;
		}
		
		Map<String, String> map = null;
		String fileId = "";
		try {
			map = StringHelper.splitQuery(new URL(templateUrl));
		} catch (UnsupportedEncodingException | MalformedURLException e1) {
			MyBankLogger.logError(this, "Error in fetching template url value : "+e1);
			throw new SystemException("Error in fetching template url value : "+e1.getMessage());
		}

		if (map.containsKey(BulkApprovalConstants.FILE_ID)) {
			fileId = map.get(BulkApprovalConstants.FILE_ID);
		}
		Boolean isAccountDocumentDownloaded;
		String fileNameFrmMetaData = "";
		try {
			AccountDocument accountDocument = bulkApprovalService.getMetadataForFile(fileId);
			fileNameFrmMetaData = accountDocument.getDocName();
			isAccountDocumentDownloaded = fileUploadService.downloadFileById(fileId, fileNameFrmMetaData, localDirectory,
					defaultUserId, applicationId, applicationPassword);
			if (!isAccountDocumentDownloaded) {
				throw new BusinessException(FileUploadConstants.UNABLE_DOWNLOAD + fileNameFrmMetaData);
			} else {
				fileUploadService.downloadFileByOutputStream(response, fileNameFrmMetaData, localDirectory);
			}
			File file = new File(localDirectory + fileNameFrmMetaData);
			boolean isFileDeleted = fileUploadService.deleteLocalFile(file);
			if (isFileDeleted)
				MyBankLogger.logInfo(this, FileUploadConstants.FILE_DELETED_SUCCESS);
			else
				MyBankLogger.logInfo(this, FileUploadConstants.UNABLE_DELETE);
		} catch (IOException | BusinessException e) {
			throw new BusinessException(e.getMessage(), e);
		}catch(Exception e){
			throw new SystemException("Unable to download template due to some internal error: "+e.getMessage(),e);
		}
	}
	
	@RequestMapping(value = "/fetchTemplateDetails", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody Map<String, String> fetchTemplateDetails() {
		Map<String,String> templateMap = new HashMap<String,String>();
		AccountDocument document = null;

		document = fetchTempMetaData(openTemplate);
		templateMap.put("OPEN", document.getModifiedOn());

		document = fetchTempMetaData(modifyTemplate);
		templateMap.put("MODIFY_ALL", document.getModifiedOn());

		document = fetchTempMetaData(closeTemplate);
		templateMap.put("CLOSE", document.getModifiedOn());

		document = fetchTempMetaData(signerTemplate);
		templateMap.put("SIGNER", document.getModifiedOn());
		
		document = fetchTempMetaData(modifyInternalTemplate);
        templateMap.put("MODIFY_INTERNAL", document.getModifiedOn());

		return templateMap;
	}

	private AccountDocument fetchTempMetaData(String url) {
		String fileId = "";
		AccountDocument document = null;
		if (!url.isEmpty()) {
			Map<String, String> map;
			try {
				map = StringHelper.splitQuery(new URL(url));
				if (map.containsKey(BulkApprovalConstants.FILE_ID)) {
					fileId = map.get(BulkApprovalConstants.FILE_ID);
				}
				document = bulkApprovalService.getMetadataForFile(fileId);

			} catch (UnsupportedEncodingException | MalformedURLException e) {
				MyBankLogger.logError(this, "Error in Decoding the Document URL" + e.getMessage(), e);
				throw new SystemException(e);
			}catch(Exception e){
				throw new SystemException("Failed to download template metadata : "+e.getMessage(),e);
			}
		}
		return document;
	}
}

