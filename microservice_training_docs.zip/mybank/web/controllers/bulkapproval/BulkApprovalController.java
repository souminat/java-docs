/**
 * Copyright GE
 */
package com.ge.treasury.mybank.web.controllers.bulkapproval;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.bulkapproval.service.impl.BulkApprovalService;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.inflightrequest.service.impl.InflightRequestService;
import com.ge.treasury.mybank.config.CacheService;
import com.ge.treasury.mybank.domain.BulkApprovalSearchCriteria;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.PaginatedResultList;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.bulkapproval.BulkAccountSigner;
import com.ge.treasury.mybank.domain.bulkapproval.BulkApprovalRequest;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.BulkApprovalConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.web.BulkUploadProcessScheduler;
import com.ge.treasury.mybank.util.web.BulkUploadSignerProcessScheduler;
import com.ge.treasury.mybank.util.web.CSVFileReader;
import com.ge.treasury.mybank.web.controllers.BaseController;

/**
 * @author MyBank Dev Team
 */
@Controller
@RequestMapping(BulkApprovalConstants.API)
public class BulkApprovalController extends BaseController implements BulkApprovalConstants {

	@Autowired
	BulkApprovalService bulkApprovalService;

	@Autowired
	BulkUploadService bulkUploadService;
	
	@Autowired
    AccountRequestService accountService;
	
	@Autowired
	CacheService cacheService;
	
	@Autowired
	InflightRequestService inflightRequestService;
	
	@Value("${mdm.ms.account}")
	private String accountUrl;
	
	@Value("${mdm.ms.accountCore}")
	private String accountCoreUrl;

	@Value("${mdm.ms.buhierarchy}")
	private String buHierarchyUrl;
	
	@Value("${mdm.ms.companyCode}")
	private String companyCodeUrl;
	
	@RequestMapping(value = BULK_APPROVAL_FILTER_PAGINATION, method = RequestMethod.GET)
	public @ResponseBody PaginatedResultList<FileUpload> getBulkApprovalList(HttpServletRequest request,
			@ModelAttribute BulkApprovalSearchCriteria bulkApprovalSearch) throws DBException {

		User user = (User) request.getSession().getAttribute("User");
		PaginatedResultList<FileUpload> result = new PaginatedResultList<FileUpload>();
		List<FileUpload> bulkApprovalList = null;

		try {
			if("Finance Admin".equals(user.getUserProfile().getRoles().get(0).getMyBankRole())) {
				bulkApprovalSearch.setUpldTypeCode("FILE_UPLOAD_MODIFY_INTERNAL");
			}
			
			bulkApprovalList = bulkApprovalService.getBulkApprovalDetailsBYFilter(bulkApprovalSearch);
			MyBankLogger.logDebug(this, "Records fetched successfully ");
			result.setResultList(bulkApprovalList);
			result.setTotalRecords((bulkApprovalList == null || bulkApprovalList.isEmpty()) ? 0
					: bulkApprovalList.get(0).getRecordCount());

			result.setRequestQueryString(request.getQueryString());
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Failed to display BulkApproval inbox list " + BulkApprovalConstants.FETCH_DATA_FAILED,dbe);
		}catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Failed to display BulkApproval inbox list : "+e.getMessage(),e);
		}

		

		return result;

	}

	@RequestMapping(value = BULK_APPROVAL_GET_UPLOAD, method = RequestMethod.GET)
	public @ResponseBody FileUpload getBulkApprovalUploadById(HttpServletRequest request,
			@RequestParam("uploadId") String uploadId) throws DBException {
		User user = (User) request.getSession().getAttribute("User");
		FileUpload fileUpload = null;
		Long fileUpldId = null;
		try {
			if (uploadId != null) {
				fileUpldId = Long.parseLong(uploadId);
			}

			fileUpload = bulkApprovalService.getFileUploadDetailsById(fileUpldId);
			if(null!=fileUpload.getErrorFile()){
				fileUpload.setRejectedCount(CSVFileReader.getStreamRecordCount(fileUpload.getErrorFile(), fileUpload.getUpldTypeCode()));
				fileUpload.setErrorFile(null);
				fileUpload.setErrorFileFlag(true);
				
				
			}
			if(null!=fileUpload.getSuccessFile()){
				fileUpload.setAcceptedCount(CSVFileReader.getStreamRecordCount(fileUpload.getSuccessFile(), fileUpload.getUpldTypeCode()));
				fileUpload.setSuccessFile(null);
				fileUpload.setSuccessFileFlag(true);
				
			}
			
			List<FileUploadActivity> fileUploadActivityList = fileUploadActivityService.getFileUploadActivityDetailsById(fileUpldId);
			fileUpload.setActivities(fileUploadActivityList);
			if(!fileUpload.getCreateUser().equals(user.getSso())){
				fileUpload.setValidAccess(true);
			}
			MyBankLogger.logDebug(this, "Records fetched successfully ");
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Unable to display selected file details " + BulkApprovalConstants.FETCH_DATA_FAILED,dbe);
		}catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(),e);
			throw new SystemException("Unable to display file details due to internal error : "+e.getMessage(),e);
		}

		return fileUpload;
	}

	@RequestMapping(value = BULK_APPROVAL_EXPORT, method = RequestMethod.GET)
	public @ResponseBody PaginatedResultList<FileUpload> getBulkApprovalExport(HttpServletRequest request,
			@ModelAttribute BulkApprovalSearchCriteria bulkApprovalSearch) throws DBException {

		User user = (User) request.getSession().getAttribute("User");
		List<FileUpload> bulkApprovalList = null;
		PaginatedResultList<FileUpload> result = new PaginatedResultList<FileUpload>();
		try {
			if("Finance Admin".equals(user.getUserProfile().getRoles().get(0).getMyBankRole())) {
				bulkApprovalSearch.setUpldTypeCode("FILE_UPLOAD_MODIFY_INTERNAL");
			}
			bulkApprovalList = bulkApprovalService.getApprovalExportData(bulkApprovalSearch);
			MyBankLogger.logDebug(this, "Records fetched successfully ");
			
			result.setResultList(bulkApprovalList);
			result.setTotalRecords(bulkApprovalList.size());
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Unable to fetch bulk approval list into excel : "+BulkApprovalConstants.FETCH_DATA_FAILED,dbe);
		}catch(Exception e){
			throw new SystemException("Unable to fetch bulk approval list into excel due to internal error : "+e.getMessage(),e);
		}

		

		return result;
	}
	
	
	@RequestMapping(value = BULK_APPROVAL_APPROVED, method = RequestMethod.POST,consumes = "application/json")
	public @ResponseBody void processApprovedRecords(HttpServletRequest request,
			@RequestBody FileUpload fileUpload) throws DBException, BusinessException {
		
		User user = (User) request.getSession().getAttribute("User");
		String userId = user.getSso();
		String transactionId = MyBankLogger.getTransactionId();
		long startTime = System.currentTimeMillis();
		MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
		
		Date today = new Date();
		
		try {
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_PROCESSING);
			fileUpload.setLastUpdateDate(today);
			fileUpload.setLastUpdateUser(user.getSso());
			bulkApprovalService.updateFileUploadStatus(fileUpload, user);
			
			FileUploadActivity fileUploadActivity = 
					createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_APPROVED);
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
			fileUpload.setComments("");
			ExecutorService executor = Executors.newFixedThreadPool(5);
			
			Runnable worker = null;
					
			if (BULK_UPLOAD_FILE_TYPE_SIGNER.equals(fileUpload.getUpldTypeCode())) {

				worker = new BulkUploadSignerProcessScheduler(fileUpload, user, bulkApprovalService, accountService,
						fileUploadActivityService, lookupService, mdmService, messageValidator, bulkUploadService,accountUrl);
				executor.submit(worker);
				executor.shutdown();
			}
			else{
				worker= new BulkUploadProcessScheduler(fileUpload, user, bulkApprovalService,
						accountService, fileUploadActivityService, lookupService,inflightRequestService, mdmService, messageValidator,cacheService,bulkUploadService,accountUrl,accountCoreUrl,companyCodeUrl);
				executor.submit(worker);
				executor.shutdown();
			}
		} catch (DBException dbe){
			throw new DBException("Unable to approve the Bulk file for fileID: "+fileUpload.getFileUpldId()+dbe.getMessage(),dbe);
		}
		
		catch (Exception e) {
			throw new SystemException("Unable to approve the Bulk file for fileID: " + fileUpload.getFileUpldId() + "due to internal error :"+e.getMessage(),e);
		}
		
		MyBankLogger.logPerf(this, userId, transactionId,
				"File upload id " + fileUpload.getFileUpldId() + "Processed Successfully", System.currentTimeMillis() - startTime);
		
	}

	@RequestMapping(value = BulkApprovalConstants.BULK_APPROVAL_REJECT, method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody FileUpload rejectBulkApproval(HttpServletRequest request,
			@RequestBody FileUpload fileUpload) throws DBException {

		User user = (User) request.getSession().getAttribute("User");
		try {
			fileUpload.setUpldStatusCode(BulkApprovalConstants.FILEUPLOADACT_REJECTED);
			bulkApprovalService.updateFileUploadStatus(fileUpload, user);
			MyBankLogger.logDebug(this, "File Rejected successfully for Upload Id : " + fileUpload.getFileUpldId());

			FileUploadActivity fileUploadActivity = createFileUploadActivity(fileUpload, user, BulkApprovalConstants.FILEUPLOADACT_REJECTED);
			fileUploadActivityService.saveFileUploadActivity(fileUploadActivity);
			
			
			bulkApprovalService.sendBulkUploadNotification(fileUpload, user, 0, FILEUPLOADACT_REJECTED);
		}
		catch (DBException dbe){
			throw new DBException("Unable to reject Bulk Request for fileID : " + fileUpload.getFileUpldId() +  dbe.getMessage(),dbe);
		} 
		
		catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new DBException("Unable to Reject Bulk Request for fileID : "+ fileUpload.getFileUpldId() + "due to internal error : "+e.getMessage(),e);
		}

		return fileUpload;
	}
	
	@RequestMapping(value = BulkApprovalConstants.BULK_APPROVAL_PROCESS_ERROR_EXPORT, method = RequestMethod.GET, consumes = {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody PaginatedResultList<BulkApprovalRequest> exportBulkApprovalErrorRecords(
			HttpServletRequest request, @RequestParam("uploadId") String uploadId) throws DBException {

		List<BulkApprovalRequest> bulkApprovalList = null;
		PaginatedResultList<BulkApprovalRequest> result = new PaginatedResultList<BulkApprovalRequest>();
		BulkApprovalRequest bulkApprovalRequest = new BulkApprovalRequest();
		Long fileUpldId = null;
		try {
			if (uploadId != null) {
				fileUpldId = Long.parseLong(uploadId);
			}
			bulkApprovalRequest.setFileUpldId(fileUpldId);

			bulkApprovalList = bulkApprovalService.getFileUploadStagingDetails(bulkApprovalRequest);

			MyBankLogger.logDebug(this, "Records fetched successfully ");
			
			result.setResultList(bulkApprovalList);
			result.setTotalRecords(bulkApprovalList.size());
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Unable to fetch the error records for error in Bulk Approval : "+dbe.getMessage(),dbe);
		}
		catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Unable to export Error Records Report due to internal error : "+e.getMessage(),e);
		}

		

		return result;
	}
	
	@RequestMapping(value = BulkApprovalConstants.BULK_APPROVAL_PROCESS_SIGNER_ERROR_EXPORT, method = RequestMethod.GET, consumes = {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody PaginatedResultList<BulkAccountSigner> exportBulkApprovalSignerErrorRecords(
			HttpServletRequest request, @RequestParam("uploadId") String uploadId) throws DBException {

		List<BulkAccountSigner> bulkSignerList = null;
		PaginatedResultList<BulkAccountSigner> result = new PaginatedResultList<BulkAccountSigner>();
		BulkAccountSigner bulkAccountSigner = new BulkAccountSigner();
		Long fileUpldId = null;
		try {
			if (uploadId != null) {
				fileUpldId = Long.parseLong(uploadId);
			}
			bulkAccountSigner.setFileUploadId(fileUpldId);

			bulkSignerList = bulkApprovalService.getSignerStagingDetails(bulkAccountSigner);

			MyBankLogger.logDebug(this, "Records fetched successfully ");
			
			result.setResultList(bulkSignerList);
			result.setTotalRecords(bulkSignerList.size());
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Unable to fetch Signer's Error record  : "+dbe.getMessage(),dbe);
		}
		catch (Exception e) {
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Unable to fetch Signer's Error record : "+e.getMessage(),e);
		}

		

		return result;
	}
	
	@RequestMapping(value = BulkApprovalConstants.BULK_APPROVAL_PROCESS_ERROR, method = RequestMethod.GET)
	public @ResponseBody void processErrorRecords(HttpServletRequest request, @RequestBody FileUpload fileUpload)
			throws DBException {
		List<BulkApprovalRequest> bulkApprovalList = null;
		FileUpload failedRecords = null;
		try {

			BulkApprovalRequest bulkApprovalRequest = new BulkApprovalRequest();
			bulkApprovalRequest.setStatusCode(FILEUPLOADACT_FAILURE);

			bulkApprovalList = bulkApprovalService.getFileUploadStagingDetails(bulkApprovalRequest);
			for (BulkApprovalRequest bulkReq : bulkApprovalList) {
				failedRecords = bulkApprovalService.getFileUploadDetails(bulkReq.getFileUpldId());
				MyBankLogger.logDebug(this, "Failed Records: "+failedRecords);
			}

			MyBankLogger.logDebug(this, "Records fetched successfully ");
		} catch (DBException dbe) {
			MyBankLogger.logError(this, dbe.getMessage(), dbe);
			throw new DBException("Failed to fetch Bulk Approval Process Error record : "+ dbe.getMessage(),dbe);
		}catch(Exception e){
			MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Unable to fetch Bulk approval error record : "+e.getMessage(),e);
		}
	}
}
