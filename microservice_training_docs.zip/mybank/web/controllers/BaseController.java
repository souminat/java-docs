package com.ge.treasury.mybank.web.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.fileupload.service.impl.FileUploadActivityService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.domain.FileUploadActivity;
import com.ge.treasury.mybank.domain.accountrequest.FileUpload;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.AuthorizationException;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.ResourceNotFoundException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.notification.NotificationUtil;
import com.ge.treasury.mybank.util.business.validations.MessageValidator;

/**
 * @author MyBank Dev Team
 * 
 */
@Controller
public abstract class BaseController {

	
	@Autowired
	protected FileUploadActivityService fileUploadActivityService;
	
	@Autowired
	protected AccountRequestService accountService;

    @Autowired
	protected MyBankLookupService lookupService;
    

    @Autowired
    protected MDMService mdmService;
    
    @Autowired
    protected MessageValidator messageValidator;

    @Autowired
	private NotificationUtil notification;

    /**
     * 
     * @param ex
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @ExceptionHandler(DBException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public @ResponseBody
    String handleDBException(Exception ex) throws IOException {
        MyBankLogger
                .logError(this, "Database Exception: " + ex.getMessage(), ex);
        notification.sendErrorNotification(ex);
        return "Database Exception: " + ex.getMessage();
    }

    /**
     * 
     * @param ex
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @ExceptionHandler(BusinessException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public @ResponseBody
    String handleBusinessException(Exception ex) throws IOException {
        MyBankLogger
                .logError(this, "Business Exception: " + ex.getMessage(), ex);
        notification.sendErrorNotification(ex);
        return "Business Exception: " + ex.getMessage();
    }

    /**
     * 
     * @param ex
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @ExceptionHandler(SystemException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public @ResponseBody
    String handleSystemException(Exception ex) throws IOException {
        MyBankLogger.logError(this, "System Exception:" + ex.getMessage(), ex);
        notification.sendErrorNotification(ex);
        return "System Exception:" + ex.getMessage();
    }

    /**
     * 
     * @param throwable
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public @ResponseBody
    String handleTRSSystemException(Exception ex) throws IOException {
        MyBankLogger.logError(this,
                "Unhandled Exception: " + ex.getLocalizedMessage(), ex);
        notification.sendErrorNotification(ex);
        return "Internal Server Error";

    }

    /**
     * Returns the appropriate response when resource not found.
     * 
     * @param ex
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    // 404
    public @ResponseBody
    String handleResourceNotFound(Exception ex) throws IOException {
        MyBankLogger.logError(this,
                "Resource Not Found Exception" + ex.getLocalizedMessage(), ex);
        notification.sendErrorNotification(ex);
        return "Not Found Exception: " + ex.getMessage();
    }
    
    /**
     * Returns the appropriate response when Authorization exception occurs.
     * @param ex
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @ExceptionHandler(AuthorizationException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public @ResponseBody
    String handleAuthorizationException(Exception ex) throws IOException {
        MyBankLogger.logError(this,"Authorization Exception: " + ex.getMessage(), ex);
        notification.sendErrorNotification(ex);
    return ex.getLocalizedMessage();
    }

    @ExceptionHandler(ValidationFailedException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public @ResponseBody
    String handleValidationFailedException(ValidationFailedException ex)
            throws IOException {
        StringBuilder sBuff = new StringBuilder("Validation Exception: ");
        for (ObjectError error : ex.getErrors().getAllErrors()) {
            sBuff.append(error.getDefaultMessage()).append("\n");
        }
        return sBuff.toString();
    }
    
    protected FileUploadActivity createFileUploadActivity(FileUpload fileUpload, User user, String status){
    	FileUploadActivity fileUploadActivity = new FileUploadActivity();
    	fileUploadActivity.setFileUpldId(fileUpload.getFileUpldId());
		fileUploadActivity.setStatusCode(status);
		fileUploadActivity.setComments(fileUpload.getComments());
		fileUploadActivity.setCreateUser(user.getSso());
		fileUploadActivity.setLastUpdateUser(user.getSso());
		fileUploadActivity.setUserRole(user.getUserProfile().getRoles().get(0).getMyBankRole());
    	return fileUploadActivity;
    }
}
