/**
 * Copyright GE
 */
package com.ge.treasury.mybank.web.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.ApplicationVersionInfoBuilder;
import com.ge.treasury.mybank.util.business.MyBankLogger;

/**
 * Common controller to obtain application info
 * 
 * @author MyBank Dev Team
 * 
 */
@Controller
@RequestMapping("/api/fx/v1")
public class MyBankUtilsController extends BaseController {

    @Autowired
    ApplicationVersionInfoBuilder applicationInfo;

    /**
     * Call method that read from manifest.mf file and returns app version info
     * to UI to display on status bar or in "about" menu
     * 
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/appInfo", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody
    List<String> getAppInfo(HttpServletRequest request) {
        List<String> response = new ArrayList<String>();
        User user = (User) request.getSession().getAttribute("User");

        String userId = user.getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);

        String info = null;
        info = applicationInfo.extendedPropertiesAsString();
        response.add(info);

        MyBankLogger.logPerf(this, userId, transactionId,
                "Application info found : " + info, System.currentTimeMillis()
                        - startTime);

        return response;
    }

    /**
     * Call method that read from manifest.mf file and returns Build-Version
     * 
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/versionInfo", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody
    String getBuildVersion(HttpServletRequest request) {

        User user = (User) request.getSession().getAttribute("User");

        String userId = user.getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);

        String version = null;
        version = applicationInfo.getVersion();

        MyBankLogger.logPerf(this, userId, transactionId,
                "Version info found : " + version, System.currentTimeMillis()
                        - startTime);

        return version;
    }

}
