package com.ge.treasury.mybank.web.controllers.portal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.user.service.impl.UserProfileService;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.web.controllers.BaseController;



@Controller
public class PortalController extends BaseController
{
	
	@Autowired
    AccountRequestService accountService;
	
	@Autowired
    private UserProfileService userService;
	
	/**
	 * at MyBank side, expose an end point, which takes user profile and gives pending requests
		DONT check-in code, call this service from MyTRS Portal, and see how it works
	 * @param request
	 */
	@RequestMapping(value = "/Portal/getPendingRequests/{sso}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
    public @ResponseBody Map<String, Integer> pendingRequestsService(@PathVariable("sso") String sso) throws DBException {
		UserProfile userRolesList = null;
		boolean isTreasuryUser = false;
		Map<String, List<String>> searchMap = new HashMap<String, List<String>>();
		searchMap.put("subBusName", new ArrayList<String>());
		searchMap.put("bussName", new ArrayList<String>());
		Map<String, Integer> map = new HashMap<String, Integer>();
		
		userRolesList = userService.getUserBySSODomain(sso);
		
		if (userRolesList != null) {

		    for (UserRole role : userRolesList.getRoles()) {
	            if (role.getMyBankRole().matches(
	                    ControllersConstants.IS_BUSINIESS_LEVEL_ROLE_REGEX) && role.getStatusRole().equalsIgnoreCase(ValidationConstants.MYBANK_IDM_STATUSACTIVE)) {
	                searchMap.get("subBusName").add(role.getSubBusiness());
	                searchMap.get("bussName").add(role.getBusiness());
	            } else {
	                isTreasuryUser = true;
	                break;
	            }
	        }
        }
		
		if(isTreasuryUser) 
		{
			int accReqList = accountService.getPendingRequests();
			map.put("countAccReq", accReqList);
		} else {
		    List<String> list = new ArrayList<String>();
		    list.add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
		    list.add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
		    searchMap.put("accountStatus", new ArrayList<String>());
		    int accReqList = accountService.getPendingRequests();
		    map.put("countAccReq", accReqList);
		}
		
		return map;
	}

}
