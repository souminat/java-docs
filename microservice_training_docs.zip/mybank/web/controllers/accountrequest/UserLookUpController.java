/**
 * Copyright GE
 */
package com.ge.treasury.mybank.web.controllers.accountrequest;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.user.service.impl.UserAuthorizationUtil;
import com.ge.treasury.mybank.business.user.service.impl.UserProfileService;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.ResourceNotFoundException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.web.controllers.BaseController;

/**
 * User LookUp Controller Class
 * 
 * @author MyBank Dev Team
 * 
 */
@Controller
@RequestMapping("/api/acct/v1")
public class UserLookUpController extends BaseController implements
        ValidationConstants {
    
    @Autowired
    private UserProfileService userProfileService;

    @RequestMapping(value = "/userLookUp", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody
    String userLookUp(
            @RequestParam(value = "code", required = true) String code) {
    	
		String prevState;
		do {
			prevState = code;
			code = StringEscapeUtils.unescapeHtml(code);
		} while (!Objects.equals(prevState, code));
        
		return userProfileService.userLookUp(code);
    }

    /**
     * Getting User session information
     * 
     * @param request
     * @return
     * @throws ValidationFailedException
     * @throws DBException
     * @throws ResourceNotFoundException
     */
    @RequestMapping(value = "/getUserSession", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody
    User getUserSessionInfo(HttpServletRequest request){
        
        User user = null;

        try {
			user =  (User) request.getSession().getAttribute("User");
			
			String userId = user.getUserProfile().getSso();
			String transactionId = MyBankLogger.getTransactionId();
			long startTime = System.currentTimeMillis();

			MyBankLogger.logDebug(this, "User Information "
			        + user.getUserProfile().getSso() + "-"
			        + user.getUserProfile().getRoles());

			MyBankLogger.logPerf(this, userId, transactionId, request
			        .getRequestURL().toString(), 0L);

			MyBankLogger.logPerf(this, userId, transactionId,
			        "User Session Information ", System.currentTimeMillis()
			                - startTime);
		} catch (Exception e) {
			MyBankLogger.logError(this, "Error in getting user session : " + e);
			throw new SystemException("Error in getting user session : " + e.getMessage());
		}
        return user;
    }
    
    @RequestMapping(value = "/treasureServicesUsers", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<UserProfile> getTreasureServicesUsers() {
    	return userProfileService.getUsersByRole(StringUtils.join(UserAuthorizationUtil.getElevatedAccessList(),","));
    }
}
