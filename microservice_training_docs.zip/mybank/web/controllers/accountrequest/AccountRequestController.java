/**
\ * Copyright GE
 */
package com.ge.treasury.mybank.web.controllers.accountrequest;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.cashpool.service.impl.CashpoolService;
import com.ge.treasury.mybank.business.user.service.impl.UserAuthorizationUtil;
import com.ge.treasury.mybank.config.CacheService;
import com.ge.treasury.mybank.domain.AccountRequestSearchCriteria;
import com.ge.treasury.mybank.domain.PaginatedResultList;
import com.ge.treasury.mybank.domain.accountrequest.AccountComment;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.accountrequest.LastUpdatedDetails;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserRole;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.AuthorizationException;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.ResourceNotFoundException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.validations.AccountValidator;
import com.ge.treasury.mybank.web.controllers.BaseController;

/**
 * REST services for Account Request
 * 
 * @author MyBank Dev Team
 * 
 */


@Controller
@RequestMapping("/api/acct/v1")
public class AccountRequestController extends BaseController {

	@Autowired
	private AccountRequestService accountRequestService;
	
	@Value("${mdm.ms.account}")
	private String accountUrl;
	
	@Autowired
	private CashpoolService cashPoolService;
	
	@Autowired
    private CacheService cacheService;
	
	private static final String ACCOUNT_PURPOSE = "accountPurpose";
    /**
     * Controller to save an account request
     * 
     * @param request
     * @param accRequest
     * @return
     * @throws ValidationFailedException
     * @throws ResourceNotFoundException
     * @throws BusinessException
     * @throws SystemException
     */
    @RequestMapping(value = "/accountRequests", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody AccountRequest postAccountRequest(
            HttpServletRequest request, @RequestBody AccountRequest accRequest)
            throws ValidationFailedException{

        User user = null != request ? (User) request.getSession().getAttribute("User") : null;
        
        String userId = null != user ? user.getUserProfile().getSso() : null;
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);
        BindingResult errors = new BeanPropertyBindingResult(accRequest,
                "accountRequest");
        AccountValidator validator = new AccountValidator(accountService,
                lookupService, messageValidator, mdmService);
        validator.validate(accRequest, errors);

        if (errors.hasErrors()) {
            for (ObjectError error : errors.getAllErrors()) {
                MyBankLogger.logDebug(this, "Error : " + error.getCode() + " "
                        + error.getDefaultMessage());
            }
            throw new ValidationFailedException(errors);
        } else {
	            // Getting create user to be able to check user authorization
	        	//Generic Exception Handled
	            try {
					if (accRequest.getAcctReqID() != null
					        && !(accRequest.getAcctReqID().toString()).isEmpty()
					        && accRequest.getCreateUser() == null) {
	
					    Map<String, Object> searchMap = null;
					    searchMap = new HashMap<String, Object>();
					    searchMap
					            .put("acctReqID", accRequest.getAcctReqID().toString());
	
					    AccountRequest accountRequest = accountService.findAccount(
					            user, searchMap);
					    accRequest.setCreateUser((null != accountRequest) ? accountRequest.getCreateUser() : null);
					}
	
					UserAuthorizationUtil.validateUserActionsByRole(accRequest, user,
					        true);
	                
					accountService.createAccountRequest(user, cleanAccountRequestValues(accRequest),
					        false, false);
				}
	            catch(ValidationFailedException | AuthorizationException e) {
	            	throw new BusinessException(e.getLocalizedMessage(),e);
	            }
	            catch (Exception e) {
				    MyBankLogger.logError(this, e.getMessage(), e);
					throw new SystemException(ControllersConstants.NEW_REQUEST_FAILED,e);
				}

        }

        MyBankLogger.logPerf(this, userId, transactionId, "Account Request id "
                + accRequest.getAcctReqID() + " created",
                System.currentTimeMillis() - startTime);

        return accRequest;
    }

    /**
     * This method is used to update the lookup values back to display name.
     * 
     * We are sending below fields to MDM as display name
     * 1) account purpose -- removed for account purpose multi select
     * 2) cashpool reject reason
     * 
     * @param accRequest
     * @return
     */
    private AccountRequest cleanAccountRequestValues(AccountRequest accRequest) {
        if(!StringUtils.isEmpty(accRequest.getCashPoolRejectReason())) {
            accRequest.setCashPoolRejectReason(lookupService.getDisplayName(accRequest.getCashPoolRejectReason()));
        }
        if (null != accRequest.getCompanyCode() && accRequest.getCompanyCode().contains(" - ")) {
            accRequest.setCompanyCode(accRequest.getCompanyCode().split(" - ")[0]);
        }
        return accRequest;
    }

    /**
     * @param request
     * @param start
     * @param limit
     * @param direction
     * @param orderBy
     * @param maxAccountsSize
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/accountRequests", method = RequestMethod.GET, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody PaginatedResultList<AccountRequest> getAccountRequests(
            HttpServletRequest request,
            @ModelAttribute AccountRequestSearchCriteria accountSearch){

        PaginatedResultList<AccountRequest> result = new PaginatedResultList<AccountRequest>();

        User user = (User) request.getSession().getAttribute("User");

        int defaultQueryParamCount = 4;
        boolean addSubBussConstraint = false;
        boolean addBussConstraint = false;

        for (UserRole role : user.getUserProfile().getRoles()) {
            if (role.getMyBankRole().matches(ControllersConstants.IS_BUSINIESS_LEVEL_ROLE_REGEX)
                    || ValidationConstants.ACCT_REQUEST_USER_TREASURY_DIVESTED.equalsIgnoreCase(role.getMyBankRole())) {
                if (accountSearch.getSubBusName() == null && !StringUtils.isEmpty(role.getSubBusiness())) {
                    accountSearch.setSubBusName(new TreeSet<String>());
                    addSubBussConstraint = true;
                    defaultQueryParamCount = 6;
                }
                if (accountSearch.getBussName() == null) {
                    accountSearch.setBussName(new TreeSet<String>());
                    addBussConstraint = true;
                    defaultQueryParamCount = 6;
                }

                if (addBussConstraint) {
                    CollectionUtils.addIgnoreNull(accountSearch.getBussName(),
                            role.getBusiness());
                }
                if (addSubBussConstraint) {
                    CollectionUtils.addIgnoreNull(
                            accountSearch.getSubBusName(),
                            role.getSubBusiness());
                }
            }
        }

        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), startTime);

        List<AccountRequest> accountRequestResponse = null;

      //Generic Exception Handled
        try {
            Map<String, Object> map = accountSearch.toMap();
            if (map.keySet().size() > defaultQueryParamCount
                    && !map.keySet().contains("requestStatus")) {
                Set<String> accountStatus = new TreeSet<String>();
                accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
                accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
                accountStatus.add(ValidationConstants.ACCOUNT_STATUS_CANCELLED);
                accountStatus.add(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
                map.put("requestStatus", accountStatus);
            } else if (!map.keySet().contains("requestStatus")) {
                Set<String> accountStatus = new TreeSet<String>();
                accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
                accountStatus
                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
                map.put("requestStatus", accountStatus);
            }
            
            if(map.containsKey(ACCOUNT_PURPOSE)){
                map.put(ACCOUNT_PURPOSE,lookupService.getDisplayName((String)map.get(ACCOUNT_PURPOSE)));
            }

            accountRequestResponse = accountService.findAccounts(user, map);
            
            result.setResultList(accountRequestResponse);
            result.setTotalRecords((accountRequestResponse == null || accountRequestResponse.isEmpty()) ? 0 : accountRequestResponse.get(0)
                    .getRecordCount());
            result.setRequestQueryString(request.getQueryString());

        }catch(DBException e){
            MyBankLogger.logError(this, e.getMessage(), e);
        	throw new DBException("Unable to fetch request inbox records : "+ControllersConstants.FETCH_DATA_FAILED, e);
        	
        }catch (Exception dbe) {
            MyBankLogger.logError(this, dbe.getMessage(), dbe);
        	  throw new SystemException(
                      ControllersConstants.ACCOUNTS_NOTFOUND, dbe);
          }

        
        // Set result
       
        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), System.currentTimeMillis()
                - startTime);

        return result;
    }

    /**
     * 
     * @param request
     * @param acctReqID
     * @return
     * @throws ValidationFailedException
     * @throws DBException
     * @throws ResourceNotFoundException 
     */
    @RequestMapping(value = "/accountRequest", method = RequestMethod.GET, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody AccountRequest getAccountRequest(
            HttpServletRequest request,
            @ModelAttribute AccountRequestSearchCriteria accountSearch){

        User user = null != request ? (User) request.getSession().getAttribute("User") : null;
        AccountRequest result = null;
        
        if(null != user){
	        String userId = user.getUserProfile().getSso();
	        String transactionId = MyBankLogger.getTransactionId();
	        long startTime = System.currentTimeMillis();
	
	        MyBankLogger.logPerf(this, userId, transactionId, request
	                .getRequestURL().toString(), startTime);
	
	        
	
	      //Generic Exception Handled
	        try {
	        	if(null != accountSearch){
	        		result = accountService.findAccount(user, accountSearch.toMap());
	        	}
	        } 
	        catch(DBException dbe){
	        	MyBankLogger.logError(this, dbe.getMessage(), dbe);
	        	throw new DBException("Failed to retrieve the selected request : "+ControllersConstants.FETCH_DATA_FAILED, dbe);
	        }
	        catch (Exception dbe) {
	            MyBankLogger.logError(this, dbe.getMessage(), dbe);
	            throw new SystemException("Unable to find the searched account : "+ControllersConstants.ACCOUNT_NOTFOUND, dbe);
	           
	        }
	
	        
	
	        MyBankLogger.logPerf(this, userId, transactionId, request
	                .getRequestURL().toString(), System.currentTimeMillis()
	                - startTime);
	        }

        return result;
    }
    
    /**
     * Cancel Account request
     * 
     * @param request
     * @param acctReqID
     * @param lastUpdateDate
     * @param comment
     * @return
     * @throws ValidationFailedException
     * @throws DBException
     */
    @RequestMapping(value = "/cancelAccountRequest", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody Boolean cancelAccountRequest(
            HttpServletRequest request,
            @RequestParam(value = "acctReqID", required = true) long acctReqID,
            @RequestParam(value = "lastUpdateDate", required = true) String lastUpdateDate,
            @RequestParam(value = "comment", required = true) String comment)
            throws ValidationFailedException, DBException {

        User user = (User) request.getSession().getAttribute("User");
        LastUpdatedDetails lastUpdatedDetails = null;
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), startTime);

        AccountRequest accRequest = new AccountRequest();
        accRequest.setAcctReqID(new Long(acctReqID));
        accRequest.setLastUpdateDate(new Date(new Long(lastUpdateDate)));
        BindingResult errors = new BeanPropertyBindingResult(accRequest,
                "accountRequest");

        //Generic Exception Handled
        try {
			lastUpdatedDetails = accountService.getLastUpdatedDetails(acctReqID);

			if (lastUpdatedDetails.getLastUpdatedDate() != null
			        && accRequest.getLastUpdateDate() != null
			        && (lastUpdatedDetails.getLastUpdatedDate()).after(accRequest
			                .getLastUpdateDate())) {
			    errors.reject("BusinessException",
			            "Request has been modified by another user: "
			                    + lastUpdatedDetails.getLastUpdatedUser());
			}

			if (errors.hasErrors()) {
			    for (ObjectError error : errors.getAllErrors()) {
			        MyBankLogger.logDebug(this, "Error : " + error.getCode() + " "
			                + error.getDefaultMessage());
			    }
			    throw new ValidationFailedException(errors);
			} else {
				cancelAccount(user, acctReqID, comment);
			}
		} catch (DBException dbe) {
			throw new DBException(dbe.getMessage(), dbe);
		} catch(Exception e){
			throw new SystemException("Unable to cancel account request for request ID : "+acctReqID, e);
		}

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), System.currentTimeMillis()
                - startTime);

        return true;
    }
    
    private void cancelAccount(User user,long acctReqID,String comment){
    	try {
	        accountService
	                .cancelAccount(user, new Long(acctReqID), comment);
	    } catch (DBException dbe) {
	        MyBankLogger.logError(this, dbe.getMessage(), dbe);
	        throw new DBException(ControllersConstants.FETCH_DATA_FAILED, dbe);
	    }
    }

    /**
     * TCode inflight requests
     * 
     * @param request
     * @param tCode
     * @return
     * @throws DBException
     */
    @RequestMapping(value = "/isTcodeInflightRequests/{tCode}", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody AccountRequest isTcodeInflightRequest(
            HttpServletRequest request, @PathVariable("tCode") String tCode)
            throws DBException {

        User user = (User) request.getSession().getAttribute("User");

        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);

        Long accountRequestId = null;
        
         AccountRequest accountRequest;
         //Generic Exception Handled
		try {
			accountRequestId = accountService
			        .getPendingCloseOrModifyByTcode(tCode.toUpperCase());
			accountRequest = new AccountRequest();
			accountRequest.setAcctReqID(accountRequestId);
		} catch (Exception e) {
		    MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Failed to fetch accountRequestId for tCode"+tCode,e);
		}
        MyBankLogger.logPerf(this, userId, transactionId,
                "Queried close accounts for Tcode: " + tCode.toUpperCase(),
                System.currentTimeMillis() - startTime);

        return accountRequestId == null ? null : accountRequest;
    }

    /**
     * Get comments by TCode
     * 
     * @param request
     * @param tCode
     * @return
     * @throws DBException
     */
    @RequestMapping(value = "/getCommentsByTcode/{tCode}", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody List<AccountComment> getCommentsByTcode(
            HttpServletRequest request, @PathVariable("tCode") String tCode)
            throws DBException {
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();
        User user = (User) request.getSession().getAttribute("User");
        String userId = user.getUserProfile().getSso();

        List<AccountComment> comments = new ArrayList<AccountComment>();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);
        //Generic Exception Handled
        try {
			if (tCode != null) {
			    comments = accountService.getCommentsByTcode(tCode);
			}
		} catch (Exception e) {
		    MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Failed to fetch commnets for tCode"+tCode,e);
		}

        MyBankLogger.logPerf(this, userId, transactionId, "Recieved "
                + comments.size() + " comments for account with T-Code: "
                + tCode, System.currentTimeMillis() - startTime);

        return comments;
    }

    /**
     * Api to get requestId by TCode
     * 
     * @param tCode
     * @param request
     * @return
     * @throws DBException
     */
    @RequestMapping(value = "/getRequestIdByTcode/{tCode}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody String getRequestIdByTcode(
            @PathVariable("tCode") String tCode, HttpServletRequest request)
            throws DBException {
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();
        User user = (User) request.getSession().getAttribute("User");
        String userId = user.getUserProfile().getSso();
        String requestId = null;

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);
        //Generic Exception Handled
        try {
			if (tCode != null) {
			    requestId = accountService.getRequestIdByTcode(tCode);
			}
		} catch (Exception e) {
		    MyBankLogger.logError(this, e.getMessage(), e);
			throw new SystemException("Failed to fetch RequestID for tCode"+tCode,e);
		}

        MyBankLogger.logPerf(this, userId, transactionId, "Recieved "
                + requestId + " for account with T-Code: " + tCode,
                System.currentTimeMillis() - startTime);

        return requestId;
    }

    /**
     * Api to reserve bank account - Update request with isBankReserved flag to
     * Y
     * 
     * @param accRequest
     * @param request
     * @return
     * @throws SystemException
     * @throws ResourceNotFoundException
     * @throws BusinessException
     */
    @RequestMapping(value = "/reserveBankAccount", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody AccountRequest reserveBank(
            @RequestBody AccountRequest accRequest, HttpServletRequest request)throws ValidationFailedException {
        LastUpdatedDetails lastUpdatedDetails = null;
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();
        User user = (User) request.getSession().getAttribute("User");
        String userId = user.getUserProfile().getSso();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);

        BindingResult errors = new BeanPropertyBindingResult(accRequest,
                "accountRequest");
        //Generic Exception Handled
			try {
				lastUpdatedDetails = accountService.getLastUpdatedDetails(accRequest
				        .getAcctReqID());

				
				if (lastUpdatedDetails.getLastUpdatedDate() != null
				        && accRequest.getLastUpdateDate() != null
				        && (lastUpdatedDetails.getLastUpdatedDate()).after(accRequest
				                .getLastUpdateDate())) {
				    errors.reject("BusinessException",
				            "Request has been modified by another user: "
				                    + lastUpdatedDetails.getLastUpdatedUser());
				}
			} catch (DBException dbe) {
			    MyBankLogger.logError(this, dbe.getMessage(), dbe);
				throw new DBException(dbe.getMessage(), dbe);
			} 
			
			catch (Exception e) {
			    MyBankLogger.logError(this, e.getMessage(), e);
				throw new SystemException("Unable to reserve account for account request ID : "+accRequest.getAcctReqID(), e);
			}

			if (errors.hasErrors()) {
			    for (ObjectError error : errors.getAllErrors()) {
			        MyBankLogger.logDebug(this, "Error : " + error.getCode() + " "
			                + error.getDefaultMessage());
			    }
			    throw new ValidationFailedException(errors);
			} else {

			    // First call ReserveBankAccount then save request
			    try {
					accountService.reserveBankAccount(user, accRequest);
					
					// Update request with isBankReserved flag
					accountService.createAccountRequest(user, cleanAccountRequestValues(accRequest),
					        false, false);
				} catch (DBException dbe) {
				    MyBankLogger.logError(this, dbe.getMessage(), dbe);
					throw new DBException(ControllersConstants.FETCH_DATA_FAILED, dbe);
				}
			    catch(BusinessException be){
			        MyBankLogger.logError(this, be.getMessage(), be);
			    	throw new BusinessException(be.getMessage());
			    }
			    catch (Exception e) {
			        MyBankLogger.logError(this, e.getMessage(), e);
					throw new SystemException("Unable to reserve account for account request ID : "+accRequest.getAcctReqID(),e);
				}
			    
			    
			}
		
        MyBankLogger.logPerf(this, userId, transactionId,
                "Bank Account Reserved " + accRequest.getAcctReqID(),
                System.currentTimeMillis() - startTime);

        return accRequest;
    }
    
    @RequestMapping(value = "/getExportInbox", method = RequestMethod.GET, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody PaginatedResultList<AccountRequest> getExportData(
            HttpServletRequest request,
            @ModelAttribute AccountRequestSearchCriteria accountSearch) {
        
        int defaultQueryParamCount = 4;
        boolean addSubBussConstraint = false;
        boolean addBussConstraint = false;
        Map<String, String> lovLookupValues = accountService.getLovLookUpValues();
        PlatformInstance platformInstance = new PlatformInstance();
        platformInstance.setPlatformName("Not Found");
        platformInstance.setInstance("Not Found");
        List<AccountRequest> accountRequestResponse = null;
        User user = (User) request.getSession().getAttribute("User");
        
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        for (UserRole role : user.getUserProfile().getRoles()) {
            if (role.getMyBankRole().matches(
                    ControllersConstants.IS_BUSINIESS_LEVEL_ROLE_REGEX) || ValidationConstants.ACCT_REQUEST_USER_TREASURY_DIVESTED.equalsIgnoreCase(role.getMyBankRole())) {
                if (accountSearch.getSubBusName() == null && !StringUtils.isEmpty(role.getSubBusiness())) {
                    accountSearch.setSubBusName(new TreeSet<String>());
                    addSubBussConstraint = true;
                    defaultQueryParamCount = 6;
                }
                if (accountSearch.getBussName() == null) {
                    accountSearch.setBussName(new TreeSet<String>());
                    addBussConstraint = true;
                    defaultQueryParamCount = 6;
                }

                if (addSubBussConstraint) {
                    CollectionUtils.addIgnoreNull(accountSearch.getBussName(),
                            role.getBusiness());
                }
                if (addBussConstraint) {
                    CollectionUtils.addIgnoreNull(
                            accountSearch.getBussName(),
                            role.getBusiness());
                }
            }
        }
        //Generic Exception Handled
        PaginatedResultList<AccountRequest> result = new PaginatedResultList<AccountRequest>();
        try {
		        	Map<String, Object> map = accountSearch.toMap();
		        	
		            if (map.keySet().size() > defaultQueryParamCount
		                    && !map.keySet().contains("requestStatus")) {
		                Set<String> accountStatus = new TreeSet<String>();
		                accountStatus
		                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
		                accountStatus
		                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
		                accountStatus.add(ValidationConstants.ACCOUNT_STATUS_CANCELLED);
		                accountStatus.add(ValidationConstants.ACCOUNT_STATUS_COMPLETED);
		                map.put("requestStatus", accountStatus);
		            } else if (!map.keySet().contains("requestStatus")) {
		                Set<String> accountStatus = new TreeSet<String>();
		                accountStatus
		                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_BANKCONF);
		                accountStatus
		                        .add(ValidationConstants.ACCOUNT_STATUS_PEND_TREASURY);
		                map.put("requestStatus", accountStatus);
		            }
	        	
	        accountRequestResponse = accountService.getExportData(map);
            
	        //Set display name  for company code reject reason based on the lookup code
	        for(AccountRequest acctReq : accountRequestResponse) {
	        	acctReq.setSubtypeCode(lovLookupValues.getOrDefault(acctReq.getSubtypeCode(), acctReq.getSubtypeCode()));
	        	acctReq.setBankClassification(lovLookupValues.getOrDefault(acctReq.getBankClassification(), acctReq.getBankClassification()));
	        	acctReq.setCashPoolProcessCode(lovLookupValues.getOrDefault(acctReq.getCashPoolProcessCode(), acctReq.getCashPoolProcessCode()));
            	acctReq.setCoCodeRejectReason(lovLookupValues.getOrDefault(acctReq.getCoCodeRejectReason(), acctReq.getCoCodeRejectReason()));
            }
            result.setResultList(accountRequestResponse);
           	result.setTotalRecords(accountRequestResponse.size());
           	
        } catch (DBException dbe) {
            MyBankLogger.logError(this, dbe.getMessage(), dbe);
            throw new DBException("Failed to retrieve data for excel sheet : "+ControllersConstants.FETCH_DATA_FAILED, dbe);
        }catch(Exception e){
            MyBankLogger.logError(this, e.getMessage(), e);
        	throw new SystemException("Unable to export inbox data in excel sheet : "+e.getMessage(),e);
        }
        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), System.currentTimeMillis()
                - startTime);
        
        return result;
    }

    @RequestMapping(value = "/assignRequestToUser", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public @ResponseBody Boolean assignRequestToUser(
            HttpServletRequest request,
            @RequestBody AccountRequest accRequest)
            throws ValidationFailedException, DBException {
    	
    	return accountRequestService.assignRequestToUser(accRequest);
    }
    @RequestMapping(value = "/checkCashPoolValidity", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody public AccountRequest checkCashPoolValidity(
            HttpServletRequest request,
            @RequestBody AccountRequest accReq
         )
            throws ValidationFailedException{
     
        try {
        	AccountRequest acctReqReturn=null;
        	User user = (User) request.getSession().getAttribute("User");
        	String userId = user.getUserProfile().getSso();
    		String transactionId = MyBankLogger.getTransactionId();
       
        	MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
        	
        	acctReqReturn=cashPoolService.checkCashPoolValidity(user, accReq);
        	MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
        	return acctReqReturn;
        }catch(BusinessException|SystemException ex){
            MyBankLogger.logError(this, "AccountRequestController.checkCashPoolValidity failed : ",ex);
            throw ex;
        }
		 catch(Exception e){
		     MyBankLogger.logError(this, "AccountRequestController.checkCashPoolValidity failed : ",e);
		     throw new SystemException("Unable to get the channel details : ".concat(e.getMessage()), e);
		}

      
       
    }
    /**
     *  @RequestMapping(value = "/callCashPoolChannel", method = RequestMethod.POST, consumes = "application/json")
    	@ResponseStatus(HttpStatus.OK)
    	@ResponseBody public AccountRequest callCashPoolChannel(
            HttpServletRequest request,
            @RequestBody AccountRequest accReq
         )
            throws ValidationFailedException{
     
        try {
        	AccountRequest acctReqReturn=null;
        	User user = (User) request.getSession().getAttribute("User");
        	String userId = user.getUserProfile().getSso();
    		String transactionId = MyBankLogger.getTransactionId();
            String channelType=null;
        	MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
        	if("CASHPOOLPROCODE_RED".equals(accReq.getCashPoolProcessCode())){
        		channelType="RED_CHANNEL";  	
        	}
        	else if("CASHPOOLPROCODE_GREEN".equals(accReq.getCashPoolProcessCode())){
        		 channelType="GREEN_CHANNEL";
        	}
        	else{
        		channelType="STAND_ALONE";
        	}
        	
        	acctReqReturn=cashPoolService.callChannel(accReq, channelType);
        	
        	MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
        	return acctReqReturn;
        }catch(BusinessException|SystemException ex){
            MyBankLogger.logError(this, "AccountRequestController.callCashPoolChannel failed : ",ex);
            throw ex;
        }
		 catch(Exception e){
		     MyBankLogger.logError(this, "AccountRequestController.callCashPoolChannel failed : ",e);
		     throw new SystemException("Unable to get the channel details : ".concat(e.getMessage()), e);
		}
    }
     *
     */
    
    @RequestMapping(value = "/checkCashPoolDecisionAvailability", method = RequestMethod.POST, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody public AccountRequest checkCashPoolDecisionAvailability(
            HttpServletRequest request,
            @RequestBody AccountRequest accReq
         )
            throws ValidationFailedException{
     
        try {
            AccountRequest acctReqReturn=null;
            User user = (User) request.getSession().getAttribute("User");
            String userId = user.getUserProfile().getSso();
            String transactionId = MyBankLogger.getTransactionId();
          
            MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
            
            
            acctReqReturn=cashPoolService.checkCashPoolDecisionAvailability(accReq);
            
            MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
            return acctReqReturn;
        }catch(BusinessException|SystemException ex){
            MyBankLogger.logError(this, "AccountRequestController.checkCashPoolDecisionAvailability failed : ",ex);
            throw ex;
        }
         catch(Exception e){
             MyBankLogger.logError(this, "AccountRequestController.checkCashPoolDecisionAvailability failed : ",e);
             throw new SystemException("Unable to get the channel details : ".concat(e.getMessage()), e);
        }

      
       
    }
    
    
    @RequestMapping(value = "/getPlatformInstanceByTcode", method = RequestMethod.GET, consumes = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public AccountRequest getLastUpdatedPlatformInstance(HttpServletRequest request,
            @RequestParam(value = "tCode") String tCode) {

        Long platformInstance = accountService.getLastUpdatedPlatformInstance(tCode);
        List<PlatformInstance> platformInstances = cacheService.fetchPlatformData().stream()
                .filter(platform -> platform.getPlatformInstanceId().equals(platformInstance))
                .collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(platformInstances)) {
            AccountRequest accReq = new AccountRequest();
            accReq.setPlatformInstance(platformInstances.get(0));
            return accReq;
        } else {
            return null;
        }

    }
    
}
