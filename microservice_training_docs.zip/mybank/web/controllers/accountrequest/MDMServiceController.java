/**
 * 
 */
package com.ge.treasury.mybank.web.controllers.accountrequest;

import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ACTIVE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_GOLD_LE_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_REQUEST_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_ACCOUNT_CENTRALIZE_T_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_COUNTRY_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_LEGAL_NAME;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_BANK_TYPE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.BANK_MDM_ID;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.CURRENCY_CURRENCY_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.FILTER_CONST;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PARTY_NM;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PARTY_STATUS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PRIMARY_ALT_CODE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.LE_PRIMRY_SCOURCE_SYSTEM;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.MDM_MARS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.MY_BANK;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_AND;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_EQUALS;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_LIKE;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.OPERATOR_OR;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.ORDER_DESCENDING;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.SELECT;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_1;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_2;
import static com.ge.treasury.mybank.util.business.constants.MDMConstants.UPPER_LIKE;
import static com.ge.treasury.mybank.util.business.constants.ValidationConstants.MDM_ACCT_STATUS_INPROCESS;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.cashpool.service.impl.DroolsService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMService;
import com.ge.treasury.mybank.business.mdm.service.impl.MDMUtil;
import com.ge.treasury.mybank.domain.accountrequest.AccountRequest;
import com.ge.treasury.mybank.domain.mdm.MDMAccount;
import com.ge.treasury.mybank.domain.mdm.MDMSearchAccounts;
import com.ge.treasury.mybank.domain.mdm.MdmSearchCriteria;
import com.ge.treasury.mybank.domain.mdm.MdmSearchCriteriaRule;
import com.ge.treasury.mybank.domain.mdm.Sort;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.MDMConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.DBException;
import com.ge.treasury.mybank.util.business.exceptions.ResourceNotFoundException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.util.business.validations.AccountValidator;
import com.ge.treasury.mybank.util.business.validations.MessageValidator;
import com.ge.treasury.mybank.util.web.SanatizedServletRequest;
import com.ge.treasury.mybank.web.controllers.BaseController;

/**
 * @author MyBank Dev Team
 * 
 */

@Controller
@RequestMapping("/api/acct/v1")
public class MDMServiceController extends BaseController {

	@Value("${mdm.ms.accountType}")
	private String accountTypeUrl;

	@Value("${mdm.ms.country}")
	private String countryUrl;

	@Value("${mdm.ms.currency}")
	private String currencyUrl;
	
	@Value("${mdm.ms.le}")
	private String le_v2Url;
	
	@Value("${mdm.ms.business}")
	private String businessUrl;

	@Value("${mdm.ms.buhierarchy}")
	private String buHierarchyUrl;
	
	@Value("${mdm.ms.bank}")
	private String bankUrl;

	@Value("${mdm.ms.accountCore}")
	private String accountCoreUrl;

	@Value("${mdm.ms.account}")
	private String accountUrl;
	
	@Value("${mdm.ms.document}")
	private String documentTypesUrl;

	@Value("${mdm.ms.routeCode}")
	private String routeCodeUrl;
	@Value("${mdm.ms.companyCode}")
	private String companyCodeUrl;

	@Value("${mdm.ms.me}")
	private String meUrl;

	@Autowired
	DroolsService droolsService;
	
	@Autowired
	AccountRequestService accountService;

	@Autowired
	MyBankLookupService lookupService;

	@Autowired
	MessageValidator messageValidator;

	@Autowired
	MDMService mdmService;
	
	 private PolicyFactory policy = new HtmlPolicyBuilder().toFactory();
	
    @Autowired
    private OAuth2RestOperations mdmBankCentralizeTemplate;

	/**
	 * Controller to get MDM account types list
	 * 
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMAccountTypes", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	// 200
	public @ResponseBody String getMDMAccountTypes(HttpServletRequest request) throws BusinessException {

		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		long startTime = System.currentTimeMillis();
		MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);

		String url = accountTypeUrl;

		MyBankLogger.logPerf(this, userId, transactionId, "getMDMAccountTypes", System.currentTimeMillis() - startTime);

		HashMap<String, String> params = new HashMap<>();
		params.put("$totalCountRequired", "true");
		params.put("$start_index", "0");

		return this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);

	}

	/**
	 * Controller to get MDM account types list
	 * 
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMDocumentTypes", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	// 200
	public @ResponseBody String getMDMDocumentTypes(HttpServletRequest request) throws BusinessException {

		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);

		String url = documentTypesUrl;

		
		HashMap<String, String> params = new HashMap<>();
		
		final StringBuilder filter = new StringBuilder();

		filter.append("(");

		filter.append("dmn_type  = 'BANK'" );

		filter.append(")");
		params.put(FILTER_CONST, filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", "0");

		return this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
	}

	/**
	 * Controller to get MDM country list
	 * 
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMCountries", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	// 200
	public @ResponseBody String getMDMCountries(HttpServletRequest request) throws BusinessException {

		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);

		final StringBuilder filter = new StringBuilder();

		filter.append("(");

		filter.append(UPPER_2 + "CNTRY_STATUS" + ") = UPPER('" + ACTIVE + "')");

		filter.append(")");
		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());
		return this.mdmService.callMDMDenodo(params, countryUrl, HttpMethod.GET, true);

	}

	/**
	 * Controller to get MDM currency list
	 * 
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMCurrency", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	// 200
	public @ResponseBody String getMDMCurrency(HttpServletRequest request) throws BusinessException {

		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);

		final StringBuilder filter = new StringBuilder();

		filter.append("(");

		filter.append(UPPER_2 + CURRENCY_CURRENCY_STATUS + ") = UPPER('" + ACTIVE + "')");

		filter.append(")");

		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());

		return this.mdmService.callMDMDenodo(params, currencyUrl, HttpMethod.GET, true);

		
	}

	/**
	 * Controller to get MDM le list
	 * 
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@RequestMapping(value = "/getMDMLE", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String getMDMLE(@RequestParam(value = "code", required = true) String code,
			HttpServletRequest request) throws BusinessException {

		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String newCode = paramsSanitizer.getParameter(code);
		
		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		long startTime = System.currentTimeMillis();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);
		  
		
		MyBankLogger.logPerf(this, userId, transactionId, "getMDMLE",
		System.currentTimeMillis() - startTime);
		  
		 

		return mdmService.callMDMDenodo(mdmService.setLeFilterParams(true, newCode), le_v2Url, HttpMethod.GET, true);
	}

	/**
	 * @deprecated (when - for developing US32968 - Le migration, 
	 *              why - le address details can be derived from a single call to legalpartygenericservice along with le code)
	 *             
	 */
	@Deprecated
	@Cacheable(value = "dynamic", key = "#root.methodName+#code")
	@RequestMapping(value = "/getLeLocationAttributes/{code}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String getLeLocationAttributes(@PathVariable("code") String code, HttpServletRequest request)
			throws SystemException {

		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String newCode = paramsSanitizer.getParameter(code);
		
		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		long startTime = System.currentTimeMillis();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

		  MdmSearchCriteria searchCriteria = new MdmSearchCriteria();
		  searchCriteria.setEntityName(MDMConstants.ENTITY_NAME_LE);
		  searchCriteria.setRequestor(MY_BANK); searchCriteria.setPageStart(0);
		  searchCriteria.setPageIncrement(1); searchCriteria
		  .setResponseAttributes("Core Attributes,Location Attributes");
		  
		  List<Sort> sortList = new ArrayList<Sort>(); Sort sort = new Sort();
		  sort.setAttribute(LE_PRIMARY_ALT_CODE);
		  sort.setOrder(ORDER_DESCENDING); sortList.add(sort);
		  searchCriteria.setSort(sortList);
		  
		  List<MdmSearchCriteriaRule> rules = new
		  ArrayList<MdmSearchCriteriaRule>();
		  
		  MdmSearchCriteriaRule rule = new MdmSearchCriteriaRule();
		  List<String> ruleValues = new ArrayList<String>();
		  rule.setAttribute(LE_PRIMARY_ALT_CODE);
		  rule.setOperator(OPERATOR_EQUALS); ruleValues.add(newCode);
		  rule.setValue(ruleValues); rules.add(rule);
		  
		  MdmSearchCriteriaRule srcSysRule = new MdmSearchCriteriaRule();
		  List<String> srcSysRuleValues = new ArrayList<String>();
		  srcSysRule.setAttribute("PRIMRY_SRCE_SYS");
		  srcSysRule.setOperator(OPERATOR_EQUALS);
		  srcSysRuleValues.add("GOLD"); srcSysRule.setValue(srcSysRuleValues);
		  rules.add(srcSysRule);
		  
		  searchCriteria.setSearchCriteriaList(rules);
		  
		 String response = mdmService.callMDM(MDMUtil.constructJsonString(searchCriteria), le_v2Url,
				 mdmBankCentralizeTemplate);
		  
		  MyBankLogger.logPerf(this, userId, transactionId, "getLeLocationAttributes",
		  System.currentTimeMillis() - startTime);

		 return response;
	}

	/**
	 * Controller to get MDM business list
	 * 
	 * @deprecated
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@Deprecated
	@Cacheable(value = "dynamic", key = "#root.methodName + #code")
	@RequestMapping(value = "/getMDMBusiness", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String getMDMBusiness(@RequestParam(value = "code", required = true) String code,
			HttpServletRequest request) throws BusinessException {

		User user = (User) request.getSession().getAttribute("User");
		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

		String newCode = paramsSanitizer.getParameter(code);
		Map<String, String> params = mdmService.setMDMBusinessParams(newCode,true);

		return this.mdmService.callMDMDenodo(params, businessUrl, HttpMethod.GET, true);

	}

	
	/**
     * This method will give the business/sub-business based on the buCode passed.
     * 1) get the bu code from the company code service
     * 2) hit the bu hierarchy service with bu code as the filter to fetch the business/sub-business
     * 
     * @param buCode
     * @return
     */
	@RequestMapping(value = "/getMDMDerivedBusiness", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody public String getMDMDerivedBusiness(@RequestParam(value = "buCode",required = true) String code,
			HttpServletRequest request){

		User user = (User) request.getSession().getAttribute("User");
		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

		String newCode = paramsSanitizer.getParameter(code);
		
		return this.mdmService.getBusinessFromBu(newCode, false);

	}
	
	/**
     * This method will give the business/sub-business based on the buCode passed.
     * 1) get the bu code from the company code service
     * 2) hit the bu hierarchy service with bu code as the filter to fetch the business/sub-business
     * 
     * @param buCode
     * @return
     */
	@RequestMapping(value = "/getMDMBuCodes", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody public String getMDMDBuCodes(@RequestParam(value = "code",required = true) String code
	        ,@RequestParam(value = "requireActive",required = false) boolean requireActive
			,HttpServletRequest request){
		User user = (User) request.getSession().getAttribute("User");
		SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

		String newCode = paramsSanitizer.getParameter(code);
		boolean newRequireActive = Boolean.parseBoolean(String.valueOf(requireActive));
		Map<String, String> params = mdmService.setMDMBusinessParams(newCode,newRequireActive);
		
		return this.mdmService.callMDMDenodo(params, buHierarchyUrl, HttpMethod.GET, true);
	}
	
    @Cacheable(value = "dynamic", key = "#root.methodName + #code")
    @RequestMapping(value = "/getBusSubbusAR", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody public List<Map<String, String>> getBusSubbusAR(@RequestParam(value = "code",required = true) String code,
            HttpServletRequest request){
        User user = (User) request.getSession().getAttribute("User");
        SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

        String newCode = paramsSanitizer.getParameter(code);
        
        return accountService.getBusSubbus(newCode);
    }
    
    @Cacheable(value = "dynamic", key = "#root.methodName + #code")
    @RequestMapping(value = "/getBuCodesAR", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody public List<Map<String, String>> getBuCodesAR(@RequestParam(value = "code",required = true) String code,
            HttpServletRequest request){
        User user = (User) request.getSession().getAttribute("User");
        SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

        String newCode = paramsSanitizer.getParameter(code);
        return accountService.getBuCodes(newCode);
    }
    
	/**
	 * Controller to get MDM bank list
	 * 
	 * @return String
	 * @throws ValidationFailedException
	 * @throws DBException
	 */
	@Cacheable(value = "dynamic", key = "#root.methodName + #code + #countryCode")
	@RequestMapping(value = "/getMDMBank", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String getMDMBank(@RequestParam(value = "searchTerm", required = true) String code,
			@RequestParam(value = "countryCode", required = true) String countryCode, HttpServletRequest request)
			throws BusinessException{

		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		SanatizedServletRequest paramsSanatizer = new SanatizedServletRequest(request);
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanatizer.getQueryString(request.getRequestURL().toString()), 0L);

		String url = bankUrl;


		String newCode = paramsSanatizer.getParameter(code);
		String newCountryCode = paramsSanatizer.getParameter(countryCode);
		
		StringBuilder filter = new StringBuilder();
		
		try {
			filter.append("(");
			if (null != StringUtils.trimToNull(newCode)) {
				filter.append("(");
				filter.append(
						UPPER_2 + BANK_BANK_LEGAL_NAME + ") like UPPER('%" + URLDecoder.decode(newCode, MDMConstants.UTF_8) + "%')");

				filter.append(" or ");

				filter.append(UPPER_2 + BANK_MDM_ID + ") like UPPER('%" + URLDecoder.decode(newCode, MDMConstants.UTF_8) + "%')");
				filter.append(")");

			}

			if (null != StringUtils.trimToNull(newCountryCode)) {

				filter.append(" and  ");

				filter.append(
						UPPER_2 + BANK_BANK_COUNTRY_CODE + ") = UPPER('" + URLDecoder.decode(newCountryCode, MDMConstants.UTF_8) + "')");

			}

			filter.append(" and  ");

			filter.append(UPPER_2 + BANK_BANK_TYPE + ") = UPPER('" + URLDecoder.decode("BANK", MDMConstants.UTF_8) + "')");

			filter.append(" and  ");

			filter.append(
					UPPER_2 + BANK_BANK_STATUS + ") = UPPER('" + URLDecoder.decode("Active", MDMConstants.UTF_8) + "')");

			filter.append(")");
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in decodeing MDM Bank code : " + e);
			throw new SystemException("Error in decoding MDM Bank code : " + e.getMessage());
		}

		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", "0");

		String jsonOutput = this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);
		return jsonOutput;

	}

	/**
	 * Controller to call MDM service and generate tcode
	 * 
	 * @param request
	 * @param accRequest
	 * @return
	 * @throws ValidationFailedException
	 * @throws DBException
	 * @throws ResourceNotFoundException
	 */
	@RequestMapping(value = "/generateMDMTCode", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	// 200
	public @ResponseBody AccountRequest generateMDMTCode(HttpServletRequest request,
			@RequestBody AccountRequest accRequest) throws ValidationFailedException {

		User user = null != request ? (User) request.getSession().getAttribute("User") : null;

		if(null != user){
			
			String userId = user.getUserProfile().getSso();
			String transactionId = MyBankLogger.getTransactionId();
			long startTime = System.currentTimeMillis();
	
			MyBankLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);
	
			BindingResult errors = new BeanPropertyBindingResult(accRequest, "accountRequest");
			AccountValidator validator = new AccountValidator(accountService, lookupService, messageValidator, mdmService);
			validator.validate(accRequest, errors);
	
			if (null != errors && errors.hasErrors()) {
				for (ObjectError error : errors.getAllErrors()) {
					MyBankLogger.logDebug(this, "Error : " + error.getCode() + " " + error.getDefaultMessage());
				}
				throw new ValidationFailedException(errors);
			} else {
	
				MDMAccount mdmAcct = mdmService.constructMDMAccount(accRequest, MDM_ACCT_STATUS_INPROCESS);
				Object tCodeStr = mdmService.callMDMBankAccountCentralize(mdmAcct);
				if(null != tCodeStr && null != accRequest){
					String tcode = tCodeStr.toString();
					accRequest.settCode(tcode);
				}
				try {
					 accountService.createAccountRequest(user, accRequest, false, false);
				} catch (BusinessException e) {
					MyBankLogger.logError(this, e.getMessage(), e);
				}
			}
			MyBankLogger.logPerf(this, userId, transactionId,
					"Account Request id " + accRequest.getAcctReqID() + " updated", System.currentTimeMillis() - startTime);
		}

		return accRequest;
	}

	/**
	 * Controller to get MDM search accounts
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/searchMDMAccounts", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String searchMDMAccounts(HttpServletRequest request,
	        @RequestParam(value = "bussName", required = false) String bussName,
			@RequestParam(value = "subBusName", required = false) String subBusinessName,
			@RequestParam(value = "accountStatus", required = false, defaultValue = "") String accountStatus,
			@RequestParam(value = "tCode", required = false) String tCode,
			@RequestParam(value = "bankId", required = false) String bankId,
			@RequestParam(value = "iban", required = false) String iban,
			@RequestParam(value = "country", required = false) String country,
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "leCode", required = false) String leCode,
			@RequestParam(value = "routeCode", required = false) String routeCode,
			@RequestParam(value = "accountType", required = false) String accountType,
			@RequestParam(value = "acctNumber", required = false) String acctNumber,
			@RequestParam(value = "limit", required = false, defaultValue = "10") Integer limit,
			@RequestParam(value = "start", required = false, defaultValue = "0") Integer start,
			@RequestParam(value = "forTCode", required = false, defaultValue = "false") boolean forTcode,
			@RequestParam(value = "accountPurpose", required = false) String accountPurpose,
			@RequestParam(value = "companyCode", required = false) String companyCode,
			@RequestParam(value = "meCode", required = false) String meCode,
			@RequestParam(value = "isCoreService",required = false, defaultValue = "false") boolean isCore,
			@RequestParam(value = "buCode",required = false) String buCode) {


		User user = (User) request.getSession().getAttribute("User");
	    
	    MDMSearchAccounts mdmSearchAccounts = new MDMSearchAccounts();
	    mdmSearchAccounts.setBussName(bussName);
	    mdmSearchAccounts.setSubBusName(subBusinessName);
	    mdmSearchAccounts.setAccountStatus(accountStatus);
	    mdmSearchAccounts.settCode(tCode);
	    mdmSearchAccounts.setBankId(bankId);
	    mdmSearchAccounts.setIban(iban);
	    mdmSearchAccounts.setCountry(country);
	    mdmSearchAccounts.setCurrency(currency);
	    mdmSearchAccounts.setLeCode(leCode);
	    mdmSearchAccounts.setRouteCode(routeCode);
	    mdmSearchAccounts.setAccountType(accountType);
	    mdmSearchAccounts.setAcctNumber(acctNumber);
	    mdmSearchAccounts.setLimit(limit);
	    mdmSearchAccounts.setStart(start);
	    mdmSearchAccounts.setForTCode(forTcode);
	    mdmSearchAccounts.setAccountPurpose(accountPurpose);
	    mdmSearchAccounts.setCompanyCode(companyCode);
	    mdmSearchAccounts.setMeCode(meCode);
		mdmSearchAccounts.setIsCore(isCore);
		mdmSearchAccounts.setBuCode(buCode);
				
		try {
			return this.mdmService.searchMDMAccounts(mdmSearchAccounts, user);
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in decoding url : "+ e);
			throw new SystemException("Error in decoding url : " + e.getMessage());
		}
	}

	
	
	/**
	 * controller to get fuzzyle tcode search
	 * 
	 * @param code
	 * @param start
	 * @param limit
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/searchFuzzyLeTcode", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String searchFuzzyLeTcode(@RequestParam(value = "code", required = true) String code,
			@RequestParam(value = "start", defaultValue = "0") int start,
			@RequestParam(value = "limit", defaultValue = "20") int limit, HttpServletRequest request)
			throws BusinessException{

		User user = (User) request.getSession().getAttribute("User");
		SanatizedServletRequest paramsSanatizer = new SanatizedServletRequest(request);
		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();

		MyBankLogger.logPerf(this, userId, transactionId, paramsSanatizer.getQueryString(request.getRequestURL().toString()), 0L);


		final StringBuilder filter = new StringBuilder();
		String newCode = paramsSanatizer.getParameter(code);
		int newStart = Integer.parseInt(paramsSanatizer.getParameter(Integer.toString(start)));
		int newlimit = Integer.parseInt(paramsSanatizer.getParameter(Integer.toString(limit)));
		try {
			filter.append("(");
			filter.append("UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + ") = UPPER('" + lookupService.getDisplayName("MDMACCTSTATUS_OPEN") + "')");
			filter.append(" and ");
			filter.append("(");
			filter.append("UPPER(" + BANK_ACCOUNT_CENTRALIZE_GOLD_LE_CODE + ") = UPPER('" + URLDecoder.decode(newCode, MDMConstants.UTF_8)
					+ "')");
			filter.append(" or ");
			filter.append(
					"UPPER(" + BANK_ACCOUNT_CENTRALIZE_T_CODE + ") = UPPER('" + URLDecoder.decode(newCode, MDMConstants.UTF_8) + "')");
			filter.append(")");
			filter.append(")");
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in decodeing LE code : " + e);
			throw new SystemException("Error in decoding LE code : " + e.getMessage());
		}
		HashMap<String, String> params = new HashMap<>();
		params.put("$filter", filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", String.valueOf(newStart));
		params.put("$count", String.valueOf(newlimit));
		return this.mdmService.callMDMDenodo(params, accountCoreUrl, HttpMethod.GET, true);

	}

	/**
	 * Controller to get Cashpool accounts
	 * 
	 * @param tCode
	 * @return
	 */
	@RequestMapping(value = "/getCashPoolAccounts/{tCode}", method = RequestMethod.GET)
	public @ResponseBody String getCashPoolAccounts(@PathVariable("tCode") String tCode)
			throws BusinessException{

		final StringBuilder filter = new StringBuilder();
		String newTCode = sanatize(tCode);
		try {
			filter.append("(");
			filter.append("UPPER(" + BANK_ACCOUNT_CENTRALIZE_ACCOUNT_STATUS + ") = UPPER('" + "MDMACCTSTATUS_OPEN" + "')");
			filter.append(" and ");
			filter.append("UPPER(" + "CASH_POOL_TCODE" + ") = UPPER('" + URLDecoder.decode(newTCode, MDMConstants.UTF_8) + "')");
			filter.append(")");
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in decodeing tcode : " + e);
			throw new SystemException("Error in decoding tcode : " + e.getMessage());
		}
		HashMap<String, String> params = new HashMap<>();
		params.put("$filter", filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", String.valueOf(0));
		params.put("$orderby", BANK_ACCOUNT_CENTRALIZE_REQUEST_ID + "+" + ORDER_DESCENDING);
		return this.mdmService.callMDMDenodo(params, accountCoreUrl, HttpMethod.GET, true);

	}

	@Cacheable(value = "dynamic", key = "#root.methodName + #bankId  + #code")
	@RequestMapping(value = "/getRouteCodes/{bankId}/{code}", method = RequestMethod.GET)
	public @ResponseBody String getRouteCodes(@PathVariable("code") String code, @PathVariable("bankId") String bankId,
			HttpServletRequest request) throws BusinessException{

		String url = routeCodeUrl;

		User user = (User) request.getSession().getAttribute("User");

		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		SanatizedServletRequest paramsSanatizer = new SanatizedServletRequest(request);
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanatizer.getQueryString(request.getRequestURL().toString()), 0L);

		final StringBuilder filter = new StringBuilder();
		String newCode = paramsSanatizer.getParameter(code);
		try {
			filter.append("(");
			filter.append("UPPER(" + "PARENT_MDM_ID" + ") = UPPER('" + bankId + "')");
			filter.append(" and ");
			filter.append("(");
			filter.append("UPPER(" + "RTE_CODE" + ") like UPPER('%" + URLDecoder.decode(newCode, MDMConstants.UTF_8) + "%')");
			filter.append(" or ");
			filter.append("UPPER(" + "RTE_CODE_TYPE" + ") like UPPER('%" + URLDecoder.decode(newCode, MDMConstants.UTF_8) + "%')");
			filter.append(")");
			filter.append(")");
		} catch (UnsupportedEncodingException e) {
			MyBankLogger.logError(this, "Error in decoding route code : " + e);
			throw new SystemException("Error in decoding route code : " + e.getMessage());
		}
		HashMap<String, String> params = new HashMap<>();
		params.put("$filter", filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", String.valueOf(0));
		return this.mdmService.callMDMDenodo(params, url, HttpMethod.GET, true);

	}

    /**
     * This method gives the first 5 company codes for the given gold id. this
     * change is done to improve performance of loading company code typeahead.
     * 
     * This method should only be used for showing the company code typeahead
     * when we have data present for the given gold id.
     * 
     * @deprecated
     * @param goldId
     * @return
     */
	@Deprecated
	@RequestMapping(value = "/getCompanyCodes/{goldId}", method = RequestMethod.GET)
	@ResponseBody public String getCompanyCodes(@PathVariable("goldId") String goldId) {
		
		//Fetch MDM LE v2 service
		StringBuilder filter = new StringBuilder();
		HashMap<String, String> params = new HashMap<>();
		String leService = null;
		String newGoldId = sanatize(goldId);
		try {
			filter.append("(");

			filter.append("(UPPER(" + "PARENT_CODE" + ") ").append(OPERATOR_LIKE)
					.append(" UPPER('%" + URLDecoder.decode(newGoldId, MDMConstants.UTF_8) + "%'))");
			filter.append(" " + OPERATOR_AND + " ");
			filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS)
					.append(" UPPER('" + "GOLD" + "')");
			filter.append(" " + OPERATOR_AND + " ");
			filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");

			filter.append(")");

			params.put(FILTER_CONST, filter.toString());
			params.put(SELECT, "primry_alt_code");
			leService =  this.mdmService.callMDMDenodo(params, le_v2Url, HttpMethod.GET, true);

		} catch (Exception e) {
			MyBankLogger.logError(this,"Error while fetching GoldLe ", e);
		}

		
		
		Set<String> setList = new HashSet<String>();
		if (null != leService) {
			JSONObject jsonObject = new JSONObject(leService);
			JSONArray data = jsonObject.getJSONArray("elements");
			Iterator<Object> itr = data.iterator();
			while (itr.hasNext()) {
				JSONObject obj = (JSONObject) itr.next();
				setList.add(String.valueOf(obj.get("primry_alt_code")));
			}
		}
		
		setList.add(newGoldId);
		
		List<String> inputList = new ArrayList<String>();
		inputList.addAll(setList);
		
		String join = "'" + StringUtils.join(setList,"','") + "'";
		
		filter = new StringBuilder();
		params = new HashMap<>();
		
		try {
			filter.append("(");
			
			filter.append(UPPER_2 + "associated_le) IN (" + join   + ")");

			filter.append(")");
			
		} catch (Exception e) {
			MyBankLogger.logError(this, "Error in Decoding :: getCompanyCodes ", e);
		}

		

		params.put(FILTER_CONST, filter.toString());
		params.put(SELECT, "company_code,description");
		params.put("$start_index", String.valueOf(0));
        params.put("$count", String.valueOf(5));
		
		String jsonOutput = mdmService.callMDMDenodo(params, companyCodeUrl, HttpMethod.GET, false);

		return jsonOutput;
	}
	
	/**
     * This method will give filtered results for a given company code and the given gold id list (gold id and its children).
     * 1) get the child gold ids of the given gold id from MDM le V2 url
     * 2) query company code service with gold ids list form step1 and apply additional filter for comapny code and its description.
     * 
     * @param goldId
     * @param companyCode
     * @param requireActive
     * @return
     * @throws UnsupportedEncodingException
     */
	@RequestMapping(value = "/filterCompanyCodes", method = RequestMethod.GET)
    public @ResponseBody String filterCompanyCodes(HttpServletRequest request,@RequestParam(value = "goldId", required = true) String goldId
            ,@RequestParam(value = "coCode", required = true) String companyCode
            ,@RequestParam(value = "requireActive",required = false) boolean requireActive) {
        
	    User user = (User) request.getSession().getAttribute("User");
	    
	    SanatizedServletRequest paramsSanitizer = new SanatizedServletRequest(request);
		String userId = user.getUserProfile().getSso();
		String transactionId = MyBankLogger.getTransactionId();
		MyBankLogger.logPerf(this, userId, transactionId, paramsSanitizer.getQueryString(request.getRequestURL().toString()), 0L);

		String newGoldId = paramsSanitizer.getParameter(goldId);
		String newCompanyCode = paramsSanitizer.getParameter(companyCode);
		boolean newRequireActive = Boolean.parseBoolean(String.valueOf(requireActive));
        return mdmService.getFilterCompanyCodes(user, sanatize(newGoldId), sanatize(newCompanyCode),newRequireActive);
    }

	
	@RequestMapping(value = "/getCompanyDescription/{companyCode}", method = RequestMethod.GET)
    public @ResponseBody String getCompanyCodeDescription(@PathVariable("companyCode") String companyCode) throws UnsupportedEncodingException {
	    StringBuilder filter = new StringBuilder();
	    Map<String, String> params = new HashMap<String, String>();
	    
	    filter.append("(");
	    filter.append(UPPER_2 + "company_code" + UPPER_1 + URLDecoder.decode(companyCode, MDMConstants.UTF_8) + "')");
        filter.append(")");
        
        params.put(FILTER_CONST, filter.toString());
        
        String jsonOutput = mdmService.callMDMDenodo(params, companyCodeUrl, HttpMethod.GET, false);

        return jsonOutput;
	}
	
	@Cacheable(value = "dynamic", key = "#root.methodName + #code")
	@RequestMapping(value = "/getMECodes/{code}", method = RequestMethod.GET)
	public @ResponseBody String getMECodes(@PathVariable("code") String code) {

		final StringBuilder filter = new StringBuilder();
		String newCode = sanatize(code);
		try {
			
			
			filter.append("(");
			filter.append("(");
			filter.append(UPPER_2 + LE_PARTY_NM + UPPER_LIKE + URLDecoder.decode(newCode, MDMConstants.UTF_8) + "%')");
			filter.append(" " +OPERATOR_OR + " ");
			filter.append(UPPER_2 + LE_PRIMARY_ALT_CODE +  UPPER_LIKE + URLDecoder.decode(newCode, MDMConstants.UTF_8)+"%')");
			filter.append(")");
			filter.append(" " + OPERATOR_AND + " ");
            filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");
        	filter.append(" " + OPERATOR_AND + " ");
            filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + MDM_MARS + "')");
			filter.append(")");


		} catch (Exception e) {
			MyBankLogger.logError(this, "Error in Decoding :: fetchMEDetails ", e);
		}

		HashMap<String, String> params = new HashMap<>();

		params.put(FILTER_CONST, filter.toString());
		params.put("$totalCountRequired", "true");
		params.put("$start_index", "0");

		String jsonOutput = mdmService.callMDMDenodo(params, meUrl, HttpMethod.GET, false);

		return jsonOutput;

	}
	
	private String sanatize(String name) {
		String param1 = Normalizer.normalize(name, Normalizer.Form.NFKC);
		String value = param1;
		if (value == null) {
			return value;
		}

		String prevState;
		do {
			prevState = value;
			value = StringEscapeUtils.unescapeHtml(value);
		} while (!Objects.equals(prevState, value));
		
		return StringEscapeUtils.unescapeHtml(policy.sanitize(value));
	}
}
