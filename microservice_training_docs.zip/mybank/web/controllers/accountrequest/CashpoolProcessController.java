package com.ge.treasury.mybank.web.controllers.accountrequest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.cashpool.service.impl.CashpoolService;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingDetail;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingRequest;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingResponse;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.util.business.exceptions.BusinessException;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.util.business.exceptions.ValidationFailedException;
import com.ge.treasury.mybank.web.controllers.BaseController;

/**
 * @author MyBank Dev Team - This controller is used to handle cashpool process
 *         requests
 * 
 */
@Controller
@RequestMapping("/api/acct/v2/cashpool")
public class CashpoolProcessController extends BaseController {

	@Autowired
	CashpoolService cashpoolservice;

	@Autowired
	AccountRequestService accService;
	
	@RequestMapping(value = "/trigger-myfunding", method = RequestMethod.POST)
	@Transactional
	public @ResponseBody MyFundingResponse processMyFundingRequest(
			HttpServletRequest request,
			@RequestBody MyFundingRequest requestSource) throws IOException {

		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyFundingRequest>> violations = validator
				.validate(requestSource);
		List<String> errorList = null;
		MyFundingResponse response = new MyFundingResponse();

		response.setStatus(ValidationConstants.MYBANK_MYFUNDING_FAILURE);
		MyFundingDetail detail = new MyFundingDetail();
		detail.setMyBankRequestId(null != requestSource ? requestSource.getMyBankRequestId() : null);
		detail.setMyFundingDealId(null);
		response.setDealDetail(detail);

		if (!CollectionUtils.isEmpty(violations)) {
			errorList = new ArrayList<String>();
			for (ConstraintViolation<MyFundingRequest> error : violations) {
				errorList.add(error.getMessage());
			}
			response.setMessage(StringUtils.join(errorList, ','));
		} else {
				try {
				User user = (User) request.getSession().getAttribute("User");
			
				accService.searchCashPoolProcessByRequestID(requestSource
						.getMyBankRequestId());
				
				CashPoolProcess cashPoolProcess = accService.saveCashPoolProcess(requestSource, user);
			
				response = this.cashpoolservice.triggerMyFunding(requestSource);
					
				response.setCashPoolProcess(cashPoolProcess);
					if(ValidationConstants.MYBANK_MYFUNDING_FAILURE.equals(response.getStatus())){
							throw new BusinessException(response.getMessage());
					}
				cashPoolProcess.setMyFundingDealId(Long.parseLong(response.getDealDetail().getMyFundingDealId()));
				cashPoolProcess.setAcctRequestId(Long.parseLong(response.getDealDetail().getMyBankRequestId()));
				this.accService.updateCashPoolProcess(cashPoolProcess,user);
			} catch (BusinessException|SystemException ex) {
				MyBankLogger.logError(this,
						"Error in Processing : " + ex,ex);
				throw ex;

			} catch (Exception e) {
				if(null != response){
					response.setMessage("Error in Processing :" + e);
					MyBankLogger.logError(this,
							"Error in Processing : " + e,e);
				}
				throw new SystemException("Error in Processing : ".concat(e.getMessage()), e);
			}
		}

		return response;
	}



	 @RequestMapping(value = "/getDealDetails", method = RequestMethod.POST, consumes = "application/json")
	    @ResponseStatus(HttpStatus.OK)
	    @ResponseBody public CashPoolProcess getDealDetails(
	            HttpServletRequest request,
	            @RequestParam(value = "dealID", required = true) String dealID
	         )
	            throws ValidationFailedException{
		 CashPoolProcess cashPoolReq =null;
		 List<CashPoolProcess> cashPoolList=null;
		      
	     
	        try {
	        	cashPoolReq =new CashPoolProcess();
	        	cashPoolReq.setMyFundingDealId(Long.parseLong(dealID));
	        	cashPoolList=accService.selectCashPoolProcess(cashPoolReq);
	        	if(!CollectionUtils.isEmpty(cashPoolList)){
	        		cashPoolReq=cashPoolList.get(0);
	        	}
	        	
	        	return cashPoolReq;
	        }catch(BusinessException|SystemException ex){
	            MyBankLogger.logError(this, "Failed to get the Deal Details : ",ex);
	            throw ex;
	        }
			 catch(Exception e){
			     MyBankLogger.logError(this, "Failed to get the Deal Details : ",e);
			     throw new SystemException("Failed to get the Deal Details : ".concat(e.getMessage()), e);
			}

	      
	       
	    }
}
