package com.ge.treasury.mybank.web.controllers.accountrequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.treasury.mybank.business.accountrequest.service.impl.AccountRequestService;
import com.ge.treasury.mybank.business.cashpool.service.impl.CashpoolService;
import com.ge.treasury.mybank.domain.ESDRMRequest;
import com.ge.treasury.mybank.domain.accountrequest.CashPoolProcess;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingDetail;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingInRequest;
import com.ge.treasury.mybank.domain.accountrequest.MyFundingResponse;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;
import com.ge.treasury.mybank.web.controllers.BaseController;

/**
 * @author MyBank Dev Team - This controller is used to handle cashpool process
 *         requests
 * 
 */
@Controller
@RequestMapping("/api/acct/v2/incoming")
public class MyBankINController extends BaseController {

	@Autowired
	CashpoolService cashpoolservice;

	@Autowired
	AccountRequestService accService;
	

	@RequestMapping(value = "/cpResponse", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public @ResponseBody MyFundingResponse processMyFundingResponse(
			@RequestBody MyFundingInRequest requestSource) {
        CashPoolProcess cashPoolReq=null;
		
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<MyFundingInRequest>> violations = validator
				.validate(requestSource);
		List<String> errorList = new ArrayList<String>();
		MyFundingResponse response = new MyFundingResponse();

		response.setStatus(ValidationConstants.MYBANK_MYFUNDING_FAILURE);
		MyFundingDetail detail = new MyFundingDetail();
		if(null != requestSource){
		    MyBankLogger.logInfo(this, "My Funding data:"+requestSource.toString());
			detail.setMyBankRequestId(requestSource.getMyBankRequestId());
			detail.setMyFundingDealId(requestSource.getMyFundingDealId());
			response.setDealDetail(detail);
	
			 
			if (!CollectionUtils.isEmpty(violations)) {
				for (ConstraintViolation<MyFundingInRequest> error : violations) {
					errorList.add(error.getMessage());
				}
				response.setMessage(StringUtils.join(errorList, ','));
			} else if ("SUCCESS".equalsIgnoreCase(requestSource
							.getMyFundingStatus())
					&& StringUtils.trimToEmpty(requestSource.getHeaderLEId())
							.isEmpty()) {
				errorList
						.add(ValidationConstants.MYBANK_MYFUNDING_EXCEPTION_BLANK_HEADER);
				response.setMessage(StringUtils.join(errorList, ','));
			} else {
				
				cashPoolReq=new CashPoolProcess();
				String cashPoolStatus=null;
				cashPoolReq.setAcctRequestId(Long.parseLong(requestSource.getMyBankRequestId()));
				cashPoolReq.setCashPoolComments(requestSource.getComments());
				cashPoolReq.setCashPoolHeaderLe(requestSource.getHeaderLEId());
				cashPoolReq.setLastUpdateUser("MYBANK_MYFUNDING_JOB");
				if("COMPLETE".equalsIgnoreCase(requestSource.getMyFundingStatus())){
					cashPoolStatus="CASHPOOLSTATCODE_ACCEPTED";
								
				}
				else{
					cashPoolStatus="CASHPOOLSTATCODE_REJECTED";
				}
				cashPoolReq.setCashPoolStatusCode(cashPoolStatus);
				response = this.cashpoolservice
						.updateCashpoolProcess(cashPoolReq);
				if(ValidationConstants.MYBANK_MYFUNDING_SUCCESS.equalsIgnoreCase(response.getStatus())
				        && !StringUtils.isEmpty(requestSource.getMyBankRequestId())
				        && !StringUtils.isEmpty(requestSource.getMyFundingDealId())){
                    MyBankLogger.logInfo(this, "Deal ID notification :"+cashPoolStatus);
                    cashpoolservice.sendCashpoolNotification(requestSource.getMyBankRequestId());
				}
			}
		}

		return response;
	}
	
	@RequestMapping(value = "/ESDRMRequest",method=RequestMethod.POST)
	public @ResponseBody String getESDRMChanges(@RequestBody ESDRMRequest request) {
		//if(requ) {
			return "success";
		//}
	}
	
}
