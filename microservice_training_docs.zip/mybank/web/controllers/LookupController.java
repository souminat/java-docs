/**
 * Copyright GE
 */
package com.ge.treasury.mybank.web.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.constants.ControllersConstants;
import com.ge.treasury.mybank.util.business.exceptions.DBException;

/**
 * @author MyBank Dev Team
 * 
 */

@Controller
@RequestMapping("/api/acct/v1")
public class LookupController extends BaseController {

    @Autowired
    MyBankLookupService lookupService;

    /**
     * Get all lookup codes information
     * 
     * @param request
     * @return
     */
    @Cacheable(value = "static", key = "#root.methodName")
    @RequestMapping(value = "/lov", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    public @ResponseBody
    List<MyBankLookup> getLovs(HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute("User");

        request.getSession().setAttribute("User", user);        
        String userId = user.getUserProfile().getSso();
        String transactionId = MyBankLogger.getTransactionId();
        long startTime = System.currentTimeMillis();

        MyBankLogger.logPerf(this, userId, transactionId, request
                .getRequestURL().toString(), 0L);

        MyBankLogger.logDebug(this, "Calling Lov method...");
        List<MyBankLookup> lovResponse = new ArrayList<MyBankLookup>();
        try {
            lovResponse = lookupService.getAllLov(
                    ControllersConstants.DEFAULT_LOV_LOOKUPTYPE_ORDER,
                    ControllersConstants.DEFAULT_ASC_DIRECTION);
        } catch (DBException e) {
            MyBankLogger
                    .logError(
                            this,
                            "LookupController.getLovs: Error Executing getAllLov method.",
                            e);
        }

        MyBankLogger.logPerf(this, userId, transactionId, lovResponse.size()
                + " Lovs found", System.currentTimeMillis() - startTime);

        return lovResponse;
    }
}
