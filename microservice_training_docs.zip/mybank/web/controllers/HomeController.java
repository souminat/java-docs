/**
 * Copyright GE
 */
package com.ge.treasury.mybank.web.controllers;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.treasury.mybank.business.security.service.impl.CustomUserDetails;
import com.ge.treasury.mybank.business.user.service.impl.UserProfileServiceImpl;
import com.ge.treasury.mybank.domain.user.User;
import com.ge.treasury.mybank.domain.user.UserProfile;
import com.ge.treasury.mybank.util.business.MyBankLogger;
import com.ge.treasury.mybank.util.business.exceptions.SystemException;
import com.ge.treasury.mybank.web.controllers.accountrequest.UserLookUpController;
import com.ge.treasury.mybank.util.business.constants.ValidationConstants;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

    @Autowired
    UserProfileServiceImpl userService;
    @Autowired
    UserLookUpController userlookup;

    @Value("${mybank.url.error}")
    private String errorMsg;

    @Value("${mybank.url.logout}")
    private String logoutMsg;

    @Value("${mybank.url.accessdenied}")
    private String accessDeniedMsg;

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getLogoutMsg() {
        return logoutMsg;
    }

    public void setLogoutMsg(String logoutMsg) {
        this.logoutMsg = logoutMsg;
    }

    public String getAccessDeniedMsg() {
        return accessDeniedMsg;
    }

    public void setAccessDeniedMsg(String accessDeniedMsg) {
        this.accessDeniedMsg = accessDeniedMsg;
    }

    /**
     * Simply selects the home view to render by returning its name.
     */
    @RequestMapping(value = { "/", "/home", "/index.html" }, method = RequestMethod.GET)
    public String home() {

        return "redirect:/acct/home";
    }

    /*
     * Front end routes that are angular ready
     */
    @RequestMapping(value = { "/acct/**" }, method = RequestMethod.GET)
    public String angular(HttpSession session) {
        return loadFrontEndView(session, "angular");
    }

    /**
     * helper to check user session and load the front end template
     */
    @SuppressWarnings("unused")
    private String loadFrontEndView(HttpSession session, String view) {

        // Check for granted authorities-roles, if no roles found redirect to
        // logout
        @SuppressWarnings("unchecked")
        Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder
                .getContext().getAuthentication().getAuthorities();
        Exception exception = ((CustomUserDetails) SecurityContextHolder
                .getContext().getAuthentication().getPrincipal())
                .getException();

        String url = "";

        if (exception != null) {
            MyBankLogger.logError(this,
                    "Exception in HomeController.acctRoutes", exception);
            url = "error";

        } else {
            if (authorities != null && !authorities.isEmpty() && null != session) {

                Authentication auth = SecurityContextHolder.getContext()
                        .getAuthentication();

                String userSSO = (null != auth) ? auth.getName() : null;
                String firstName = "";
                String lastName = "";

                // Getting UserInfo from UserLookup service
                String result = userlookup.userLookUp(userSSO);

                if(null != StringUtils.trimToNull(result)){
                    JSONObject json = new JSONObject(result);

                    if (json != null) {
                            firstName = json.getString("firstName");
                            lastName = json.getString("lastName");
                    }
                }
                
                
                
                // Getting user profile info from Object
                UserProfile userdetails = ((CustomUserDetails) SecurityContextHolder
                        .getContext().getAuthentication().getPrincipal())
                        .getUserProfile();

                User user = new User();
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setSso(userSSO);
                user.setUserProfile(userdetails);

                session.setAttribute("User", user);

                if (user != null) {
                    url = view;
                } else {
                    session.invalidate();
                    url = "redirect:" + getAccessDeniedMsg();
                }
            } else {
            	if(null != session){
	                session.invalidate();
	                url = "redirect:" + getAccessDeniedMsg();
            	}
            }
        }
        return url;
    }

    /**
     * logout
     */
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(HttpSession session) {

        if (session != null) {
            session.invalidate();
        }

        return "redirect:" + getLogoutMsg();
    }

    /**
     * accessdenied page
     */
    @RequestMapping(value = "/accessdenied", method = RequestMethod.GET)
    @SuppressWarnings("unchecked")
    public String accessdenied(HttpServletRequest request) {
        MyBankLogger.logDebug(this, "inside accessdenied");

        Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder
                .getContext().getAuthentication().getAuthorities();
        Exception exception = ((CustomUserDetails) SecurityContextHolder
                .getContext().getAuthentication().getPrincipal())
                .getException();

        User user = (User) request.getSession().getAttribute("User");

        if (exception != null) {
            MyBankLogger.logError(this,
                    "Exception in HomeController.acctRoutes", exception);
            if(exception.getMessage().contains(ValidationConstants.MYBANK_USERPROFILE_GENERIC_ERROR)){
            	return "redirect:" + getAccessDeniedMsg();
            }
            throw new SystemException("Error on login, pls try again");
        }

        if ((authorities != null && !authorities.isEmpty()) || (user != null)) {
            return "redirect:/acct/home";
        } else {
            return "redirect:" + getAccessDeniedMsg();
        }
    }

}