package com.ge.treasury.mybank.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.ge.treasury.mybank.util.business.MyBankLogger;

@Component
public class MyBankDataLoader implements ApplicationContextAware{

	
	@Autowired
	CacheService service;	
	
	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * service.fetchMDMDataForValidation()
	 */
	@Override
	public void setApplicationContext(ApplicationContext arg0) throws UnsupportedOperationException{
	    MyBankLogger.logInfo(this, "Application Context initialization started");
	    MyBankLogger.logInfo(this, "Lookup data caching started");
		service.fetchLookUpData();
		MyBankLogger.logInfo(this, "Lookup data caching ended");
		MyBankLogger.logInfo(this, "Platform data caching started");
		service.fetchPlatformData();
		MyBankLogger.logInfo(this, "Platform data caching ended");
		MyBankLogger.logInfo(this, "Application Context initialization ended");
	}
	
}
