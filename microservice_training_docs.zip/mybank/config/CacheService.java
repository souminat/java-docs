package com.ge.treasury.mybank.config;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ge.treasury.mybank.business.accountrequest.service.impl.MyBankLookupService;
import com.ge.treasury.mybank.business.fileupload.service.impl.BulkUploadService;
import com.ge.treasury.mybank.business.platforminstance.service.impl.PlatformInstanceService;
import com.ge.treasury.mybank.domain.accountrequest.MDMDetails;
import com.ge.treasury.mybank.domain.accountrequest.MyBankLookup;
import com.ge.treasury.mybank.domain.accountrequest.PlatformInstance;

@Service
public class CacheService {
	
	@Autowired
	BulkUploadService bulkUploadService;
	
	@Autowired
	protected MyBankLookupService lookupService;
	
	@Autowired
	PlatformInstanceService platformInstanceService;
	
	//@Cacheable(value = { "mdm-data" })
	public MDMDetails fetchMDMDataForValidation () {
		MDMDetails mdmData = new MDMDetails();
		bulkUploadService.loadMDMDetails(mdmData);
		return mdmData;
	}
	
	@Cacheable(value= {"lookup-data"})
	public List<MyBankLookup> fetchLookUpData(){
		List<MyBankLookup> lookUpList = new ArrayList<MyBankLookup>();
		lookUpList = lookupService.getAllLov("DISPLAY_ORDER", "ASC");
		return lookUpList;
	}
	
	@Cacheable(value= {"platform-data"})
    public List<PlatformInstance> fetchPlatformData(){
        return platformInstanceService.getAllPlatformInstance();
    }
	
}
