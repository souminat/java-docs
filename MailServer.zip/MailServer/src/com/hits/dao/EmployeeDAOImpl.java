package com.hits.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hits.bean.Employee;
import com.hits.bean.TaskAllocated;
import com.hits.bean.TaskCompleted;
import com.hits.bean.TaskPending;
import com.hits.bean.User;
import com.hits.util.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO{

	@Override
	public User loginUser(String userName) {
		// TODO Auto-generated method stub
		Connection con = null;
		User user=null;
		try{
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement("select * from hits_login where username=?"+userName);
			pstmt.setString(1, userName);
			ResultSet res = pstmt.executeQuery();
			while(res.next()){
				user = new User(res.getInt("userid"),res.getString("username"),res.getString("userrole"));
			}			
		}catch(Exception e){
			
		}finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		if(user == null){
			///throw new EmployeeException("Employee not found");
		}
		
		return user;
	}




	@Override
	public void assignTask(TaskAllocated task) {
		Connection con = null;
		
		try {
			task.setTaskStatus("N");
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement("insert into hits_emp_task values(?,?,?,?)");
			pstmt.setInt(1, task.getTaskID());
			pstmt.setString(2, task.getTaskDesc());
			pstmt.setString(3, task.getTaskStatus());
			pstmt.setInt(4, task.getEmpAssgnID());
			pstmt.setInt(5, task.getMngID());
			
			pstmt.execute();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	@Override
	public List<TaskAllocated> sendTask(Employee employee) {
		// TODO Auto-generated method stub
		Connection con = null;
		List<TaskAllocated> tasksAlloc = new ArrayList<TaskAllocated>();
		List<TaskCompleted> tasksComp = new ArrayList<TaskCompleted>();
		List<TaskPending> tasksPend = new ArrayList<TaskPending>();
		try{
			con = DBUtil.getConnection();
			
			
			PreparedStatement pstmt1 = con.prepareStatement("select * from hits_emp_task where task_id=?"+employee.getEmpId());
			pstmt1.setInt(1, employee.getEmpId());
			ResultSet res = pstmt1.executeQuery();
			
			while(res.next()){
				TaskAllocated taskAlloc = new TaskAllocated(res.getInt("task_id"), res.getString("task_desc"), res.getString("iscomp"), res.getInt("emp_alloc_id"), res.getInt("mng_assg_id"));
				tasksAlloc.add(taskAlloc);
				TaskPending taskPend = new TaskPending(res.getInt("task_id"), res.getString("task_desc"), res.getString("iscomp"), res.getInt("emp_alloc_id"), res.getInt("mng_assg_id"));
				tasksPend.add(taskPend);
			}
			employee.setTaskAllocated(tasksAlloc);
			employee.setTaskPending(tasksPend);
			employee.setTaskCompleted(null);
			
			PreparedStatement pstmt2 = con.prepareStatement("update hits_emp set (taskalloc,taskpend,taskcomp) values(?,?,?) where empid=?"+employee.getEmpId());
			pstmt2.setInt(1, tasksAlloc.size());
			pstmt2.setInt(2, tasksPend.size());
			pstmt2.setInt(3, 0);
			pstmt2.setInt(4, employee.getEmpId());
			
			pstmt2.execute();
		}catch(Exception e){
			//exception handling
		}
		
		return tasksAlloc;
	}

	@Override
	public String acceptTask(int empID) {
		// TODO Auto-generated method stub
		return getEmailids(empID);
	}

	@Override
	public void sendTaskUpdate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getEmailids(int empID) {
		Connection con = null;
		String emailID = "";
 		try{
			con = DBUtil.getConnection();
			
			PreparedStatement pstmt1 = con.prepareStatement("select empmail from hits_employee where empid=?"+empID);
			pstmt1.setInt(1, empID);
			ResultSet res1 = pstmt1.executeQuery();
			
			while(res1.next()){
				emailID = res1.getString("empmail");
			}
			
			PreparedStatement pstmt2 = con.prepareStatement("select mngemailid from hits_manager where empunder=?"+empID);
			pstmt1.setInt(1, empID);
			ResultSet res2 = pstmt1.executeQuery();
			
			while(res2.next()){
				emailID += res2.getString("mngemailid");
			}
		}catch(Exception ex){
			
		}
		return emailID;
	}


}
