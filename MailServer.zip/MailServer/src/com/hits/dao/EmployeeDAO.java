package com.hits.dao;

import java.util.List;

import com.hits.bean.Employee;
import com.hits.bean.TaskAllocated;
import com.hits.bean.User;

public interface EmployeeDAO {
	public User loginUser(String userName);
	public void assignTask(TaskAllocated task);
	public List<TaskAllocated> sendTask(Employee employee);
	public String getEmailids(int empID);
	public String acceptTask(int empID);
	public void sendTaskUpdate();
}
