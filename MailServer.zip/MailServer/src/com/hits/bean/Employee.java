package com.hits.bean;

import java.util.List;

public class Employee {
	private int empId;
	private String empName;
	private String empUserName;
	private String empGender;
	private String empMailId;
	private String empPassword;
	private List<TaskAllocated> taskAllocated;
	private List<TaskPending> taskPending;
	private List<TaskCompleted> taskCompleted;
	
	public Employee() {
		super();
	}

	public Employee(int empId, String empName, String empUserName, String empGender, String empMailId,
			String empPassword, List<TaskAllocated> taskAllocated, List<TaskPending> taskPending,
			List<TaskCompleted> taskCompleted) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empUserName = empUserName;
		this.empGender = empGender;
		this.empMailId = empMailId;
		this.empPassword = empPassword;
		this.taskAllocated = taskAllocated;
		this.taskPending = taskPending;
		this.taskCompleted = taskCompleted;
	}

	public String getEmpUserName() {
		return empUserName;
	}

	public void setEmpUserName(String empUserName) {
		this.empUserName = empUserName;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMailId() {
		return empMailId;
	}

	public void setEmpMailId(String empMailId) {
		this.empMailId = empMailId;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public List<TaskAllocated> getTaskAllocated() {
		return taskAllocated;
	}

	public void setTaskAllocated(List<TaskAllocated> taskAllocated) {
		this.taskAllocated = taskAllocated;
	}

	


	public List<TaskPending> getTaskPending() {
		return taskPending;
	}

	public void setTaskPending(List<TaskPending> taskPending) {
		this.taskPending = taskPending;
	}



	public List<TaskCompleted> getTaskCompleted() {
		return taskCompleted;
	}


	public void setTaskCompleted(List<TaskCompleted> taskCompleted) {
		this.taskCompleted = taskCompleted;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empUserName=" + empUserName + ", empGender="
				+ empGender + ", empMailId=" + empMailId + ", empPassword=" + empPassword + ", taskAllocated="
				+ taskAllocated + ", taskPending=" + taskPending + ", taskCompleted=" + taskCompleted + "]";
	}

	
}
