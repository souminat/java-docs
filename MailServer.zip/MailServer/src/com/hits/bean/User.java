package com.hits.bean;

public class User {
	int userID;
	String userName;
	String userRole;
	
	public User(int userID, String userName, String userRole) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userRole = userRole;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	
	
}
