package com.hits.bean;

public class TaskPending {
	private int taskID;
	private String taskDesc;
	private String taskStatus;
	private int empAssgnID;
	private int mngID;
	
	
	public TaskPending(int taskID, String taskDesc, String taskStatus, int empAssgnID, int mngID) {
		super();
		this.taskID = taskID;
		this.taskDesc = taskDesc;
		this.taskStatus = taskStatus;
		this.empAssgnID = empAssgnID;
		this.mngID = mngID;
	}
	public int getTaskID() {
		return taskID;
	}
	public int getEmpAssgnID() {
		return empAssgnID;
	}
	public void setEmpAssgnID(int empAssgnID) {
		this.empAssgnID = empAssgnID;
	}
	public int getMngID() {
		return mngID;
	}
	public void setMngID(int mngID) {
		this.mngID = mngID;
	}
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}
	public String getTaskDesc() {
		return taskDesc;
	}
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	
	
	
}
