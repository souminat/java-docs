package com.hits.bean;

import java.util.List;

public class Manager {
	
	private String managerName;
	private int managerId;
	private String managerUserName;
	private String managerGender;
	private String managerMailId;
	private String managerPassword;
	private List<TaskAllocated> taskProvided;
	private List<TaskPending> taskPending;
	private List<TaskCompleted> taskAccomplished;
	
	public Manager() {
		super();
	}

	public Manager(String managerName, int managerId, String managerUserName, String managerGender,
			String managerMailId, String managerPassword, List<TaskAllocated> taskProvided,
			List<TaskPending> taskPending, List<TaskCompleted> taskAccomplished) {
		super();
		this.managerName = managerName;
		this.managerId = managerId;
		this.managerUserName = managerUserName;
		this.managerGender = managerGender;
		this.managerMailId = managerMailId;
		this.managerPassword = managerPassword;
		this.taskProvided = taskProvided;
		this.taskPending = taskPending;
		this.taskAccomplished = taskAccomplished;
	}

	public String getManagerUserName() {
		return managerUserName;
	}
	public void setManagerUserName(String managerUserName) {
		this.managerUserName = managerUserName;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public String getManagerGender() {
		return managerGender;
	}
	public void setManagerGender(String managerGender) {
		this.managerGender = managerGender;
	}
	public String getManagerMailId() {
		return managerMailId;
	}
	public void setManagerMailId(String managerMailId) {
		this.managerMailId = managerMailId;
	}
	public String getManagerPassword() {
		return managerPassword;
	}
	public void setManagerPassword(String managerPassword) {
		this.managerPassword = managerPassword;
	}
	
	public List<TaskAllocated> getTaskProvided() {
		return taskProvided;
	}

	public void setTaskProvided(List<TaskAllocated> taskProvided) {
		this.taskProvided = taskProvided;
	}

	
	public List<TaskPending> getTaskPending() {
		return taskPending;
	}

	public void setTaskPending(List<TaskPending> taskPending) {
		this.taskPending = taskPending;
	}

	public List<TaskCompleted> getTaskAccomplished() {
		return taskAccomplished;
	}

	public void setTaskAccomplished(List<TaskCompleted> taskAccomplished) {
		this.taskAccomplished = taskAccomplished;
	}

	@Override
	public String toString() {
		return "Manager [managerName=" + managerName + ", managerId=" + managerId + ", managerUserName="
				+ managerUserName + ", managerGender=" + managerGender + ", managerMailId=" + managerMailId
				+ ", managerPassword=" + managerPassword + ", taskProvided=" + taskProvided + ", taskPending="
				+ taskPending + ", taskAccomplished=" + taskAccomplished + "]";
	}


	
	
}
