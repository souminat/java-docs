package com.hits.ui;

import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;

import com.hits.service.MailServer;

public class CommunicationUI {
	
	
	public static void main(String[] args) throws ResourceNotFoundException, ParseErrorException, Exception{
		MailServer server = new MailServer();
		
		server.sendErrorNotification(null);
		
	}

}
