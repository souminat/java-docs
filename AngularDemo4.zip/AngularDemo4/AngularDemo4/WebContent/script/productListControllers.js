angular.module("productStore")
	.constant("productListActiveClass","btn-primary")
	.constant("productListPageCount",3)
	.controller("productListCtrl",function($scope,$filter,productListPageCount,productListActiveClass,cart){
		
			var selectedCategory = null;
			
			$scope.selectedPage = 1;
			$scope.pageSize = productListPageCount;
			
			$scope.selectCategory = function(newCategory){
				selectedCategory = newCategory;
				$scope.selectedPage = 1;
			}
			
			$scope.selectPage = function(newPage){
				$scope.selectedPage = newPage;
			}
			
			$scope.categoryFilterFn = function(product){
				return selectedCategory == null || product.category == selectedCategory;
			}
			
			$scope.getCategoryClass = function(category){
				return selectedCategory == category ? productListActiveClass : "";
			}
			
			$scope.getPageClass = function(page){
				return $scope.selectedPage == page? productListActiveClass : "";
			}
			
			$scope.getProductCount = function(item,products){
				var count = 0;
				
				for(var i = 0;i < products.length;++i){
					if(products[i].category == item){
						count++;
					}
				}
					return count;
			}
			
			$scope.addProductToCart = function(product){
				cart.addProduct(product.item,product.name,product.price);
			}
	});