angular.module("productStore")
	.controller("cartSummaryController",function($scope,cart){
			
		$scope.cartData = cart.getProducts();
		
		$scope.totalAmount = function(){
			var total = 0;
			var productCart = $scope.cartData;
			
			for(var i = 0;i < productCart.length;++i){
				total += productCart[i].price + productcart[i].count;
			}
				return total;
		}
		
		$scope.remove = function(id){
			cart.removeProduct(id);
		}
		
	});