angular.module("cart",[])
	.factory("cart",function(){
		var productCart = [];
		
		return{
			addProduct:function(id,name,price){
				var itemSelected = false;
				
				for(var i=0;i<productCart.length;++i){
					if(productCart[i].id == id){
						productCart[i].count++;
						itemSelected = true;
						break;
					}
				}
					
					if(!itemSelected){
						productCart.push({
							count:1,id:id,name:name,price:price
						});
					}
				
			},
			
			removeProduct:function(id){
				
				for(var i=0;i<productCart.length;++i){
					if(productCart[i].id == id){
						productCart.slice(i,1);
						break;
					}
				}
			},
			
			getProducts:function(){
				return productCart;
			}
			
		};
		
		
	})
	
	.directive("productCartSummary",function(cart){
			return{
				restrict: "E",
				templateUrl: "view/cartSummary.html",
				controller: function($scope){
					var productCart = cart.getProducts();
					
					$scope.totalAmount = function(){
						var total = 0;
						
						for(var i = 0;i < productCart.length;++i){
							total += productCart[i].price * productcart[i].count;
						}
							return total;
					}
					
					
					$scope.totalItems = function(){
						var total = 0;
						
						for(var i=0;i<productCart.length;++i){
							total += productCart[i].count;
						}
							return total;
					}
				}
			};
		
		
	});