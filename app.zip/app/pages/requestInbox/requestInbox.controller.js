angular.module('app.pages.requestInbox.controller',[
	'ui.router',
	'ui.bootstrap',
	'ct.loadingOverlay',
	'app.config',
	'app.messages',
	'app.directives'
])

.config(function ($stateProvider, configProvider) {

	$stateProvider
		/*.state('pages.requests', {
			url: "/requests",
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/requestInbox/requestInbox.controller.html',
					controller: 'requestInboxController as inbox'
				}
			}
		})*/
		.state('pages.approvals', {
			url: "/approvals",
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/requestInbox/requestInbox.controller.html',
					controller: "requestInboxController as inbox"
				}
			}
		});
})

.controller('requestInboxController', function ($state, $uibModal,$document, $rootScope, $scope, $q, config, simpleModal, messages, paymentRequestManager) {

	var inbox = this;
	var pageType = 'Approval';
	var paginatedresult = {
			offset : 0,
			pageType:pageType
		};
	inbox.paymentList = {};
	inbox.filter = {};
	inbox.shwFilterApplied = [];
	//$scope.sortReverse = true;
	$scope.data = inbox.paymentList.data;
	//inbox.filterApplied = false;
	//inbox.filterDisplayBlock = false;
	//inbox.filterDisplayNone = true;
	//$('#payment-filter').css('background-color', 'transparent'); 
	
	
	
	angular.extend(inbox, {
		
		isLoading: 				false,
		filterApplied : false,
	    //filterDisplayBlock : false,
	    //filterDisplayNone : true,
	    requestDate : '',
	    valueDate : '',
	    filterButtonColor : true,
	    sortReverse : '',
	    sortPropertyName : '',
	    erpPaymentRequest : false,
		filters: {
			start_index: 		1,
			count:				10,
			currentPage:		1
		},
		channels: function() {
        	$scope.$on('customTableChangePagination', inbox.changePagination);
        	$scope.$on('customTableViewObjectEmit', inbox.viewPayment);
        	$scope.$on('customTableSortObject',inbox.changeSortBy);
        	$scope.$on('sortReverseVariable', function(event, arg){
        		inbox.sortReverse = arg;
        	  });
        	$scope.$on('sortPropertyName', function(event, arg){
        		inbox.sortPropertyName = arg;
        	  });
        },
        getRequestType : function(text){
			
			//alert(text);
        	var defer = $q.defer();
        	
        	var criteria = {
                requestType: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getRequestTypeOptions(text);
        	promise.$promise.then(function(result) {
        		inbox.requests = result.requestType;
        		defer.resolve(result.requestType);
        	});
        	
        	return defer.promise;
        },
        
        getPayeeName : function(text){
			
			
        	var defer = $q.defer();
        	var payerList = {
        			
        	};
        	var criteria = {
                payeeSearchValue: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getPayeeList(text);
        	promise.$promise.then(function(result) {
        		inbox.payeeNames = result.payeeName;
        		defer.resolve(result.payeeName);
        	});
        	
        	return defer.promise;
        },
        
        getPayerName : function(text){
			
        	var defer = $q.defer();
        	var payerList = {
        			
        	};
        	var criteria = {
                payerSearchValue: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getPayerList(text);
        	promise.$promise.then(function(result) {
        		inbox.payerNames = result.payerName;
        		
        		defer.resolve(result.payerName);
        	});
        	
        	return defer.promise;
        },
        
        viewPayment: function(event, payment) {
        	if (payment.requestTypeCode == 'Manual Payment')
        		inbox.erpPaymentRequest = false;
        	else if (payment.requestTypeCode == 'ERP Manual Payment')
        		inbox.erpPaymentRequest = true;
        		
        	switch(payment.status) {
        		case 'Submitted':
        			$state.go('pages.approvalsApprover', {
                		paymentId: payment.requestId,
                		erpPaymentRequest: inbox.erpPaymentRequest
                	});
        		break;
        		case 'Approved':
        			$state.go('pages.approvalsPreparer', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: inbox.erpPaymentRequest
                	});
            	break;
        		case 'Rejected':
        			$state.go('pages.approvalsApprover', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: inbox.erpPaymentRequest
                	});
                break;
        		case 'Prepared':
        			$state.go('pages.approvalsReleaser', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: inbox.erpPaymentRequest
                	});
                break;
        		case 'Cancelled':
        			$state.go('pages.approvalsApprover', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: inbox.erpPaymentRequest
                	});
                break;
        	};
        },
        search: function(paginatedresult) {
        	console.log("Loading dashboard for Approvers : " + inbox);
        	//inbox.userRole = $state.includes("pages.approvals") ? 'Approver' : 'Requestor';
    		//inbox.title = (inbox.userRole === 'Requestor') ? 'My Open Requests' : 'My Pending Approval';
    		
        	inbox.isLoading = true;
        	
        	var promise = paymentRequestManager.getApprovalDashboardResults(paginatedresult);
        	
        	promise.$promise.then(function(result) {
            	
                var data = result.resultList;
                var total = result.totalRecords;

                inbox.paymentList = {
                	idProperty: 'requestId',	
                    total: total,
                    start: inbox.filters.start_index,
                    limit: inbox.filters.count,
                    currentPage: inbox.filters.currentPage,
                    headers: [
                        {
                            field: 'requestId',
                            name: 'Request ID'
                            
                        },
                        {
                            field: 'requestDate',
                            name: 'Request Date'
                        },
                        {
                            field: 'requestType',
                            name: 'Request Type'
                        },
                        {
                            field: 'payerDescription',
                            name: 'Payer'
                        },
                        {
                            field: 'payeeDescripton',
                            name: 'Payee'
                        },
                        {
                            field: 'payeeBankCountry',
                            name: 'Country'
                        },
                        {
                            field: 'payeeCurrency',
                            name: 'Currency'
                        },
                        {
                            field: 'payeeAmount',
                            name: 'Amount'
                        },
                        {
                            field: 'valueDate',
                            name: 'Value Date'
                        },
                        {
                            field: 'requester',
                            name: 'Requester'
                        },
                        {
                            field: 'assignedTo',
                            name: 'Assigned To'
                        },
                        {
                            field: 'status',
                            name: 'Status'
                        },
                        {
	                        field: 'requestTypeCode',
	                        name: 'Payment Type Code'
	                    },
                    ],
                    data: data
                };
                inbox.isLoading = false;
            });
        },
        
	   	 applyFilter : function () {
             var columnName = inbox.sortPropertyName;
        	 var sortOrder = inbox.sortReverse;  
        	 inbox.shwFilterApplied = [];
        	 inbox.filterApplied = true;
        	 inbox.filterButtonColor = false;
          	
          	 if(inbox.filter.requestDate) {
          		 inbox.requestDate = moment(inbox.filter.requestDate).format('DD-MM-YY');
               }
          	 
          	 if(inbox.filter.valueDate) {
          		 inbox.valueDate = moment(inbox.filter.valueDate).format('DD-MM-YY');
               }
        	   if (inbox.filter.requestId != undefined && inbox.filter.requestId != "") {
        		   inbox.shwFilterApplied.push("Request ID:");
        		   inbox.shwFilterApplied.push(inbox.filter.requestId);
        	   }
        	   if (inbox.filter.requestType != undefined && inbox.filter.requestType != "") {
        		   inbox.shwFilterApplied.push("Request Type:");
        		   inbox.shwFilterApplied.push(inbox.filter.requestType);
        	   }
        	   if (inbox.filter.requestDate != undefined && inbox.filter.requestDate != "") {
        		   inbox.shwFilterApplied.push("Request Date:");
        		   inbox.shwFilterApplied.push(moment(inbox.filter.requestDate).format('DD-MMM-YY'));
        	   }
        	   if (inbox.filter.payer != undefined && inbox.filter.payer != "") {
        		   inbox.shwFilterApplied.push("Payer:");
        		   inbox.shwFilterApplied.push(inbox.filter.payer);
        	   }
        	   if (inbox.filter.payee != undefined && inbox.filter.payee != "") {
        		   inbox.shwFilterApplied.push("Payee:");
        		   inbox.shwFilterApplied.push(inbox.filter.payee);
        	   }
        	   if (inbox.filter.country != undefined && inbox.filter.country != "") {
        		   inbox.shwFilterApplied.push("Country:");
        		   inbox.shwFilterApplied.push(inbox.filter.country);
        	   }
        	   if (inbox.filter.currency != undefined && inbox.filter.currency != "") {
        		   inbox.shwFilterApplied.push("Currency:");
        		   inbox.shwFilterApplied.push(inbox.filter.currency);
        	   }
        	   if (inbox.filter.Amount != undefined && inbox.filter.Amount != "") {
        		   inbox.shwFilterApplied.push("Amount:");
        		   inbox.shwFilterApplied.push(inbox.filter.Amount);
        	   }
        	   if (inbox.filter.valueDate != undefined && inbox.filter.valueDate != "") {
        		   inbox.shwFilterApplied.push("Value Date:");
        		   inbox.shwFilterApplied.push(moment(inbox.filter.valueDate).format('DD-MMM-YY'));
        	   }
        	   if (inbox.filter.requester != undefined && inbox.filter.requester != "") {
        		   inbox.shwFilterApplied.push("Requester:");
        		   inbox.shwFilterApplied.push(inbox.filter.requester);
        	   }
        	   if (inbox.filter.assignedTo != undefined && inbox.filter.assignedTo != "") {
        		   inbox.shwFilterApplied.push("Assigned To:");
        		   inbox.shwFilterApplied.push(inbox.filter.assignedTo);
        	   }
        	   if (inbox.filter.status != undefined && inbox.filter.status != "") {
        		   inbox.shwFilterApplied.push("Status:");
        		   inbox.shwFilterApplied.push(inbox.filter.status);
        	   }
        	   inbox.filters= {
        			   start_index: 1,
        			   count: 10,
        			   currentPage: 1
        	   };
        	   paginatedresult = {
        		   orderByColumn :columnName,
        		   sortingOrder : sortOrder,
        		   requestId : inbox.filter.requestId,
        		   requestType :inbox.filter.requestType,
        		   requestDate : inbox.requestDate,
        		   payerDescription :inbox.filter.payer,
        		   payeeDescripton :inbox.filter.payee,
        		   payeeBankCountry :inbox.filter.country,
        		   payeeCurrency:inbox.filter.currency,
        		   payeeAmount:inbox.filter.Amount,
        		   valueDate:inbox.valueDate,
        		   requester:inbox.filter.requester,
        		   assignedTo:inbox.filter.assignedTo,
        		   status:inbox.filter.status,
        		   pageType:pageType
           	}
           	inbox.search(paginatedresult);
  			//inbox.filterDisplayNone = true;
           },
           
           //Sorting
           
           changeSortBy: function(event,pName,page,start) {
   			var columnName = inbox.sortPropertyName;
       	   var sortOrder = inbox.sortReverse; 
       	   if(inbox.filter.requestDate) {
         		 inbox.requestDate = moment(inbox.filter.requestDate).format('DD-MM-YY');
              }
       	   if(inbox.filter.valueDate) {
       		   inbox.valueDate = moment(inbox.filter.valueDate).format('DD-MM-YY');
       	   }
       	   inbox.filters.currentPage = page;
       	   inbox.filters.start_index = start;
			
	    	var totalNxt = inbox.paymentList.total;
	 	    var next = 0;
	 	    if(totalNxt - start <10) {
	 	    	next = totalNxt - start;
	 	    } else {
	 	    	next = 10;
	 	    }
       	            
   			paginatedresult = {
   				next : next,
              	orderByColumn :columnName,
              	sortingOrder : sortOrder,
              	requestId : inbox.filter.requestId,
        		requestType :inbox.filter.requestType,
        		requestDate : inbox.requestDate,
                payerDescription :inbox.filter.payer,
                payeeDescripton :inbox.filter.payee,
                payeeBankCountry :inbox.filter.country,
                payeeCurrency:inbox.filter.currency,
                payeeAmount:inbox.filter.Amount,
                valueDate:inbox.valueDate,
                requester:inbox.filter.requester,
                assignedTo:inbox.filter.assignedTo,
                status:inbox.filter.status,
                pageType:pageType
             };
   			 inbox.search(paginatedresult);
            },
            
            
            changePagination: function(event, page, start) {
            	inbox.filters.currentPage = page;
            	inbox.filters.start_index = start;
    		
            	var totalNxt = inbox.paymentList.total
            	var columnName = inbox.sortPropertyName;
            	var sortOrder = inbox.sortReverse;
            	if(inbox.filter.requestDate) {
            		inbox.requestDate = moment(inbox.filter.requestDate).format('DD-MM-YY');
            	}
           	    if(inbox.filter.valueDate) {
           	    	inbox.valueDate = moment(inbox.filter.valueDate).format('DD-MM-YY');
           	    }
            	
            	var next = 0;        		
            	if(totalNxt - start <10) {
            		next = totalNxt - start;
            	} else {
            		next = 10;
            	}
            		
            	paginatedresult ={
            		offset : start,
            		next : next,
            		orderByColumn :columnName,
            		sortingOrder : sortOrder,
            		requestId : inbox.filter.requestId,
         			requestType :inbox.filter.requestType,
         			requestDate : inbox.requestDate,
                    payerDescription :inbox.filter.payer,
                    payeeDescripton :inbox.filter.payee,
                    payeeBankCountry :inbox.filter.country,
                    payeeCurrency:inbox.filter.currency,
                    payeeAmount:inbox.filter.Amount,
                    valueDate:inbox.valueDate,
                    requester:inbox.filter.requester,
                    assignedTo:inbox.filter.assignedTo,
                    status:inbox.filter.status,
                    pageType:pageType
            	}
            	inbox.search(paginatedresult);
            },
            resetFilter : function() {
            	paginatedresult = {offset :0,pageType:pageType};
            	 inbox.filters= {
          			   start_index: 1,
          			   count: 10,
          			   currentPage: 1
            	 };
            	inbox.shwFilterApplied = [];
            	inbox.filterApplied = false;
            	inbox.filter = {};
            	inbox.requestDate = '';
            	inbox.valueDate = '';
            	inbox.search(paginatedresult);
            	inbox.filterButtonColor = true;
             }
       
		
	});
	
	//Load Dashboard
	inbox.channels();
	inbox.search(paginatedresult);
	
});