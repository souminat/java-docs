angular.module('app.pages.releaserdashboard.controller',[
	'ui.router',
	'ui.bootstrap',
	'ct.loadingOverlay',
	'app.config',
	'app.messages',
	'app.directives'
])

.config(function ($stateProvider, configProvider) {

	$stateProvider
		.state('pages.releaser', {
			url: "/releaser",
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/dashboard/releaserdashboard.controller.html',
					controller: "releaserdashboardController as rd"
				}
			}
		});
})

.controller('releaserdashboardController', function ($state, $uibModal,$document, $rootScope, $scope, $q, config, simpleModal, messages, paymentRequestManager, userManager) {

	var rd = this;
	var pageType = 'Release';
	var paginatedresult = {
			offset : 0,
			pageType : pageType
		};
	rd.paymentList = {};
	rd.filter = {};
	rd.shwFilterApplied = [];
	$scope.data = rd.paymentList.data;
	//$scope.sortReverse = true;
	
	
	//$('#payment-filter').css('background-color', 'transparent'); 
	
	
	
	angular.extend(rd, {
		
		isLoading: 				false,
		filterApplied:		    false,
		filterDisplayBlock:		false,
		filterDisplayNone:		true,
		requestDate : '',
	    valueDate : '',
	    filterButtonColor : true,
	    sortReverse : '',
	    sortPropertyName : '',
	    userRole: '',
	    
		filters: {
			start_index: 		1,
			count:				10,
			currentPage:		1
		},
		channels: function() {
        	$scope.$on('customTableChangePagination', rd.changePagination);
        	$scope.$on('customTableViewObjectEmit', rd.viewPayment);
        	$scope.$on('customTableSortObject',rd.changeSortBy);
        	$scope.$on('sortReverseVariable', function(event, arg){
        	    rd.sortReverse = arg;
        	  });
        	$scope.$on('sortPropertyName', function(event, arg){
        	    rd.sortPropertyName = arg;
        	  });
        },
 getRequestType : function(text){
			
			//alert(text);
        	var defer = $q.defer();
        	
        	var criteria = {
                requestType: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getRequestTypeOptions(text);
        	promise.$promise.then(function(result) {
        		rd.requests = result.requestType;
        		defer.resolve(result.requestType);
        	});
        	
        	return defer.promise;
        },
        
	getPayeeName : function(text){
			
			
        	var defer = $q.defer();
        	var payerList = {
        			
        	};
        	var criteria = {
                payeeSearchValue: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getPayeeList(text);
        	promise.$promise.then(function(result) {
        		rd.payeeNames = result.payeeName;
        		defer.resolve(result.payeeName);
        	});
        	
        	return defer.promise;
        },
        
        getPayerName : function(text){
			
        	var defer = $q.defer();
        	var payerList = {
        			
        	};
        	var criteria = {
                payerSearchValue: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getPayerList(text);
        	promise.$promise.then(function(result) {
        		rd.payerNames = result.payerName;
        		
        		defer.resolve(result.payerName);
        	});
        	
        	return defer.promise;
        },
        viewPayment: function(event, payment) {
        	if (payment.requestTypeCode == 'Manual Payment')
        		rd.erpPaymentRequest = false;
        	else if (payment.requestTypeCode == 'ERP Manual Payment')
        		rd.erpPaymentRequest = true;
        		
        	switch(payment.status) {
        		case 'Submitted':
        			$state.go('pages.approvalsApprover', {
                		paymentId: payment.requestId,
                		erpPaymentRequest: rd.erpPaymentRequest
                	});
        		break;
        		case 'Approved':
        			$state.go('pages.approvalsPreparer', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: rd.erpPaymentRequest
                	});
            	break;
        		case 'Rejected':
        			$state.go('pages.approvalsApprover', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: rd.erpPaymentRequest
                	});
                break;
        		case 'Prepared':
        			$state.go('pages.approvalsReleaser', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: rd.erpPaymentRequest
                	});
                break;
        		case 'Released':
        			$state.go('pages.approvalsConfirmation', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: rd.erpPaymentRequest
                	});
                break;
        		case 'Cancelled':
        			$state.go('pages.approvalsPreparer', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: rd.erpPaymentRequest
                	});
            	break;
        		case 'Confirmed':
        			$state.go('pages.approvalsConfirmReadOnly', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: rd.erpPaymentRequest
                	});
            	break;
        	};
        },
        search: function(paginatedresult) {
        	console.log("Loading dashboard for Releasers : " + rd);
        	//rd.userRole = $state.includes("pages.approvals") ? 'Approver' : 'Requestor';
    		//rd.title = (rd.userRole === 'Requestor') ? 'My Open Requests' : 'My Pending Approval';
    		
        	rd.isLoading = true;
        	
        	var promise = paymentRequestManager.getApprovalDashboardResults(paginatedresult);
        	
        	promise.$promise.then(function(result) {
            	
                var data = result.resultList;
                //console.log("Data : " + data);
                var total = result.totalRecords;
                //console.log("total : " + total);
                var releaser =  result.releaserList;
                
                rd.paymentList = {
                	idProperty: 'requestId',	
                    total: total,
                    start: rd.filters.start_index,
                    limit: rd.filters.count,
                    currentPage: rd.filters.currentPage,
                    releaser:releaser,
                    pageType:pageType,
                    userRole: rd.userRole.toUpperCase(),
                    headers: [
                    	{
                            field: 'requestId',
                            name: 'Request ID'
                            
                        },
                        {
                            field: 'requestDate',
                            name: 'Request Date'
                        },
                        {
                            field: 'requestType',
                            name: 'Request Type'
                        },
                        {
                            field: 'payerDescription',
                            name: 'Payer'
                        },
                        {
                            field: 'payeeDescripton',
                            name: 'Payee'
                        },
                        {
                            field: 'payeeBankCountry',
                            name: 'Country'
                        },
                        {
                            field: 'payeeCurrency',
                            name: 'Currency'
                        },
                        {
                            field: 'payeeAmount',
                            name: 'Amount'
                        },
                        {
                            field: 'valueDate',
                            name: 'Value Date'
                        },
                        {
                            field: 'requester',
                            name: 'Requester'
                        },
                        /*{
                        field: 'assignedTo',
                        name: 'Assigned To'
	                    },*/
	                    {
	                        field: 'status',
	                        name: 'Status'
	                    },
	                    {
	                        field: 'requestTypeCode',
	                        name: 'Payment Type Code'
	                    },
	                   {
	                        field: 'assignto',
	                        name: 'Assigned To'
	                    }
                    ],
                    data: data
                };
                rd.isLoading = false;
            });
        },
        
       	 applyFilter : function () {
             var columnName = rd.sortPropertyName;
        	   	var sortOrder = rd.sortReverse;  
        	   	rd.shwFilterApplied = [];
           	rd.filterApplied = true;
           	rd.filterButtonColor = false;
          	
          	 if(rd.filter.requestDate) {
          		 rd.requestDate = moment(rd.filter.requestDate).format('DD-MM-YY');
               }
          	 
          	 if(rd.filter.valueDate) {
          		 rd.valueDate = moment(rd.filter.valueDate).format('DD-MM-YY');
               }
        	   if (rd.filter.requestId != undefined && rd.filter.requestId != "") {
        		   rd.shwFilterApplied.push("Request ID:");
        		   rd.shwFilterApplied.push(rd.filter.requestId);
        	   }
        	   if (rd.filter.requestType != undefined && rd.filter.requestType != "") {
        		   rd.shwFilterApplied.push("Request Type:");
        		   rd.shwFilterApplied.push(rd.filter.requestType);
        	   }
        	   if (rd.filter.requestDate != undefined && rd.filter.requestDate != "") {
        		   rd.shwFilterApplied.push("Request Date:");
        		   rd.shwFilterApplied.push(moment(rd.filter.requestDate).format('DD-MMM-YY'));
        	   }
        	   if (rd.filter.payer != undefined && rd.filter.payer != "") {
        		   rd.shwFilterApplied.push("Payer:");
        		   rd.shwFilterApplied.push(rd.filter.payer);
        	   }
        	   if (rd.filter.payee != undefined && rd.filter.payee != "") {
        		   rd.shwFilterApplied.push("Payee:");
        		   rd.shwFilterApplied.push(rd.filter.payee);
        	   }
        	   if (rd.filter.country != undefined && rd.filter.country != "") {
        		   rd.shwFilterApplied.push("Country:");
        		   rd.shwFilterApplied.push(rd.filter.country);
        	   }
        	   if (rd.filter.currency != undefined && rd.filter.currency != "") {
        		   rd.shwFilterApplied.push("Currency:");
        		   rd.shwFilterApplied.push(rd.filter.currency);
        	   }
        	   if (rd.filter.Amount != undefined && rd.filter.Amount != "") {
        		   rd.shwFilterApplied.push("Amount:");
        		   rd.shwFilterApplied.push(rd.filter.Amount);
        	   }
        	   if (rd.filter.valueDate != undefined && rd.filter.valueDate != "") {
        		   rd.shwFilterApplied.push("Value Date:");
        		   rd.shwFilterApplied.push(moment(rd.filter.valueDate).format('DD-MMM-YY'));
        	   }
        	   if (rd.filter.requester != undefined && rd.filter.requester != "") {
        		   rd.shwFilterApplied.push("Requester:");
        		   rd.shwFilterApplied.push(rd.filter.requester);
        	   }
        	   if (rd.filter.assignedTo != undefined && rd.filter.assignedTo != "") {
        		   rd.shwFilterApplied.push("Assigned To:");
        		   rd.shwFilterApplied.push(rd.filter.assignedTo);
        	   }
        	   if (rd.filter.status != undefined && rd.filter.status != "") {
        		   rd.shwFilterApplied.push("Status:");
        		   rd.shwFilterApplied.push(rd.filter.status);
        	   }
        	   rd.filters= {
          			   start_index: 1,
          			   count: 10,
          			   currentPage: 1
        	   };
        	   paginatedresult = {
        		   orderByColumn :columnName,
        		   sortingOrder : sortOrder,
        		   requestId : rd.filter.requestId,
        		   requestType :rd.filter.requestType,
        		   requestDate : rd.requestDate,
        		   payerDescription :rd.filter.payer,
        		   payeeDescripton :rd.filter.payee,
        		   payeeBankCountry :rd.filter.country,
        		   payeeCurrency:rd.filter.currency,
        		   payeeAmount:rd.filter.Amount,
        		   valueDate:rd.valueDate,
        		   requester:rd.filter.requester,
        		   assignedTo:rd.filter.assignedTo,
        		   status:rd.filter.status,
        		   pageType:pageType
           	}
           	rd.search(paginatedresult);
  			//rd.filterDisplayNone = true;
           },
           
           //Sorting
           
           changeSortBy: function(event,pName,page,start) {
   			var columnName = rd.sortPropertyName;
       	   var sortOrder = rd.sortReverse; 
       	   if(rd.filter.requestDate) {
         		 rd.requestDate = moment(rd.filter.requestDate).format('DD-MM-YY');
              }
       	   if(rd.filter.valueDate) {
       		   rd.valueDate = moment(rd.filter.valueDate).format('DD-MM-YY');
       	   }
       	   
       	   rd.filters.currentPage = page;
       	   rd.filters.start_index = start;
			
	    	var totalNxt = rd.paymentList.total;
	 	    var next = 0;
	 	    if(totalNxt - start <10) {
	 	    	next = totalNxt - start;
	 	    } else {
	 	    	next = 10;
	 	    }      
       	            
   			paginatedresult = {
   				next : next,
              		orderByColumn :columnName,
              		sortingOrder : sortOrder,
              		requestId : rd.filter.requestId,
        			requestType :rd.filter.requestType,
        			requestDate : rd.requestDate,
                   payerDescription :rd.filter.payer,
                   payeeDescripton :rd.filter.payee,
                   payeeBankCountry :rd.filter.country,
                   payeeCurrency:rd.filter.currency,
                   payeeAmount:rd.filter.Amount,
                   valueDate:rd.valueDate,
                   requester:rd.filter.requester,
                   assignedTo:rd.filter.assignedTo,
                   status:rd.filter.status,
                   pageType:pageType
              	};
              	rd.search(paginatedresult);
            },
            resetFilter : function() {
            	paginatedresult = {offset :0,pageType :pageType};
            	rd.filters= {
           			   start_index: 1,
           			   count: 10,
           			   currentPage: 1
            	};
            	rd.shwFilterApplied = [];
             	rd.filterApplied = false;
             	rd.filter = {};
    			rd.requestDate = '';
                rd.valueDate = '';
                rd.search(paginatedresult);
             	rd.filterButtonColor = true;
             },
            
            changePagination: function(event, page, start) {
            	rd.filters.currentPage = page;
            	rd.filters.start_index = start;
    		
            	var totalNxt = rd.paymentList.total
            	var columnName = rd.sortPropertyName;
            	var sortOrder = rd.sortReverse;
            	if(rd.filter.requestDate) {
            		rd.requestDate = moment(rd.filter.requestDate).format('DD-MM-YY');
            	}
           	    if(rd.filter.valueDate) {
           	    	rd.valueDate = moment(rd.filter.valueDate).format('DD-MM-YY');
           	    }
            	
            	var next = 0;        		
            	if(totalNxt - start <10) {
            		next = totalNxt - start;
            	} else {
            		next = 10;
            	}
            		
            	paginatedresult ={
            		offset : start,
            		next : next,
            		orderByColumn :columnName,
            		sortingOrder : sortOrder,
            		requestId : rd.filter.requestId,
         			requestType :rd.filter.requestType,
         			requestDate : rd.requestDate,
                    payerDescription :rd.filter.payer,
                    payeeDescripton :rd.filter.payee,
                    payeeBankCountry :rd.filter.country,
                    payeeCurrency:rd.filter.currency,
                    payeeAmount:rd.filter.Amount,
                    valueDate:rd.valueDate,
                    requester:rd.filter.requester,
                    assignedTo:rd.filter.assignedTo,
                    status:rd.filter.status,
                    pageType:pageType
            	}
            	rd.search(paginatedresult);
            },
            
            getUserRole: function () {
            	var ssoPromise = userManager.get();
        		ssoPromise.$promise.then(function(result) {
        			rd.userRole = result.appRole;
        		});
            }
       
		
	});
	
	//Load Dashboard
	rd.channels();
	rd.getUserRole();
	rd.search(paginatedresult);
	
});