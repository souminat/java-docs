angular.module('app.pages.myApprovalDashboard.controller',[
	'ui.router',
	'ui.bootstrap',
	'ct.loadingOverlay',
	'app.config',
	'app.messages'
])

.config(function ($stateProvider, configProvider) {

	$stateProvider
		.state('pages.myApproval', {
			url: "/myApproval",
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/dashboard/myApprovalDashboard.controller.html',
					controller: "myApprovalDashboardController as myApproval"
				}
			}
		});
})

.controller('myApprovalDashboardController', function ($state, $uibModal,$document, $filter, $scope, $q, config, simpleModal, messages, paymentRequestManager) {

	var myApproval = this;
	var paginatedresult = {
			offset : 0
		};
	
	angular.extend(myApproval, {
		
		isLoading: false,
		pag: true,
		entries: 10,
		filter: {},
		filterValues: {},
		filterApplied : false,
		filterButtonColor : true,
		filters: {
			start_index: 		1,
			count:				10,
			currentPage:		1
		},
		sort: {
    		column: 'userName',
    		descending: true
        },
		 
        search: function(paginatedresult) {
        	myApproval.isLoading = true;
        	
        	var promise = paymentRequestManager.getMyApprovalDashboardResults();
        	
        	promise.$promise.then(function(result) {
        		var mainList = [];
        		var responseData = result.responseData;
        		
        		angular.forEach(responseData, function(respData) {
            		var roles = respData.roles;
            		angular.forEach(roles, function(role) {
            			var fgLst = role.fg;
                		if (fgLst != null) {
                			angular.forEach(fgLst, function(fg) {
                				var desiredList = {
                						userName: respData.sso,
            							business: role.busLevel5Name,
            							subBusiness: role.busLevel6Name,
            							requestType: fg.requestType,
            							paymentType: fg.paymentType,
            							approvalRange: fg.approvalRange
            					};
                				mainList.push(desiredList);
                			});
                			
						} else {
							var desiredList = {
        							userName: respData.sso,
        							business: role.busLevel5Name,
        							subBusiness: role.busLevel6Name,
        							requestType: '',
        							paymentType: '',
        							approvalRange: ''
        					};
							mainList.push(desiredList);
						}
                	});
            	});
        		
        		myApproval.resultList = mainList;
        		var data = myApproval.resultList;
                var total = myApproval.resultList.length;
                
                myApproval.approversList = {
                	pageSize: 10,
                	maxSize:5,
                	itemsPerPage: 10,
                    total: total,
                    start: myApproval.filters.start_index,
                    limit: myApproval.filters.count,
                    currentPage: myApproval.filters.currentPage,
                    headers: [
                    	{
                            field: 'userName',
                            name: 'User Name'
                            
                        },
                        {
                            field: 'business',
                            name: 'Business'
                        },
                        {
                            field: 'subBusiness',
                            name: 'Sub Business'
                        },
                        {
                            field: 'requestType',
                            name: 'Request Type'
                        },
                        {
                            field: 'paymentType',
                            name: 'Payment Type'
                        },
                        {
                            field: 'approvalRange',
                            name: 'ApprovalRange'
                        }
                    ],
                    data: data
                };
                myApproval.isLoading = false;
            });
        },
        
        sortBy : function(headerName) {
        	if (myApproval.sort.descending)
        		myApproval.sort.descending = false;
			else
				myApproval.sort.descending = true;
        	
        	
        	if (myApproval.sort.column == headerName.trim())
        		myApproval.sort.descending = myApproval.sort.descending;
            else 
            	myApproval.sort.column = headerName.trim();
            
		},
		
        getUserName: function(searchText) {
			var propertyName = 'userName';
			var defer = $q.defer();
        	var promise;
        	var internalArray = [];
        	
        	angular.forEach(myApproval.approversList.data, function(obj) {
        		if (obj[propertyName].toLowerCase().match(searchText.toLowerCase())) {
        			var internal = {
        					userName:obj[propertyName]
        			};
        			internalArray.push(internal);
        		}
        	});
        	
        	promise = _.uniq(internalArray, propertyName);
        	defer.resolve(promise);
        	
        	return defer.promise;
		},
		
		getBusiness: function(searchText) {
			var propertyName = 'business';
			var defer = $q.defer();
        	var promise;
        	var internalArray = [];
        	
        	angular.forEach(myApproval.approversList.data, function(obj) {
        		if (obj[propertyName].toLowerCase().match(searchText.toLowerCase())) {
        			var internal = {
        					business:obj[propertyName]
        			};
        			internalArray.push(internal);
        		}
        	});
        	
        	promise = _.uniq(internalArray, propertyName);
        	defer.resolve(promise);
        	
        	return defer.promise;
		},
		
		getSubBusiness: function(searchText) {
			var propertyName = 'subBusiness';
			var defer = $q.defer();
        	var promise;
        	var internalArray = [];
        	
        	angular.forEach(myApproval.approversList.data, function(obj) {
        		if (obj[propertyName].toLowerCase().match(searchText.toLowerCase())) {
        			var internal = {
        					subBusiness:obj[propertyName]
        			};
        			internalArray.push(internal);
        		}
        	});
        	
        	promise = _.uniq(internalArray, propertyName);
        	defer.resolve(promise);
        	
        	return defer.promise;
		},
		
		getRequestType: function(searchText) {
			var propertyName = 'requestType';
			var defer = $q.defer();
        	var promise;
        	var internalArray = [];
        	
        	angular.forEach(myApproval.approversList.data, function(obj) {
        		if (obj[propertyName].toLowerCase().match(searchText.toLowerCase())) {
        			var internal = {
        					requestType:obj[propertyName]
        			};
        			internalArray.push(internal);
        		}
        	});
        	
        	promise = _.uniq(internalArray, propertyName);
        	defer.resolve(promise);
        	
        	return defer.promise;
		},
		
		getPaymentType: function(searchText) {
			var propertyName = 'paymentType';
			var defer = $q.defer();
        	var promise;
        	var internalArray = [];
        	
        	angular.forEach(myApproval.approversList.data, function(obj) {
        		if (obj[propertyName].toLowerCase().match(searchText.toLowerCase())) {
        			var internal = {
        					paymentType:obj[propertyName]
        			};
        			internalArray.push(internal);
        		}
        	});
        	
        	promise = _.uniq(internalArray, propertyName);
        	defer.resolve(promise);
        	
        	return defer.promise;
		},
		
		getApprovalRange: function(searchText) {
			var propertyName = 'approvalRange';
			var defer = $q.defer();
        	var promise;
        	var internalArray = [];
        	
        	angular.forEach(myApproval.approversList.data, function(obj) {
        		if (obj[propertyName].toLowerCase().match(searchText.toLowerCase())) {
        			var internal = {
        					approvalRange:obj[propertyName]
        			};
        			internalArray.push(internal);
        		}
        	});
        	
        	promise = _.uniq(internalArray, propertyName);
        	defer.resolve(promise);
        	
        	return defer.promise;
		},
		
		applyFilter: function() {
			myApproval.filterApplied = true;
			myApproval.filterButtonColor = false;
			myApproval.filterValues = {
					userName: (!_.isUndefined(myApproval.filter.userName) ? myApproval.filter.userName.userName : undefined ),
					business:(!_.isUndefined(myApproval.filter.business) ? myApproval.filter.business.business : undefined ), 
					subBusiness:(!_.isUndefined(myApproval.filter.subBusiness) ? myApproval.filter.subBusiness.subBusiness : undefined ),
					requestType:(!_.isUndefined(myApproval.filter.requestType) ? myApproval.filter.requestType.requestType : undefined ), 
					paymentType:(!_.isUndefined(myApproval.filter.paymentType) ? myApproval.filter.paymentType.paymentType : undefined ), 
					approvalRange: (!_.isUndefined(myApproval.filter.approvalRange) ? myApproval.filter.approvalRange.approvalRange : undefined )
			};
			
			var filteredData = $filter('filter')(myApproval.approversList.data,myApproval.filterValues);
			myApproval.resultList = filteredData;
			if (filteredData.length != 0) {
				myApproval.approversList.currentPage = 1;
				if (filteredData.length < myApproval.entries) {
					myApproval.entries = filteredData.length;
				}
			} else {
				myApproval.approversList.currentPage = 0;
			}
			myApproval.approversList.total = filteredData.length;
			myApproval.approversList.start = 1;
			myApproval.approversList.limit = 10;
		},
		
		resetFilter: function () {
			myApproval.filter = {};
			myApproval.filterValues = {};
			myApproval.filterApplied = false;
			myApproval.filterButtonColor = true;
			myApproval.entries = 10;
			myApproval.approversList.total = myApproval.approversList.data.length;
			myApproval.resultList = myApproval.approversList.data;
			myApproval.approversList.start = 1;
			myApproval.approversList.limit = 10;
			myApproval.approversList.currentPage = 1;
			myApproval.sort = {
	    		column: 'userName',
	    		descending: true
	        };
		},
		
		chkSize: function () {
			var flag = true;
			if (angular.equals({}, myApproval.filterValues)) {
				flag = false;
			}
			return flag;
		},
		
		getCurrentEntries: function() {
			if (!_.isUndefined(myApproval.approversList)) {
				var currentEntries = myApproval.approversList.currentPage * myApproval.entries;
				if( currentEntries > myApproval.approversList.total ) {
					currentEntries = myApproval.approversList.total;
				}
				return currentEntries;
			}
		},
	});
	
	//Load Dashboard
	myApproval.search(paginatedresult);
	
});