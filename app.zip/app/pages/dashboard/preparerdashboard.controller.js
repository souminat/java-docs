angular.module('app.pages.preparerdashboard.controller',[
	'ui.router',
	'ui.bootstrap',
	'ct.loadingOverlay',
	'app.config',
	'app.messages',
	'app.directives'
])

.config(function ($stateProvider, configProvider) {

	$stateProvider
		.state('pages.preparer', {
			url: "/preparer",
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/dashboard/preparerdashboard.controller.html',
					controller: "preparerdashboardController as pd"
				}
			}
		});
})

.controller('preparerdashboardController', function ($state, $uibModal,$document, $rootScope, $scope, $q, config, simpleModal, messages, paymentRequestManager, userManager) {

	var pd = this;
	var pageType = 'Prepare';
	var paginatedresult = {
			offset : 0,
			pageType : pageType
		};
	pd.paymentList = {};
	pd.filter = {};
	pd.shwFilterApplied = [];
	$scope.data = pd.paymentList.data;
	
	//$scope.sortReverse = true;
	
	
	
	//$('#payment-filter').css('background-color', 'transparent'); 
	
	
	
	angular.extend(pd, {
		
		isLoading: 				false,
		filterApplied: 			false,
		filterDisplayBlock: 	false,
		filterDisplayNone:       true,
		requestDate : '',
	    valueDate : '',
	    filterButtonColor : true,
	    sortReverse : '',
	    sortPropertyName : '',
	    userRole: '',
	    
		filters: {
			start_index: 		1,
			count:				10,
			currentPage:		1
		},
		channels: function() {
        	$scope.$on('customTableChangePagination', pd.changePagination);
        	$scope.$on('customTableViewObjectEmit', pd.viewPayment);
        	$scope.$on('customTableSortObject',pd.changeSortBy);
        	$scope.$on('sortReverseVariable', function(event, arg){
        	    pd.sortReverse = arg;
        	  });
        	$scope.$on('sortPropertyName', function(event, arg){
        	    pd.sortPropertyName = arg;
        	  });
        },
getRequestType : function(text){
			
			//alert(text);
        	var defer = $q.defer();
        	
        	var criteria = {
                requestType: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getRequestTypeOptions(text);
        	promise.$promise.then(function(result) {
        		pd.requests = result.requestType;
        		defer.resolve(result.requestType);
        	});
        	
        	return defer.promise;
        },
        
	getPayeeName : function(text){
			
			
        	var defer = $q.defer();
        	var payerList = {
        			
        	};
        	var criteria = {
                payeeSearchValue: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getPayeeList(text);
        	promise.$promise.then(function(result) {
        		pd.payeeNames = result.payeeName;
        		defer.resolve(result.payeeName);
        	});
        	
        	return defer.promise;
        },
        
        getPayerName : function(text){
			
        	var defer = $q.defer();
        	var payerList = {
        			
        	};
        	var criteria = {
                payerSearchValue: encodeURI(text)        		
        	};
        	var promise = paymentRequestManager.getPayerList(text);
        	promise.$promise.then(function(result) {
        		pd.payerNames = result.payerName;
        		
        		defer.resolve(result.payerName);
        	});
        	
        	return defer.promise;
        },
        
        viewPayment: function(event, payment) {
        	if (payment.requestTypeCode == 'Manual Payment')
        		pd.erpPaymentRequest = false;
        	else if (payment.requestTypeCode == 'ERP Manual Payment')
        		pd.erpPaymentRequest = true;
        		
        	switch(payment.status) {
        		case 'Submitted':
        			$state.go('pages.approvalsApprover', {
                		paymentId: payment.requestId,
                		erpPaymentRequest: pd.erpPaymentRequest
                	});
        		break;
        		case 'Approved':
        			$state.go('pages.approvalsPreparer', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: pd.erpPaymentRequest
                	});
            	break;
        		case 'Rejected':
        			$state.go('pages.approvalsApprover', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: pd.erpPaymentRequest
                	});
                break;
        		case 'Prepared':
        			$state.go('pages.approvalsReleaser', {
        				paymentId: payment.requestId,
        				erpPaymentRequest: pd.erpPaymentRequest
                	});
                break;
        		case 'Cancelled':
        			$state.go('pages.approvalsApprover', {
                		paymentId: payment.requestId,
                		erpPaymentRequest: pd.erpPaymentRequest
                	});
        		break;
        	};
        },
        search: function(paginatedresult) {
        	console.log("Loading dashboard for Preparers : " + pd);
        	//pd.userRole = $state.includes("pages.approvals") ? 'Approver' : 'Requestor';
    		//pd.title = (pd.userRole === 'Requestor') ? 'My Open Requests' : 'My Pending Approval';
    		
        	pd.isLoading = true;
        	var promise = paymentRequestManager.getApprovalDashboardResults(paginatedresult);
        	
        	promise.$promise.then(function(result) {
            	
                var data = result.resultList;
                console.log("Data : " + data);
                var total = result.totalRecords;
                console.log("total : " + total);

                var preparer =  result.preparerList;
                
                pd.paymentList = {
                	idProperty: 'requestId',	
                    total: total,
                    start: pd.filters.start_index,
                    limit: pd.filters.count,
                    currentPage: pd.filters.currentPage,
                    preparer:preparer,
                    pageType:pageType,
                    userRole: pd.userRole.toUpperCase(),
                    headers: [
                    	{
                            field: 'requestId',
                            name: 'Request ID'
                            
                        },
                        {
                            field: 'requestDate',
                            name: 'Request Date'
                        },
                        {
                            field: 'requestType',
                            name: 'Request Type'
                        },
                        {
                            field: 'payerDescription',
                            name: 'Payer'
                        },
                        {
                            field: 'payeeDescripton',
                            name: 'Payee'
                        },
                        {
                            field: 'payeeBankCountry',
                            name: 'Country'
                        },
                        {
                            field: 'payeeCurrency',
                            name: 'Currency'
                        },
                        {
                            field: 'payeeAmount',
                            name: 'Amount'
                        },
                        {
                            field: 'valueDate',
                            name: 'Value Date'
                        },
                        {
                            field: 'requester',
                            name: 'Requester'
                        },
                        /*{
                        field: 'assignedTo',
                        name: 'Assigned To'
	                    },*/
	                    {
	                        field: 'status',
	                        name: 'Status'
	                    },
	                    {
	                        field: 'requestTypeCode',
	                        name: 'Payment Type Code'
	                    },
	                   {
	                        field: 'assignto',
	                        name: 'Assigned To'
	                    }
                    ],
                    data: data
                };
                pd.isLoading = false;
            });
        },
        
         applyFilter : function () {
             var columnName = pd.sortPropertyName;
        	   	var sortOrder = pd.sortReverse;  
        	   	pd.shwFilterApplied = [];
           	pd.filterApplied = true;
           	pd.filterButtonColor = false;
          	
          	 if(pd.filter.requestDate) {
          		 pd.requestDate = moment(pd.filter.requestDate).format('DD-MM-YY');
               }
          	 
          	 if(pd.filter.valueDate) {
          		 pd.valueDate = moment(pd.filter.valueDate).format('DD-MM-YY');
               }
        	   if (pd.filter.requestId != undefined && pd.filter.requestId != "") {
        		   pd.shwFilterApplied.push("Request ID:");
        		   pd.shwFilterApplied.push(pd.filter.requestId);
        	   }
        	   if (pd.filter.requestType != undefined && pd.filter.requestType != "") {
        		   pd.shwFilterApplied.push("Request Type:");
        		   pd.shwFilterApplied.push(pd.filter.requestType);
        	   }
        	   if (pd.filter.requestDate != undefined && pd.filter.requestDate != "") {
        		   pd.shwFilterApplied.push("Request Date:");
        		   pd.shwFilterApplied.push(moment(pd.filter.requestDate).format('DD-MMM-YY'));
        	   }
        	   if (pd.filter.payer != undefined && pd.filter.payer != "") {
        		   pd.shwFilterApplied.push("Payer:");
        		   pd.shwFilterApplied.push(pd.filter.payer);
        	   }
        	   if (pd.filter.payee != undefined && pd.filter.payee != "") {
        		   pd.shwFilterApplied.push("Payee:");
        		   pd.shwFilterApplied.push(pd.filter.payee);
        	   }
        	   if (pd.filter.country != undefined && pd.filter.country != "") {
        		   pd.shwFilterApplied.push("Country:");
        		   pd.shwFilterApplied.push(pd.filter.country);
        	   }
        	   if (pd.filter.currency != undefined && pd.filter.currency != "") {
        		   pd.shwFilterApplied.push("Currency:");
        		   pd.shwFilterApplied.push(pd.filter.currency);
        	   }
        	   if (pd.filter.Amount != undefined && pd.filter.Amount != "") {
        		   pd.shwFilterApplied.push("Amount:");
        		   pd.shwFilterApplied.push(pd.filter.Amount);
        	   }
        	   if (pd.filter.valueDate != undefined && pd.filter.valueDate != "") {
        		   pd.shwFilterApplied.push("Value Date:");
        		   pd.shwFilterApplied.push(moment(pd.filter.valueDate).format('DD-MMM-YY'));
        	   }
        	   if (pd.filter.requester != undefined && pd.filter.requester != "") {
        		   pd.shwFilterApplied.push("Requester:");
        		   pd.shwFilterApplied.push(pd.filter.requester);
        	   }
        	   if (pd.filter.assignedTo != undefined && pd.filter.assignedTo != "") {
        		   pd.shwFilterApplied.push("Assigned To:");
        		   pd.shwFilterApplied.push(pd.filter.assignedTo);
        	   }
        	   if (pd.filter.status != undefined && pd.filter.status != "") {
        		   pd.shwFilterApplied.push("Status:");
        		   pd.shwFilterApplied.push(pd.filter.status);
        	   }
        	   pd.filters= {
          			   start_index: 1,
          			   count: 10,
          			   currentPage: 1
        	   };
        	   paginatedresult = {
        		   orderByColumn :columnName,
        		   sortingOrder : sortOrder,
        		   requestId : pd.filter.requestId,
        		   requestType :pd.filter.requestType,
        		   requestDate : pd.requestDate,
        		   payerDescription :pd.filter.payer,
        		   payeeDescripton :pd.filter.payee,
        		   payeeBankCountry :pd.filter.country,
        		   payeeCurrency:pd.filter.currency,
        		   payeeAmount:pd.filter.Amount,
        		   valueDate:pd.valueDate,
        		   requester:pd.filter.requester,
        		   assignedTo:pd.filter.assignedTo,
        		   status:pd.filter.status,
        		   pageType :pageType
           	}
           	pd.search(paginatedresult);
  			//pd.filterDisplayNone = true;
           },
           
           //Sorting
           
           changeSortBy: function(event,pName,page,start) {
   			var columnName = pd.sortPropertyName;
       	   var sortOrder = pd.sortReverse; 
       	   if(pd.filter.requestDate) {
         		 pd.requestDate = moment(pd.filter.requestDate).format('DD-MM-YY');
              }
       	   if(pd.filter.valueDate) {
       		   pd.valueDate = moment(pd.filter.valueDate).format('DD-MM-YY');
       	   }
       	   pd.filters.currentPage = page;
    	   pd.filters.start_index = start;
			
	    	var totalNxt = pd.paymentList.total;
	 	    var next = 0;
	 	    if(totalNxt - start <10) {
	 	    	next = totalNxt - start;
	 	    } else {
	 	    	next = 10;
	 	    }        
   			paginatedresult = {
   				next : next,
              		orderByColumn :columnName,
              		sortingOrder : sortOrder,
              		requestId : pd.filter.requestId,
        			requestType :pd.filter.requestType,
        			requestDate : pd.requestDate,
                   payerDescription :pd.filter.payer,
                   payeeDescripton :pd.filter.payee,
                   payeeBankCountry :pd.filter.country,
                   payeeCurrency:pd.filter.currency,
                   payeeAmount:pd.filter.Amount,
                   valueDate:pd.valueDate,
                   requester:pd.filter.requester,
                   assignedTo:pd.filter.assignedTo,
                   status:pd.filter.status,
                   pageType:pageType
                   
              	};
              	pd.search(paginatedresult);
            },
            
            
            changePagination: function(event, page, start) {
            	pd.filters.currentPage = page;
            	pd.filters.start_index = start;
    		
            	var totalNxt = pd.paymentList.total
            	var columnName = pd.sortPropertyName;
            	var sortOrder = pd.sortReverse;
            	if(pd.filter.requestDate) {
            		pd.requestDate = moment(pd.filter.requestDate).format('DD-MM-YY');
            	}
           	    if(pd.filter.valueDate) {
           	    	pd.valueDate = moment(pd.filter.valueDate).format('DD-MM-YY');
           	    }
            	
            	var next = 0;        		
            	if(totalNxt - start <10) {
            		next = totalNxt - start;
            	} else {
            		next = 10;
            	}
            		
            	paginatedresult ={
            		offset : start,
            		next : next,
            		orderByColumn :columnName,
            		sortingOrder : sortOrder,
            		requestId : pd.filter.requestId,
         			requestType :pd.filter.requestType,
         			requestDate : pd.requestDate,
                    payerDescription :pd.filter.payer,
                    payeeDescripton :pd.filter.payee,
                    payeeBankCountry :pd.filter.country,
                    payeeCurrency:pd.filter.currency,
                    payeeAmount:pd.filter.Amount,
                    valueDate:pd.valueDate,
                    requester:pd.filter.requester,
                    assignedTo:pd.filter.assignedTo,
                    status:pd.filter.status,
                    pageType:pageType
            	}
            	pd.search(paginatedresult);
            },
            
            resetFilter : function() {
           	paginatedresult = {offset :0,pageType :pageType};
           	pd.filters= {
       			   start_index: 1,
       			   count: 10,
       			   currentPage: 1
           	};
           	pd.shwFilterApplied = [];
            	pd.filterApplied = false;
            	pd.filter = {};
   			pd.requestDate = '';
               pd.valueDate = '';
               pd.search(paginatedresult);
            	pd.filterButtonColor = true;
            },
            
            getUserRole: function () {
            	var ssoPromise = userManager.get();
        		ssoPromise.$promise.then(function(result) {
        			pd.userRole = result.appRole;
        		});
            }
       
		
	});
	
	//Load Dashboard
	pd.channels();
	pd.getUserRole();
	pd.search(paginatedresult);
	
});