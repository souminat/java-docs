angular.module('app.pages.upload.controller',[
	'ui.router',
	'app.config',
	'ux.form.simpleModal',
	'app.messages',
	'app.services',
	'app.directives'
])

.config(function ($stateProvider, configProvider) {

	$stateProvider
		.state('pages.upload', {
			url: "/upload",
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/upload/upload.controller.html',
					controller: 'uploadController as upload'
				}
			}
		});
})

.controller('uploadController', function ($scope, config, $state, $q, simpleModal, csv, messages) {

	var upload = this;

	upload.startPage = 1;
	upload.constantLimitPage = config.PAGINATION_SIZE;
	upload.limitPage = config.PAGINATION_SIZE;
	
});