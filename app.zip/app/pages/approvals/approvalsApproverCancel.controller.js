angular.module('app.pages.approvals.approver.cancel.controller', [
    'ui.router',
    'ct.loadingOverlay',
    'ux.form.simpleModal',
    'app.config',
    'app.services',
    'app.directives'
])
.config(function ($stateProvider, configProvider) {
	$stateProvider
    	.state('pages.approvalsApproverCancel', {
    		url: "/approvals/approver/cancel/:paymentId/:erpPaymentRequest",
    		params: {
    			paymentId: null,
    			erpPaymentRequest: null
    			
    		},
    		data: {
    			
    		},
    		views: {
    			'content': {
    				templateUrl: configProvider.templateBasePath + 'app/pages/approvals/approvalsApproverCancel.controller.html',
    				controller: 'approvalsApproverCancelController as approvals'
    			}
    		}
    	});
})
.controller('approvalsApproverCancelController', function ($scope, $state, $stateParams, $q, config, paymentRequestManager, holidayCalendarManager, currencyManager, simpleModal) {
	var approvals = this;
	
	// Public properties/functions
    angular.extend(approvals, {
    	isLoading: false,
    	getPayment: function() {
    		approvals.isLoading = true;
    		var paymentId = $stateParams.paymentId;
    		approvals.erpPaymentRequestType = $stateParams.erpPaymentRequest.trim();
    		
    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
    		promise.$promise.then(function(paymentRequest) {
    			approvals.payment = paymentRequest;
    			if(_.isNull(approvals.payment.paymentAccounting)) {
    				approvals.payment.paymentAccounting = {};
    			}
    			approvals.payment.paymentAccounting.isGOFBooked = approvals.payment.isGofBooked;
    			approvals.payment.payerCurrency = approvals.payment.payeeCurrency;
    			approvals.isLoading = false;
    		});
    	},
    	isRejectStatus: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment) && _.isEqual(approvals.payment.paymentStatusCode, 'REJECTED')) {
    			flag = true;
    		}
    		return flag;
    	},
    	createPayment: function() {
    		var payment = angular.copy(approvals.payment);
			payment.requestStatusId = {
				comments: 				approvals.comments,
				rejectCancelReason: 	approvals.cancelReason
			};
			return payment;
    	},
    	cancel: function() {
    		var payment = approvals.createPayment();
			var promise = paymentRequestManager.cancelPaymentRequest(payment);
			promise.$promise.then(function(result) {
				approvals.isLoading = false;
				$state.go('pages.payments');
			});
    	},
    	isAbleToCancel: function() {
    		var flag = true;
    		
    		if(_.isUndefined(approvals.cancelReason) || _.isEmpty(approvals.comments)) {
    			flag = false;
    		}
    		
    		return flag;
    	},
    	back: function() {
    		history.back();
    	}
    });
    
    // Obtain the payment
    approvals.getPayment();
});
