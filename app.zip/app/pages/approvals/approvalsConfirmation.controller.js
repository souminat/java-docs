angular.module('app.pages.approvals.confirmation.controller', [
    'ui.router',
    'ct.loadingOverlay',
    'ux.form.simpleModal',
    'app.config',
    'app.services',
    'app.directives'
])
.config(function ($stateProvider, configProvider) {
	$stateProvider
    	.state('pages.approvalsConfirmation', {
    		url: "/approvals/confirmation/:paymentId/:erpPaymentRequest",
    		params: {
    			paymentId: null,
    			erpPaymentRequest: null
    		},
    		data: {
    			
    		},
    		views: {
    			'content': {
    				templateUrl: configProvider.templateBasePath + 'app/pages/approvals/approvalsConfirmation.controller.html',
    				controller: 'approvalsConfirmationController as confirmation'
    			}
    		}
    	});
})
.controller('approvalsConfirmationController', function ($scope, $state, $stateParams, $q, config, paymentRequestManager, holidayCalendarManager, currencyManager, simpleModal) {
	var confirmation = this;
	
	// Public properties/functions
    angular.extend(confirmation, {
    	paymentProcess: 'Completed',
    	isLoading: false,
    	getPayment: function() {
    		confirmation.isLoading = true;
    		var paymentId = $stateParams.paymentId;
    		confirmation.erpPaymentRequestType = $stateParams.erpPaymentRequest;
    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
    		promise.$promise.then(function(paymentRequest) {
    			confirmation.payment = paymentRequest;
    			var paymentDate = paymentRequest.paymentDate;
    			if(!_.isDate(paymentDate)) {
    				paymentDate = moment(paymentDate, 'YYYY-MM-DD HH:mm:ss');
    			}
    			confirmation.common = {
    				paymentDate: paymentDate.toDate()
    			};
    			if(_.isNull(confirmation.payment.paymentAccounting)) {
    				confirmation.payment.paymentAccounting = {};
    			}
    			confirmation.payment.paymentAccounting.isGOFBooked = confirmation.payment.isGofBooked;
    			confirmation.payment.payerCurrency = confirmation.payment.payeeCurrency;
    			confirmation.payerFilters = {
    	    		mdmBusinessName: 		confirmation.payment.mdmBusinessName,
    	    		mdmSubBusinessName:		confirmation.payment.mdmSubBusinessName,
    	    		leName: {
    	    			mdm_id: 			confirmation.payment.payer.mdmGoldId,
    	    			party_nm: 			confirmation.payment.payer.mdmLEName
    	    		}
    	    	};
    			confirmation.isLoading = false;
    		});
    	},
    	isReleasedStatus: function() {
    		var flag = false;
    		if(!_.isUndefined(confirmation.payment) && _.isEqual(confirmation.payment.paymentStatusCode, 'RELEASED')) {
    			flag = true;
    		}
    		return flag;
    	},
    	createPayment: function() {
    		var payment = angular.copy(confirmation.payment);
    		confirmation.paymentRequestId = payment.requestId;
    		confirmation.requestActivities = payment.requestActivities;
    		 if(confirmation.paymentExecutionDt) {
    			 confirmation.paymentExecutionDt = moment(confirmation.paymentExecutionDt).format('YYYY-MM-DD');
         	 }
    		 if(confirmation.bankStatusDt) {
    			 confirmation.bankStatusDt = moment(confirmation.bankStatusDt).format('YYYY-MM-DD');
         	 }
			return confirmation;
    	},
    	confirm: function() {
    		confirmation.isLoading = true;
    		if(!_.isUndefined(confirmation.bankConfirmationNo) && confirmation.bankConfirmationNo == '') {
    			if (confirmation.bankConfirmationNo.trim() == '') {
    				confirmation.isLoading = false;
                	var modal = simpleModal.open({
            			title: 				'Error',
            			size: 				'lg',
            			allowClose: 		true,
            			allowDismiss:		false,
            			closeText:			'Close',
            			bodyHTML: 			'<p>Please enter confirmation number.</p>'
            		});
				}
            	
            } else {
            	var payment = confirmation.createPayment();
            	var promise = paymentRequestManager.confirmPaymentRequest(payment);
            	promise.$promise.then(function(result) {
            		confirmation.isLoading = false;
            		history.back();
            	});
            }
    	},
    	isAbleToConfirm: function() {
    		var flag = false;
    		if(!_.isEmpty(confirmation.bankConfirmationNo)
    				&& _.isDate(confirmation.paymentExecutionDt) 
    				&& !_.isEmpty(confirmation.bankStatusCode)
    				&& _.isDate(confirmation.bankStatusDt)) {
    			flag = true;
    		}
    		return flag;
    	},
    	back: function() {
    		history.back();
    	}
    });
    
    // Obtain the payment
    confirmation.getPayment();
});