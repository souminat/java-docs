angular.module('app.pages.approvals.confirmReadOnly.controller', [
    'ui.router',
    'ct.loadingOverlay',
    'ux.form.simpleModal',
    'app.config',
    'app.services',
    'app.directives'
])
.config(function ($stateProvider, configProvider) {
	$stateProvider
    	.state('pages.approvalsConfirmReadOnly', {
    		url: "/approvals/confirmationDetails/:paymentId/:erpPaymentRequest",
    		params: {
    			paymentId: null,
    			erpPaymentRequest: null
    		},
    		data: {
    			
    		},
    		views: {
    			'content': {
    				templateUrl: configProvider.templateBasePath + 'app/pages/approvals/approvalsConfirmReadOnly.controller.html',
    				controller: 'approvalsConfirmReadOnlyController as confirm'
    			}
    		}
    	});
})
.controller('approvalsConfirmReadOnlyController', function ($scope, $state, $stateParams, $q, config, paymentRequestManager, holidayCalendarManager, currencyManager, simpleModal) {
	var confirm = this;
	
	// Public properties/functions
    angular.extend(confirm, {
    	paymentProcess: 'Completed',
    	isLoading: false,
    	getPayment: function() {
    		confirm.isLoading = true;
    		var paymentId = $stateParams.paymentId;
    		confirm.erpPaymentRequestType = $stateParams.erpPaymentRequest;
    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
    		promise.$promise.then(function(paymentRequest) {
    			confirm.payment = paymentRequest;
    			var paymentDate = paymentRequest.paymentDate;
    			if(!_.isDate(paymentDate)) {
    				paymentDate = moment(paymentDate, 'YYYY-MM-DD HH:mm:ss');
    			}
    			confirm.common = {
    				paymentDate: paymentDate.toDate()
    			};
    			if(_.isNull(confirm.payment.paymentAccounting)) {
    				confirm.payment.paymentAccounting = {};
    			}
    			confirm.payment.paymentAccounting.isGOFBooked = confirm.payment.isGofBooked;
    			confirm.payment.payerCurrency = confirm.payment.payeeCurrency;
    			confirm.payerFilters = {
    	    		mdmBusinessName: 		confirm.payment.mdmBusinessName,
    	    		mdmSubBusinessName:		confirm.payment.mdmSubBusinessName,
    	    		leName: {
    	    			mdm_id: 			confirm.payment.payer.mdmGoldId,
    	    			party_nm: 			confirm.payment.payer.mdmLEName
    	    		}
    	    	};
    			confirm.isLoading = false;
    		});
    	}
    	
    });
    
    // Obtain the payment
    confirm.getPayment();
});