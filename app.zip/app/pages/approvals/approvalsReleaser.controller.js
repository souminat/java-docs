angular.module('app.pages.approvals.releaser.controller', [
    'ui.router',
    'ct.loadingOverlay',
    'ux.form.simpleModal',
    'app.config',
    'app.services',
    'app.directives'
])
.config(function ($stateProvider, configProvider) {
	$stateProvider
    	.state('pages.approvalsReleaser', {
    		url: "/approvals/releaser/:paymentId/:erpPaymentRequest",
    		params: {
    			paymentId: null,
    			erpPaymentRequest: null
    		},
    		data: {
    			
    		},
    		views: {
    			'content': {
    				templateUrl: configProvider.templateBasePath + 'app/pages/approvals/approvalsReleaser.controller.html',
    				controller: 'approvalsReleaserController as approvals'
    			}
    		}
    	});
})
.controller('approvalsReleaserController', function ($scope, $state, $stateParams, $q, config, paymentRequestManager, holidayCalendarManager, currencyManager, simpleModal) {
	var approvals = this;
	var today = new Date();
	
	$scope.$watch('approvals.common.paymentDate', function(newValue) {
    	if (!_.isUndefined(approvals.common))
    		if (!_.isUndefined(approvals.common.paymentDate) && 
    				parseInt(approvals.common.paymentDate.getDate().toString()) >= parseInt(today.getDate().toString()))
    			approvals.paymentDateFlag = false;
    });
	
	// Public properties/functions
    angular.extend(approvals, {
    	isLoading: false,
    	paymentDateFlag: false,
    	getPayment: function() {
    		approvals.isLoading = true;
    		var paymentId = $stateParams.paymentId;
    		approvals.erpPaymentRequestType = $stateParams.erpPaymentRequest;
    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
    		promise.$promise.then(function(paymentRequest) {
    			approvals.payment = paymentRequest;
    			var paymentDate = paymentRequest.paymentDate;
    			if(!_.isDate(paymentDate)) {
    				paymentDate = moment(paymentDate, 'YYYY-MM-DD HH:mm:ss');
    			}
    			approvals.common = {
    				paymentDate: paymentDate.toDate()
    			};
    			if(_.isNull(approvals.payment.paymentAccounting)) {
    				approvals.payment.paymentAccounting = {};
    			}
    			approvals.payment.paymentAccounting.isGOFBooked = approvals.payment.isGofBooked;
    			approvals.payment.payerCurrency = approvals.payment.payeeCurrency;
    			approvals.payerFilters = {
    	    		mdmBusinessName: 		approvals.payment.mdmBusinessName,
    	    		mdmSubBusinessName:		approvals.payment.mdmSubBusinessName,
    	    		leName: {
    	    			mdm_id: 			approvals.payment.payer.mdmGoldId,
    	    			party_nm: 			approvals.payment.payer.mdmLEName
    	    		}
    	    	};
    			
    			if (parseInt(approvals.common.paymentDate.getDate().toString()) < parseInt(today.getDate().toString()))
					approvals.paymentDateFlag = true;
    			
    			approvals.isLoading = false;
    		});
    	},
    	isPreparedStatus: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment) && _.isEqual(approvals.payment.paymentStatusCode, 'PREPARED')) {
    			flag = true;
    		}
    		return flag;
    	},
    	createPayment: function() {
    		var payment = angular.copy(approvals.payment);
			payment.rejectReason = approvals.common.rejectReason;
			payment.paymentDate = approvals.common.paymentDate;
			payment.requestStatusId = {
				comments: 		approvals.common.comments,
				rejectCancelReason: 	approvals.common.rejectReason
			};
			return payment;
    	},
    	getCurrencies: function (currencyCode) {
            return currencyManager.getByCurrencyCode(currencyCode);
        },
        getHolidays: function (currency) {
            return holidayCalendarManager.getHolidaysByCalendarName([currency.cal_nm]);
        },
    	release: function() {
    		approvals.isLoading = true;
    		if(approvals.payment.payer && approvals.common.paymentDate) {
    			var currencies = approvals.getCurrencies(approvals.payment.mdmPayerCurrency);
    			var holidays = approvals.getHolidays(currencies);
                holidays.$promise.then(function(response) {
                    var spotDays,
                        holidayDates,
                        today = new Date();

                    holidayDates = holidayCalendarManager.parseDates(response.elements);
                    var isHoliday = _.find(holidayDates, function(holiday) {
                    	var momentPaymentDate = moment(approvals.common.paymentDate);
                    	var momentHoliday = moment(holiday);
                    	return momentPaymentDate.isSame(momentHoliday, 'day');
                    });
                    if(isHoliday) {
                    	approvals.isLoading = false;
                    	var modal = simpleModal.open({
                			title: 				'Error',
                			size: 				'lg',
                			allowClose: 		true,
                			allowDismiss:		false,
                			closeText:			'Close',
                			bodyHTML: 			'<p>Please select a non holiday payment date.</p>'
                		});
                    } else {
                    	var payment = approvals.createPayment();
            			var promise = paymentRequestManager.releasePaymentRequest(payment);
            			promise.$promise.then(function(result) {
            				approvals.isLoading = false;
            				history.back();
            			});
                    }
                });
    		} else {
    			var payment = approvals.createPayment();
    			var promise = paymentRequestManager.releasePaymentRequest(payment);
    			promise.$promise.then(function(result) {
    				approvals.isLoading = false;
    				history.back();
    			});
    		}
    	},
    	isAbleToRelease: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment.payer) 
    				&& !_.isUndefined(approvals.common.paymentDate)
    				&& !approvals.paymentDateFlag) {
    			flag = true;
    		}
    		return flag;
    	},
    	reject: function() {
    		approvals.isLoading = true;
    		var payment = approvals.createPayment();
    		var promise = paymentRequestManager.rejectReleasePaymentRequest(payment);
			promise.$promise.then(function(result) {
				approvals.isLoading = false;
				history.back();
			});
    	},
    	isAbleToReject: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment)
    				&& !_.isUndefined(approvals.payment.payer) 
    				&& !_.isUndefined(approvals.common.comments)
    				&& !_.isEmpty(approvals.common.comments)
    				&& !_.isUndefined(approvals.common.rejectReason)) {
    			flag = true;
    		}
    		return flag;
    	},
    	back: function() {
    		history.back();
    	},
    	isPaymentMethodAllowed: function() {
    		var flag = false;
    		if(_.isEqual(approvals.payment.paymentSystem, 'WEBCASH_PAYMENT')) {
    			flag = true;
    		}
    		return flag;
    	}
    });
    
    // Obtain the payment
    approvals.getPayment();
});