angular.module('app.pages.approvals.approver.controller', [
    'ui.router',
    'ct.loadingOverlay',
    'ux.form.simpleModal',
    'app.config',
    'app.services',
    'app.directives'
])
.config(function ($stateProvider, configProvider) {
	$stateProvider
    	.state('pages.approvalsApprover', {
    		url: "/approvals/approver/:paymentId/:erpPaymentRequest",
    		params: {
    			paymentId: null,
    			erpPaymentRequest: null
    			
    		},
    		data: {
    			
    		},
    		views: {
    			'content': {
    				templateUrl: configProvider.templateBasePath + 'app/pages/approvals/approvalsApprover.controller.html',
    				controller: 'approvalsApproverController as approvals'
    			}
    		}
    	});
})
.controller('approvalsApproverController', function ($scope, $state, $stateParams, $q, config, paymentRequestManager, holidayCalendarManager, currencyManager, CountryManager, simpleModal) {
	var approvals = this;
	var today = new Date();
	
	// Watchers declaration
	/**
	 * Watch for changes in payer object
	 */ 
    $scope.$watch('approvals.payment.payer', function(newPayer, oldPayer) {
    	if(!_.isEqual(newPayer, oldPayer) && !_.isUndefined(newPayer)) {
    		// Validates if the bank currency is restricted or not
    		approvals.isRestrictedPayerCurrency = currencyManager.isRestrictedCurrency(newPayer.bankCurrency);
    		// Validates if the bank country is restricted or not
    		approvals.isRestrictedPayerCountry = CountryManager.isRestrictedCountry(newPayer.bankCountry);
    	}
    }, true);
    
    $scope.$watch('approvals.common.paymentDate', function(newValue) {
    	if (!_.isUndefined(approvals.common))
    		if (!_.isUndefined(approvals.common.paymentDate) && 
    				parseInt(approvals.common.paymentDate.getDate().toString()) >= parseInt(today.getDate().toString()))
    			approvals.paymentDateFlag = false;
    });
	
	// Public properties/functions
    angular.extend(approvals, {
    	isLoading: false,
    	paymentDateFlag: false,
    	getPayment: function() {
    		approvals.isLoading = true;
    		var paymentId = $stateParams.paymentId;
    		approvals.erpPaymentRequestType = $stateParams.erpPaymentRequest.trim();
    		
    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
    		promise.$promise.then(function(paymentRequest) {
    			var today = new Date();
    			approvals.payment = paymentRequest;
    			var paymentDate = paymentRequest.paymentDate;
    			var instrumentType = paymentRequest.instrumentType;
    			if(!_.isDate(paymentDate)) {
    				paymentDate = moment(paymentDate, 'YYYY-MM-DD HH:mm:ss').toDate();
    			}
    			approvals.common = {
    				paymentDate: paymentDate
    			};
    			if(_.isNull(approvals.payment.paymentAccounting)) {
    				approvals.payment.paymentAccounting = {};
    			}
    			approvals.payment.paymentAccounting.isGOFBooked = approvals.payment.isGofBooked;
    			approvals.payment.payerCurrency = approvals.payment.payeeCurrency;
    			if(_.isEqual(instrumentType,null)){
    				approvals.payment.instrumentType = '--';
    			}else{
    				approvals.payment.instrumentType = instrumentType;
    			}
    			
    			if(!_.isUndefined(approvals.payment.payer) && !_.isEmpty(approvals.payment.payer)){
    			approvals.payerFilters = {
    	    		mdmBusinessName: 		approvals.payment.mdmBusinessName,
    	    		mdmSubBusinessName:		approvals.payment.mdmSubBusinessName,
    	    		leName: {
    	    			mdm_id: 			approvals.payment.payer.mdmGoldId,
    	    			party_nm: 			approvals.payment.payer.mdmLEName
    	    		}
    	    	}
    			}
    			if (parseInt(approvals.common.paymentDate.getDate().toString()) < parseInt(today.getDate().toString()))
					approvals.paymentDateFlag = true;
				    			 
    			approvals.isLoading = false;
    		});
    	},
    	isApprovalStatus: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment) && _.isEqual(approvals.payment.paymentStatusCode, 'SUBMITTED')) {
    			flag = true;
    		}
    		return flag;
    	},
    	isRejectStatus: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment) && _.isEqual(approvals.payment.paymentStatusCode, 'REJECTED')) {
    			flag = true;
    		}
    		return flag;
    	},
    	createPayment: function() {
    		
    		var payment = angular.copy(approvals.payment);
			payment.rejectReason = approvals.common.rejectReason;
			payment.paymentDate = approvals.common.paymentDate;
			payment.requestStatusId = {
				comments: 		approvals.common.comments,
				rejectCancelReason: 	approvals.common.rejectReason
			};
			if(payment.payer) {
				payment.payer.isRestrictedCurrency = approvals.isRestrictedPayerCurrency;  
				payment.payer.isRestrictedCountry = approvals.isRestrictedPayerCountry;
			}
			
			return payment;
    	},
    	getCurrencies: function (currencyCode) {
            return currencyManager.getByCurrencyCode(currencyCode);
        },
        getHolidays: function (currency) {
            var holidays;
            if(!_.isUndefined(currency)) {
            	holidays = holidayCalendarManager.getHolidaysByCalendarName([currency.cal_nm]);
            }
        	return holidays;
        },
    	approve: function() {
    		approvals.isLoading = true;
    		if(approvals.payment.payer && approvals.payment.payer.bankCurrency && approvals.common.paymentDate) {
    			var currencies = approvals.getCurrencies(approvals.payment.mdmPayerCurrency);
    			var holidays = approvals.getHolidays(currencies);
                holidays.$promise.then(function(response) {
                    var spotDays,
                        holidayDates,
                        today = new Date();

                    holidayDates = holidayCalendarManager.parseDates(response.elements);
                    var isHoliday = _.find(holidayDates, function(holiday) {
                    	var momentPaymentDate = moment(approvals.common.paymentDate);
                    	var momentHoliday = moment(holiday);
                    	return momentPaymentDate.isSame(momentHoliday, 'day');
                    });
                    if(isHoliday) {
                    	approvals.isLoading = false;
                    	var modal = simpleModal.open({
                			title: 				'Error',
                			size: 				'lg',
                			allowClose: 		true,
                			allowDismiss:		false,
                			closeText:			'Close',
                			bodyHTML: 			'<p>Please select a non holiday payment date.</p>'
                		});
                    } else {
                    	var modal = simpleModal.open({
                			title: 				'Approve #' + approvals.payment.requestId,
                			size: 				'lg',
                			allowClose: 		true,
                			allowDismiss:		false,
                			closeText:			'Approve',
                			bodyHTML: 			'<p>The verbiage may change slightly depending on final policy.</p>'
                		});
                		modal.closed.then(function(result) {
                			var payment = approvals.createPayment();
                			var promise = paymentRequestManager.approvePaymentRequest(payment);
                			promise.$promise.then(function(result) {
                				approvals.isLoading = false;
                				history.back();
                			});
                			approvals.isLoading = false;
                		});
                    }
                });
    		} else {
    			var modal = simpleModal.open({
        			title: 				'Approve #' + approvals.payment.requestId,
        			size: 				'lg',
        			allowClose: 		true,
        			allowDismiss:		false,
        			closeText:			'Approve',
        			bodyHTML: 			'<p>The verbiage may change slightly depending on final policy.</p>'
        		});
        		modal.closed.then(function(result) {
        			var payment = approvals.createPayment();
        			var promise = paymentRequestManager.approvePaymentRequest(payment);
        			promise.$promise.then(function(result) {
        				approvals.isLoading = false;
        				history.back();
        			});
        		});
    		}
    	},
    	isAbleToApprove: function() {
    		var flag = true;
    		
    		if(_.isNull(approvals.payment.payeeReasonManualEntry)) {
    			flag = false;
    		}
    		
    		if(approvals.isCrossCurrency() && _.isEmpty(approvals.payment.trsEntityName)) {
    			flag = false;
    		}
    		
    		if(!_.isNull(approvals.payment.payeeReasonManualEntry)
    			&& (_.isEqual(approvals.payment.payeeReasonManualEntry, 'REASON_ERP_NOT_TRUSTED') && _.isEmpty(approvals.payment.erpName))) {
    			flag = false;
    		}
    		
    		if(!_.isNull(approvals.payment.payeeReasonManualEntry)
        		&& ((_.isEqual(approvals.payment.payeeReasonManualEntry, 'REASON_ES_FAILURE') || _.isEqual(approvals.payment.payeeReasonManualEntry, 'REASON_ES_NO_PAYEE')) && _.isEmpty(approvals.payment.esSystemName))) {
        		flag = false;
        	}
    		
    		if(_.isUndefined(approvals.payment)
    			|| (_.isUndefined(approvals.payment.payer) || _.isEmpty(approvals.payment.payer))
    			|| _.isUndefined(approvals.common.paymentDate)) {
    				flag = false;
    		}
    		if (approvals.paymentDateFlag) {
    			flag = false;
    		}
    			
			
    		return flag;
    	},
    	reject: function() {
    		approvals.isLoading = true;
    		var payment = approvals.createPayment();
    		var promise = paymentRequestManager.rejectPaymentRequest(payment);
			promise.$promise.then(function(result) {
				approvals.isLoading = false;
				history.back();
			});
    	},
    	isAbleToReject: function() {
    		var flag = false;
    		if(!_.isUndefined(approvals.payment)
    				&& !_.isUndefined(approvals.common.comments)
    				&& !_.isEmpty(approvals.common.comments)
    				&& !_.isUndefined(approvals.common.rejectReason)) {
    			flag = true;
    		}
    		return flag;
    	},
    	back: function() {
    		history.back();
    	},
    	cancel: function() {
    		$state.go('pages.approvalsApproverCancel', {
        		paymentId: approvals.payment.requestId,
        		erpPaymentRequest:approvals.erpPaymentRequestType
        	});
    	},
    	edit: function() {
    		if(_.isEqual(approvals.erpPaymentRequestType, 'true')) {
    			$state.go('pages.createERPPayment', {
            		paymentId: 			approvals.payment.requestId
            	});
    		} else {
    			$state.go('pages.createPayment', {
            		paymentId: 			approvals.payment.requestId
            	});
    		}
    	},
    	goToPrepare: function() {
    		$state.go('pages.approvalsPreparer', {
        		paymentId: approvals.payment.requestId,
        		erpPaymentRequest:approvals.erpPaymentRequestType
        	});
    	},
    	isCrossCurrency: function() {
        	var flag = false;
        	if(!_.isUndefined(approvals.payment) && !_.isUndefined(approvals.payment.payer) && !_.isEqual(approvals.payment.payeeCurrency, approvals.payment.payer.bankCurrency)) {
        		flag = true;
        	}
        	return flag;
        },
    	watchers: function() {
    		$scope.$watch('approvals.payment.payeeReasonManualEntry', function(newValue, oldValue) {
    			if(!_.isEqual(newValue, oldValue)) {
    				approvals.payment.erpName = undefined;
    				approvals.payment.esSystemName = undefined;
    			}
    		});
    	}
    });
    
    // Initialization of watchers
    approvals.watchers();
    // Obtain the payment
    approvals.getPayment();
});