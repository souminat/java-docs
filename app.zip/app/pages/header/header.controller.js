angular.module('app.pages.header.controller', [
'ui.bootstrap',
'app.config',
'app.messages',
'app.services',
'app.pages.about.controller'
])

.controller('headerController', function ($q, $state, $uibModal, config, messages, userManager) {
	var header = this;

	//header.currentUser = currentUser;
	
	header.dropShown = false;
	header.searchTerm = '';
	
	header.toggleDrop = function() {
		header.dropShown = !header.dropShown;
	}
	header.toggleMenu = function() {
		config.mobileMenuShown = !config.mobileMenuShown;
	}
	
	header.showAbout = function() {
		$uibModal.open({
			templateUrl: config.templateBasePath + 'app/pages/about/about.controller.html',
			controller: 'aboutController as about'
		});
	};
	
	// Initialization of user 
	header.initUser = function() {
		var defer = $q.defer();
		
		var ssoPromise = userManager.get();
		
		ssoPromise.$promise.then(function(result) {
			var sso = result.sso;
			
			var userPromise = userManager.get(sso);
			userPromise.$promise.then(function(result) {
				var user = result.data[0];
				
				// Set the current user to be displayed in header
				header.currentUser = user;
				
				defer.resolve(user);
			});
			
		});
		
		return defer.promise;
	}
	
	// Initialization method
	header.init = function() {
		// Initialization of user
		header.initUser();
	};
	
	// Initialization method that runs when controller loads
	header.init();
});
