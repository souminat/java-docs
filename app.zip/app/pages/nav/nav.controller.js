angular.module('app.pages.nav.controller',[
	'app.services'
])
.controller('navController', function ($scope, currentUser, config, userManager) {
	var nav = this;
	
	if(window.location.hostname.indexOf('-dev')>-1){
	nav.userRoleFromService = '';
	
	nav.init = function(){
		var ssoPromise = userManager.get();
		ssoPromise.$promise.then(function(result) {
			nav.userRoleFromService = result.appRole;
		});
	}
	
	nav.isApprover = function (){
		if(_.isEqual(nav.userRoleFromService.toUpperCase() , 'ROLE_Payment Approver'.toUpperCase())){
			return true;
		}
	}
	
	nav.ERPBatchUser = function() {
		if(_.isEqual(nav.userRoleFromService.toUpperCase() , 'ROLE_ERP Manual Payment File Requester'.toUpperCase())){
			return true;
		}
	}
	
	nav.isReleaser = function(){
		if(_.isEqual(nav.userRoleFromService.toUpperCase() , 'ROLE_Global Treasury Releaser'.toUpperCase()) 
			|| _.isEqual(nav.userRoleFromService.toUpperCase() , 'ROLE_GoT Assigner'.toUpperCase())){
			return true;
		}
	}
	
	nav.isPreparer= function(){
		if(_.isEqual(nav.userRoleFromService.toUpperCase() , 'ROLE_Global Treasury Preparer'.toUpperCase()) 
			|| _.isEqual(nav.userRoleFromService.toUpperCase() , 'ROLE_GoT Assigner'.toUpperCase())){
			return true;
		}
	}
	
	nav.init();
	}else{
		nav.isApprover = function (){
				return true;
		}
		
		nav.ERPBatchUser = function() {
				return true;
		}
		
		nav.isReleaser = function(){
				return true;
		}
		
		nav.isPreparer= function(){
				return true;
		}
	}
});