angular.module('app.pages',[
	'ui.router',
	'app.config',
	'app.services.currentUser',
	'app.pages.home.controller',
	'app.pages.header.controller',
	'app.pages.nav.controller',
	'app.pages.accountForm.controller',
	'app.pages.paymentForm.controller',
	'app.pages.upload.controller',
	'app.pages.requestInbox.controller',
	'app.pages.preparerdashboard.controller',
	'app.pages.releaserdashboard.controller',
	'app.pages.paymentsList.controller',
	'app.pages.approvals.approver.controller',
	'app.pages.approvals.approver.cancel.controller',
	'app.pages.approvals.preparer.controller',
	'app.pages.approvals.releaser.controller',
	'app.pages.approvals.confirmation.controller',
	'app.pages.approvals.confirmReadOnly.controller',
	'app.pages.myApprovalDashboard.controller'
])

.config(function ($stateProvider, configProvider) {
		$stateProvider.state('pages', {
		abstract: true,
		url: "",
		 resolve: {
			 currentUserMePromise: function(currentUser) {
				return currentUser.me.$promise; 
		 	}
		},
		views: {
			'': {
				templateUrl: configProvider.templateBasePath + 'app/pages/pages.layout.html',
				controller: 'layoutController as layout'
			},
			/* important note: load the pages template then x@pages will be found inside that template  */
			'header@pages': {
				templateUrl: configProvider.templateBasePath + 'app/pages/header/header.controller.html',
				controller: 'headerController as header'
			},
			'nav@pages': {
				templateUrl: configProvider.templateBasePath + 'app/pages/nav/nav.controller.html',
				controller: 'navController as nav'
			}
		}
	});
})
.controller('layoutController', function ($scope, config) {
	var layout = this;
	
	layout.config = config;

});
