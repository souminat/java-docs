angular.module('app.pages.about.controller',[
	'app.services'
])
.controller('aboutController', function ($uibModalInstance, aboutManager) {
	var controller = this;
	controller.content = aboutManager.get();

	controller.close = function() {
		$uibModalInstance.close();
	};

});