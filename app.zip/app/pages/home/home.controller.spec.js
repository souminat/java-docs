describe("app.pages.home.controller.spec", function() {

	var $httpBackend, $controller, config;

	var fakeModalInstance = {
		close: function() {}
	};
	var defaultHomePage = 'mypayments/payments';

	beforeEach(module('ui.router'));
	beforeEach(module('app.pages.home.controller'));
	beforeEach(module('app.pages.paymentsList.controller'));
	beforeEach(module('app.config'));
	beforeEach(module('app.services.user.mock'));
	beforeEach(module('app.services.currentUser'));

	beforeEach(module(function($provide) {
		$provide.service('app.services.currentUser', function() {
			this.homePage = jasmine.createSpy('homePage').andCallFake(function() {
				return defaultHomePage
			});
		});
	}));

	beforeEach(inject(function($injector){
		$httpBackend = $injector.get('$httpBackend');
		$controller = $injector.get('$controller');
		$state = $injector.get('$state');
		config = $injector.get('config');
	}));

	it('redirects to the currentUser\'s homePage', function() {
		spyOn($state, 'go');

		// $httpBackend.expect('GET', config.apiBasePath + 'api/fx/v1/appInfo');
		$controller('homeController');
		$httpBackend.flush();

		expect($state.go).toHaveBeenCalledWith('pages.payments');
		// $httpBackend.verifyNoOutstandingRequest();

	});

});
