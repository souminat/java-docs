angular.module('app.pages.paymentForm.controller', [
	'ct.datepickerPopup',
	'ui.router',
    'app.config',
    'ux.form.simpleModal',
    'ux.form.simpleModal',
    'ux.util.numeralFilter',
    'app.messages',
    'app.services',
    'app.directives'
])
	.config(function ($stateProvider, configProvider) {
		$stateProvider.state('pages.createPayment', {
			url: "/payments/create",
			params: {
				paymentId: null,
				editRequestGroup: null
			},
			data: {
				requestTypeCode: 'PAYREQTYPE_INDIVID'
			},
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/requestForms/paymentForm.controller.html',
					controller: 'paymentFormController as paymentForm'
				}
			}
		});
    })
    .controller('paymentFormController', function ($scope, $state, $stateParams, $q, config, requestGroupManager, currencyManager, holidayCalendarManager, simpleModal, paymentRequestManager, userManager, simpleModal, messages, enterpriseStandardsManager, businessNamesManager, bankAccountManager, CountryManager) {
        var paymentForm = this,
            isPaymentDateLoading = false,
            paymentDateOptions = {},
            currencies = [],
            getCurrencies,
            getHolidays,
            currencyChange,
            //loadStaticUrl,
            saveRequestGroup;
        	paymentForm.isCheckPayment = '';
        
        paymentForm.paymentZero = {};
        paymentForm.spotRate = {};
        
        paymentForm.trsUrl = '';
        
        //If is Edit flow
        if ($state.params.editRequestGroup) {
            paymentForm.requestGroup = $state.params.editRequestGroup;
        } else if ($state.current.data.requestTypeCode) {
            paymentForm.requestGroup = requestGroupManager.newRequestGroup($state.current.data.requestTypeCode);
        } else {
            $state.go('pages.home');
            return;
        }

        //
        //== WATCH EXPRESSIONS
        //
        // Watch for changes in payment object
        $scope.$watch('paymentForm.payment', function(newPayment, oldPayment) {
        	if(!_.isEqual(newPayment, oldPayment) && !_.isUndefined(newPayment)) {
        		$scope.$broadcast('sendPaymentBroadcast', newPayment);
        	}
        });
        // Watch for changes in payee object
        $scope.$watch('paymentForm.paymentZero.payee', function(newPayee, oldPayee) {
        	if(!_.isEqual(newPayee, oldPayee) && !_.isUndefined(newPayee)) {
        		$scope.$broadcast('sendPayeeBroadcast', newPayee);
        		// Validates if the bank currency is restricted or not
        		paymentForm.isRestrictedPayeeCurrency = currencyManager.isRestrictedCurrency(newPayee.bankCurrency);
        		// Validates if the bank country is restricted or not
        		paymentForm.isRestrictedPayeeCountry = CountryManager.isRestrictedCountry(newPayee.bankCountry);
        	}
        }, true);
        // Watch for changes in payer object
        $scope.$watch('paymentForm.paymentZero.payer', function(newPayer, oldPayer) {
        	if(!_.isEqual(newPayer, oldPayer) && !_.isUndefined(newPayer)) {
        		$scope.$broadcast('sendPayerBroadcast', newPayer);
        		// Validates if the bank currency is restricted or not
        		paymentForm.isRestrictedPayerCurrency = currencyManager.isRestrictedCurrency(newPayer.bankCurrency);
        		// Validates if the bank country is restricted or not
        		paymentForm.isRestrictedPayerCountry = CountryManager.isRestrictedCountry(newPayer.bankCountry);
        	}
        }, true);
        // Watch for changes in Manual Payment Reason select to clean the ERP and System values after user change the selector
        $scope.$watch('paymentForm.paymentZero.esCd', function(newValue, oldValue) {
        	if(!_.isEqual(newValue, oldValue)) {
        		if(newValue) {
        			var promise = enterpriseStandardsManager.getPaymentTypes(newValue);
        			promise.$promise.then(function(result) {
        				var sortedPaymentTypeList = _.sortBy(result, function(obj) {
            				return obj.paymentTypeDescription;
            			});
        				paymentForm.paymentTypes = sortedPaymentTypeList;
        			});
        		}
        	}
        });
        // Watch for changes in Business select to display the options on Sub-Business select
        $scope.$watch('paymentForm.payerFilters.mdmBusinessName', function(newValue, oldValue) {
        	if(!_.isEqual(newValue, oldValue)) {
        		var promise = businessNamesManager.all();
        		promise.$promise.then(function(result) {
        			var filteredList = _.filter(result.elements, function(element) {
        				return _.isEqual(element.bus_acct_grp, newValue);
        			});
        			filteredList = _.sortBy(filteredList, function(subbusiness) {
        				return subbusiness.sub_bus_acct_grp;
        			});
        			paymentForm.subBusiness = filteredList;
        		});
        	}
        });
        
        //
        //==PRIVATE METHODS
        //

        /**
         * Initialization of user
         */ 
    	initUser = function() {
    		var defer = $q.defer();
    		
    		var ssoPromise = userManager.get();
    		
    		ssoPromise.$promise.then(function(result) {
    			
    			// Set the current session
    			paymentForm.currentSession = result;
    			
    			var userPromise = userManager.get(result.sso);
    			userPromise.$promise.then(function(result) {
    				var user = result.data[0];
    				
    				// Set the current user 
    				paymentForm.currentUser = user;
    				
    				defer.resolve(user);
    			});
    		});
    		
    		return defer.promise;
    	}
        
    	// Initialization of user data
    	initUser();
    	
    	/**
    	 * Initialize the enterprise standards selector
    	 */
    	initEnterpriseStandards = function() {
    		var promise = enterpriseStandardsManager.all();
    		promise.$promise.then(function(result) {
    			paymentForm.enterpriseStandards = result;
    		});
    	};
    	
    	// Initialization of enterprise standards selector
    	initEnterpriseStandards();
    	
    	/**
    	 * Initialize the business selector
    	 */
    	initBusinessNames = function() {
    		var promise = businessNamesManager.all();
    		promise.$promise.then(function(result) {
    			var groupedList = _.sortBy(result.elements, function(obj) {
    				return obj.bus_acct_grp;
    			});
    			groupedList =  _.groupBy(groupedList, function(element) {
    				return element.bus_acct_grp;
    			});
    			paymentForm.business = groupedList;
    		});
    	};
    	
    	// Initialize the business selector
    	initBusinessNames();
    	
        /**
         * @param direction
         * @param value
         */
        currencyChange = function (direction, value) {
            paymentForm.paymentZero[direction + 'Currency'] = (_.has(value, 'currencyCode'))
                ? value.currencyCode
                : null;
        };

        /**
         * Get an array of Currency objects, based on any number of currency codes
         *
         * @param {Array} currencyCodes
         * @returns {Array}
         */
        getCurrencies = function (currencyCodes) {
            return _.map(currencyCodes, function(currencyCode) {
                return currencyManager.getByCurrencyCode(currencyCode);
            });
        };

        /**
         * Get a Promise that will resolve to an array of Holiday elements, based on any number of Currency objects
         *
         * @param {Array} currencies - array of currency objects
         * @returns {Promise}
         */
        getHolidays = function (currencies) {
            return holidayCalendarManager.getHolidaysByCalendarName(_.map(currencies, function(currency) {
                return currency.CAL_NM;
            }));
        };
        
        /**
         * Validates that payer exists if internal payment is selected
         */
        validatePayer = function() {
        	var flag = true;
        	
        	if(_.isEqual(paymentForm.paymentZero.payeeIdType, 'INTERNAL') && _.isEmpty(paymentForm.paymentZero.payer)) {
        		flag = false;
        	}
        	
        	return flag;
        }
        
        /**
         * @param {string} action
         * @returns {Promise}
         */
        saveRequestGroup = function (action) {
            var typeAction = (paymentForm.requestGroup.requestGrpId) ? 'update' : 'insert';
            if(!validatePayer()) {
            	simpleModal.open({
					title:'Error', 
					body: messages.validation.emptyPayer
				});
            } else {
            	if (paymentForm.form.$valid) {
                    paymentForm.clearErrors();

                    paymentForm.paymentZero.mdmBusinessName = paymentForm.payerFilters.mdmBusinessName;
                    paymentForm.paymentZero.mdmSubBusinessName = paymentForm.payerFilters.mdmSubBusinessName;
                    paymentForm.paymentZero.requestTypeCode = 'MANUAL_PAYMENT';
                    paymentForm.paymentZero.payeeCurrency = paymentForm.payment.payerCurrency;
                    paymentForm.paymentZero.payerAmount = paymentForm.payment.payeeAmount;
                    paymentForm.paymentZero.invoiceNumber = paymentForm.payment.invoiceNumber;
                    paymentForm.paymentZero.isGofBooked = paymentForm.paymentZero.paymentAccounting.isGOFBooked;
                    paymentForm.paymentZero.mdmSpotRate = 1;
                    paymentForm.paymentZero.requestActivities = [{
                    	userBusiness:		paymentForm.paymentZero.mdmBusinessName,
                    	userSubBusiness:	paymentForm.paymentZero.mdmSubBusinessName,
                    	comments:			paymentForm.comments
                    }];
                    if(!_.isEmpty(paymentForm.paymentZero.payee)) {
                    	paymentForm.paymentZero.payee.payerOrPayee = 'PAYEE';
                    	paymentForm.paymentZero.payeeSource = paymentForm.paymentZero.payee.payerPayeeSrcId;
                    	if(paymentForm.paymentZero.payee.payeeReasonManualEntry) {
                        	paymentForm.paymentZero.payeeReasonManualEntry = paymentForm.paymentZero.payee.payeeReasonManualEntry;
                        	paymentForm.paymentZero.isHighRiskPayee = paymentForm.paymentZero.payee.highRiskItem;
                        	paymentForm.paymentZero.highRiskNumber = paymentForm.paymentZero.payee.highRiskNumber;
                        }
                    	if(_.isUndefined(paymentForm.paymentZero.payeeSource)) {
                    		paymentForm.paymentZero.payeeSource = 'MANUAL';
                    	}else{
                    		if(_.isEqual(paymentForm.paymentZero.payeeIdType, 'INTERNAL')){
                    			paymentForm.paymentZero.payeeSource = 'INTERNAL';
                    		}
                    	}
                    } 
                    if(!_.isEmpty(paymentForm.paymentZero.payer)) {
                    	paymentForm.paymentZero.payer.payerOrPayee = 'PAYER';
                    	if(paymentForm.paymentZero.payer.bankCurrency) {
                    		paymentForm.paymentZero.mdmPayerCurrency = paymentForm.paymentZero.payer.bankCurrency;
                    	}
                    	paymentForm.paymentZero.tCodeServiceCenter = paymentForm.paymentZero.payer.serviceCenter;
                    }
                    if(!_.isEmpty(paymentForm.spotRate)) {
                    	paymentForm.paymentZero.payeeAmount = paymentForm.spotRate.payeeAmount;
                    	paymentForm.paymentZero.mdmSpotRate = paymentForm.spotRate.spotRate;
                    } else {
                    	paymentForm.paymentZero.payeeAmount = paymentForm.payment.payeeAmount;
                    }
                    // Change the invoice date format from TZ to YYYY-MM-DD as requested by service
                    if(paymentForm.payment.invoiceDate) {
                    	paymentForm.paymentZero.invoiceDate = moment(paymentForm.payment.invoiceDate).format('YYYY-MM-DD');
                    }
                    // Change the payment date format from TZ to YYYY-MM-DD as requested by service
                    if(paymentForm.payment.paymentDate) {
                    	paymentForm.paymentZero.paymentDate = moment(paymentForm.payment.paymentDate).format('YYYY-MM-DD');
                    }
                    
                    // Add payee restristed country and currencies
                    if(paymentForm.paymentZero.payee) {
                    	paymentForm.paymentZero.payee.isRestrictedCurrency = paymentForm.isRestrictedPayeeCurrency;
                        paymentForm.paymentZero.payee.isRestrictedCountry = paymentForm.isRestrictedPayeeCountry;
                    }
                    
                    // Add payer restristed country and currencies
                    if(paymentForm.paymentZero.payer) {
                    	paymentForm.paymentZero.payer.isRestrictedCurrency = paymentForm.isRestrictedPayerCurrency;
                        paymentForm.paymentZero.payer.isRestrictedCountry = paymentForm.isRestrictedPayerCountry;
                    }
                    
                    // TODO: Remove this properties, /getSearchMDMBankAccounts needs to fetch these data instead
                    paymentForm.paymentZero.mdmMorRate = '1';
                    paymentForm.paymentZero.isManual = 'true';
                    paymentForm.paymentZero.isCheckPayment = paymentForm.isCheckPayment;
                    
                    var rg = angular.copy(paymentForm.requestGroup);
                    rg.payments[0] = paymentForm.paymentZero;

                    switch (action) {
                        case 'submit':
                            rg.requestGrpStatusCode = 'PAYREQSTAT_PENDAPPROV';
                            if (typeAction === 'insert') {
                            	
                            	return paymentRequestManager.createPaymentRequest(rg.payments[0]);
                            } else {
                                // TODO implement update methods
                                // rg = requestGroupManager.getRequestGroupCleaned(rg);
                                // return requestGroupManager.updatePayment(rg);
                            }
                            break;

                        case 'draft':
                        break;
                    }
                }
            }
            paymentForm.form.$submitted = true;
            $scope.$digest();
        };
        
        $scope.$on('spotRateEmit', function(event, spotRate) {
        	paymentForm.spotRate = spotRate;
        });
        
        //
        //==PUBLIC PROPERTIES/METHODS
        //
        angular.extend(paymentForm, {
            paymentZero: angular.copy(paymentForm.requestGroup.payments[0]),
            getPayment: function() {
				paymentForm.isLoading = true;
	    		var paymentId = $stateParams.paymentId;
	    		
	    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
	    		promise.$promise.then(function(paymentRequest) {
	    			paymentForm.paymentZero = paymentRequest;
	    			
	    			paymentForm.payment = {
	    				payerCurrency: 			paymentForm.paymentZero.payeeCurrency,
	    				payeeAmount:			paymentForm.paymentZero.payerAmount,
	    				invoiceNumber:			paymentForm.paymentZero.invoiceNumber,
	    				invoiceDate:			moment(paymentForm.paymentZero.invoiceDate, 'YYYY-MM-DD HH:mm:ss').toDate(),
	    				paymentDate:			moment(paymentForm.paymentZero.paymentDate, 'YYYY-MM-DD HH:mm:ss').toDate(),
	    				isGofBooked:			paymentForm.paymentZero.isGofBooked
	    			};
	    			
	    			if(!_.isDate(paymentForm.paymentZero.paymentDate)) {
	    				paymentForm.paymentZero.paymentDate = moment(paymentForm.paymentZero.paymentDate, 'YYYY-MM-DD HH:mm:ss').toDate();
	    			}
	    			
	    			if(!_.isDate(paymentForm.paymentZero.invoiceDate)) {
	    				paymentForm.paymentZero.invoiceDate = moment(paymentForm.paymentZero.invoiceDate, 'YYYY-MM-DD HH:mm:ss').toDate();
	    			}
	    			
	    			if(paymentForm.paymentZero.payeeAmount && paymentForm.paymentZero.mdmSpotRate) {
	    				paymentForm.spotRate = {
	    					payeeAmount:		paymentForm.paymentZero.payeeAmount,
	    					spotRate:			paymentForm.paymentZero.mdmSpotRate
	    				};
	    			}
	    			
	    			paymentForm.payerFilters = {
		    	    	mdmBusinessName: 		paymentForm.paymentZero.mdmBusinessName,
		    	    	mdmSubBusinessName:		paymentForm.paymentZero.mdmSubBusinessName
	    			};
	    			
	    			if(_.isEqual(paymentForm.paymentZero.payeeSource, 'MDM')) {
	    				paymentForm.paymentZero.payeeIdType = 'INTERNAL';
	    			} else {
	    				paymentForm.paymentZero.payeeIdType = 'MANUAL';
	    			}
	    			
	    			if(!_.isUndefined(paymentForm.paymentZero.payer) && !_.isEmpty(paymentForm.paymentZero.payer)) {
	    				var criteria = {
    	                    goldLeName: encodeURI(paymentForm.paymentZero.payer.mdmGoldId),
    	            		goldId: encodeURI(paymentForm.paymentZero.payer.mdmGoldId)
    	            	};
    	            	var promise = bankAccountManager.getGoldLeNames(criteria);
    	            	promise.$promise.then(function(result) {
    	            		var leName = _.find(result.elements, function(element) {
    	            			return _.isEqual(element.mdm_id, paymentForm.paymentZero.payer.mdmGoldId);
    	            		});
    	            		paymentForm.payerFilters.leName = leName;
    	            	});
	    			}
	    			
	    			paymentForm.isLoading = false;
	    		});
	    	},
            isPayerEnabled: function() {
            	var flag = false;
            	
            	if(paymentForm.payerFilters 
            			&& paymentForm.payerFilters.mdmBusinessName 
            			&& paymentForm.payerFilters.mdmSubBusinessName 
            			&& _.isObject(paymentForm.payerFilters.leName)) {
            		flag = true;
            	}
            	
            	return flag;
            },
            /**
             * Get legal entity names and gold id for le name selector
             */
            getLeNames: function(text) {
            	var defer = $q.defer();
            	
            	var criteria = {
                    goldLeName: encodeURI(text),
            		goldId: encodeURI(text)
            	};
            	var promise = bankAccountManager.getGoldLeNames(criteria);
            	promise.$promise.then(function(result) {
            		paymentForm.leNames = result.elements;
            		defer.resolve(result.elements);
            	});
            	
            	return defer.promise;
            },
            /**
             * Displays the manual entry reasons extra fields like erpName or ES System 
             */
            isManualEntryReason: function(reason) {
            	var flag = false;
            	if(_.isEqual(paymentForm.paymentZero.paymentReason, reason)) {
            		flag = true;
            	}
            	return flag;
            },
            /**
             * Validates that payer or payee is selected by user 
             */
            isPayeePayerSelected: function(payeePayer) {
            	var flag =  true;
            	
            	if(_.isEmpty(payeePayer)) {
            		flag = false;
            	}
            	
            	return flag;
            },
            /**
             * TODO
             */
            goRequestGroup: function() {
                // $state.go('pages.requests.details', {requestGroupId:requestForms.requestGroup.requestGrpId, action: 'draft'});
            },

            /**
             * @returns {boolean}
             */
            isAbleToSubmit: function () {
            	var paymentTypeFlag = false;
            	if(paymentForm.paymentZero.payeeIdType =='MANUAL'){
            		if(!_.isEmpty(paymentForm.isCheckPayment)){
            			paymentTypeFlag = true;
            		}
            	}else{
            		paymentTypeFlag = true;
            	}
            	
            	if(paymentForm.form.$valid
        				&& paymentForm.payment
        				&& !_.isEmpty(paymentForm.paymentZero.documents)
        				&& paymentTypeFlag){
            		
        			return true;
        		}else{
        			return false;
        		}
            },

            /**
             * @returns {boolean}
             */
            readyForQuickSummary: function () {
            	return !_.isEmpty(paymentForm.paymentZero.payer) 
            		&& !_.isEmpty(paymentForm.paymentZero.payee)
            		&& !_.isEmpty(paymentForm.paymentZero.payer.bankCurrency) 
            		&& !_.isEmpty(paymentForm.paymentZero.payee.bankCurrency)
            		&& _.isEqual(paymentForm.paymentZero.payeeIdType, 'INTERNAL')
            		&& paymentForm.payment;
            },

            /**
             * @returns {boolean}
             */
            paymentDateDisabled: function () {
                return (
                    paymentForm.paymentDateLoading() ||
                    !(paymentForm.paymentZero.payerCurrency && paymentForm.paymentZero.payeeCurrency)
                );
            },

            /**
             * @returns {boolean}
             */
            paymentDateLoading: function () {
                return !!isPaymentDateLoading;
            },

            /**
             * @returns {*}
             */
            paymentDateOptions: function () {
                return paymentDateOptions;
            },

            /**
             * Submit button
             */
            submit: function () {
                return saveRequestGroup('submit');
            },

            /**
             * Cancel button
             */
            cancel: function() {
            	$state.go('pages.payments');
            },
            /**
             * TODO
             * @param errors
             */
            handleServerErrors: function(errors) {
                var errorJSON;
                var unknownErrors = '';

                try {
                    errorJSON = JSON.parse(errors.data);
                }
                catch(err) {
                    unknownErrors = errors.data;
                }

                if(unknownErrors !== '') {
                    simpleModal.open({bodyHTML:unknownErrors});
                }
                else 
                	{
                	simpleModal.open({
						title: errorJSON.errorCode, 
						body: errorJSON.errorMessage
					});
                	}

                $('.ng-invalid').focus();
            },

            /**
             * Clear all server error messages
             */
            clearErrors: function () {
                var thisForm = paymentForm.form;
                angular.forEach(thisForm, function (value, key) {
                    if (typeof value === 'object' && value.hasOwnProperty('$modelValue'))
                        value.$error['server'] = '';
                });
            },
            
            /**
             * Display the payee id section depending of the selected payee id type  
             */
            isPayeeId: function(value) {
            	var flag = false;
            	
            	if(_.isEqual(paymentForm.paymentZero.payeeIdType, value)) {
            		flag = true;
            	}
            	
            	return flag;
            },
            isCrossCurrency: function() {
            	var flag = false;
            	if(!_.isUndefined(paymentForm.payment) && !_.isUndefined(paymentForm.paymentZero.payer) && !_.isEqual(paymentForm.payment.payerCurrency, paymentForm.paymentZero.payer.bankCurrency)) {
            		flag = true;
            	}
            	return flag;
            }
        });
        
        /*
		 * Initialize the payment request
		 */ 
		initPayment = function() {
			if($stateParams.paymentId) {
				paymentForm.getPayment();
				paymentForm.isResubmit = true;
			} else {
				paymentForm.isResubmit = true;
			}
			this.loadStaticUrl();
		};
		
		loadStaticUrl = function() {
			var promise = paymentRequestManager.getStaticUrls();
			promise.$promise.then(function(result) {
				paymentForm.trsUrl = result.trsUrl;
			});
    	},
		
		// Initialize the payment request
		initPayment();
    });