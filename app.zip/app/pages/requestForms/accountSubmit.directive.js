angular.module('app.pages.accountForm.accountSubmit.directive', [
	'ct.loadingButton'
])
    .directive('mypaymentsErpPaymentSubmit', function () {
        return {
            restrict: 'A',
            require: ['ctLoadingButton', 'mypaymentsErpPaymentSubmit'],
            scope: {
                'mypaymentsErpPaymentSubmit': '@',
                'pageController': '='
            },

            bindToController: true,
            controllerAs: 'paymentSubmit',

            controller: function ($state) {
                var paymentSubmit = this,
                    paymentForm = paymentSubmit.pageController,
                    setLoading;
                angular.extend(paymentSubmit, {
                    setLoadingMethod: function (cb) {
                        setLoading = cb;
                    },

                    submit: function () {
                        if (angular.isFunction(paymentSubmit[paymentSubmit.mypaymentsErpPaymentSubmit])) {
                            setLoading(true);
                            paymentSubmit[paymentSubmit.mypaymentsErpPaymentSubmit]();
                        }
                    },

                    save: function () {
                        var response = paymentForm.submit();
                        if (response) {
                            response.$promise.then(function () {
                                // TODO implement approver list...
                                // var deferred = $q.defer();
                                // paymentForm.approverList = requestGroupManager.getApproverList(response.requestGrpId, response.trades[0].umbrellaName);
                                // paymentForm.approverList.$promise.then(function () {
                                //     paymentForm.sendApproverEmail(response.requestGrpId, action);
                                //
                                //     deferred.resolve(paymentForm.approverList);
                                // });

                                setLoading(false);
                                console.log('Successfully submitted payment!');
                                $state.go('pages.payments');
                            }, function (errors) {
                                paymentForm.handleServerErrors(errors);
                                setLoading(false);
                            });
                        } else {
                            setLoading(false);
                        }
                    },

                    saveDraft: function () {
                        var response = paymentForm.submitDraft();
                        if (response) {
                            response.$promise.then(function () {
                                $state.go('pages.requests.details', {requestGroupId: response.requestGrpId, action: action});
                            }, paymentSubmit.handleError);
                        } else {
                            setLoading(false);
                        }
                    },

                    handleError: function (errors) {
                        paymentForm.handleServerErrors(errors);
                        setLoading(false);
                    }
                });
            },

            link: function (scope, element, attrs, ctrls) {
                ctrls[1].setLoadingMethod(ctrls[0].setLoading);
                element.on('click', ctrls[1].submit);
            }
        };
    });