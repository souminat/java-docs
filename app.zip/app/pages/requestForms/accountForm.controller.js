angular.module('app.pages.accountForm.controller', [
	'ct.datepickerPopup',
	'ui.router',
	'ux.form.simpleModal',
	'ux.util.numeralFilter',
    'app.config',
    'app.services',
    'app.directives'
])

.config(function ($stateProvider, configProvider) {
	$stateProvider
		.state('pages.createERPPayment', {
			url: "/payments/createERP",
			params: {
				paymentId: null,
				editRequestGroup: null
			},
			data: {
				requestTypeCode: 'PAYREQTYPE_INDIVID',
			},
			views: {
				'content': {
					templateUrl: configProvider.templateBasePath + 'app/pages/requestForms/accountForm.controller.html',
					controller: 'accountFormController as accountForm'
				}
			}
		});
	})
	.controller('accountFormController', function ($scope, $state, $stateParams, $q, config, requestGroupManager, currencyManager, CountryManager, holidayCalendarManager, simpleModal, paymentRequestManager, userManager, simpleModal, messages, enterpriseStandardsManager, businessNamesManager, bankAccountManager) {
		var accountForm = this,
		isPaymentDateLoading = false,
		paymentDateOptions = {},
		currencies = [],
		getCurrencies,
		getHolidays,
		currencyChange,
		saveRequestGroup;

		accountForm.paymentZero = {};
		accountForm.spotRate = {};

		// If is Edit flow
		if ($state.params.editRequestGroup) {
			accountForm.requestGroup = $state.params.editRequestGroup;
		} else if ($state.current.data.requestTypeCode) {
			accountForm.requestGroup = requestGroupManager.newRequestGroup($state.current.data.requestTypeCode);
		} else {
			$state.go('pages.home');
			return;
		}
		
		/**
		 * @param {string} action
		 * @returns {Promise}
		 */
		saveRequestGroup = function (action) {
			var typeAction = /*(accountForm.requestGroup.requestGrpId) ? 'update' :*/ 'insert';
			
			if (accountForm.form.$valid) {
				accountForm.clearErrors();
				accountForm.paymentZero.mdmBusinessName = accountForm.payerFilters.mdmBusinessName;
				accountForm.paymentZero.mdmSubBusinessName = accountForm.payerFilters.mdmSubBusinessName;
				accountForm.paymentZero.payeeCurrency = accountForm.payment.payeeCurrency;
				accountForm.paymentZero.payerAmount = accountForm.payment.payeeAmount;
				accountForm.paymentZero.numberOfPayments = accountForm.payment.numberOfPayments;
				accountForm.paymentZero.isGofBooked = accountForm.payment.isGofBooked;
				accountForm.paymentZero.mdmSpotRate = 1;
				accountForm.paymentZero.isManual = 'false';
				accountForm.paymentZero.requestActivities = [{
					userBusiness:		accountForm.paymentZero.mdmBusinessName,
					userSubBusiness:	accountForm.paymentZero.mdmSubBusinessName,
					comments:			accountForm.comments
				}];
				
				if(!_.isEmpty(accountForm.paymentZero.payer)) {
					accountForm.paymentZero.payer.payerOrPayee = 'PAYER';
					if(accountForm.paymentZero.payer.bankCurrency) {
						accountForm.paymentZero.mdmPayerCurrency = accountForm.paymentZero.payer.bankCurrency;
                	}
					accountForm.paymentZero.tCodeServiceCenter = accountForm.paymentZero.payer.serviceCenter;
				} else {
					accountForm.paymentZero.mdmPayerCurrency = accountForm.paymentZero.payeeCurrency;
				}
				
				if(!_.isEmpty(accountForm.spotRate)) {
					accountForm.paymentZero.payeeAmount = accountForm.spotRate.payeeAmount;
					accountForm.paymentZero.mdmSpotRate = accountForm.spotRate.spotRate;
				} else {
					accountForm.paymentZero.payeeAmount = accountForm.payment.payeeAmount;
				}
				
				// Change the payment date format from TZ to YYYY-MM-DD as requested by service
				if(accountForm.payment.paymentDate) {
					accountForm.paymentZero.paymentDate = moment(accountForm.payment.paymentDate).format('YYYY-MM-DD');
				}
				
				// Add payer restristed country and currencies
                if(accountForm.paymentZero.payer) {
                	accountForm.paymentZero.payer.isRestrictedCurrency = accountForm.isRestrictedPayerCurrency;
                    accountForm.paymentZero.payer.isRestrictedCountry = accountForm.isRestrictedPayerCountry;
                }
				
				// TODO: Remove this properties, /getSearchMDMBankAccounts needs to fetch these data instead
				accountForm.paymentZero.mdmMorRate = '1';

				var rg = angular.copy(accountForm.requestGroup);
				rg.payments[0] = accountForm.paymentZero;

				switch (action) {
					case 'submit':
						rg.requestGrpStatusCode = 'PAYREQSTAT_PENDAPPROV';
						if (typeAction === 'insert') {
							return paymentRequestManager.createERPPaymentRequest(rg.payments[0]);
						} else {
							// TODO implement update methods
						}
					break;
				}
			}
			accountForm.form.$submitted = true;
			$scope.$digest();
		};

		$scope.$on('spotRateEmit', function(event, spotRate) {
			accountForm.spotRate = spotRate;
		});

		// Public methods
		angular.extend(accountForm, {
			getPayment: function() {
				accountForm.isLoading = true;
	    		var paymentId = $stateParams.paymentId;
	    		
	    		var promise = paymentRequestManager.getPaymentRequestById(paymentId);
	    		promise.$promise.then(function(paymentRequest) {
	    			accountForm.paymentZero = paymentRequest;
	    			accountForm.payerFilters = {
		    	    	mdmBusinessName: 		accountForm.paymentZero.mdmBusinessName,
		    	    	mdmSubBusinessName:		accountForm.paymentZero.mdmSubBusinessName
	    			};
	    			
	    			if(!_.isUndefined(accountForm.paymentZero.payer) && !_.isEmpty(accountForm.paymentZero.payer)){
	    				var criteria = {
    	                    goldLeName: encodeURI(accountForm.paymentZero.payer.mdmLEName),
    	            		goldId: encodeURI(accountForm.paymentZero.payer.mdmGoldId)
    	            	};
    	            	var promise = bankAccountManager.getGoldLeNames(criteria);
    	            	promise.$promise.then(function(result) {
    	            		var leName = _.find(result.elements, function(element) {
    	            			return _.isEqual(element.party_nm, accountForm.paymentZero.payer.mdmLEName) 
    	            					&& _.isEqual(element.primry_alt_code, accountForm.paymentZero.payer.mdmGoldId);
    	            		});
    	            		accountForm.payerFilters.leName = leName;
    	            	});
	    			}
	    			
	    			if(_.isEqual(accountForm.paymentZero.payeeSource, 'MDM')) {
	    				accountForm.paymentZero.payeeIdType = 'INTERNAL';
	    			} else {
	    				accountForm.paymentZero.payeeIdType = 'MANUAL';
	    			}
	    			
	    			accountForm.payment = {
	    				payeeCurrency: 			accountForm.paymentZero.payeeCurrency,
	    				payeeAmount:			accountForm.paymentZero.payerAmount,
	    				numberOfPayments:		accountForm.paymentZero.numberOfPayments,
	    				isGofBooked:			accountForm.paymentZero.isGofBooked,
	    				paymentDate:			moment(accountForm.paymentZero.paymentDate).toDate()
	    			};
	    			
	    			accountForm.isLoading = false;
	    		});
	    	},
			isPayerEnabled: function() {
				var flag = false;
				
				if(accountForm.payerFilters 
						&& accountForm.payerFilters.mdmBusinessName 
						&& accountForm.payerFilters.mdmSubBusinessName 
						&& _.isObject(accountForm.payerFilters.leName)) {
					flag = true;
				}
				return flag;
			},
			/**
			 * Get legal entity names and gold id for le name selector
			 */
			getLeNames: function(text) {
				var defer = $q.defer();
				var criteria = {
					goldLeName: encodeURI(text)
				};
				var promise = bankAccountManager.getGoldLeNames(criteria);
				promise.$promise.then(function(result) {
					accountForm.leNames = result.elements;
					defer.resolve(result.elements);
				});
				return defer.promise;
			},
			/**
			 * @returns {boolean}
			 */
			readyForQuickSummary: function () {
				return 
					accountForm.paymentZero.payer
					&& accountForm.paymentZero.payer.bankCurrency
					&& accountForm.payment
					&& accountForm.payment.payeeCurrency;
			},
			/**
			 * Validates that payer or payee is selected by user 
			 */
			isPayeePayerSelected: function(payeePayer) {
				var flag =  true;
				
				if(_.isEmpty(payeePayer)) {
					flag = false;
				}
				
				return flag;
			},
			/**
			 * Displays the manual entry reasons extra fields like erpName or ES System 
			 */
			isAbleToSubmit: function () {
				if(accountForm.form.$valid
						&& accountForm.payment
						&& !_.isEmpty(accountForm.paymentZero.documents)){
					return true;
				} else {
					return false;
				}
			},
			/**
			 * Clear all server error messages
			 */
			clearErrors: function () {
				var thisForm = accountForm.form;
				angular.forEach(thisForm, function (value, key) {
					if (typeof value === 'object' && value.hasOwnProperty('$modelValue'))
						value.$error['server'] = '';
				});
			},
			/**
			 * TODO
			 * @param errors
			 */
			handleServerErrors: function(errors) {
				var errorJSON;
				var unknownErrors = '';
				
				try {
					errorJSON = JSON.parse(errors.data);
				} catch(err) {
					unknownErrors = errors.data;
				}
				
				if(unknownErrors !== '') {
					simpleModal.open({bodyHTML:unknownErrors});
				}

				$('.ng-invalid').focus();
			},
			/**
			 * Cancel button
			 */
			cancel: function() {
				$state.go('pages.payments');
			},
			isCrossCurrency: function() {
            	var flag = false;
            	if(!_.isUndefined(accountForm.payment) && !_.isUndefined(accountForm.paymentZero.payer) && !_.isEqual(accountForm.payment.payerCurrency, accountForm.paymentZero.payer.bankCurrency)) {
            		flag = true;
            	}
            	return flag;
            }
		});

		// Code added one by one
		// Payment type code
		// Watch for changes in Manual Payment Reason select to clean the ERP and System values after user change the selector
		$scope.$watch('accountForm.paymentZero.esCd', function(newValue, oldValue) {
			if(!_.isEqual(newValue, oldValue)) {
				if(newValue) {
					var promise = enterpriseStandardsManager.getPaymentTypes(newValue);
					promise.$promise.then(function(result) {
						var sortedPaymentTypeList = _.sortBy(result, function(obj) {
							return obj.paymentTypeDescription;
						});
						accountForm.paymentTypes = sortedPaymentTypeList;
					});
				}
			}
		});
     
		// Watch for changes in Business select to display the options on Sub-Business select
		$scope.$watch('accountForm.payerFilters.mdmBusinessName', function(newValue, oldValue) {
			if(!_.isEqual(newValue, oldValue)) {
				var promise = businessNamesManager.allERP();
				promise.$promise.then(function(result) {
					var filteredList = _.filter(result.elements, function(element) {
						return _.isEqual(element.bus_acct_grp, newValue);
					});
					filteredList = _.sortBy(filteredList, function(subbusiness) {
						return subbusiness.sub_bus_acct_grp;
					});
					accountForm.subBusiness = filteredList;
				});
			}
		});
		
		// Watch for changes in payer object
		$scope.$watch('accountForm.paymentZero.payer', function(newPayer, oldPayer) {
			if(!_.isEqual(newPayer, oldPayer) && !_.isUndefined(newPayer)) {
				$scope.$broadcast('sendPayerBroadcast', newPayer);
				// Validates if the bank currency is restricted or not
				accountForm.isRestrictedPayerCurrency = currencyManager.isRestrictedCurrency(newPayer.bankCurrency);
        		// Validates if the bank country is restricted or not
				accountForm.isRestrictedPayerCountry = CountryManager.isRestrictedCountry(newPayer.bankCountry);
			}
		}, true);

		$scope.$watch('accountForm.payment', function(newPayment, oldPayment) {
			if(!_.isEqual(newPayment, oldPayment) && !_.isUndefined(newPayment)) {
				$scope.$broadcast('sendPaymentBroadcast', newPayment);
			}
		});
		
		/**
		 * Initialize the enterprise standards selector
		 */
		initEnterpriseStandards = function() {
			var promise = enterpriseStandardsManager.all();
			promise.$promise.then(function(result) {
				accountForm.enterpriseStandards = result;
			});
		};
		
		// Initialization of enterprise standards selector
		initEnterpriseStandards();
		/**
		 * Initialize the business selector
		 */
		initBusinessNames = function() {
			var promise = businessNamesManager.allERP();
			promise.$promise.then(function(result) {
				var groupedList = _.sortBy(result.elements, function(obj) {
					return obj.bus_acct_grp;
				});
				groupedList =  _.groupBy(groupedList, function(element) {
					return element.bus_acct_grp;
				});
				accountForm.business = groupedList;
			});
		};
		
		// Initialize the business selector
		initBusinessNames();
		
		accountForm.submit = function(){
			return saveRequestGroup('submit');
		};
		
		/*
		 * Initialize the payment request
		 */ 
		initPayment = function() {
			if($stateParams.paymentId) {
				accountForm.getPayment();
			}
		};
		
		// Initialize the payment request
		initPayment();
		
	});