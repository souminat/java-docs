angular.module('app.components.addPayee.controller', [
	'ct.loadingOverlay',
	'app.directives'
])

    .controller('addPayeeController', function ($scope, $uibModalInstance, ngModel,paymentRequestManager ) {
        var apc = this;
        apc.highRiskUrl = '';
        
        // Public properties/functions
        angular.extend(apc, {
            isLoading: false,
            payee: ngModel,
            /*
             * Saves the payee
             */
            addPayee: function() {
            	$scope.$parent.pp.ngModel = apc.payee;
            	apc.cancel();
            },
            /*
             * Close the modal
             */
            cancel: function() {
            	$uibModalInstance.close();
            },
            isHighRiskItemSelected: function() {
            	var flag = false;
            	if(_.isEqual(apc.payee.highRiskItem, 'Y')) {
            		flag = true;
            	}
            	return flag;
            },
            
        	
        });
        
        loadStaticUrl = function() {
			var promise = paymentRequestManager.getStaticUrls();
			promise.$promise.then(function(result) {
				apc.highRiskUrl = result.highRiskUrl;
			});
    	},
    	
        loadStaticUrl();
    });