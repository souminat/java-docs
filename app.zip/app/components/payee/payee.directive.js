angular.module('app.components.payee.directive', [
    'app.config',
    'app.directives'
])
    .directive('mypaymentsPayee', ['config', function (config) {
        return {
            restrict: 'E',
            require: '?ngModel',
            scope: {
                ngModel:					'=',
                title:						'@'
            },
            templateUrl: config.templateBasePath + 'app/components/payee/payee.directive.html',
            bindToController: true,
            controllerAs: 'pp',
            controller: function ($scope, $uibModal) {

            	var pp = this;
            	
            	// Public properties/functions
                angular.extend(pp, {
                	/**
                	 * Open the modal window
                	 */
                	openModal: function () {
                    	$uibModal.open({
                            templateUrl: config.templateBasePath + 'app/components/payee/addPayee.controller.html',
                            controller: 'addPayeeController as apc',
                            bindToController: true,
                            size: 'lg',
                            resolve: {
                            	ngModel: function() {
                            		return pp.ngModel;
                            	}
                            },
                            scope: $scope
                        });
                    },
	                /**
	                 * Verifies that ngModel contains an object
	                 */
	                isModelSelected: function() {
	                	var flag =  true;
	                	
	                	if(_.isEmpty(pp.ngModel)) {
	                		flag = false;
	                	}
	                	
	                	return flag;
	                },
	                /**
	                 * Obtains the title of link
	                 */
	                getTitle: function() {
	                	var title = 'Add a payee';
	                	
	                	if(!_.isEmpty(pp.ngModel)) {
	                		title = 'Change payee';
	                	}
	                	
	                	return title;
	                }
                });
            }
        };
    }]);