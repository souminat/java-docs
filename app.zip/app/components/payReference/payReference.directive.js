angular.module('app.components.payReference.directive', [
    'app.config'
])
    .directive('mypaymentsPayReference', ['config', function (config) {
        return {
            restrict: 'E',
            require: '?ngModel',
            scope: {
                references: '=ngModel'
            },
            templateUrl: config.templateBasePath + 'app/components/payReference/payReference.directive.html',
            bindToController: true,
            controllerAs: 'pr',
            controller: function () {

            	var pr = this;
            	
            	// Public properties/functions
                angular.extend(pr, {
                	addReference: function(reference) {
                		reference.isAdded = true;
                		pr.references.push({
                			name: '',
                    		value: '',
                    		isAdded: false
                		});
                	},
                	removeReference: function(index) {
                		pr.references.splice(index, 1);
                	}
                });
                
                pr.init = function() {
                	if(!pr.references) {
                		pr.references = [{
                			name: '',
                			value: '',
                			isAdded: false
                		}];
                	}
                };
                
                pr.init();
            }
        };
    }]);