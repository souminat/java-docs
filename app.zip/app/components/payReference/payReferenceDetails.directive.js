angular.module('app.components.payReference.details.directive', [
    'app.config'
])
    .directive('mypaymentsPayReferenceDetails', ['config', function (config) {
        return {
            restrict: 'E',
            require: '?references',
            scope: {
            	references: '='
            },
            templateUrl: config.templateBasePath + 'app/components/payReference/payReferenceDetails.directive.html',
            bindToController: true,
            controllerAs: 'prd',
            controller: function () {

            	var pr = this;
            	
            }
        };
    }]);