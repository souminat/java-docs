describe("app.components.formItem.directive.spec", function() {

	var $compile, $rootScope, $httpBackend;

	beforeEach(module('templates'));
	beforeEach(module('app.components.formItem.directive'));

	beforeEach(inject(function($injector){

		$compile = $injector.get('$compile');
		$rootScope = $injector.get('$rootScope');
		$httpBackend = $injector.get('$httpBackend');

	}));

	it('renders form item directive', function() {

		$rootScope.fakeThing = {};
		var element = $compile("<application-form-item label='ThisIsLabel'>Inside</application-form-item>")($rootScope);
		$rootScope.$digest();
		//$httpBackend.flush();

		expect(element.html()).toContain("Inside");

	});

});
