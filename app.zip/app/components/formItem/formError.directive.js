angular.module('app.components.formError.directive', [
	'app.config',
	'app.messages'
])

.directive('applicationFormError', function (config) {
	return {
		restrict: 'E',
		transclude: true,
		scope: {
			form: '=',
			field: '@',
			validation: '@'
		},
		template: '<span class="help-block" ng-if="hasError()">{{message}}</span>',
		controller:function($scope, $element, messages) {
			if($scope.validation === 'required') {
				$scope.message = messages.validation.empty;
			}

			$scope.hasError = function() {
				//catch if calling before the field is registered
				if(!$scope.form[$scope.field]) {
					return false;
				}
				var error = false;

				if($scope.validation){
					//show validation error if feild is "dirty" or if show validation bit is true
					error = ($scope.form[$scope.field].$dirty || $scope.form.$submitted) && $scope.form[$scope.field].$error[$scope.validation];
				}
				else {
					//if no validation passed make sure html element is valid
					error = ($scope.form[$scope.field].$dirty || $scope.form.$submitted) && $scope.form[$scope.field].$invalid;
				}

				if(!error) {
					//check for server error
					if($scope.form[$scope.field].$error['server']) {
						$scope.message = $scope.form[$scope.field].$error['server'];
						error = true;
					}
				}

				//if there is an error, set parent node error class
				$element.closest('.form-group').toggleClass('has-error', error || false);
				// if(error) {
				// 	$element.closest('.form-group').addClass('has-error');
				// }
				// else {
				// 	$element.closest('.form-group').removeClass('has-error');
				// }

				return error;
			}
		},
		link: function (scope, element, attrs, ctrl) {
            element.attr['data-test'] = scope.hasError();
        }
	};
})