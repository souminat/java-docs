// TODO extract into separate component repository
angular.module('ct.loadingButton', [])
    .directive('ctLoadingButton', function () {
        return {
            restrict: 'A',

            controller: function () {
                var callback;
                angular.extend(this, {
                    setCallback: function (cb) {
                        callback = cb;
                    },
                    setLoading: function(isLoading) {
                        if (angular.isFunction(callback)) {
                            callback(isLoading);
                        }
                    }
                });
            },

            link: function (scope, element, attrs, ctrl) {
                var loadingText = element.data('loading-text') || 'Loading';
                // Append spinner icon if no icon is already defined
                if (loadingText.indexOf('<i') === -1) {
                    loadingText = '<i class="fa fa-spinner fa-pulse fa-fw"></i>&nbsp;' + loadingText
                }
                element.data('loading-text', loadingText);
                ctrl.setCallback(function (loading) {
                    element.button(loading ? 'loading' : 'reset');
                });
            }
        };
    });