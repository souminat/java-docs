angular.module('app.components.formItem.directive', [
	'app.config'
])

.directive('applicationFormItem', function (config) {
	return {
		restrict: 'E',
		transclude: true,
		scope: {
			label: '@',
			ngClass: '=',
			controlClass: '@'
		},
		templateUrl: config.templateBasePath + 'app/components/formItem/formItem.directive.html'
	};
});