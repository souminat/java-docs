angular.module('app.components.intermediaryDetails.directive', [
	'app.config'
])

.directive('mypaymentsIntermediaryDetails', function (config) {
    return {
        restrict:               'E',
        scope: {
            ngModel:			'=',
            index:				'@'
        },
        templateUrl: config.templateBasePath + 'app/components/intermediaries/intermediaryDetails.directive.html',
        bindToController: true,
        controllerAs: 'id',
        controller: function($scope) {
            var id = this;
            
        }
    };
});