angular.module('app.components.addIntermediary.controller', [
	'ct.loadingOverlay'
])

    .controller('addIntermediaryController', function ($scope, $uibModalInstance, intermediary) {
        var aic = this;
        
        // Public properties/functions
        angular.extend(aic, {
        	intermediary: intermediary,
        	/*
             * Saves the payee
             */
            addIntermediary: function() {
            	$scope.$emit('addIntermediaryEmit', aic.intermediary);
            	aic.cancel();
            },
            /*
             * Close the modal
             */
            cancel: function() {
            	$uibModalInstance.close();
            }
        });
        
    });