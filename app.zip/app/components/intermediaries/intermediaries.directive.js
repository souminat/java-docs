angular.module('app.components.intermediaries.directive', [
    'app.config',
    'app.directives'
])
    .directive('mypaymentsIntermediaries', ['config', function (config) {
        return {
            restrict: 			'E',
            require: 			'?ngModel',
            scope: {
                intermediaries:	'=ngModel'
            },
            templateUrl: config.templateBasePath + 'app/components/intermediaries/intermediaries.directive.html',
            bindToController: true,
            controllerAs: 'int',
            controller: function ($scope, $uibModal) {

            	var int = this;	
            	                
            	// Public properties/functions
                angular.extend(int, {
                	openModal: function (index) {
                    	$uibModal.open({
                            templateUrl: config.templateBasePath + 'app/components/intermediaries/addIntermediary.controller.html',
                            controller: 'addIntermediaryController as aic',
                            bindToController: true,
                            size: 'lg',
                            scope: $scope,
                            resolve: {
                            	intermediary: function() {
                            		return int.intermediaries[index];
                            	}
                            }
                        });
                    },
                    addIntermediary: function(event, intermediary) {
                    	int.intermediaries.push(intermediary);
                    },
                    displaySecondIntermediary: function() {
                    	var flag = false;
                    	
                    	if(int.intermediaries && int.intermediaries.length > 0) {
                    		flag = true;
                    	}
                    	
                    	return flag;
                    },
                    isIntermediarySelected: function(index) {
                    	var flag = false;
                    	
                    	if(int.intermediaries[index]) {
                    		flag = true;
                    	}
                    	
                    	return flag;
                    },
                    getLinkText: function(index, text) {
                    	var label = text;
                    	
                    	if(int.intermediaries[index]) {
                    		label = 'Change intermediary';
                    	}
                    	
                    	return label;
                    },
                    removeIntermediary: function(index) {
                    	if(int.intermediaries && int.intermediaries[index]) {
                    		int.intermediaries.splice(index, 1);
                    	}
                    },
                    channels: function() {
                    	$scope.$on('addIntermediaryEmit', int.addIntermediary);
                    },
                    initIntermediaries: function() {
                    	if(_.isUndefined(int.intermediaries)) {
                    		int.intermediaries = [];
                    	}
                    }
                });
                
                // Initialization of channels
                int.channels();
                
                // Initialization of intermediaries
                int.initIntermediaries();
            }
        };
    }]);