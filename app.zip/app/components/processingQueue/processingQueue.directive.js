angular.module('app.components.processingQueue.directive', [
	'app.config',
	'app.directives'
])
.directive('applicationProcessingQueue', function (config) {
	return {
		restrict: 								'E',
		scope: {
			file:								'=',
			processingQueueData:				'=data'
		},
		templateUrl: config.templateBasePath + 'app/components/processingQueue/processingQueue.directive.html',
		controller: function($scope) {			
			
			// Initialization of processing queue table
			var initProcessingQueue = function() {
				$scope.processingQueueHeaders = [
				    {
				    	field:			'createDate',
				    	name:			'Upload date'
				    },
				    {
				    	field:			'fileUpldId',
				    	name:			'Upload ID'
				    },
				    {
				    	field:			'upldStatus',
				    	name:			'Status'
				    }
				];
			};
			
			// Initialization method
			var init = function() {
				// Initialization of processing queue table
				initProcessingQueue();
			};
			
			// Triggers initialization method when controller loads
			init();
		}
	};
});