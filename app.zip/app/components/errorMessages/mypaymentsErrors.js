angular.module('app.mypaymentsErrors', [
	'app.config',
	'app.messages',
	'ct.errorMessages'
])

    .directive('mypaymentsErrors', function (config, messages) {
        return {
            restrict: 'A',
            require: 'ctErrorMessages',
            link: function (scope, element, attrs, errorsCtrl) {
                errorsCtrl.addMessages(
                    config.templateBasePath + 'app/components/errorMessages/mypaymentsErrors.html',
                    {
                        empty: messages.validation.empty
                    },
                    attrs.mypaymentsErrors
                );
            }
        };
    });
