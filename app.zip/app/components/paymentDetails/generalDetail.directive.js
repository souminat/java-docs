angular.module('app.components.generalDetail.directive', [
    'app.config',
    'app.filters'
])
    .directive('mypaymentsPaymentGeneralDetail', ['config', function (config) {
        return {
            restrict: 'E',
            require: ['?ngModel'],
            scope: {
                title:						'@',
            	ngModel:					'='
            },
            templateUrl: config.templateBasePath + 'app/components/paymentDetails/generalDetail.directive.html',
            bindToController: true,
            controllerAs: 'generalDetail',
            controller: function ($scope) {

            	var generalDetail = this;
            	
            	// Public properties/functions
                angular.extend(generalDetail, {
                	
                });
            }
        };
    }]);