angular.module('app.components.addERPPayment.controller', [
	'ct.loadingOverlay',
	'app.services',
	'app.directives'
])

    .controller('addERPPaymentController', function ($scope, $uibModalInstance, ngModel, /*accounting,*/ payer, currencyManager, holidayCalendarManager) {
        var apc = this;
        $scope.onlyNumbers = /^[1-9]+[0-9]*$/;
        apc.valueDtFlag = true;
        
        // Watch for changes to currencies in order to determine possible payment dates
        $scope.$watch('apc.payment.payeeCurrency', function (newValues) {
            var holidays;
            if (newValues && _.isEqual(newValues.length, 3)) {
            	apc.valueDtFlag = false;
                apc.currencies = apc.getCurrencies(newValues);
                apc.holidays = apc.getHolidays(apc.currencies);
                apc.isPaymentDateLoading = true;
                apc.holidays.$promise.then(function(response) {
                    var spotDays,
                        holidayDates,
                        today = new Date();

                    apc.isPaymentDateLoading = false;

                    apc.holidayDates = holidayCalendarManager.parseDates(response.elements);
                    apc.spotDays = currencyManager.getSpotDays(apc.currencies);

                    if(!_.isUndefined(payer) && !_.isEqual(payer.bankCurrency, newValues)) {
                    	// Default to current date + 1 
                    	apc.crossCurrencyDate = holidayCalendarManager.addBusinessDays(today, apc.holidayDates, 1);
                        apc.isCrossCurrency = true;
                    } else {
                    	// Default to spot date
                        apc.isCrossCurrency = false;
                    }
                    
                    // Set the available range of dates as today -> spot date + 5 business days (excluding holidays)
                    apc.dateOptions.minDate = holidayCalendarManager.addBusinessDays(today, apc.holidayDates);
                    apc.dateOptions.maxDate = holidayCalendarManager.addBusinessDays(today, apc.holidayDates, apc.spotDays + 5);
                    apc.holidayCalendarDates = apc.holidayDates;
                    if (!_.isUndefined(apc.payment)) {
                    	if (apc.payment.paymentDate) {
                    		if (parseInt(apc.payment.paymentDate.getDate().toString()) < parseInt(apc.dateOptions.minDate.getDate().toString()) ||
                    				parseInt(apc.payment.paymentDate.getDate().toString()) > parseInt(apc.dateOptions.maxDate.getDate().toString())) {
                    			apc.payment.paymentDate = '';
							}
                			for (var i = 0; i < apc.holidayDates.length; i++) {
								if (parseInt(apc.payment.paymentDate.getDate().toString()) == parseInt(apc.holidayDates[0].getDate().toString())) {
									apc.payment.paymentDate = '';
								}
							}
    					}
                    }
                }, function(reason) {
                	apc.isPaymentDateLoading = false;
                });
                
                // Validates if the currency is restricted or not
                apc.isRestrictedCurrency = currencyManager.isRestrictedCurrency(newValues);
            } else {
                apc.holidayCalendarDates = [];
                apc.currencies = [];
                apc.valueDtFlag = true;
            }
        });
        
        // Public properties/functions
        angular.extend(apc, {
        	isPaymentDateLoading: false,
        	payment: ngModel,
        	dateOptions: {
        		minDate: new Date()
        	},
        	defaultOptions: {
        		maxDate: new Date() 
        	},
        	/**
        	 * Validate if the cross currency payment value date is invalid
        	 */
        	isCrossCurrencyInvalid: function() {
        		var flag = false;
        		
        		if(apc.isCrossCurrency) {
        			var paymentValueDate = moment(apc.payment.paymentDate);
        			var crossDate = moment(apc.crossCurrencyDate);
        			flag = paymentValueDate.isBefore(crossDate);
        		}
        		
        		return flag;
        	},
            /*
             * Saves the payee
             */
            addPayment: function() {
            	$scope.$emit('addERPPaymentEmit', apc.payment);
            	apc.cancel();
            },
            /*
             * Close the modal
             */
            cancel: function() {
            	$uibModalInstance.close();
            },
            /*
             * Payment loading
             */
            paymentDateLoading: function () {
                return apc.isPaymentDateLoading;
            },
            /**
             * Get currencies
             */
            getCurrencies: function (currencyCode) {
                /*
            	return _.map(currencyCodes, function(currencyCode) {
                    return currencyManager.getByCurrencyCode(currencyCode);
                });
                */
            	return currencyManager.getByCurrencyCode(currencyCode);
            },
            /**
             * Get holidays
             */
            getHolidays: function (currency) {
                var holidays;
                if(!_.isUndefined(currency)) {
                	holidays = holidayCalendarManager.getHolidaysByCalendarName([currency.cal_nm]);
                }
            	return holidays;
            },
            /**
             * Get payment options
             */
            paymentDateOptions: function () {
                return apc.dateOptions;
            },
            paymentNormalDateOptions: function() {
            	return apc.defaultOptions;
            },
            isSameDaySelected: function () {
            	var flag = false;
        		if(!_.isUndefined(apc.payment)) {
        			if (apc.payment.paymentDate) {
        				var today = new Date();
        				var paymentValueDate = apc.payment.paymentDate;
            			flag = paymentValueDate.getDate().toString() == today.getDate().toString();
					}
        		}
        		return flag;
            }
        });
    });