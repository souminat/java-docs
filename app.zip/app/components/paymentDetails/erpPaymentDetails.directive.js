angular.module('app.components.erpPaymentDetails.directive', [
    'app.config',
    'app.directives'
])
    .directive('mypaymentsErpPaymentDetails', ['config', function (config) {
        return {
            restrict: 'E',
            require: ['?ngModel'/*, '?accounting'*/],
            scope: {
                ngModel:		'='/*,
                accounting:		'='	*/		
            },
            templateUrl: config.templateBasePath + 'app/components/paymentDetails/erpPaymentDetails.directive.html',
            bindToController: true,
            controllerAs: 'pd',
            controller: function ($scope, $uibModal) {

            	var pd = this;
            	
            	// Public properties/functions
                angular.extend(pd, {
                	getTitle: function() {
                		var title = 'Add ERP payment details';
                		
                		if(!_.isEmpty(pd.ngModel)) {
	                		title = 'Change ERP payment details';
	                	}
                		
                		return title;
                	},
                	openModal: function () {
                    	$uibModal.open({
                            templateUrl: config.templateBasePath + 'app/components/paymentDetails/addERPPayment.controller.html',
                            controller: 'addERPPaymentController as apc',
                            bindToController: true,
                            size: 'lg',
                            scope: $scope,
                            resolve: {
                                ngModel: function() {
                                    return pd.ngModel;
                                },
                                /*accounting: function() {
                                	return pd.accounting;
                                },*/
                                payer: function() {
                                	return pd.payer;
                                }
                            },
                        });
                    },
                    addERPPayment: function(event, payee) {
                 
                    	pd.ngModel = {};
                    	pd.ngModel.payeeCurrency = payee.payeeCurrency;
                    	pd.ngModel.paymentDate = payee.paymentDate;
                    	pd.ngModel.payeeAmount = payee.payeeAmount;
                    	pd.ngModel.numberOfPayments = payee.numberOfPayments;
                    	pd.ngModel.paymentDate = payee.paymentDate;
                    	if(!_.isUndefined(payee.isGofBooked)){
                    		pd.ngModel.isGofBooked = payee.isGofBooked;
                    	}else{
                    		pd.ngModel.isGofBooked = 'N';
                    	}
                    	
                    	/*pd.accounting = {};
                    	pd.accounting.isGOFBooked = accounting.isGOFBooked;
                    	pd.accounting.glAccountNumber = accounting.glAccountNumber;
                    	pd.accounting.projectName = accounting.projectName;
                    	pd.accounting.costCenterFnlArea = accounting.costCenterFnlArea;
                    	pd.accounting.productLine = accounting.productLine;
                    	pd.accounting.reference = accounting.reference;
                    	pd.accounting.geography = accounting.geography;*/
                    },
                    
                    setPayer: function(event, payer) {
                    	pd.payer = payer;
                    },
                    channels: function() {
                    	$scope.$on('addERPPaymentEmit', pd.addERPPayment);
                    	$scope.$on('sendPayerBroadcast', pd.setPayer);
                    }
                });
                
                // Init channels 
                pd.channels();
            }
        };
    }]);