angular.module('app.components.erpPaymentDetail.directive', [
    'app.config'
])
    .directive('mypaymentsErpPaymentDetail', ['config', function (config) {
        return {
            restrict: 'E',
            require: ['?ngModel'/*, '?accounting'*/],
            scope: {
                title:						'@',
            	ngModel:					'='/*,
                accounting:					'='*/
            },
            templateUrl: config.templateBasePath + 'app/components/paymentDetails/erpPaymentDetail.directive.html',
            bindToController: true,
            controllerAs: 'pd',
            controller: function ($scope) {

            	var pd = this;
            	
            	// Public properties/functions
                angular.extend(pd, {
                	
                });
            }
        };
    }]);