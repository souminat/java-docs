angular.module('app.components.paymentDetails.directive', [
    'app.config',
    'app.directives'
])
    .directive('mypaymentsPaymentDetails', ['config', function (config) {
        return {
            restrict: 'E',
            require: ['?ngModel', '?accounting'],
            scope: {
                ngModel:		'=',
                accounting:		'='	,
                isCheckPayment:	'=',
                payee:			'=',
                payer:			'=',
                isResubmit:		'='
            },
            templateUrl: config.templateBasePath + 'app/components/paymentDetails/paymentDetails.directive.html',
            bindToController: true,
            controllerAs: 'pd',
            controller: function ($scope, $uibModal) {

            	var pd = this;
            	
            	// Public properties/functions
                angular.extend(pd, {
                	getTitle: function() {
                		var title = 'Add payment details';
                		
                		if(!_.isEmpty(pd.ngModel)) {
	                		title = 'Change payment details';
	                	}
                		
                		return title;
                	},
                	openModal: function () {
                    	$uibModal.open({
                            templateUrl: config.templateBasePath + 'app/components/paymentDetails/addPayment.controller.html',
                            controller: 'addPaymentController as apc',
                            bindToController: true,
                            size: 'lg',
                            scope: $scope,
                            resolve: {
                                ngModel: function() {
                                    return pd.ngModel;
                                },
                                accounting: function() {
                                	return pd.accounting;
                                },
                                payer: function() {
                                	return pd.payer;
                                },
                                isResubmit: function() {
                                	return pd.isResubmit;
                                }
                            },
                        });
                    },
                    addPayee: function(event, payee, accounting) {
                    	pd.ngModel = {};
                    	pd.ngModel.payerCurrency = payee.payerCurrency;
                    	pd.ngModel.paymentDate = payee.paymentDate;
                    	pd.ngModel.payeeAmount = payee.payeeAmount;
                    	pd.ngModel.invoiceNumber = payee.invoiceNumber;
                    	pd.ngModel.invoiceDate = payee.invoiceDate;
                    	
                    	pd.accounting = {};
                    	if(!_.isUndefined(accounting.isGOFBooked)){
                    		pd.accounting.isGOFBooked = accounting.isGOFBooked;
                    	}else{
                    		pd.accounting.isGOFBooked = 'N';
                    	}
                    	pd.accounting.glAccountNumber = accounting.glAccountNumber;
                    	pd.accounting.projectName = accounting.projectName;
                    	pd.accounting.costCenterFnlArea = accounting.costCenterFnlArea;
                    	pd.accounting.productLine = accounting.productLine;
                    	pd.accounting.reference = accounting.reference;
                    	pd.accounting.geography = accounting.geography;
                    },
                    setPayee: function(event, payee) {
                    	pd.payee = payee;
                    },
                    setPayer: function(event, payer) {
                    	pd.payer = payer;
                    },
                    channels: function() {
                    	$scope.$on('addPayeeEmit', pd.addPayee);
                    	$scope.$on('sendPayeeBroadcast', pd.setPayee);
                    	$scope.$on('sendPayerBroadcast', pd.setPayer);
                    }
                });
                
                // Init channels 
                pd.channels();
            }
        };
    }]);