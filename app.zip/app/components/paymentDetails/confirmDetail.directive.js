angular.module('app.components.confirmDetail.directive', [
    'app.config'
])
    .directive('mypaymentsConfirmDetail', ['config', function (config) {
        return {
            restrict: 'E',
            require: ['?ngModel'/*, '?accounting'*/],
            scope: {
                title:						'@',
            	ngModel:					'='/*,
                accounting:					'='*/
            },
            templateUrl: config.templateBasePath + 'app/components/paymentDetails/confirmDetail.directive.html',
            bindToController: true,
            controllerAs: 'confirmation',
            controller: function ($scope) {

            	var confirmation = this;
            	
            	// Public properties/functions
                angular.extend(confirmation, {
                	
                });
            }
        };
    }]);