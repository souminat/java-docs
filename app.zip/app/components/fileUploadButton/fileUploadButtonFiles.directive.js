angular.module('app.components.fileUploadButtonFiles.directive', [
    'ct.loadingOverlay',
    'app.config',
    'app.services'
])
    .directive('applicationFileUploadButtonFiles', ['config', 'fileUploadManager', 'simpleModal', function (config, fileUploadManager) {
        return {
            restrict: 				'E',
            require: 				'?ngModel',
            scope: {
            	ngModel:				'='
            },
            templateUrl: config.templateBasePath + 'app/components/fileUploadButton/fileUploadButtonFiles.directive.html',
            bindToController: true,
            controllerAs: 'fubf',
            controller: function () {

            	var fubf = this;
            	
            	// Method used to display or not the file list
            	fubf.containsFiles = function () {
                    var flag = false;

                    // Verify if file's array contain files
                    if (fubf.ngModel.length > 0) {
                        flag = true;
                    }

                    return flag;
                };

                // Method used to remove files once the user clicks on remove button
                fubf.removeFile = function (removedFile) {
                	var promise = fileUploadManager.deleteFile(removedFile.fileId);
                	promise.$promise.then(function(result) {
                		if(result) {
                			fubf.ngModel = _.filter(fubf.ngModel, function(file) {
                        	    return file !== removedFile;
                        	});
                		}
                	});
                };

                // Initialization of files
                var initFiles = function () {
                    // If ngModel is undefined, initialize it as an array
                    if (!fubf.ngModel) {
                    	fubf.ngModel = [];
                    }
                };

                // Initialization method
                var init = function () {
                    // Initialization of files
                    initFiles();
                };

                // Triggers when directive is being loaded
                init();
            }
        };
    }]);