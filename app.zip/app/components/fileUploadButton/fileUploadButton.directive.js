angular.module('app.components.fileUploadButton.directive', [
    'ct.loadingOverlay',
    'ux.form.simpleModal',
    'app.config',
    'app.services'
])
    .directive('applicationFileUploadButton', ['config', 'fileUploadManager', 'simpleModal', function (config, fileUploadManager, simpleModal) {
        return {
            restrict: 				'E',
            require: 				'?ngModel',
            scope: {
                ngModel: 			'='
            },
            templateUrl: config.templateBasePath + 'app/components/fileUploadButton/fileUploadButton.directive.html',
            bindToController: true,
            controllerAs: 'fub',
            controller: function () {

            	var fub = this;
            	
            	fub.isLoading = false;
                
            },
            link: function (scope, element, attrs, ctrl) {

                // Method used to clone the file objects
            	ctrl.createFileObject = function (file, fileId) {
                    var obj;
                    // Validates that file is an object
                    if (file) {
                        obj = {
                        	documentName: 		file.name,
                            size: 				file.size,
                            type: 				file.type,
                            fileId: 			fileId,
                            isDocActive:		'Y',
                            docUrl:				'box/downloadFileByFileId?fileId=' + fileId
                        };
                    }
                    return obj;
                };

                // Method that is triggered after the user select files in browser file explorer
                ctrl.upload = function (files) {
                	if(files && files.length <= 10) {
                		scope.fub.isLoading = true;
                    	var fd = new FormData();
                    	
                        //Take the first selected file
                        angular.forEach(files, function(fileData) {
                            fd.append("file", fileData);
                        });
                        var uploadFilePromise = fileUploadManager.uploadNewFile(fd);
                        uploadFilePromise.$promise.then(function (paymentDocument) {
                        	_.each(files, function(file) {
                        		var obj = ctrl.createFileObject(file, paymentDocument.fileId);
                                scope.fub.ngModel.push(obj);
                        	});
                        	scope.button.val('');
                        	scope.fub.isLoading = false;
                        }, function(error) {
                        	var modal = simpleModal.open({
        		    			title: 				'Error',
        		    			size: 				'lg',
        		    			allowClose: 		true,
        		    			allowDismiss:		false,
        		    			closeText:			'Ok',
        		    			bodyHTML: 			'<p>' + error.data + '</p>'
        		    		});
                        });
                	} else {
                		var modal = simpleModal.open({
                			title: 				'Error',
                			size: 				'lg',
                			allowDismiss:		true,
                			allowClose:			false,
                			dismissText:		'Close',
                			bodyHTML: 			'<p>You cannot upload more than 10 files</p>'
                		});
                	}
                };

                // Initialization of drop element
                var initDrop = function () {
                    scope.drop = $('.drop', element);
                };

                // Initialization of upload button element
                var initUploadButton = function () {
                    scope.button = $('#upload-button', element);
                };

                // Initialization of events
                var initEvents = function () {

                    // Stops propagation in dragover
                    scope.drop.on('dragover', function (e) {
                    	e.preventDefault();
                        e.stopPropagation();
                        scope.drop.addClass('is-dragover');
                    });

                    // Stops propagation in dragenter
                    scope.drop.on('dragenter', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                    });
                    
                    // Stops propagation in dragleave
                    scope.drop.on('dragleave', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        scope.drop.removeClass('is-dragover');
                    });

                    // Disable default behavior in drop event
                    scope.drop.on('drop', function (e) {
                    	e.preventDefault();
                        e.stopPropagation();
                        scope.drop.removeClass('is-dragover');
                        
                        if (e.originalEvent.dataTransfer) {
                            if (e.originalEvent.dataTransfer.files.length > 0) {
                                ctrl.upload(e.originalEvent.dataTransfer.files);
                            }
                        }
                        return false;
                    });

                    // detect a change in a file input with an id of “upload-button”
                    scope.button.change(function () {
                        if (this.files.length > 0) {
                            ctrl.upload(this.files);
                        }
                    });

                };

                // Initialization method
                var init = function () {
                    // Initialization of drop element
                    initDrop();
                    // Initialization of upload button element
                    initUploadButton();
                    // Initialization of events
                    initEvents();
                };

                // Triggers when directive is already loaded
                init();
            }
        };
    }])
    .filter('bytes', function() {
        return function(bytes, precision) {
            if (isNaN(parseFloat(bytes)) || !isFinite(bytes)) {
                return '-';
            }

            if (typeof precision === 'undefined') {
                precision = 1;
            }

            var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'],
                number = Math.floor(Math.log(bytes) / Math.log(1024));

            return (bytes / Math.pow(1024, Math.floor(number))).toFixed(precision) +  ' ' + units[number];
        }
    });