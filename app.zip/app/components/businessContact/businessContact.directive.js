angular.module('app.components.businessContact.directive', [
	 'app.config',
	 'app.services.payments',	
	 'app.services.businessContact', 
	 'ux.form.simpleModal',
	 'ui.router'
])
.directive('businessContactLookup', 
	function(config, simpleModal, businessContact){
        return {
            restrict: 'E',
            scope: {
            	ngModel: 			'=',
            	activity:			'@',
            	ngRequestId:		'=',
    			ngValue:		    '=',
            	name: 				'@',
            	ngReadonly: 		'=',
            	ngRequired: 		'=?',
                ngDisabled: 		'=?',
                placeholder: 		'@'
            },
            templateUrl: config.templateBasePath + 'app/components/businessContact/businessContact.directive.html',
            bindToController: true,
            controllerAs: 'bu',
            controller: function($q,$state, $scope, businessContact,paymentRequestManager){
            	
            	var bu = this;
            	var assignToPerson = {};
            	var activityFlag;
            	
                $scope.noResults = false;
                
                angular.extend(bu,{ 
                	
                	isSelected: false,
                	isLoading: false,
                	
                	getFilteredContacts: function(searchTerm){
                		/*var confirmCloseout = null;
                		if (bu.activity != 'Filter') {
                			confirmCloseout = simpleModal.open({
                        		title: 'Looking up SSO...',
                        		body: '', allowDismiss: false, keyboard: false,
                                backdrop: 'static', allowClose: false
                        	});
						}*/
                		bu.isLoading = true;
                		return businessContact.getbusinessContact(searchTerm).
                    	$promise.then(function(data){
                    		if(data.length > 0){
                    			bu.noResults = false;
                    			/*(bu.activity != 'Filter')? confirmCloseout.close(): null;*/
                    		}else{
                    			bu.noResults = true;
                    			bu.ngModel = '';
                    			/*(bu.activity != 'Filter')? confirmCloseout.close(): null;*/
                    		}
                    		bu.isLoading = false;	
            	 			return data;
             			});
                	},
                	onSelect:  function(){
                		bu.isSelected= true;
                		 activityFlag =$(this)[0].activity;
                		if( activityFlag == 'Assign') {
                			/*console.log("Activity type is Assign Do Assignment");*/
			                assignToPerson.requestId = $(this)[0].ngRequestId;
                      	  	assignToPerson.assignToSSO = $(this)[0].ngModel;
                      	  	paymentRequestManager.assignPersonToRequest(assignToPerson);
                      	  	$state.reload();
                		} /*else if(activityFlag == 'Filter') {
                			console.log("Activity type is filter Do nothing");
                		}*/
                	}
                });
            }
        };
    });