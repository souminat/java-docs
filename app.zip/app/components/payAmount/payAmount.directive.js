angular.module('app.components.payAmount.directive', [
	'app.config'
])

    .directive('mypaymentsPayAmount', function (config) {
        return {
            restrict: 'E',
            scope: {
                ngModel: '='
            },
            templateUrl: config.templateBasePath + 'app/components/payAmount/payAmount.directive.html',
            controller: 'mypaymentsPayAmountController as pa'
        };
    })

    .controller('mypaymentsPayAmountController', function ($scope) {
        var getCurrencyCode, otherDirection,
            pa = this,
            currencies = {
                payer: null,
                payee: null
            };

        pa.direction = 'payee';

        $scope.$watch('ngModel.payer.bankAcct.currencyCode', function (newValue) {
            currencies.payer = newValue;
        });
        $scope.$watch('ngModel.payee.bankAcct.currencyCode', function (newValue) {
            currencies.payee = newValue;
        });


        // Private functions

        otherDirection = function () {
            return (pa.direction === 'payer') ? 'payee' : 'payer';
        };

        getCurrencyCode = function (inverse) {
            var direction = pa.direction;
            if (inverse) {
                direction = otherDirection();
            }

            return currencies[direction];
        };


        // Public functions

        pa.changeSource = function () {
            var previous = pa.direction + 'Amount',
                amount = _.has($scope.ngModel, previous) ? $scope.ngModel[previous] : null;
            pa.direction = otherDirection();
            $scope.ngModel[previous] = null;
            $scope.ngModel[pa.direction + 'Amount'] = amount;
        };

        pa.paymentCurrency = function () {
            return getCurrencyCode();
        };

        pa.otherCurrency = function () {
            return getCurrencyCode(true);
        };

        pa.isMultiCurrency = function () {
            var source = getCurrencyCode(),
                other = getCurrencyCode(true);

            return (source && other && (source !== other));
        };
    })
;