describe("app.components.payAmount.directive.spec", function() {

	var $compile, $rootScope, $httpBackend;

	beforeEach(module('templates'));
	beforeEach(module('app.services.currency'));
	beforeEach(module('app.services.currency.mock'));
	beforeEach(module('app.components.payAmount.directive'));

	beforeEach(inject(function ($injector) {

		$compile = $injector.get('$compile');
		$rootScope = $injector.get('$rootScope');
		$httpBackend = $injector.get('$httpBackend');

		$rootScope.fakePayment = {};
	}));

	function setPayer(currency, amount) {
		$rootScope.fakePayment.payer = {
			bankAcct: {
				currencyCode: currency
			}
		};
		$rootScope.fakePayment.payerAmount = amount;
	}

	function setPayee(currency, amount) {
		$rootScope.fakePayment.payee = {
			bankAcct: {
				currencyCode: currency
			}
		};
		$rootScope.fakePayment.payeeAmount = amount;
	}

	it('shows no currency beside the amount when no payer or payee', function () {
		var directiveElement = angular.element('<mypayments-pay-amount ng-model="fakePayment" name="amount"></mypayments-pay-amount>');
		var element = $compile(directiveElement)($rootScope);
		$rootScope.$digest();

		expect(element.find('span.add-on').length).toBe(0);
	});

	it('shows payee currency beside amount field by default', function () {
		var directiveElement = angular.element('<mypayments-pay-amount ng-model="fakePayment" name="amount"></mypayments-pay-amount>');
		var element = $compile(directiveElement)($rootScope);
		var currentCurrency;

		setPayee('GBP');

		$rootScope.$digest();
		currentCurrency = element.find('span.input-group-addon');
		expect(currentCurrency.length).toBe(1);
		expect(currentCurrency.text()).toBe('GBP');
	});

	it('shows payer currency after clicking to switch direction', function () {
		var directiveElement = angular.element('<mypayments-pay-amount ng-model="fakePayment" name="amount"></mypayments-pay-amount>');
		var element = $compile(directiveElement)($rootScope);
		var controller, currentCurrency;

		setPayee('GBP');
		setPayer('USD');

		$rootScope.$digest();
		currentCurrency = element.find('span.input-group-addon');
		expect(currentCurrency.length).toBe(1);

		// Before switch shows payee currency
        expect(currentCurrency.text()).toBe('GBP');

		controller = element.controller('mypaymentsPayAmount');
		controller.changeSource();

		// Should show payer currency after switching
		$rootScope.$digest();
		expect(currentCurrency.text()).toBe('USD');
	});

	it('does not show a switch link when both currencies are the same', function () {
		var directiveElement = angular.element('<mypayments-pay-amount ng-model="fakePayment" name="amount"></mypayments-pay-amount>');
		var element = $compile(directiveElement)($rootScope);

		setPayee('GBP');
		setPayer('GBP');

		$rootScope.$digest();
		expect(element.find('span.input-group-addon').length).toBe(1);
		expect(element.find('a').length).toBe(0);
	});

	it('uses the payee payeeAmount value by default', function () {
		var directiveElement = angular.element('<mypayments-pay-amount ng-model="fakePayment" name="amount"></mypayments-pay-amount>');
		var element = $compile(directiveElement)($rootScope);
		var inputElement;

		setPayee('USD', '1,000');

		$rootScope.$digest();
		inputElement = element.find('input');
		expect(inputElement.length).toBe(1);
		expect(inputElement.val()).toBe('1,000');
	});

	it('moves the amount to the payAmount when switching currency', function () {
		var directiveElement = angular.element('<mypayments-pay-amount ng-model="fakePayment" name="amount"></mypayments-pay-amount>');
		var element = $compile(directiveElement)($rootScope);
		var controller, inputElement;

		setPayee('USD', '1,000');
		setPayer('EUR');

		$rootScope.$digest();

		controller = element.controller('mypaymentsPayAmount');
		controller.changeSource();
		
		expect($rootScope.fakePayment.payerAmount).toBe('1,000');
	});
});