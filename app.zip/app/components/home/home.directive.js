angular.module('app.components.home.directive', [
	'ux.form.fileChange.directive',
	'app.config',
	'app.directives'
])
.directive('applicationHome', function (config) {
	return {
		restrict: 				'E',
		scope: {
			file:				'=',
			errors:				'='
		},
		templateUrl: config.templateBasePath + 'app/components/home/home.directive.html',
		controller: function($scope) {			
			
			// Initialization of errors table
			var initErrors = function() {
				$scope.headers = [
					{
						field:			'column',
						name:			'Column'
					},
					{
				    	field:			'error',
				    	name:			'Error'
				    },
					{
				    	field:			'row',
				    	name:			'Row'
				    }
				];
			};
			
			// Initialization method
			var init = function() {
				// Initialization of errors table
				initErrors();
				

			};
			
			// Triggers initialization method when controller loads
			init();
			
		}
	};
});