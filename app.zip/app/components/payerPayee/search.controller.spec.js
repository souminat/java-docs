describe("app.components.payerPayee.search.controller.spec", function () {

    var $httpBackend, $controller, searchController, selectModel;

    beforeEach(module('templates'));
    beforeEach(module('app.services.payerPayee'));
    beforeEach(module('app.components.payerPayee.search.controller'));

    beforeEach(module(function($provide) {
        $provide.service('$uibModalInstance', function() {
            this.close = jasmine.createSpy('close');
        });
    }));

    beforeEach(inject(function($injector){
        $httpBackend = $injector.get('$httpBackend');
        $controller = $injector.get('$controller');
        selectModel = jasmine.createSpy('selectModel');

        searchController = $controller('payerPayeeSearchController', {
            searchType: 'payer',
            selectModel: selectModel
        });
    }));

    describe('setIndex', function () {
        var mockResults = function (count) {
            var i, results = [];
            for (i = 0; i < count; i++) {
                results[i] = {};
            }
            return results;
        };

        it('can not change index when there are no results', function () {
            var i;
            for (i = 0; i < 10; i++) {
                searchController.setIndex(i);
                expect(searchController.selectedIndex).toBe(0);
            }
        });

        it('can set index to any valid zero-based value based on result count', function () {
            var i, numResults = 5;
            searchController.results = mockResults(numResults);
            for (i = 0; i < numResults; i++) {
                searchController.setIndex(i);
                expect(searchController.selectedIndex).toBe(i);
            }
        });

        it('can not set an index beyond the range of the search results', function () {
            var numResults = 5;
            searchController.results = mockResults(5);

            // Negative numbers have no effect
            searchController.setIndex(-5);
            expect(searchController.selectedIndex).toBe(0);

            // Numbers greater than or equal to the results length are ignored
            searchController.setIndex(numResults + 2);
            expect(searchController.selectedIndex).toBe(0);
            searchController.setIndex(numResults);
            expect(searchController.selectedIndex).toBe(0);
        });

        it('can change page when index is not on the current page', function () {
            var numResults = searchController.pageSize * 2;
            searchController.results = mockResults(numResults);
            spyOn(searchController, 'changePage');

            // Changing to an index on the current page will not call changePage...
            searchController.setIndex(2);
            expect(searchController.changePage).not.toHaveBeenCalled();

            searchController.setIndex(searchController.pageSize);
            expect(searchController.selectedIndex).toBe(searchController.pageSize);
            expect(searchController.changePage).toHaveBeenCalled();
        });
    });

});