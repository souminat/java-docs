angular.module('app.components.payerPayeeDetails.directive', [
	'ct.loadingOverlay',
	'app.config',
    'app.directives'
])

.directive('mypaymentsPayerPayeeDetails', function (config) {
    return {
        restrict: 'E',
        scope: {
            ngModel: '='
        },
        templateUrl: config.templateBasePath + 'app/components/payerPayee/payerPayeeDetails.directive.html',

        controllerAs: 'ppd',
        bindToController: true,

        controller:function($timeout) {
            var ppd = this;

            angular.extend(ppd, {
                changeOwner: function() {
                    ppd.ngModel.tradeEntityName = '';
                    ppd.ngModel.tCode = '';
                    ppd.ngModel.umbrellaName = '';
                    ppd.ngModel.mdmPortfolioCode = '';
                    ppd.ngModel.bankAcct = {};

                    $timeout(function() {
                        ppd.focusInput();
                    }, 0);
                },

                isLoadingBankAccount: function () {
                    return _.has(ppd.ngModel.bankAcct, '$resolved') && !ppd.ngModel.bankAcct.$resolved;
                }
            });
        },

        link: function (scope, element, attrs, ctrl) {
            ctrl.focusInput = function() {
                element.prev().find('input').focus();
            }
        }
    };
});
