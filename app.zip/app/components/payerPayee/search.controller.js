angular.module('app.components.payerPayee.search.controller', [
	'ct.loadingOverlay',
	'app.directives'
])
    .controller('payerPayeeSearchController', function ($uibModalInstance, $timeout, payerPayeeManager, searchType, selectModel) {
        var pps = this;
        var searchInterval = 600; // delay to simulate wait for typing to finish before searching
        var searchTimer;
        var minimumCharacters = 4;

        // Public properties/functions
        angular.extend(pps, {
            searchType: (searchType === 'payer') ? 'Source' : 'Payee',
            model: {},
            results: [],
            currentPage: 1,
            offset: 0,
            pageSize: 8,
            selectedIndex: 0,

            close: function () {
                $uibModalInstance.close();
            },

            onChange: function () {
                pps.results = [];
                $timeout.cancel(searchTimer);
                searchTimer = $timeout(pps.search, searchInterval);
            },

            search: function () {
                if (!pps.remainingCharacters()) {
                    pps.results = payerPayeeManager.advancedSearch(pps.model);
                    pps.results.$promise.then(function (response) {
                        pps.results = response;
                        pps.setIndex(0);
                    });
                }
            },

            remainingCharacters: function () {
                var count, remaining, countFn = function (memo, val, index) {
                    if (index === 'currencyCode') {
                        return memo;
                    }
                    return memo + val.length;
                };

                count = _.reduce(pps.model, countFn, 0);
                remaining = minimumCharacters - count;

                return remaining > 0 ? remaining : 0;
            },

            onKeydown: function ($event) {
                var keysEnum = {up: 38, down: 40, enter: 13};
                switch ($event.keyCode) {
                    case keysEnum.up:
                        pps.setIndex(pps.selectedIndex - 1);
                        break;
                    case keysEnum.down:
                        pps.setIndex(pps.selectedIndex + 1);
                        break;
                    case keysEnum.enter:
                        if (pps.results.length) {
                            pps.selectPayerPayee(pps.selectedIndex - pps.offset);
                        }
                        break;
                }
            },

            setIndex: function (index) {
                var nextOffset;
                if (index < 0 || index >= pps.results.length) {
                    return;
                }
                pps.selectedIndex = index;

                // Also check if we need to change the current page
                nextOffset = Math.floor(index / pps.pageSize);
                if (nextOffset !== pps.offset) {
                    pps.currentPage = Math.ceil((index + 1) / pps.pageSize);
                    pps.changePage();
                }
            },

            isLoadingResults: function () {
                return _.has(pps.results, '$resolved') && !pps.results.$resolved;
            },

            selectPayerPayee: function (index) {
                pps.close();
                selectModel(pps.results[index + pps.offset]);
            },

            showPagination: function () {
                return pps.totalItems() > pps.pageSize;
            },

            changePage: function () {
                pps.offset = (pps.currentPage - 1) * pps.pageSize;
            },

            totalItems: function () {
                return pps.results.length;
            },

            hasResults: function () {
                return _.has(pps.results, '$resolved') && pps.results.$resolved;
            },

            reset: function () {
                pps.model = {};
                pps.results = [];
            }
        });
    });