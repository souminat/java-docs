angular.module('app.components.payerPayee.directive', [
    'app.config',
    'app.services',
    'app.directives'
])

    .directive('mypaymentsPayerPayee', function (config) {
        return {
            restrict: 'E',
            scope: {
                ngModel: '=',
                name: '@',
                ngRequired: '=',
                showInactive: '=',
                type: '@'           // payer/payee
            },
            templateUrl: config.templateBasePath + 'app/components/payerPayee/payerPayee.directive.html',
            controllerAs: 'pp',
            bindToController: true,

            controller: function ($scope, $uibModal, $timeout, $q, payerPayeeManager, bankAccountManager) {
                var pp = this,
                    searchInterval = 400,
                    searchTimer,
                    contains,
                    filterPayerPayees;

                // Private functions
                contains = function (str, term) {
                    return angular.isString(str) && str && str.toLowerCase().indexOf(term.toLowerCase()) > -1;
                };

                filterPayerPayees = function (response, searchTerm) {
                    var lastTCode, i, results;

                    results = _.filter(response, function (val) {
                        return contains(val.umbrellaName, searchTerm) ||
                            contains(val.tradeEntityName, searchTerm) ||
                            contains(val.portfolioCode, searchTerm) ||
                            contains(val.tCode, searchTerm);
                    });

                    pp.noResults = (results.length === 0);

                    lastTCode = '';
                    for (i in results) {
                        results[i].showTCode = (results[i].tCode !== lastTCode);
                        lastTCode = results[i].tCode;
                    }

                    return results;
                };

                // Public interface
                angular.extend(pp, {
                    nextInput: null,
                    selectedModel: null,
                    noResults: false,
                    filteredAccounts: [],
                    lastSearchTerm: null,

                    getFilteredAccounts: function (searchTerm) {
                        var deferred = $q.defer();

                        $timeout.cancel(searchTimer);

                        if (pp.lastSearchTerm && contains(searchTerm, pp.lastSearchTerm)) {
                            deferred.resolve(filterPayerPayees(pp.filteredAccounts, searchTerm));
                        } else {
                            searchTimer = $timeout(function () {
                                payerPayeeManager.search(searchTerm).then(function(response) {
                                    // Cache the last search term that retrieved results, so that additional
                                    // characters entered can further filter these results rather than
                                    // making an unnecessary search request
                                    pp.lastSearchTerm = searchTerm;
                                    pp.filteredAccounts = filterPayerPayees(response, searchTerm);
                                    deferred.resolve(pp.filteredAccounts);
                                });

                            }, searchInterval);
                        }

                        return deferred.promise;
                    },

                    selectModel: function (model) {
                        pp.selectedModel = model;
                        pp.onSelect();
                    },

                    onSelect: function () {
                        var nextInput;
                        pp.ngModel.tradeEntityName = pp.selectedModel.tradeEntityName;
                        pp.ngModel.umbrellaName = pp.selectedModel.umbrellaName;
                        pp.ngModel.mdmPortfolioCode = pp.selectedModel.portfolioCode;
                        pp.ngModel.tCode = pp.selectedModel.tCode;

                        if (pp.selectedModel.bankAcct) {
                            pp.ngModel.bankAcct = pp.selectedModel.bankAcct;
                        } else {
                            pp.ngModel.bankAcct = bankAccountManager.get(pp.selectedModel.tCode);
                            pp.ngModel.bankAcct.$promise.then(function (result) {
                                pp.ngModel.bankAcct = result;
                            });
                        }

                        pp.ngModel.$selectedModel = angular.copy(pp.selectedModel);
                        pp.selectedModel = null;

                        nextInput = pp.nextInput();
                        if (nextInput) {
                            nextInput.focus();
                        }
                    },

                    search: function() {
                        $uibModal.open({
                            templateUrl: config.templateBasePath + 'app/components/payerPayee/internalSearch.controller.html',
                            controller: 'payerPayeeSearchController as pps',
                            bindToController: true,
                            resolve: {
                                searchType: function () {
                                    return pp.name;
                                },
                                selectModel: function () {
                                    return pp.selectModel;
                                }
                            }
                            // size: 'lg'
                        });
                    }
                });
            },

            link: function (scope, element, attrs, ctrl) {
                var findNextInput = function (parentElem) {
                    var input, next = parentElem.next();
                    if (!next.length) {
                        return null;
                    }
                    input = next.find('input,select,textarea');

                    return input.length ? input : findNextInput(next);
                };

                // Cannot parse the next input yet as it may not exist in the DOM.
                // Set the function on the controller so that the next input may be retrieved when needed
                ctrl.nextInput = function() {
                    return findNextInput(element.closest('application-form-item'));
                }
            }
        };
    })

    .directive('mypaymentsPayerPayeeValidation', function () {
        return {
            require: ['ngModel', '^mypaymentsPayerPayee'],
            restrict: 'A',
            scope: false,
            link: function ($scope, $element, $attrs, $ctrl) {
                var modelCtrl = $ctrl[0],
                    payerPayeeCtrl = $ctrl[1];

                modelCtrl.$validators.queryMatch = function (modelValue, viewValue) {
                    var value = modelValue || viewValue;
                    return value && !payerPayeeCtrl.noResults;
                }
            }
        };
    });
