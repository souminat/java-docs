describe("app.components.payerPayeeDetails.directive.spec", function () {

    var $compile, $rootScope;

    beforeEach(module('templates'));
    beforeEach(module('app.services.currency'));
    beforeEach(module('app.services.currency.mock'));
    beforeEach(module('app.components.payerPayeeDetails.directive'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');

        $rootScope.fakePayer = {
            tradeEntityName: 'Entity',
            tCode: 'T123',
            umbrellaName: 'Umbrella',
            mdmPortfolioCode: 'XX123SAD324',
            bank: {
                name: 'GE Bank'
            }
        };
    }));

    it('clears payer/payee attributes when changing owner', function () {
        var element = angular.element('<mypayments-payer-payee-details ng-model="fakePayer"></mypayments-payer-payee-details>');
        $compile(element)($rootScope);
        $rootScope.$digest();
        element.controller('mypaymentsPayerPayeeDetails').changeOwner();
        expect($rootScope.fakePayer.tradeEntityName).toBe('');
    });
});