angular.module('app.components.typeaheadassign.directive', [
	'ui.router',
	'app.config',
	'app.services'
])
.directive('applicationAssignTypeahead', function (config) {
	return {
		restrict: 				'E',
		scope: {
			label:				'@',
			id:					'@propertyId',
			name:				'@propertyName',
			name2:				'@propertyName2',
			ngRequestId:		'=',
			ngValue:		    '=',
			source:				'=',
			source2:			'=',
			async:				'=',
			callback:			'=',
			ngModel:			'=',
			ngRequired:			'=',
			icon:				'=',
			minLength:			'@',
            showallOnclick:		'@',
            placeholder:		'@'
        },
		templateUrl: config.templateBasePath + 'app/components/typeahead/typeaheadassign.directive.html',
		bindToController: true,
        controllerAs: 'at',
		controller: function($scope,$state, $q,paymentRequestManager) {
			
			var at = this;
			var assignToPerson = {};
			
			
			// Public properties/functions
            angular.extend(at, {
            	isSelected: false,
            	isLoading: false,
            	/**
            	 * Method triggered when user select an option
            	 */
            	onSelect: function() {
    				// Change the flag to indicate that a value was selected
    				at.isSelected = true;
    				// $scope.$emit('changeTypeahead', at.ngModel);
    				
    				console.log($(this)[0].ngModel);
    				console.log($(this)[0].ngRequestId);
    				console.log($(this)[0].ngValue);
    				//if($("application-assign-typeahead").attr("property-assignTo") === "true"){
    					//Need to call Assign To Service
    					//var assignToSSO = $(this)[0].ngModel;
    					//var requestId = $(this)[0].ngRequestId;

    					assignToPerson.requestId = $(this)[0].ngRequestId;
    					assignToPerson.assignToSSO = $(this)[0].ngModel;
    					
    					//return paymentRequestManager.assignPersonToRequest(requestId,sso);
    					 paymentRequestManager.assignPersonToRequest(assignToPerson);
    					
    					
    					//$window.location.reload();
    					$state.go('pages.payments');
    					$state.reload();
    					
    				//}
    			},
    			filterDataSource: function(searchTerm) {
                    
    				var defer = $q.defer();
    				
    				searchTerm = searchTerm.trim();
                    var result = [];
                    var data;
                    
                    if(at.callback) {
                    	at.isLoading = true;
                    	promise = at.callback(searchTerm);
                    	promise.then(function(callbackResult) {
                    		at.isLoading = false;
                    		defer.resolve(callbackResult);
                    	});
                    } else {
                    	result =  _.filter(at.source, function(obj) { 
        					var searchedProperty = obj[at.name]; 
        					if((searchedProperty) && (searchedProperty.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1 )) {
        						return obj;
        					}
        				});
                    	
                    	if(result.length === 0) {
        					at.noResults = true;
        				} else { 
        					at.noResults = false;
        				}
                    	
                    	data = _.sortBy(result, at.name);
                    	defer.resolve(data);
                    }
    				
    				return defer.promise;
    			},
    			formatSelection: function() {
    				var text = undefined;
    				text=at.ngModel;
    				/*if(at.name2) {
    					if(at.ngModel) {
        					text = at.ngModel[at.name] + ' - ' + at.ngModel[at.name2];
        				}
    				} else {
    					if(at.ngModel) {
    						if(at.name){
    							text = at.ngModel[at.name];
    						}else{
    							text = at.ngModel;
    						}
        					
        				}
    				}*/
    				return text;
    			},
    			getName: function(obj) {
    				var text = undefined;
    				text=obj;
    				/*if(at.name2) {
    					if(obj) {
        					text = obj[at.name] + ' - ' + obj[at.name2];
        				}
    				} else {
    					if(obj) {
    						if(at.name){
    							text = obj[at.name];
    						}else{
    							text=obj;
    						}
        				}
    				}*/
    				
    				return text;
    			}
            });
		}
	};
}).directive('typeaheadAssignFocus', function () {1
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModel) {

            //trick the type ahead to show all on focus using ' ' string
            element.bind('click', function () {
                var viewValue = ngModel.$viewValue;
                ngModel.$setViewValue(viewValue || ' ');
            });
        }
    };
});