angular.module('app.components.typeahead.directive', [
	'app.config'
])
.directive('applicationTypeahead', function (config) {
	return {
		restrict: 				'E',
		scope: {
			label:				'@',
			id:					'@propertyId',
			name:				'@propertyName',
			name2:				'@propertyName2',
			source:				'=',
			async:				'=',
			callback:			'=',
			ngModel:			'=',
			ngRequired:			'=',
			icon:				'=',
			minLength:			'@',
            showallOnclick:		'@',
            placeholder:		'@'
        },
		templateUrl: config.templateBasePath + 'app/components/typeahead/typeahead.directive.html',
		bindToController: true,
        controllerAs: 'at',
		controller: function($scope, $q) {
			
			var at = this;
			
			
			// Public properties/functions
            angular.extend(at, {
            	isSelected: false,
            	isLoading: false,
            	/**
            	 * Method triggered when user select an option
            	 */
            	onSelect: function() {
    				// Change the flag to indicate that a value was selected
    				at.isSelected = true;
    				// $scope.$emit('changeTypeahead', at.ngModel);
    			},
    			filterDataSource: function(searchTerm) {
                    
    				var defer = $q.defer();
    				
    				searchTerm = searchTerm.trim();
                    var result = [];
                    var data;
                    
                    if(at.callback) {
                    	at.isLoading = true;
                    	promise = at.callback(searchTerm);
                    	promise.then(function(callbackResult) {
                    		at.isLoading = false;
                    		defer.resolve(callbackResult);
                    	});
                    } else {
                    	result =  _.filter(at.source, function(obj) { 
        					var searchedProperty = obj[at.name]; 
        					if((searchedProperty) && (searchedProperty.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1 )) {
        						return obj;
        					}
        				});
                    	
                    	if(result.length === 0) {
        					at.noResults = true;
        				} else { 
        					at.noResults = false;
        				}
                    	
                    	data = _.sortBy(result, at.name);
                    	defer.resolve(data);
                    }
    				
    				return defer.promise;
    			},
    			formatSelection: function() {
    				var text = undefined;
    				
    				if(at.name2) {
    					if(at.ngModel) {
        					text = at.ngModel[at.name] + ' - ' + at.ngModel[at.name2];
        				}
    				} else if(at.name == 'payee_name') {
    					if(at.ngModel){
    						text = at.ngModel;
    					}
    				}else if(at.name == 'payer_name') {
    					if(at.ngModel){
    						text = at.ngModel;
    					}
    				}else if(at.name == 'request_Type') {
    					if(at.ngModel){
    						text = at.ngModel;
    					}
    				}  else if(at.name == 'status') {
    					if(at.ngModel){
    						text = at.ngModel;
    					}
    				}  
    				else {
    					if(at.ngModel) {
        					text = at.ngModel[at.name];
        				}
    				}
    				
    				return text;
    			},
    			getName: function(obj) {
    				var text = undefined;
    				
    				if(at.name2) {
    					if(obj) {
        					text = obj[at.name] + ' - ' + obj[at.name2];
        				}
    				} else if(at.name == 'payee_name') {
    					if(obj){
    						text = obj;
    					}
    				} else if(at.name == 'payer_name') {
    					if(obj){
    						text = obj;
    					}
    				}
    				else if(at.name == 'request_Type') {
    					if(obj){
    						text = obj;
    					}
    				}
    				else if(at.name == 'status') {
    					if(obj){
    						text = obj;
    					}
    				}
    				else {
    					if(obj) {
        					text = obj[at.name];
        				}
    				}
    				
    				return text;
    			}
            });
		}
	};
}).directive('typeaheadFocus', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModel) {

            //trick the type ahead to show all on focus using ' ' string
            element.bind('click', function () {
                var viewValue = ngModel.$viewValue;
                ngModel.$setViewValue(viewValue || ' ');
            });
        }
    };
});