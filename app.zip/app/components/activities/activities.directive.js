angular.module('app.components.activities.directive', [
    'app.config',
    'app.filters'
])
.directive('mypaymentsActivities', ['config', function (config) {
    return {
        restrict: 				'E',
        require: 				'?ngModel',
        scope: {
            ngModel: 			'=',
            title:				'@'
        },
        templateUrl: config.templateBasePath + 'app/components/activities/activities.directive.html',
        bindToController: true,
        controllerAs: 'activities',
        controller: function ($scope) {

        	var activities = this;
        	
        	// Public properties/functions
            angular.extend(activities, {
            	
            });
        }
    };
}]);