angular.module('app.components.countryPicker.directive', [
		'app.config',
		'app.services'
	])

    .directive('applicationCountryPicker', function (config) {
        return {
            restrict: 'E',
            scope: {
                name: '@',
                ngModel: '=',
                ngRequired: '=?',
                ngChange: '=?',
                ngKeydown: '=?',
                placeholder: '@'
            },
            templateUrl: config.templateBasePath + 'app/components/country/countryPicker.directive.html',

            controllerAs: 'countrypicker',
            bindToController: true,

            controller: function ($scope, CountryManager) {
                var countrypicker = this,
                    keydownBypassed = false,
                    countries;

                $scope.$watch('countrypicker.ngModel', function () {
                	countrypicker.onChange();
                }, true);

                // Private variables/functions

                countries = CountryManager.all();

                // Public properties/methods
                if (!countrypicker.ngChange) {
                	countrypicker.ngChange = _.noop;
                }
                if (!countrypicker.ngKeydown) {
                    countrypicker.ngKeydown = _.noop;
                }

                angular.extend(countrypicker, {
                    ngRequired: !!countrypicker.ngRequired,
                    getCountries: function () {
                        if (_.has(countries, '$promise')) {
                        	countries.$promise.then(function () {
                        		countries = CountryManager.all();
                            });

                            return [];
                        }
                        
                        countries = _.sortBy(countries, 'cntry_iso_2_code');
                        return countries;
                    },
                    getFilteredCountries: function (searchTerm) {
                        var allCountries = countrypicker.getCountries(),
                            hasRecent = _.has(allCountries, 'recent'),
                            all = [],
                            recent = [],
                            filterCountries,
                            mapCountries;

                        searchTerm = searchTerm === ' ' ? '' : searchTerm;

                        filterCountries = function (val) {
                            if (_.has(val, 'cntry_iso_2_code')) {
                                val = val.cntry_iso_2_code;
                            }
                            return val.substr(0, searchTerm.length).toLowerCase() === searchTerm.toLowerCase();
                        };

                        mapCountries = function (val) {
                            var out = {'country': val.cntry_iso_2_code};
                            if (hasRecent) {
                                out.type = '';
                            }
                            return out;
                        };

                        if (hasRecent) {
                            recent = _.map(_.filter(allCountries.recent, filterCountries), mapCountries);
                            all = _.map(_.filter(allCountries.all, filterCountries), mapCountries);

                            //set only the first item's group name
                            if (recent.length > 0) {
                                recent[0].type = 'Recent';
                            }
                            if (all.length > 0) {
                                all[0].type = 'All';
                            }

                            all = _.union(recent, all);
                        } else {
                            all = _.map(_.filter(allCountries, filterCountries), mapCountries);
                        }

                        //if there is just one, set the model
                        if (all.length === 1 && all[0].country.toLowerCase() === searchTerm.toLowerCase()) {
                        	countrypicker.ngModel = all[0].country;
                            return [];
                        }

                        return all;
                    },
                    isCountryValid: function(countryText) {
                    	allCountries = countrypicker.getCountries();
                    	
                    	countryFounded = _.find(allCountries, function(country) {
                    		return _.isEqual(country.cntry_iso_2_code, countryText);
                    	}); 
                    	
                    	var flag = false;
                    	
                    	if(!_.isUndefined(countryFounded)) {
                    		flag = true;
                    	}
                		
                        return flag;
                    },
                    selectCountry: function($item, $model, $label, $event) {
                    	var isCountryValid = countrypicker.isCountryValid($model);
                    	
                    	if(isCountryValid) {
                    		countrypicker.form[countrypicker.name].$setValidity('countryValidator', true);
                    	} else {
                    		countrypicker.form[countrypicker.name].$setValidity('countryValidator', false);
                    	}
                    },
                    /**
                     * Convert ngModel (currency code) to upper case
                     */
                    onChange: function () {
                        if (!_.isUndefined(countrypicker.ngModel)) {
                        	countrypicker.ngModel = countrypicker.ngModel.toUpperCase();
                            keydownBypassed = countrypicker.ngModel.length && (countrypicker.ngModel.length < 3);
                        }
                        countrypicker.ngChange();
                    },
                    onKeydown: function ($event) {
                        var keyChar,
                            keyCode = $event.keyCode,
                            keysEnum = {up: 38, down: 40, enter: 13, backspace: 8, delete: 46};

                        if (!keydownBypassed) {
                        	countrypicker.ngKeydown($event);
                        }

                        // If a letter was entered or removed, then allow typeahead to control the keydown event
                        keyChar = String.fromCharCode(keyCode);
                        if (/[a-zA-Z]/.test(keyChar) || keyCode === keysEnum.backspace || keyCode === keysEnum.delete) {
                            keydownBypassed = true;
                        }

                        // Pressing enter while bypassing keydown means that the typeahead will close, so we can
                        // re-enable handling keydown events
                        if (keydownBypassed && keyCode === keysEnum.enter) {
                        	countrypicker.enableKeydown();
                        }
                    },
                    onFocus: function () {
                        keydownBypassed = !countrypicker.ngModel.length;
                    },
                    enableKeydown: function () {
                        keydownBypassed = false;
                    }
                });
            },

            link: function (scope, element, attr, ctrl) {
                // Listen to keydown events on the input
                // (can't use ng-keydown in the template as it would be overridden by the typeahead directive)
                element.on('keydown', 'input', ctrl.onKeydown);

                // Can't simply enable/disable keydown when clicking the input - whether the typeahead
                // is displayed will depend on whether anything has been typed. So let the controller handle this.
                element.on('click', 'input', ctrl.onFocus);

                // Losing focus or clicking a typeahead link will hide the typeahead,
                // so it is safe to re-enable handling keydown events
                element.on('blur', 'input', ctrl.enableKeydown);
                element.on('click', '.typeahead-link', ctrl.enableKeydown);
            }
        };
    })
    //popup typeahead on click (using on focus breaks validation)
    .directive('typeaheadFocus', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModel) {

                //trick the type ahead to show all on focus using ' ' string
                element.bind('click', function () {
                    var viewValue = ngModel.$viewValue;
                    ngModel.$setViewValue(viewValue || ' ');
                });
            }
        };
    })
    //custom validator for country typeahead
    .directive('countryValidator', function () {
        return {
            restrict: 'A',
        	require: 'ngModel',
            link: function (scope, element, attr, ctrl) {
            	
            	function countryValidator(ngModelValue) {
                    
            		var allCountries, countryFounded;
            		
            		var isCountryValid = scope.countrypicker.isCountryValid(ngModelValue);
            		
            		if(isCountryValid) {
                		scope.countrypicker.form[scope.countrypicker.name].$setValidity('countryValidator', true);
                	} else {
                		scope.countrypicker.form[scope.countrypicker.name].$setValidity('countryValidator', false);
                	}
            		
            		/*
            		allCountries = scope.countrypicker.getCountries();
                	
                	countryFounded = _.find(allCountries, function(country) {
                		return _.isEqual(country.cntry_iso_2_code, ngModelValue);
                	});
            		
                	if(!_.isUndefined(countryFounded)) {
                		ctrl.$setValidity('countryValidator', true);
                	} else {
                		ctrl.$setValidity('countryValidator', false);
                	}
                	*/
            		
                    return ngModelValue;
                }

                ctrl.$parsers.push(countryValidator);
            }
        };
    });