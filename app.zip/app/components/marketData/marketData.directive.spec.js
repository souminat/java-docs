describe('app.components.marketData.directive', function () {

    var $compile, $rootScope, $httpBackend, $controller, marketData, config, marketRateCache;

    function getController(payerCurrency, payerAmount, payeeCurrency, payeeAmount) {
        var controller;
        $rootScope.payment = {
            payerCurrency: payerCurrency,
            payerAmount: payerAmount,
            payeeCurrency: payeeCurrency,
            payeeAmount: payeeAmount
        };

        // Ensure the paymentSummary ("controller as" value) is added to the scope to allow testing watch expressions
        controller = $controller('paymentSummaryController', {$scope: $rootScope, marketData: marketData});
        $rootScope.paymentSummary = controller;

        return controller;
    }

    function expectRate(rate, inverseRate) {
        if (typeof inverseRate === 'undefined') {
            inverseRate = 1 / rate;
        }
        $httpBackend.expectPOST(config.apiBasePath + 'api/mypayments/v1/retrieveMarketRate').respond({
            'dateSetResponseList': [
                {
                    'rateValue': rate,
                    'inverseRateValue': inverseRate,
                    'inverseMatch': false
                }
            ]
        });
    }

    beforeEach(module('app.services.lov.mock'));
    beforeEach(module('app.services.marketData.mock'));
    beforeEach(module('app.services.marketData'));
    beforeEach(module('app.components.marketData.directive'));
    beforeEach(module('templates'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
        $httpBackend = $injector.get('$httpBackend');
        $controller = $injector.get('$controller');
        marketData = $injector.get('marketData');
        config = $injector.get('config');
        marketRateCache = $injector.get('marketRateCache');
    }));

    // Controller method tests
    describe('paymentSummaryController controller', function() {
        it('marks the pay amount as estimated when payee amount is provided', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expect(controller.isEstimated('payer')).toBeTruthy();
            expect(controller.isEstimated('payee')).toBeFalsy();
        });

        it('marks the payee amount as estimated when pay amount is provided', function () {
            var controller = getController('EUR', '1,000', 'GBP', null);
            expect(controller.isEstimated('payer')).toBeFalsy();
            expect(controller.isEstimated('payee')).toBeTruthy();
        });

        it('marks the payee amount as estimated when pay amount is provided', function () {
            var controller = getController('EUR', '1,000', 'GBP', null);
            expect(controller.isEstimated('payer')).toBeFalsy();
            expect(controller.isEstimated('payee')).toBeTruthy();
        });

        it('does not get the estimated rate when there are currencies missing', function () {
            var controller = getController(null, '1,000', null, null);
            // Do not flush. There shouldn't be any outstanding requests
            $httpBackend.verifyNoOutstandingExpectation();

            expect(controller.rate()).toBeNull();
        });

        it('does not get the estimated rate when currencies are the same', function () {
            getController('EUR', '1,000', 'EUR', null);
            // Do not flush. There shouldn't be any outstanding requests
            $httpBackend.verifyNoOutstandingExpectation();
        });

        it('returns the same amount for the non-specified field when currencies are the same', function () {
            var controller = getController('EUR', '1,000', 'EUR', null);
            expect(controller.amount('payer')).toBe(1000);
            expect(controller.amount('payee')).toBe(1000);

            controller = getController('EUR', null, 'EUR', '2,000');
            expect(controller.amount('payer')).toBe(2000);
            expect(controller.amount('payee')).toBe(2000);
        });

        it('caches both directions after making a market rate request', function () {
            getController('EUR', '1,000', 'GBP', null);
            expectRate('1.25', '0.8');
            $httpBackend.flush();
            expect(marketRateCache.get('EURGBP')).toBe(1.25);
            expect(marketRateCache.get('GBPEUR')).toBe(0.8);
        });

        it('shows the payment rate in the direction of the pay to the payee currency', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expectRate('1.25', '0.8');
            $httpBackend.flush();
            expect(controller.rate()).toBe(1.25);
            expect(controller.paymentRate()).toBe(0.8);
        });

        it('shows the payment rate in the direction of the pay to the payee currency', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expectRate('1.25', '0.8');
            $httpBackend.flush();
            expect(controller.rate()).toBe(1.25);
            expect(controller.paymentRate()).toBe(0.8);
        });

        it('has the same payment rate and rate when specifying the payment amount', function () {
            var controller = getController('EUR', '1,000', 'GBP', null);
            expectRate(1.25);
            $httpBackend.flush();
            expect(controller.rate()).toBe(controller.paymentRate());
        });

        it('calculates the non-specified amount using the market rate', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expectRate('1.25', '0.8');
            $httpBackend.flush();
            expect(controller.amount('payer')).toBe(1250);
        });

        it('sets rate error when failed to load market rate', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            $httpBackend.expectPOST(config.apiBasePath + 'api/mypayments/v1/retrieveMarketRate').respond(500, {});
            $httpBackend.flush();
            expect(controller.rateError).toBeTruthy();
        });

        it('flips rate when changing payment direction', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expectRate(1.25, 0.8);
            $httpBackend.flush();
            expect(controller.rate()).toBe(1.25);

            // Flip the payment direction...
            controller.payment.payerAmount = '1,000';
            controller.payment.payeeAmount = null;
            $rootScope.$apply();

            expect(controller.rate()).toBe(0.8);
            // Assert that swapping the direction does not look up a new rate - both directions should have been cached
            $httpBackend.verifyNoOutstandingExpectation();
        });

        it('looks up new rate when changing currency', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expectRate(1.13);
            $httpBackend.flush();
            expect(controller.rate()).toBe(1.13);

            // Change the payment currency...
            expectRate(1.25);
            controller.payment.payerCurrency = 'USD';

            $rootScope.$digest();
            $httpBackend.flush();

            expect(controller.rate()).toBe(1.25);
        });

        it('looks up new rate when changing currency', function () {
            var controller = getController('EUR', null, 'GBP', '1,000');
            expectRate(1.13);
            $httpBackend.flush();
            expect(controller.rate()).toBe(1.13);

            // Change the payment currency...
            expectRate(1.25);
            controller.payment.payerCurrency = 'USD';

            $rootScope.$digest();
            $httpBackend.flush();

            expect(controller.rate()).toBe(1.25);
        });
    });


    // Directive element tests
    describe('mypaymentsPayAmount directive', function() {

        beforeEach(function () {
            $rootScope.fakePayment = {
                payerCurrency: 'EUR',
                paeryAmount: null,
                payeeCurrency: 'GBP',
                payeeAmount: 1000
            }
        });

        it('displays the estimated payment conversion rate when specifying payee amount', function () {
            var directiveElement = angular.element('<payment-summary payment="fakePayment"></mypayments-pay-amount>');
            var element = $compile(directiveElement)($rootScope);

            expectRate(1.25, 0.8);
            $httpBackend.flush();
            $rootScope.$digest();

            expect(element.find('.rate').text()).toContain('0.8');
        });
    });
});
