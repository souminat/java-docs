angular.module('app.components.marketData.directive', [
	'ux.util.numeralFilter',
	'app.config',
	'app.services'
])

    .directive('paymentSummary', function (config) {
        return {
            restrict: 			'E',
            scope: {
                ngModel:		'=',
            	payment: 		'=',
                payee:			'=',
                payer:			'='
            },
            templateUrl: config.templateBasePath + 'app/components/marketData/marketData.directive.html',
            controller: 'paymentSummaryController as paymentSummary'
        };
    })

    .factory('marketRateCache', function ($cacheFactory) {
        return $cacheFactory('marketRates');
    })

    .controller('paymentSummaryController', function ($scope, marketData, marketRateCache) {
        
    	var parseNum, currentIndex;
        var paymentSummary = this;

        if(_.isUndefined(paymentSummary.ngModel)) {
        	paymentSummary.ngModel = {};
        }
        
        paymentSummary.rateError = false;
        paymentSummary.isExecuted = false;
        
        $scope.$watch('paymentSummary.payee', function(newPayee, oldPayee) {
        	if(!_.isEqual(newPayee, oldPayee) && !_.isUndefined(newPayee)) {
        		paymentSummary.getRate();
        	}
        });
        
        $scope.$watch('paymentSummary.payer', function(newPayer, oldPayer) {
        	if(!_.isEqual(newPayer, oldPayer) && !_.isUndefined(newPayer)) {
        		paymentSummary.getRate();
        	}
        });
        
        paymentSummary.getRate = function() {
        	if(!_.isEmpty(paymentSummary.payer)
        			&& !_.isEmpty(paymentSummary.payer.bankCurrency)
        			&& !_.isEmpty(paymentSummary.payee)
        			&& !_.isEmpty(paymentSummary.payee.bankCurrency)) {
        		paymentSummary.isLoading = true;
        		var promise = marketData.getSpotRate(paymentSummary.payer.bankCurrency, paymentSummary.payee.bankCurrency);
            	promise.$promise.then(function(result) {
            		paymentSummary.isLoading = false;
            		paymentSummary.rateError = false;
            		var elements = result.elements[0];
            		if(elements && elements.atrributes && elements.atrributes.length > 0) {
            			var exchangeRate = _.filter(elements.atrributes, function(rate) {
            				return _.isEqual(rate.attr_nm, 'XchRate'); 
            			});
            			if(exchangeRate.length > 0) {
            				paymentSummary.ngModel.spotRate = exchangeRate[0].attr_val;
            			}
            		} else {
            			paymentSummary.rateError = true;
            		}
            	}, function(error) {
            		paymentSummary.rateError = true;
            	});
        	}
        	if(!_.isEmpty(paymentSummary.payment) && !_.isEmpty(paymentSummary.payer) && !_.isEmpty(paymentSummary.payer.bankCurrency) && paymentSummary.payment.numberOfPayments > 0) {
        		paymentSummary.isLoading = true;
        		var promise = marketData.getSpotRate(paymentSummary.payer.bankCurrency, paymentSummary.payment.payeeCurrency);
            	promise.$promise.then(function(result) {
            		paymentSummary.isLoading = false;
            		paymentSummary.rateError = false;
            		var elements = result.elements[0];
            		if(elements && elements.atrributes && elements.atrributes.length > 0) {
            			var exchangeRate = _.filter(elements.atrributes, function(rate) {
            				return _.isEqual(rate.attr_nm, 'XchRate'); 
            			});
            			if(exchangeRate.length > 0) {
            				paymentSummary.ngModel.spotRate = exchangeRate[0].attr_val;
            			}
            		} else {
            			paymentSummary.rateError = true;
            		}
            	}, function(error) {
            		paymentSummary.rateError = true;
            	});
        	}
        }
        
        paymentSummary.amount = function (direction) {
            var rateAmount;
            
            if(paymentSummary.payment && paymentSummary.ngModel && paymentSummary.ngModel.spotRate) {
            	rateAmount = parseNum(paymentSummary.payment[direction + 'Amount']);
                rateAmount = (rateAmount / paymentSummary.ngModel.spotRate);
                paymentSummary.ngModel.payeeAmount = rateAmount;
                $scope.$emit('spotRateEmit', paymentSummary.ngModel);
            }
            
            return rateAmount;
        };

        paymentSummary.setPayment = function(event, payment) {
        	paymentSummary.payment = payment;
        };
        
        paymentSummary.setPayee = function(event, payee) {
        	paymentSummary.payee = payee;
        };
        
        paymentSummary.setPayer = function(event, payer) {
        	paymentSummary.payer = payer;
        };
        
        paymentSummary.channels = function() {
        	$scope.$on('sendPaymentBroadcast', paymentSummary.setPayment);
        	$scope.$on('sendPayeeBroadcast', paymentSummary.setPayee);
        	$scope.$on('sendPayerBroadcast', paymentSummary.setPayer);
        }

        paymentSummary.channels();
        
        // PRIVATE functions
        parseNum = function (source) {
            if (!source || typeof source !== 'string') {
                return source;
            }

            return +(source.replace(/[^0-9\.]/, ''));
        };
    });
