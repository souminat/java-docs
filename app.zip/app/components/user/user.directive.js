angular.module('app.components.user.directive', [
	'app.services'
])

.directive('mytrsUser', function userDirective(userManager) {

	return {
		restrict: 'E',
		scope: {
			sso: '@'
		},
		template: '<span ng-if="!user.fullName">{{sso}}</span><span>{{ user.fullName }}</span>',
		controller:function($scope) {
			$scope.user = userManager.get($scope.sso, {allowCache: true});
		}
	};

});