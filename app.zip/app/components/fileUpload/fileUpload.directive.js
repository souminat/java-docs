angular.module('app.components.fileUpload.directive', [
	'ux.form.fileChange.directive',
	'app.config',
	'app.directives'
])
.directive('applicationFileUpload', function (config) {
	return {
		restrict: 				'E',
		scope: {
			file:				'=',
			errors:				'='
		},
		templateUrl: config.templateBasePath + 'app/components/fileUpload/fileUpload.directive.html',
		controller: function($scope) {			
			
			// Upload file event handler
			$scope.changeFile = function(files) {
				var file = files[0];
				$scope.$emit('emitFile', file);				
			};
			
			// Initialization of errors table
			var initErrors = function() {
				$scope.headers = [
					{
						field:			'column',
						name:			'Column'
					},
					{
				    	field:			'error',
				    	name:			'Error'
				    },
					{
				    	field:			'row',
				    	name:			'Row'
				    }
				];
			};
			
			// Initialization of channels
			var initChannels = function() {
				$scope.$on('resetFile', function(event, args) {
					angular.element("input[type='file']").val(null);
				});
			};
			
			// Initialization method
			var init = function() {
				// Initialization of errors table
				initErrors();
				
				// Initialization of channels
				initChannels();
			};
			
			// Triggers initialization method when controller loads
			init();
			
		}
	};
});