angular.module('app.components.customTable.directive', [
	'ui.bootstrap',
	'app.config',
	'app.directives',
	'app.services'
])
.directive('applicationCustomTable', function (config, lov) {
	return {
		restrict: 				'E',
		scope: {
			id:					'@',
			linkId:				'=',
			async:				'=',
			pag:				'=',
			action:				'=',
			headers:			'=',
			data:				'=',
			total:				'=',
			start:				'=',
			limit:				'=',
			currentPage:		'='
			
		},
		templateUrl: config.templateBasePath + 'app/components/customTable/customTable.directive.html',
		bindToController: true,
        controllerAs: 'ct',
		controller: function($scope, $rootScope,$q, bankAccountManager,paymentRequestManager) {			
			
			var ct = this;
			 			
			angular.extend(ct, {
				entries: 10,
				sortReverse: false,
				propertyName: 'Request ID',

				
				/*//Get Preparer
				getPreparer: function(text) {
	            	var defer = $q.defer();
	            	var newArray =[];
	            	
	            	var criteria = {
	                    goldLeName: encodeURI(text),
	            		goldId: encodeURI(text)
	            	};
	            	
	            	//Testing
	            	var promise=$rootScope.preparers;
	            	for (var j=0; j<promise.length; j++) {
	                    if (promise[j].match(text)){
	                    	newArray.push(promise[j]);
	                    }
	                }
	            	
	            	if(_.has(promise, text)){
	            		console.log("In _.has");
	            		//newArray.push(promise);
	            	}
	            	
	            	promise=newArray;
	            	defer.resolve(promise);
	            	console.log(newArray);
	            	
	            	
	            	//working
	            	var promise=$rootScope.preparers;
	            	defer.resolve($rootScope.preparers);
	            	
	            	//var promise = bankAccountManager.getPreparer(criteria);
	            	//var promise = paymentRequestManager.getDashboardResults(criteria);
	            	//var result ={'0':'999999001'}
	            	//console.log(ct.total);
	            	//console.log(ct.payments.preparers);
	            	console.log($rootScope.preparers);
	            	
	            	promise.$promise.then(function(result) {
	            		
	            		console.log(result);
	            		console.log(result[0]);
	            	    ct.preparer = result[0];
	            		defer.resolve(result);
	            	});
	            	
	            	return defer.promise;
	            },*/
				
				/*
				 * Method executed when user clicks on pagination buttons
				 */
				
				
				changePagination: function(page) {
					// Set the start to one
					var start = 0;
					if(page > 1) {
						// Calculate the start depending of the selected page
						start = (page * ct.entries) - ct.entries;
					}
					$scope.$emit('customTableChangePagination', page, start);
				},
				/**
				 * Clicks on first button under pagination section
				 */
				firstPage: function() {
					ct.currentPage = 1;
					ct.changePagination(ct.currentPage);
				},
				/**
				 * Clicks on previous button under pagination section
				 */
				previousPage: function() {
					if(ct.currentPage > 1) {
						ct.currentPage = ct.currentPage - 1;
						ct.changePagination(ct.currentPage);
					}
				},
				/**
				 * Select a button in pagination
				 */
				setCurrentPage: function(newPage) {
					ct.currentPage = newPage;
					ct.changePagination(ct.currentPage);
				},
				/**
				 * Clicks on next button under pagination section
				 */
				nextPage: function() {
					if(ct.currentPage < ct.buttonSize) {
						ct.currentPage = ct.currentPage + 1;
						ct.changePagination(ct.currentPage);
					}
				},
				/**
				 * Clicks on last button under pagination section
				 */
				lastPage: function() {
					ct.currentPage = ct.buttonSize;
					ct.changePagination(ct.currentPage);
				},
				/**
				 * Hide the first buttons under pagination section
				 */
				hideFirstButtons: function() {
					var flag = true;
					if(ct.currentPage === 1) {
						flag = false;
					}
					return flag;
				},
				/**
				 * Hide the last buttons under pagination section
				 */
				hideLastButtons: function() {
					var flag = true;
					if(ct.currentPage === ct.buttonSize) {
						flag = false;
					}
					return flag;
				},
				/**
				 * Hide the pagination buttons if they far from current pagination (+- 2)
				 */
				isVisible: function(page) {
					var flag = false;
					// Shows the first and last button
					if( (page >= (ct.currentPage - 2)) && (page <= (ct.currentPage + 2)) ) {
						flag = true;
					}
					return flag;
				},
				/**
				 * Displays the left indicator under pagination section
				 */
				isLeftIndicatorVisible: function() {
					var flag = false;
					if(ct.currentPage >= 5) {
						flag = true;
					}
					return flag;
				},
				/**
				 * 
				 */
				isRightIndicatorVisible: function() {
					var flag = false;
					if( (ct.buttonSize - ct.currentPage) > 2 ) {
						flag = true;
					}
					return flag;
				},
				/**
				 * Get current entries to display it into pagination section
				 */
				getCurrentEntries: function() {
					var currentEntries = ct.currentPage * ct.entries;
					if( currentEntries > ct.total ) {
						currentEntries = ct.total;
					}
					return currentEntries;
				},
				/**
				 * Validates if the current page is selected
				 */
				isCurrentPage: function(page) {
					var flag = false;
					if(ct.currentPage === page) {
						flag = true;
					}
					return flag;
				},
				/**
				 * Methods to create a button array used to create the buttons in pagination section
				 */
				createButtonsArray: function(size) {
					var buttonsArray = [];
					for (i = 1; i <= size; i++) { 
					    buttonsArray.push(i);
					}
					return buttonsArray;
				},
				/**
				 * Calculate the number of entries displayed in left section of pagination
				 */
				calculateEntries: function(currentPage) {
					var entries = 0;
					if(ct.total > 0) {
						entries = ( (currentPage - 1) * ct.entries ) + 1;
					}
					return entries;
				},
				/**
				 * Determines if source list is empty, if it is empty, display in the screen a message that no records are found
				 */
				isSourceEmpty: function() {
					var flag = true;
					if(ct.data && ct.data.length > 0) {
						flag = false;
					}
					return flag;
				},
				/**
				 * Method to determine if show or not the column
				 */
				validateColumn: function(key) {
					var flag = false;
					var selectedColumn = undefined;
					selectedColumn = _.find(ct.headers, function(header) {
						return _.isEqual(header.field, key);
					});
					if(!_.isUndefined(selectedColumn)) {
						flag = true;
					}
					return flag;
				},
				/**
				 * Method used to validate if the row has or not a hover effect
				 */
				containsLink: function() {
					var flag = false;
					if(!_.isUndefined(ct.linkId)) {
						flag = true;
					}
					return flag;
				},
				/**
				 * Method used to display the column or not as a link
				 */
				isLinkId:  function(key) {
					var flag = false;
					if(_.isEqual(key, ct.linkId)) {
						flag = true;
					}
					return flag;
				},
				/**
				 * Display pagination buttons
				 */
				displayPagination: function() {
					if(ct.data) {
						ct.buttonSize = Math.ceil( ct.total / ct.entries );
						ct.buttons = ct.createButtonsArray( ct.buttonSize );
					}
				},
				/**
				 * Method that filters the data in table
				 */
				filterData: function() {
					if(ct.async) {
						ct.displayPagination();
						return ct.data;
					} else {
						var partition = _.partition(ct.data, function(obj, index, list) {
							var flag = false;
							// Error data to be displayed
							if(obj.error) {
								flag = true;
							} else {
								// Normal data to be displayed
								var minLimit = (ct.currentPage - 1) * ct.entries;
								var maxLimit = (ct.currentPage * ct.entries) - 1;
								if( (index >= minLimit ) && ( index <= maxLimit ) ) {
									flag = true;
								}
							}
							return flag;
						});
						return partition[0];
					}
				},
				/**
				 * Show errors message
				 */
				showErrors: function(obj) {
					var modal = $modal.open({
						templateUrl: config.templateBasePath + 'app/pages/upload/failErrors.controller.html',
						controller: 'failErrorsController as failErrors', 
						resolve: {
							requestGroupId: function () {
								return obj.requestGroupId;
							} 
						}
					});
				},
				/**
				 * Method used when user clicks on link
				 */
				openLink: function(value) {
					$scope.$emit('customTableViewObjectEmit', value);
				},
				/**
				 * Method triggered when user select a bank account row
				 */
				selectRow: function(obj) {
					$scope.$emit('customTableSelectObjectEmit', obj);
				},
				/**
				 * Save object method
				 */
				save: function(obj) {
					$scope.$emit('customTableSaveObjectEmit', obj);
				},
				/**
				 * Edit object method
				 */
				edit: function(obj) {
					$scope.$emit('customTableEditObjectEmit', obj);
				},
				/**
				 * Delete object method
				 */
				delete: function(obj) {
					$scope.$emit('customTableDeleteObjectEmit', obj);
				},
				/**
				 * Initialize events
				 */
				channels: function() {
					$scope.$on('changeSource', ct.displayPagination);
					$scope.$watch('data', ct.displayPagination);
				},
				
				sortBy : function(propertyName) {
					if (ct.sortReverse)
						ct.sortReverse = false;
					else
						ct.sortReverse = true;
		        	
					var start = 0;
					if(ct.currentPage > 1) {
						// Calculate the start depending of the selected page
						start = (ct.currentPage * ct.entries) - ct.entries;
					}
					ct.propertyName = propertyName.trim();
					$scope.$emit('sortReverseVariable', ct.sortReverse);
					$scope.$emit('sortPropertyName', ct.propertyName);
					$scope.$emit('customTableSortObject', propertyName,ct.currentPage,start);
		           
				}
				
				
            });
			// Initialize the events when controller loads
			ct.channels();
		}
	};
});