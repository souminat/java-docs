angular.module('app.components.summary.directive', [
	'app.config'
])
.directive('summary', function ($q, config) {
	return {
		restrict: 'E',
		scope: {
			
		},
		templateUrl: config.templateBasePath + 'app/components/summary/summary.directive.html',
		bindToController: true,
        controllerAs: 'summary',
		controller: function($scope) {			
			
			var summary = this;
			
			// Public properties/functions
            angular.extend(summary, {
            	
            });
		}
	};
});