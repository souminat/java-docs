angular.module('app.components.payerPayeeSearch.directive', [
    'app.config',
    'app.directives'
])
    .directive('mypaymentsPayerPayeeSearch', ['config', function (config) {
        return {
            restrict: 						'E',
            require: 						'?ngModel',
            scope: {
                ngModel:					'=',
                title:						'@',
                position:					'@',
                isPayer:					'=',
                isEnabled:					'=',
                filters:					'='
            },
            templateUrl: config.templateBasePath + 'app/components/payerPayeeSearch/payerPayeeSearch.directive.html',
            bindToController: true,
            controllerAs: 'pps',
            controller: function ($scope, $uibModal) {

            	var pps = this;
            	
            	// Public properties/functions
                angular.extend(pps, {
                	filterCriteria: {
                    	tCode: undefined,
                    	goldId:	undefined,
                    	leName: undefined,
                    	currency: undefined,
                    	country: undefined,
                    	companyCode: undefined,
                    	businessSubbusiness: undefined
                    },
                    initFilterCriteria: function(newValue, oldValue) {
                    	if(!_.isEqual(newValue, oldValue)) {
                    		if(_.isObject(newValue.leName)) {
                    			pps.filterCriteria.goldId = newValue.leName.mdm_id;
                    			pps.filterCriteria.leName = newValue.leName.party_nm;
                    		}
                    		if(newValue.mdmBusinessName && newValue.mdmSubBusinessName) {
                    			pps.filterCriteria.business = newValue.mdmBusinessName;
                    			pps.filterCriteria.subBusiness = newValue.mdmSubBusinessName;  
                    		}
                    	}
                    },
                    initWatchers: function() {
                    	$scope.$watch('pps.filters', pps.initFilterCriteria, true);
                    },
                    isPosition: function(position) {
                    	var flag = false;
                    	
                    	if(_.isEqual(pps.position, position)) {
                    		flag = true;
                    	}
                    	
                    	return flag;
                    },
                    getTitle: function() {
                    	var displayedTitle = pps.title;
                    	
                    	if(!_.isEmpty(pps.ngModel)) {
                    		if(pps.isPayer) {
                    			displayedTitle = 'Change Payer';
                    		} else {
                    			displayedTitle = 'Change Payee';
                    		}
                    	}
                    	
                    	return displayedTitle;
                    },
                    isModelSelected: function() {
                    	var flag =  true;
                    	
                    	if(_.isEmpty(pps.ngModel)) {
                    		flag = false;
                    	}
                    	
                    	return flag;
                    },
                	openModal: function () {
                    	$uibModal.open({
                            templateUrl: config.templateBasePath + 'app/components/payerPayeeSearch/internalSearch.controller.html',
                            controller: 'internalSearchController as isc',
                            bindToController: true,
                            size: 'lg',
                            resolve: {
                                modalTitle: function() {
                                    return pps.title;
                                },
                                filterCriteria: function() {
                                	return pps.filterCriteria;
                                },
                                isPayer: function() {
                                	return pps.isPayer;
                                }
                            },
                            scope: $scope
                        });
                    }
                });
                
                // Initialization of watchers
                pps.initWatchers();
            }
        };
    }]);