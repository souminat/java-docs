angular.module('app.components.payerPayeeSearch.details.directive', [
    'app.config',
    'app.filters'
])
    .directive('mypaymentsPayerPayeeSearchDetails', ['config', function (config) {
        return {
            restrict: 						'E',
            require: 						'?ngModel',
            scope: {
                title:						'@',
            	ngModel:					'='
            },
            templateUrl: config.templateBasePath + 'app/components/payerPayeeSearch/payerPayeeDetails.directive.html',
            bindToController: true,
            controllerAs: 'ppd',
            controller: function () {

            	var ppd = this;
            	
            }
        };
    }]);