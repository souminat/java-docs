
angular.module('app.components.payerPayeeSearch.search.controller', [
	'ct.loadingOverlay',
	'app.directives',
	'app.services'
])

    .controller('internalSearchController', function ($scope, $uibModalInstance, modalTitle, filterCriteria, bankAccountManager, isPayer) {
        var isc = this;
        
        // Initialization of variables
        filterCriteria.start_Index = 0;
        isc.currentPage = 1;
        
        // Public properties/functions
        angular.extend(isc, {
            title: modalTitle,
            isPayer: isPayer,
            filters: filterCriteria,
            clear: function() {
            	if(isPayer) {
            		delete isc.filters.tCode;
            		delete isc.filters.currency;
            		delete isc.filters.country;
            		delete isc.filters.companyCode;
            	} else {
            		isc.filters = {};
            	}
            },
            cancel: function() {
            	isc.clear();
            	$uibModalInstance.close();
            },
            select: function(event, bank) {
            	isc.isLoading = true;
            	var promise = bankAccountManager.getDetails(bank);
            	promise.$promise.then(function(bankDetails) {
            		$scope.$parent.pps.ngModel = bankDetails;
            		$scope.$parent.pps.isSelected = true;
                	isc.isLoading = false;
                	isc.cancel();
            	});
            },
            channels: function() {
            	$scope.$on('customTableSelectObjectEmit', isc.select);
            	$scope.$on('customTableChangePagination', isc.changePagination);
            },
            changePagination: function(event, page, start) {
            	isc.currentPage = page;
            	isc.filters.start_Index = start;
            	isc.search();
            },
            orderData: function(headers, data) {
            	var orderedData;
            	if(data.length > 0) {
            		orderedData = [];
            	} 
            	_.each(data, function(obj) {
            		var orderedObj = {};
            		_.each(headers, function(header) {
            			orderedObj[header.field] = obj[header.field];
            		});
            		orderedData.push(orderedObj);
            	})
            	return orderedData;
            },
            search: function() {
            	
            	var criteria = angular.copy(isc.filters);
            	
            	if(_.isString(criteria.business) && _.isString(criteria.subBusiness)) {
            		criteria.business = encodeURI(criteria.business);
            		criteria.subBusiness = encodeURI(criteria.subBusiness);
            	} else if(_.isObject(criteria.business)) {
            		var business = encodeURI(criteria.business.bus_acct_grp);
            		var subBusiness = encodeURI(criteria.business.sub_bus_acct_grp);
            		criteria.business = business;
            		criteria.subBusiness = subBusiness;
            	}
            	
            	if(_.isObject(criteria.leName)) {
            		criteria.leName = encodeURI(criteria.leName.party_nm);
            	} else if(_.isString(criteria.leName)) {
            		criteria.leName = encodeURI(criteria.leName);
            	}
            	
            	criteria.count = 10;
            	isc.isLoading = true;
            	
            	var promise = bankAccountManager.getFilteredList(criteria);
            	promise.$promise.then(function(result) {
            		var data = result.resultList;
            		var total = result.totalRecords;
            		var headers = [
            			{
    	            		field: 'tcode',
    	            		name: 'T-CODE'
    	            	},
    	            	{
    	            		field: 'gold_le_code',
    	            		name: 'Gold Code'
    	            	},
    	            	{
    	            		field: 'gold_le_name',
    	            		name: 'Legal Entity Name'
    	            	},
    	            	{
    	            		field: 'company_code',
    	            		name: 'Company Code'
    	            	},
    	            	{
    	            		field: 'acct_title',
    	            		name: 'Account title'
    	            	},
    	            	{
    	            		field: 'bank_mdm_id',
    	            		name: 'Bank Relationship parent'
    	            	},
    	            	{
                			field: 'cntry_desc',
                			name: 'Country'
                		},
    	            	{
                			field: 'currency_code',
                			name: 'Currency'
    	            	},
    	            	{
    	            		field: 'natl_bank_acct_nbr',
    	            		name: 'NBAN'
    	            	},
    	            	{
    	            		field: 'iban',
    	            		name: 'IBAN'
    	            	}
            		];
            		
            		var orderedData = isc.orderData(headers, data);
            		
            		isc.results = {
            			total: total,
            			start: criteria.start_Index,
            			limit: criteria.count,
            			currentPage: isc.currentPage,
            			headers: headers,
                    	data: orderedData
                    };
            		isc.isLoading = false;
            	}, function(reason) {
            		isc.isLoading = false;
            	});
            }
        });
        
        // Initialization of channels
        isc.channels();
    });