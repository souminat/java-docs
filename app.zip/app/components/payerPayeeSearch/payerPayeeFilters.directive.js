angular.module('app.components.payerPayeeSearch.filters.directive', [
    'app.config',
    'app.services',
    'app.directives'
])
    .directive('mypaymentsPayerPayeeSearchFilters', ['config', function (config) {
        return {
            restrict: 				'E',
            require: 				'?ngModel',
            scope: {
                ngModel: 			'=',
                isPayer:			'='
            },
            templateUrl: config.templateBasePath + 'app/components/payerPayeeSearch/payerPayeeFilters.directive.html',
            bindToController: true,
            controllerAs: 'ppf',
            controller: function ($scope, $q, businessNamesManager, bankAccountManager) {

            	var ppf = this;
            	
            	// Public properties/functions
                angular.extend(ppf, {
                	getLeNames: function(text) {
                    	var defer = $q.defer();
                    	
                    	var criteria = {
                            goldLeName: encodeURI(text),
                    		//goldId: encodeURI(text)
                    	};
                    	var promise = bankAccountManager.getGoldLeNames(criteria);
                    	promise.$promise.then(function(result) {
                    		ppf.businessNames = result.elements;
                    		defer.resolve(result.elements);
                    	});
                    	
                    	return defer.promise;
                    },
                	search: function() {
                		$scope.$parent.isc.search();
                	},
                	cancel: function() {
                		$scope.$parent.isc.cancel();
                	},
                	clear: function() {
                		$scope.$parent.isc.clear();
                	},
                	initBusinessNames: function() {
                		var promise = businessNamesManager.all();
                		promise.$promise.then(function(result) {
                			ppf.businessNames = result.elements;
                		});
                	}
                });
                
                ppf.initBusinessNames();
            }
        };
    }]);