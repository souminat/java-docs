angular.module('app.components.header.directive', [
	'app.config'
])

.directive('applicationHeader', function (config) {
	return {
		restrict: 				'E',
		scope: {
			title:				'@'
		},
		templateUrl: config.templateBasePath + 'app/components/header/header.directive.html',
		controller: function($scope) {
			
		}
	};
});