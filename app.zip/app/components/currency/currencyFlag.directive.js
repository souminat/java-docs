angular.module('app.components.currencyFlag.directive', [
	'app.services'
])

    .directive('mypaymentsCurrencyFlag', function () {
        return {
            restrict: 'E',
            scope: {
                code: '@',
                showName: '='
            },
            template: '<span class="flag" ng-if="mcf.code"><i class="flags-{{ mcf.code }}"></i><span ng-if="mcf.code" class="currency-code">{{ mcf.getCurrency() }}</span></span>',
            bindToController: true,
            controllerAs: 'mcf',
            controller: function (currencyManager) {
                var mcf = this;
                angular.extend(mcf, {
                    getCurrency: function() {
                        var data, currency = mcf.code;
                        if (mcf.showName) {
                            data = currencyManager.getByCurrencyCode(mcf.code);
                            if (_.has(data, 'CURR_DESC')) {
                                currency += ' - ' + data.CURR_DESC;
                            }
                        }

                        return currency;
                    }
                });
            }
        }
    });
