describe("app.components.currencyFlag.directive.spec", function() {

	var $compile, $rootScope, $httpBackend, deferredResolution;

	beforeEach(module('app.services.currency'));
	beforeEach(module('app.services.currency.mock'));
	beforeEach(module('app.components.currencyFlag.directive'));

	beforeEach(inject(function ($injector) {

		$compile = $injector.get('$compile');
		$rootScope = $injector.get('$rootScope');
		$httpBackend = $injector.get('$httpBackend');

	}));

	it('shows currency code with flag icon', function () {

		var directiveElement = angular.element('<mypayments-currency-flag code="GBP"></mypayments-currency-flag>');
		var element = $compile(directiveElement)($rootScope);
		$rootScope.$digest();

        $httpBackend.flush();

		expect(element.find('i').hasClass('flags-GBP')).toBe(true);
		expect(element.text()).toBe("GBP");
	});

	it('shows currency name with flag icon', function () {

		var directiveElement = angular.element('<mypayments-currency-flag show-name="true" code="GBP"></mypayments-currency-flag>');
		var element = $compile(directiveElement)($rootScope);
		$rootScope.$digest();

        $httpBackend.flush();

		expect(element.find('i').hasClass('flags-GBP')).toBe(true);
		expect(element.text()).toBe("GBP - Pound Sterling");
	});
});