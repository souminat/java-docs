angular.module('app.components.currencyPicker.directive', [
	'app.config',
	'app.services'
])

    .directive('applicationCurrencyPicker', function (config) {
        return {
            restrict: 'E',
            scope: {
                name: '@',
                ngModel: '=',
                ngRequired: '=?',
                ngChange: '=?',
                ngKeydown: '=?',
                placeholder: '@'
            },
            templateUrl: config.templateBasePath + 'app/components/currency/currencyPicker.directive.html',

            controllerAs: 'cp',
            bindToController: true,

            controller: function ($scope, currencyManager) {
                var cp = this,
                    keydownBypassed = false,
                    currencies;

                $scope.$watch('cp.ngModel', function () {
                    cp.onChange();
                }, true);

                // Private variables/functions

                currencies = currencyManager.all();

                // Public properties/methods
                if (!cp.ngChange) {
                    cp.ngChange = _.noop;
                }
                if (!cp.ngKeydown) {
                    cp.ngKeydown = _.noop;
                }

                angular.extend(cp, {
                    ngRequired: !!cp.ngRequired,
                    getCurrencies: function () {
                        if (_.has(currencies, '$promise')) {
                            currencies.$promise.then(function () {
                                currencies = currencyManager.all();
                            });

                            return [];
                        }
                        
                        currencies = _.sortBy(currencies, 'curr_code'); 
                        return currencies;
                    },
                    getFilteredCurrencies: function (searchTerm) {
                        var allCurrencies = cp.getCurrencies(),
                            hasRecent = _.has(allCurrencies, 'recent'),
                            all = [],
                            recent = [],
                            filterCurrencies,
                            mapCurrencies;

                        searchTerm = searchTerm === ' ' ? '' : searchTerm;

                        filterCurrencies = function (val) {
                            if (_.has(val, 'curr_code')) {
                                val = val.curr_code;
                            }
                            return val.substr(0, searchTerm.length).toLowerCase() === searchTerm.toLowerCase();
                        };

                        mapCurrencies = function (val) {
                            var out = {'curr': val.curr_code};
                            if (hasRecent) {
                                out.type = '';
                            }
                            return out;
                        };

                        if (hasRecent) {
                            recent = _.map(_.filter(allCurrencies.recent, filterCurrencies), mapCurrencies);
                            all = _.map(_.filter(allCurrencies.all, filterCurrencies), mapCurrencies);

                            //set only the first item's group name
                            if (recent.length > 0) {
                                recent[0].type = 'Recent';
                            }
                            if (all.length > 0) {
                                all[0].type = 'All';
                            }

                            all = _.union(recent, all);
                        } else {
                            all = _.map(_.filter(allCurrencies, filterCurrencies), mapCurrencies);
                        }

                        //if there is just one, set the model
                        if (all.length === 1 && all[0].curr.toLowerCase() === searchTerm.toLowerCase()) {
                            cp.ngModel = all[0].curr;
                            return [];
                        }

                        return all;
                    },
                    isCurrencyValid: function(currencyText) {
                    	var allCurrencies = cp.getCurrencies();
                    	
                    	var currencyFounded = _.find(allCurrencies, function(currency) {
                    		return _.isEqual(currency.curr_code, currencyText);
                    	}); 
                    	
                    	var flag = false;
                    	
                    	if(!_.isUndefined(currencyFounded)) {
                    		flag = true;
                    	}
                		
                        return flag;
                    },
                    selectCurrency: function($item, $model, $label, $event) {
                    	var isCurrencyValid = cp.isCurrencyValid($model);
                    	
                    	if(isCurrencyValid) {
                    		cp.form[cp.name].$setValidity('currencyValidator', true);
                    	} else {
                    		cp.form[cp.name].$setValidity('currencyValidator', false);
                    	}
                    },
                    /**
                     * Convert ngModel (currency code) to upper case
                     */
                    onChange: function () {
                        if (!_.isUndefined(cp.ngModel) && !_.isNull(cp.ngModel)) {
                            cp.ngModel = cp.ngModel.toUpperCase();
                            keydownBypassed = cp.ngModel.length && (cp.ngModel.length < 3);
                        }
                        cp.ngChange();
                    },
                    onKeydown: function ($event) {
                        var keyChar,
                            keyCode = $event.keyCode,
                            keysEnum = {up: 38, down: 40, enter: 13, backspace: 8, delete: 46};

                        if (!keydownBypassed) {
                            cp.ngKeydown($event);
                        }

                        // If a letter was entered or removed, then allow typeahead to control the keydown event
                        keyChar = String.fromCharCode(keyCode);
                        if (/[a-zA-Z]/.test(keyChar) || keyCode === keysEnum.backspace || keyCode === keysEnum.delete) {
                            keydownBypassed = true;
                        }

                        // Pressing enter while bypassing keydown means that the typeahead will close, so we can
                        // re-enable handling keydown events
                        if (keydownBypassed && keyCode === keysEnum.enter) {
                            cp.enableKeydown();
                        }
                    },

                    onFocus: function () {
                        keydownBypassed = !cp.ngModel.length;
                    },
                    enableKeydown: function () {
                        keydownBypassed = false;
                    }
                });
            },

            link: function (scope, element, attr, ctrl) {
                // Listen to keydown events on the input
                // (can't use ng-keydown in the template as it would be overridden by the typeahead directive)
                element.on('keydown', 'input', ctrl.onKeydown);

                // Can't simply enable/disable keydown when clicking the input - whether the typeahead
                // is displayed will depend on whether anything has been typed. So let the controller handle this.
                element.on('click', 'input', ctrl.onFocus);

                // Losing focus or clicking a typeahead link will hide the typeahead,
                // so it is safe to re-enable handling keydown events
                element.on('blur', 'input', ctrl.enableKeydown);
                element.on('click', '.typeahead-link', ctrl.enableKeydown);
            }
        };
    })
    //popup typeahead on click (using on focus breaks validation)
    .directive('typeaheadFocus', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModel) {

                //trick the type ahead to show all on focus using ' ' string
                element.bind('click', function () {
                    var viewValue = ngModel.$viewValue;
                    ngModel.$setViewValue(viewValue || ' ');
                });
            }
        };
    })
    //custom validator for currencies typeahead
    .directive('currencyValidator', function () {
        return {
            restrict: 'A',
        	require: 'ngModel',
            link: function (scope, element, attr, ctrl) {
            	
            	function currencyValidator(ngModelValue) {
                    
            		var isCurrencyValid = scope.cp.isCurrencyValid(ngModelValue);
                	
                	if(isCurrencyValid) {
                		scope.cp.form[scope.cp.name].$setValidity('currencyValidator', true);
                	} else {
                		scope.cp.form[scope.cp.name].$setValidity('currencyValidator', false);
                	}
            		
                    return ngModelValue;
                }

                ctrl.$parsers.push(currencyValidator);
            }
        };
    });