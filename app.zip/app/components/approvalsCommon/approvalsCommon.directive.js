angular.module('app.components.approvalsCommon.directive', [
    'app.config',
    'ct.errorMessages',
    'app.directives'
    
])
    .directive('mypaymentsApprovalsCommon', ['config', function (config) {
        return {
            restrict: 				'E',
            require: 				'?ngModel',
            scope: {
                ngModel: 			'=',
                paymentDateFlag:	'=',
                isCommentsRequired:	'='
            },
            templateUrl: config.templateBasePath + 'app/components/approvalsCommon/approvalsCommon.directive.html',
            bindToController: true,
            controllerAs: 'approvalsCommon',
            controller: function ($scope) {

            	var approvalsCommon = this;
            	
            	// Public properties/functions
                angular.extend(approvalsCommon, {
                	dateOptions: {
                		minDate: new Date()
                	},
                	defaultDateOptions: function() {
                		return approvalsCommon.dateOptions;
                	},
                	initData: function() {
                		if(_.isUndefined(approvalsCommon.isCommentsRequired)) {
                			approvalsCommon.isCommentsRequired = false;
                		}
                	},
                	changeModel: function(newValue, oldValue) {
                		if(!_.isEqual(newValue, oldValue)) {
                			if(!_.isUndefined(approvalsCommon.ngModel) && !_.isUndefined(approvalsCommon.ngModel.paymentDate)) {
                				approvalsCommon.dateOptions = {
                    				minDate: approvalsCommon.ngModel.paymentDate
                        		}
                    		}
                		}
                	},
                	watchers: function() {
                		$scope.$watch('approvalsCommon.ngModel', approvalsCommon.changeModel);
                	}
                });
                
                // Initialization of watchers
                approvalsCommon.watchers();
                
                // Initialization of data
                approvalsCommon.initData();
            }
        };
    }]);