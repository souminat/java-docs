describe("app.components.lov-select.directive.spec", function() {

	var $compile, $rootScope, $httpBackend, lov;

	beforeEach(module('app.services.lov.mock'));
	beforeEach(module('app.services.lov'));
	beforeEach(module('app.components.lov-select.directive'));

	beforeEach(inject(function($injector){
		$compile = $injector.get('$compile');
		$rootScope = $injector.get('$rootScope');
		$httpBackend = $injector.get('$httpBackend');
		lov = $injector.get('lov');

		$httpBackend.flush();

	}));

	it('shows select list for BUYSELL', function() {

		var element = $compile("<application-lov-select type='BUYSELL_TYPE'></mytrs-lov>")($rootScope);
		$rootScope.$digest();
		$rootScope.$digest();

		expect(element.html()).toContain("Sell");

	});

});
