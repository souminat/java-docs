angular.module('app.components.lov.directive', [
	'app.services'
])

.directive('applicationLov', function (lov) {
	return {
		restrict: 'E',
		scope: {
			code: '@'
		},
		template: '{{ lookupCode.displayName }}',
		controller:function($scope, lov) {
			$scope.lookupCode = lov.getLookupCode($scope.code);
		}
};
});
