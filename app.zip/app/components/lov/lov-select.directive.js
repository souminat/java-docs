angular.module('app.components.lov-select.directive', [
	'app.config',
	'app.directives',
	'app.services'
])
.directive('applicationLovSelect', function (config, lov) {
	return {
		restrict: 'E',
		scope: {
			type: '@',
			ngModel: '=',
			myClass: '@',
			ngChange: '=',
			name: '@',
			ngRequired: '=',
			exclude: '@',
			firstOption: '@',
			ngHide: '@',
			optionSelected: '@',
			displayCode: '='
		},
		templateUrl: config.templateBasePath + 'app/components/lov/lov-select.directive.html',
		bindToController: true,
        controllerAs: 'ls',
		controller:function($scope, lov) {
			
			var ls = this;
			
			// Public properties/functions
            angular.extend(ls, {
            	initProperty: function() {
            		if(ls.displayCode) {
        				ls.property = 'lookupCode';
        			} else {
        				ls.property = 'displayName';
        			}
            	},
            	initExclude: function() {
            		if(ls.exclude) {
        				ls.list = lov.getByLookupTypeExclude(ls.type, ls.exclude);
        			} else {
        				ls.list = lov.getByLookupType(ls.type);
        			}
            	},
            	initList: function() {
            		ls.list.then(function (response) {
        				ls.list = response;
        				var sortedLSList = _.sortBy(ls.list, function(obj) {
							return obj[ls.property];
						});
        				ls.list = sortedLSList;
        				
        				if(ls.firstOption) {
        					ls.ngModel = ls.list[0].lookupCode;
        				}

        				if(ls.optionSelected) {
        					for(var i = 0; i < ls.list.length; i++) {

        						var item = ls.list[i];

        						if(item.lookupCode === ls.optionSelected) {
        							ls.ngModel = item.lookupCode;
        						}
        					}
        				}
        			});
            	}
            });
            
            ls.initProperty();
            ls.initExclude();
            ls.initList();
		}
	};
});
