angular.module('app.components.templates.directive', [
	'app.config',
	'app.services'
])
.directive('applicationTemplates', function ($q, config, templatesManager) {
	return {
		restrict: 'E',
		scope: {
			
		},
		templateUrl: config.templateBasePath + 'app/components/templates/templates.directive.html',
		controller: function($scope) {			
			
			// Initialization of templates data
			var initTemplates = function() {
				
				var deferred = $q.defer();
				
				var templates = templatesManager.getTemplatesInfo();
				templates.$promise.then(function(result) {
					$scope.templates = result.templates;
					deferred.resolve(result.templates);
				});
				
				return deferred.promise;
			};
			
			// Initialization method
			var init = function() {
				// Initialization of templates data
				initTemplates();
			};
			
			// Triggers initialization method when controller loads
			init();
		}
	};
});