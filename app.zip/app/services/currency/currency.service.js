angular.module('app.services.currency', ['ngResource', 'app.config'])

    .factory('CurrencyList', function ($resource, config) {
        //setup custom action
        var _actions = {
            search: {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getMDMCurrency', {}, _actions);

        return function () {
            return _resource.search();
        }
    })

    .service('currencyManager', function (CurrencyList) {
        var currencyManager = this,
            currencyList;

        currencyList = new CurrencyList();
        currencyList.$promise.then(function (response) {
            currencyList = response.elements;
        });

        // Public properties/methods
        angular.extend(currencyManager, {
            /**
             * Get the raw json list of elements
             *
             * @returns {CurrencyList|*}
             */
            all: function () {
                return currencyList;
            },

            /**
             * Get a single currency "object" from the cached JSON response
             *
             * @param currencyCode
             * @returns {*}
             */
            getByCurrencyCode: function (currencyCode) {
                return _.findWhere(currencyList, {'curr_code': currencyCode});
            },

            /**
             * Get the spot days for a given pair of currencies
             *
             * @param currencyFrom
             * @param currencyTo
             * @returns {Number}
             */
            getSpotDays: function (currencyFrom, currencyTo) {
            	var spotDays;
            	if(currencyTo) {
            		spotDays = parseInt(_.max([currencyFrom.spot_dd_cnt, currencyTo.spot_dd_cnt]));
            	} else {
            		spotDays = currencyFrom.spot_dd_cnt;
            	}
                return spotDays;
            },
            
            /**
             * Determines if the currency is restricted or not
             */
            isRestrictedCurrency: function(currencyValue) {
            	var flag = 'N';
            	
            	var currency = _.find(currencyList, function(curr) {
            		var isCurrency = false;
            		if(_.isEqual(curr.curr_code, currencyValue) && _.isEqual(curr.curr_rstri_ind, 'Y')) {
            			isCurrency = true;
            		}
            		return isCurrency;
            	});
            	
            	if(!_.isUndefined(currency)) {
            		flag = 'Y';
            	}
            	return flag;
            }
        });
    });
