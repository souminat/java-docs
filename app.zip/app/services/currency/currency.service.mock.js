angular.module('app.services.currency.mock', ['ngMock', 'app.config'])

    .run(function ($httpBackend, config) {
        var mockdata = {
            responseData: {
                data: [
                    {
                        MDM_ID: "GBP",
                        CURR_CODE: "GBP",
                        CURR_ISO_NBR: "826",
                        CURR_DESC: "Pound Sterling",
                        CURR_EFF_DATE: null,
                        CURR_END_DATE: null,
                        PRIMRY_SRCE_SYS: "CDH",
                        STATUS: "Active",
                        SPOT_DD_CNT: "2",
                        NBR_PRECN: "2",
                        RND_DESC: "NEAR",
                        BUS_DD_RULE: "MF",
                        CAL_NM: "LnB",
                        RISK_FREE_INDX_NM: "LIBOR",
                        FX_INDX_NM: "LIBOR",
                        ISDA_CODE: "GBP",
                        BASIS_VAL: "A365F",
                        CURR_NOT_CNVBL_IND: "Y",
                        SRCE_SYS_NM: "CDH",
                        CURR_RSTRI_IND: "N",
                        CURR_ORDINAL_VAL: null,
                        CURR_PRICE_QUOT_CVTNAL_VAL: null,
                        NON_DLVBL_FWD_FLG: "NO"
                    },
                    {
                        MDM_ID: "USD",
                        CURR_CODE: "USD",
                        CURR_ISO_NBR: "840",
                        CURR_DESC: "US Dollar",
                        CURR_EFF_DATE: null,
                        CURR_END_DATE: null,
                        PRIMRY_SRCE_SYS: "CDH",
                        STATUS: "Active",
                        SPOT_DD_CNT: "2",
                        NBR_PRECN: "2",
                        RND_DESC: "NEAR",
                        BUS_DD_RULE: "MF",
                        CAL_NM: "NYB",
                        RISK_FREE_INDX_NM: "LIBOR",
                        FX_INDX_NM: "LIBOR",
                        ISDA_CODE: "USD",
                        BASIS_VAL: "A360",
                        CURR_NOT_CNVBL_IND: "Y",
                        SRCE_SYS_NM: "CDH",
                        CURR_RSTRI_IND: "N",
                        CURR_ORDINAL_VAL: null,
                        CURR_PRICE_QUOT_CVTNAL_VAL: null,
                        NON_DLVBL_FWD_FLG: "NO"
                    }
                ]
            }
        };

        $httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/getMDMCurrency').respond(mockdata);

    });
