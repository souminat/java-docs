angular.module('app.services.gapMorDates', ['ngResource', 'app.config'])

.factory('gapMorDatesModel', function($resource, config) {

	var _resource = $resource(config.apiBasePath + 'api/em/v1/getGAPMORMapDates');

	return function() {
		return _resource;
	}
})

.service('gapMorDates', function (gapMorDatesModel) {

	var gapMorDates = this;

	gapMorDates.gapMorDatesArray = gapMorDatesModel().query();

	gapMorDates.gapMorDatesArray.$promise.then(function(){
		gapMorDates.gapMorDatesArray = _.each(gapMorDates.gapMorDatesArray, function(val,key){ gapMorDates.gapMorDatesArray[key].date = val.date.toLowerCase(); });			
	});

	gapMorDates.getDate = function(qtrMonth) {				
		var res = _.findWhere(gapMorDates.gapMorDatesArray, { date : qtrMonth.toLowerCase() });
		return res ? res.gapMorDate : null;
	};	


});
