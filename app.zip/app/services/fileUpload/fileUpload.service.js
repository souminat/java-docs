angular.module('app.services.fileUpload',['ngResource','app.config'])

.factory('FileUpload', function($resource, config) {
	
	var _actions = {
		uploadRawFile: {
			method: 'POST',
			//transformRequest: angular.identity,
			headers: {
				'Content-Type': undefined,
				enctype: 'multipart/form-data'
			},
			data: {}
		}
	};
	var _resource = $resource(config.apiBasePath + 'box/uploadFile', {}, _actions);

	return function() {
		return _resource;
	}
})
.factory('DeleteFile', function($resource, config) {
	
	var _actions = {
		deleteFile: {
			method: 'POST',
			//transformRequest: angular.identity,
			headers: {
				'Content-Type': undefined
			},
			params: {
				fileId: '@fileId'
			},
			data: {}
		}
	};
	var _resource = $resource(config.apiBasePath + 'box/deleteFileById', {}, _actions);

	return function() {
		return _resource;
	}
})
.service('fileUploadManager', function (FileUpload, DeleteFile) {
	var fileUploadManager = this;
	
	fileUploadManager.uploadNewFile = function(rawFile) {
		return new FileUpload().uploadRawFile(rawFile);
	};
	
	fileUploadManager.deleteFile = function(fileId) {
		return new DeleteFile().deleteFile({
			fileId: fileId
		});
	};
	
});