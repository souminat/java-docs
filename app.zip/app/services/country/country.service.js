angular.module('app.services.country', ['ngResource', 'app.config'])

    .factory('CountryList', function ($resource, config) {
        //setup custom action
        var _actions = {
        	searchAll: {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getMDMCountry', {}, _actions);

        return function () {
            return _resource.searchAll();
        }
    })
    
    .service('CountryManager', function (CountryList) {
        var countryManager = this,
            countryList;

        countryList = new CountryList();
        countryList.$promise.then(function (response) {
            countryList = response.elements;
        });

        // Public properties/methods
        angular.extend(countryManager, {
            /**
             * Get the raw json list of elements
             *
             * @returns {countryList|*}
             */
            all: function () {
                return countryList;
            },
            isRestrictedCountry: function(countryValue) {
            	var flag = 'N';
            	
            	var country = _.find(countryList, function(coun) {
            		var isCountry = false;
            		if(_.isEqual(coun.cntry_iso_2_code, countryValue) && _.isEqual(coun.cntry_rstri_ind, 'Y')) {
            			isCountry = true;
            		}
            		return isCountry;
            	});
            	
            	if(!_.isUndefined(country)) {
            		flag = 'Y';
            	}
            	return flag;
            }
        });
    });