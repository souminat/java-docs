angular.module('app.services.enterpriseStandards', ['ngResource', 'app.config'])

    .factory('EnterpriseStandardsFactory', function ($resource, config) {
        var _actions = {
            getEnterpriseStandards: {
                method: 'GET',
                cache: true,
                isArray: true,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/lov/enterpriseStandards', {}, _actions);

        return function () {
            return _resource;
        };
    })

    .factory('PaymentTypesFactory', function ($resource, config) {
        var _actions = {
            getPaymentTypes: {
                method: 'GET',
                cache: true,
                isArray: true,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/lov/paymentTypes', {}, _actions);

        return function () {
            return _resource;
        };
    })
    
    .service('enterpriseStandardsManager', function (EnterpriseStandardsFactory, PaymentTypesFactory) {
        var enterpriseStandardsManager = this;

        // get all the enterprise standards
        enterpriseStandardsManager.all = function () {
            return new EnterpriseStandardsFactory().getEnterpriseStandards();
        };
        
        // get the payment typers per enterprise standard code
        enterpriseStandardsManager.getPaymentTypes = function (esCode) {
            return new PaymentTypesFactory().getPaymentTypes({
            	esCode: esCode
            });
        };
    });