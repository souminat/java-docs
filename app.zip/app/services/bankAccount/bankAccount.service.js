angular.module('app.services.bankAccount', ['ngResource', 'app.config'])

    .factory('BankAccountFactory', function ($resource, config) {
        var _actions = {
            getBankAccount: {
                method: 'GET',
                cache: true,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getMDMBankAccount', {}, _actions);

        return function () {
            return _resource;
        };
    })

    .factory('BankAccountSearchFactory', function ($resource, config) {
        var _actions = {
            getBankAccountList: {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                params: {
                	start_index: '@start_index',
                	count: '@count'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/searchMDMBankAccounts', {}, _actions);

        return function () {
            return _resource;
        };
    })

    .factory('LESearchFactory', function ($resource, config) {
        var _actions = {
            getGoldLeNames: {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                params: {
                	start_index: '@start_index',
                	count: '@count'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/goldLe', {}, _actions);

        return function () {
            return _resource;
        };
    })
    
    .factory('BankAccountDetailsFactory', function ($resource, config) {
        var _actions = {
            getBankAccountDetails: {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                params: {
                	
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getPayerSearchResult', {}, _actions);

        return function () {
            return _resource;
        };
    })
    
    .service('bankAccountManager', function (BankAccountFactory, BankAccountSearchFactory, BankAccountDetailsFactory, LESearchFactory) {
        var bankAcccountManager = this;

        // Remove properties that are undefined or empty from filters
    	var clearFilters = function(filters) {
    		
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
        // get a bank account by Id
        bankAcccountManager.get = function (tCode) {
            return new BankAccountFactory().getBankAccount({tCode: tCode});
        };
        
        // get the bank account list
        bankAcccountManager.getFilteredList = function (filters) {
        	criteria = clearFilters(filters)
        	return new BankAccountSearchFactory().getBankAccountList(criteria);
        };

        // get the Gold LE Names list
        bankAcccountManager.getGoldLeNames = function (filters) {
        	criteria = clearFilters(filters)
        	return new LESearchFactory().getGoldLeNames(criteria);
        };
        
        // get the bank account details
        bankAcccountManager.getDetails = function (model) {
        	var params = {
        		tCode: model.tcode,
        		mdmId: model.bank_mdm_id
        	};
        	return new BankAccountDetailsFactory().getBankAccountDetails(params);
        };
    });