angular.module('app.services.templates', ['ngResource','app.config'])

.factory('templatesFactory', function($resource, config) {

	//setup custom action
	var _actions = {
		getTemplatesInfo: {
			method: 'GET',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			data: '' //you have data present for content-type header to be applied
		}
	};
	
	//the url is a place holder 
	var _resource = $resource(config.templateBasePath + 'app/apis/templates.json', {}, _actions);

	return function() {
		return _resource;
	};
})

.service('templatesManager', function (templatesFactory) {
	var templatesManager = this;

	templatesManager.getTemplatesInfo = function() {						
		return  new templatesFactory().getTemplatesInfo();
	};
});