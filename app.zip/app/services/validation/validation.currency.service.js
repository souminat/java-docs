angular.module('app.services.validation.currency',['app.services.currency'])

//ruleTypes: code
.service('currencyValidation', function (currencyManager) {
	var currencyValidation = this;
	
	currencyValidation.currencyList = {};
	
	currencyValidation.loadPrequisites = function() {
		
		//grab the currencies and return the promise
		currencyValidation.currencyList = currencyManager.all();
		
		return currencyValidation.currencyList.$promise;
	};
	
	currencyValidation.unloadPrequisites = function() {
		
		currencyValidation.currencyList = {};
	};
	
	currencyValidation.getCurrencyDecimal = function(currency){
		
		var found = _.find(currencyValidation.currencyList.responseData.data, function(cur){
			return cur.CURR_CODE === currency;
		});
		
		if(found){
			return found.NBR_PRECN;
		}else{
			return false;
		}
	};
	
	currencyValidation.format = function(ruleType, value) {
		
		//no formating needed
		return value;
	};
	
	currencyValidation.unformat = function(ruleType, value) {
		
		if(ruleType ==='amt'){
			//extract decimals, so then can later be attached to final result 
			var decimals = (value.replace(/[\,\(\)]+/g, '')).split('.')[1];
			//parse number form string 
			var result = numeral().unformat(value);
			if(decimals){
				//remove decimals from string, and attach the decimals that was extracted earlier 
				result = (''+result).split('.')[0]+'.'+decimals;
			}
			else{				
				result = result+'.00';				
			}

			return result;
		}
		else{
			return value;
		}
	};
		
	currencyValidation.test = function(ruleType, value, rowValue) {
		if(ruleType ==='code'){
			
			// If both are empty, no compare
			if(rowValue['FUNCTIONAL CURRENCY'] !== '' || rowValue['EXPOSURE CURRENCY'] !== ''){
				// if one is entered, then other should be entered
				if(rowValue['FUNCTIONAL CURRENCY'] === '' || rowValue['EXPOSURE CURRENCY'] === ''){
					return {
						
						worked: false,
						result: "Exposure and functional currency should be entered"
					};
				}
				//If both are same show error
				if(rowValue['FUNCTIONAL CURRENCY'].toLowerCase()=== rowValue['EXPOSURE CURRENCY'].toLowerCase()){
					return {
						
						worked: false,
						result: "Exposure and functional currency cannot be the same"
					};
				}
			}
			
			//test this against currency data
			var found = _.find(currencyValidation.currencyList.responseData.data, function(cur){
				return cur.CURR_CODE === value;
			});
			
			if(found) {
				return {
					worked: true,
					result: value
				};
			}
			else {
				var errorMessage = value ===''?'required field':'Unable to find matching currency for: "' + value + '"';
				return {
					
					worked: false,
					result: errorMessage
				};
			}
		}else if(ruleType ==='amt'){
			//if action is update and notional or actual values are not empty, then exposure currency is reuqired to get currency percesion 
			if(rowValue['ACTION'] === 'Update' && (rowValue['NOTIONAL AMOUNT'].trim() !='' ||rowValue['ACTUAL AMOUNT'].trim() !='') && rowValue['EXPOSURE CURRENCY'].trim() ===''){
				return {
					worked: false,
					result: 'Exposure Currency is required if action is update and actual or notional amounts are not empty'
				};
			}
			
			
			if(value =='' && rowValue['ACTION'] == 'New'){
				return {
					worked: false,
					result: 'Required field'
				};
			}
			//simple numbers only (removes commas and dollar signs)
			parsed = Number(value.replace(/[\,\(\)]+/g, ''));
			
			if(parsed) {			
			 var afterDecimal = (value.replace(/[\,\(\)]+/g, '')).split('.')[1];
				var currencyPercesion = Number(currencyValidation.getCurrencyDecimal(rowValue['EXPOSURE CURRENCY']));
				
				if(parsed > 999999999999999) {
					return {
						worked: false,
						result: 'Number is too large'
					};
				}				 
				else if(currencyPercesion === false){
						return {
							worked: false,
							result: 'Failed to get currency precision'
						};		
				 }	else  if(afterDecimal && afterDecimal.length > currencyPercesion){
						return {
							worked: false,
							result: 'Invalid decimal places'
						};	
				}else {
					return {
						worked: true,
						result: currencyValidation.unformat(ruleType, value)
					};					
								
				}
				
			}else{	//if string cannot be parsed into number Or  if it is 0
					if(parsed == 0) {
						return {
							worked: false,
							result: 'Amount cannot be 0'
						};
					}else{
						return {
							worked: false,
							result: 'Failed to parse '+value+' into number'
						};
					}
					
				
			}
		}
	};

});