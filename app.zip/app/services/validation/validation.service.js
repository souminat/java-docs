angular.module('app.services.validation',[
'app.services.validation.type',
'app.services.validation.lookup',
'app.services.validation.currency'
])

.service('validation', function ($q, typeValidation, lookupValidation, currencyValidation) {
	var validation = this;
	
	validation.loadPrequisites = function() {
		return $q.all([
		               lookupValidation.loadPrequisites(),
		               currencyValidation.loadPrequisites()
		]);
	};
	
	validation.unloadPrequisites = function() {
		currencyValidation.unloadPrequisites();		
	};
	
	validation.format = function(rule, ruleType, value) {	
		//find the right validator and run format
		return validation.getValidationService(rule).format(ruleType, value);
	};
	
	validation.unformat = function(rule, ruleType, value) {		
		//find the right validator and run unformat
		return validation.getValidationService(rule).unformat(ruleType, value);		
	};
	validation.test = function(rule, ruleType, value, rowValue) {		
		//find the right validator and run test
		return validation.getValidationService(rule).test(ruleType, value, rowValue);
	};
	
	validation.getValidationService = function(rule) {
		if(rule === 'type') { return typeValidation; }
		else if(rule === 'lookup') { return lookupValidation; }
		else if(rule === 'currency') { return currencyValidation; }
		else {
			throw new Error('validator not found for the rule: ' + rule);
		}
	};
});