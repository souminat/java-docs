angular.module('app.services.validation.lookup',['app.services.lov'])

//ruleTypes: [lov type code]
.service('lookupValidation', function ($q, lov) {
	var lookupValidation = this;		
	
	lookupValidation.loadPrequisites = function() {
				
		return $q.all([
			lov.lovsArray.$promise, //lov service stores its own data so just return the promise			
		]);
	}
	
	lookupValidation.format = function(ruleType, value) {
		
		//get the display value from the code
		return lov.getLookupCode(value, ruleType).displayName;
	}
	
	lookupValidation.unformat = function(ruleType, value) {
		
		//get the code from the display value
		return lov.getLookupByDisplayName(value, ruleType);;
	}
		
	lookupValidation.test = function(ruleType, value) {
		
		//test this against lov data
		var lovResult = lov.getLookupByDisplayName(value.trim(), ruleType);
		
		if(lovResult) {
			return {
				worked: true,
				result: lovResult.lookupCode
			};
		}
		else {
			var errorMessage = value ===''?'required field': 'Expected "' + value + '" to be a matching lookup code of type: "' + ruleType + '"';
		
			return {
				worked: false,
				result: errorMessage
			};
		}
		
	}

})