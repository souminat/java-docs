angular.module('app.services.validation.type',[])

//ruleTypes: currency, number, date, string, empty
.service('typeValidation', function () {
	var typeValidation = this;
	
	typeValidation.format = function(ruleType, value) {
		
		if(ruleType === 'currency') {
			//do not format blank values
			if(value =='') {
				return '';
			}
			return numeral(value).format('0,0.00[00]');
		}
		else if(ruleType === 'number') {
			return numeral().unformat(value);
		}
		else if(ruleType === 'date') {
			var m = moment(value);
			if(m.isValid()) {
				return m.format('DD MMM YYYY');
			}
			return '';
		}
		else if(ruleType === 'empty') {
			return '';
		}
		//for anything else, no formatting needed
		return value;
	};
	
	typeValidation.unformat = function(ruleType, value) {
		
		if(ruleType === 'number' || ruleType === 'currency') {
			return numeral().unformat(value);
		}
		else if(ruleType === 'date') {
			return moment(value).format('DD MMM YYYY');
		}
		else if(ruleType === 'empty') {
			return '';
		}
		else if(ruleType === 'alphanumeric'){
			return value.trim();
		}
		//for anything else, no formatting needed
		return value;
	};
		
	typeValidation.test = function(ruleType, value) {
		
		var parsed = false;
		
		if(ruleType === 'stringRequired') {
			if(value.trim().length >250){
				return {
					worked: false,
					result: 'Comment cannot exceed 250 characters.'
				};
			}
			else if(value.trim() != '') {
				return {
					worked: true,
					result: typeValidation.unformat(ruleType, value)
				};
			}
			else {
				return {
					worked: false,
					result: 'This field is required'
				};
			}
		}
		else if(ruleType === 'alphanumeric') {
			var re = /^[a-zA-Z0-9_ ]+$/;
			if(value.trim().length  > 28){
				return {
					worked: false,
					result: 'Program ID cannot exceed 28 characters.'
				};
			}
			else if(value.trim().match(re)) {
				return {
					worked: true,
					result: typeValidation.unformat(ruleType, value)
				};
			}
			else {
				return {
					worked: false,
					result: 'field must be alphanumeric.'
				};
			}
		}
		else {
			if(ruleType === 'empty') {
				parsed = value.trim() == '';
			}
			else if(ruleType === 'string') {
				parsed = true;
			}
			
			if(parsed) {
				
				return {
					worked: true,
					result: typeValidation.unformat(ruleType, value)
				};
			}
		}

		if(ruleType === 'empty'){
			return {
				worked: false,
				result: 'Field should be empty'
			};	
		} else {
			return {
				worked: false,
				result: 'Unable to parse '+ value +' as ' + ruleType
			};
		}
	};

});