angular.module('app.services.requestGroup', ['ngResource', 'app.config', 'ct.dateFormatter'])


    .factory('RequestGroup', function ($http, $resource, config) {

        var _actions = {
            saveNew: {
                method: 'POST',
                url: config.apiBasePath + 'api/mypayments/v1/requestGroups'
            },
            // saveNewDraft: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/requestGroups/draft'
            // },
            // update: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/mypayments/v1/requestGroups/:requestGrpId',
            // 	params: {
            // 		requestGrpId: '@requestGrpId'
            // 	}
            // },
            // updateDraft: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/requestGroups/:requestGrpId/draft',
            // 	params: {
            // 		requestGrpId: '@requestGrpId'
            // 	}
            // },
            // submit: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/requestGroup/:requestGroupId/submitForApproval',
            // 	params: {  //default parameters
            // 		requestGroupId: '@requestGrpId'
            // 	}
            // },
            // approve: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/requestGroups/approve',
            // 	params:{
            // 		reqgroup_id: '@reqgroup_id',
            // 		is_hedge_adj: '@is_hedge_adj'
            // 	}
            // },
            // approveAsync: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/fileUpload/approve',
            // 	params:{
            // 		requestGrpId: '@requestGrpId',
            // 		isHedgeAdj: '@isHedgeAdj'
            // 	}
            // },
            // reject: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/requestGroups/reject',
            // 	params:{
            // 		reqgroup_id    : '@reqgroup_id',
            // 		rejectReason   : '@rejectReason'
            // 	}
            // },
            // rejectAsync: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/fileUpload/reject',
            // 	params:{
            // 		requestGrpId   : '@requestGrpId',
            // 		rejectReason   : '@rejectReason'
            // 	}
            // },
            // cancel: {
            // 	method: 'POST',
            // 	url: config.apiBasePath + 'api/fx/v1/requestGroups/:requestGroupId/cancel',
            // 	params: {  //default parameters
            // 		requestGroupId: '@requestGrpId'
            // 	}
            // },
            getRequestGroup: {
                method: 'GET',
                url: config.apiBasePath + 'api/mypayments/v1/requestGroups/requester',
                params: {  //default parameters
                    start: 1,
                    limit: 20,
                    orderBy: 'REQUEST_GROUP_ID',
                    direction: 'DESC'
                },
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _requesterResource = $resource(config.apiBasePath + 'api/mypayments/v1/requestGroups/requester', {}, _actions);
        var _approverResource = $resource(config.apiBasePath + 'api/mypayments/v1/requestGroups/approvals/:requestGroupId', {}, _actions);

        // return function(userRole) {
        // 	return (userRole === 'Approver') ? _approverResource : _requesterResource;
        // };

        return function () {
            return _requesterResource;
        };
    })

    .service('requestGroupManager', function (RequestGroup, CtDateFormatter) {

        var requestGroupManager = this;
        var rgdefaults = {
            requestGrpId: null,
            productGrpName: 'FX'
        };
        var formatPayment;

        formatPayment = function (payment) {
            payment = angular.copy(payment);
            payment.valueDate = new CtDateFormatter(payment.valueDate).format('DD MMM YYYY');
            payment.dateToExecute = new CtDateFormatter(payment.dateToExecute).format('DD MMM YYYY');

            return payment;
        };

        //get a request from a list or fetch it from server
        requestGroupManager.get = function (id, userRole, requestGroupList) {
            requestGroupList = requestGroupList || [];

            //find it
            var requestGroup = _.findWhere(requestGroupList, {requestGrpId: id});

            //only call service if we did not find something
            if (requestGroup) {
                return requestGroup;
            }
            else {
                return new RequestGroup().get({requestGroupId: id});
            }
        };

        //make a new request group object
        requestGroupManager.newFromPayments = function (rgtype, paymentsArray) {
            var rg = {};

            rg.requestGrpTypeCode = rgtype;
            rg.payments = (paymentsArray || []);

            return _.defaults(rg, rgdefaults);
        };

        requestGroupManager.newRequestGroup = function (requestTypeCode) {
            var newPaymentsArray = [{
                // Default values of new payment...

                payer: {},
                payee: {},
                valueDate: null,
                paymentDateOptions: {},
                holidayCalendarDates: []
            }];
            return requestGroupManager.newFromPayments(requestTypeCode, newPaymentsArray);
        };

        requestGroupManager.paymentStatus = function (requestGroup) {
            // if(requestGroup.fileUploadStatusCode === 'REQGRP_PENDING_APPROVAL') {
            // 	return 'TRDREQSTAT_PENDAPPROV';
            // }
            // else if(requestGroup.fileUploadStatusCode === 'REQGRP_DRAFT_ERROR') {
            // 	return 'TRDREQSTAT_DRAFT_ERROR';
            // }
            // else if(requestGroup.fileUploadStatusCode === 'REQGRP_PROCESSING' || requestGroup.fileUploadStatusCode === 'REQGRP_SUBMITFORAPPROVAL') {
            // 	return requestGroup.fileUploadStatusCode;
            // }
            //
            return requestGroup.payments[0].paymentStatusCode;
        };

        requestGroupManager.submitNewPayment = function (requestGroup) {
            requestGroup.payments = _.map(requestGroup.payments, formatPayment);
            return new RequestGroup().saveNew(requestGroup);
        };

        requestGroupManager.updatePayment = function (requestGroup) {
            return new RequestGroup().update({requestGrpId: requestGroup.requestGrpId}, requestGroup);
        };

        // requestGroupManager.submitTrade = function(requestGroupId){
        // 	return new RequestGroup().submit({requestGrpId: requestGroupId});
        // };
        //
        // requestGroupManager.rejectTrade = function(requestGroupId,reject_Reason){
        // 	return new RequestGroup().reject({reqgroup_id: requestGroupId,rejectReason : reject_Reason});
        // };
        //
        // requestGroupManager.rejectTradeAsync = function(requestGroupId,reject_Reason){
        // 	return new RequestGroup().rejectAsync({requestGrpId: requestGroupId, rejectReason: reject_Reason});
        // };

        requestGroupManager.getRequestGroupByFilter = function (filter) {
            return new RequestGroup().getRequestGroup(filter);
        };

        // requestGroupManager.getApproverList = function(reqGrpId, umbrellaName){
        // 	return new RequestGroup().getApproverList({reqGrpId: reqGrpId, umbrellaName: umbrellaName});
        // };
        //
        // requestGroupManager.sendApproverEmail = function(requestGroup, approver){
        // 	return new RequestGroup().sendApproverEmail({requestGrpId: requestGroup}, approver);
        // };

        requestGroupManager.cancelPayment = function (requestGroupId) {
            return new RequestGroup().cancel({requestGrpId: requestGroupId});
        };

        requestGroupManager.getRequestGroupCleaned = function (requestGroup) {
            delete requestGroup.lastUpdateDate;
            delete requestGroup.lastUpdateUser;
            delete requestGroup.createDate;
            delete requestGroup.requestCreateTime;
            if (requestGroup.fileUpload) {
                delete requestGroup.fileUpload.lastUpdateDate;
                delete requestGroup.fileUpload.lastUpdateUser;
                delete requestGroup.fileUpload.createDate;
            }
            for (var i in requestGroup.trades) {
                delete requestGroup.trades[i].activityList;
                delete requestGroup.trades[i].tradeInterface;
                delete requestGroup.trades[i].tradeRequestWorkflow;
                delete requestGroup.trades[i].lastUpdateDate;
                delete requestGroup.trades[i].lastUpdateUser;
                delete requestGroup.trades[i].createDate;
                delete requestGroup.trades[i].hedgeAccount.createDate;
                delete requestGroup.trades[i].hedgeAccount.lastUpdateDate;
                if (requestGroup.trades[i].tradeError) {
                    delete requestGroup.trades[i].tradeError.lastUpdateDate;
                    delete requestGroup.trades[i].tradeError.lastUpdateUser;
                    delete requestGroup.trades[i].tradeError.createDate;
                }
            }
            return requestGroup;
        };

    });