describe("app.services.requestGroup.spec", function() {

	var $httpBackend, requestGroupManager, fakeRequestGroup, config;
	
	beforeEach(module('templates'));
	beforeEach(module('app.services.requestGroup'));
	beforeEach(module('app.services.requestGroup.mock'));
	beforeEach(module('app.config'));

	beforeEach(inject(function($injector){
		$httpBackend = $injector.get('$httpBackend');
		requestGroupManager = $injector.get('requestGroupManager');
		config = $injector.get('config');
		
		fakeRequestGroup = {
			"requestGrpId": 123,
			"payments": [
				{"paymentStatusCode": "Status_Test"}
			]
		};
	}));

	// TODO REQUEST_GROUP implement when no longer mocking API call
	// it('calls requestor service', function() {
	//
	// 	$httpBackend.expect('GET', config.apiBasePath + 'api/mypayments/v1/requestGroups/requester/123');
	//
	// 	requestGroupManager.get(123, 'Requester');
	// 	$httpBackend.flush();
    //
	// });
	
	it('does not call service when we already have it in array', function() {
		
		requestGroupManager.get(123, 'Requester', [{"requestGrpId": 123}]);
		//do not flush because no calls to server should be made
		
		$httpBackend.verifyNoOutstandingRequest();

	});
	
	

});
