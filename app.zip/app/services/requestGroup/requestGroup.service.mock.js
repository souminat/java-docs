angular.module('app.services.requestGroup.mock', ['ngMock', 'app.config'])

    .run(function ($httpBackend, config) {
        var mockdata = {
            "lastUpdateUser": "999999000",
            "lastUpdateDate": "12 Oct 2016",
            "createDate": "12 Oct 2016",
            "createUser": "999999000",
            "requestGrpId": 26,
            "requestGrpTypeCode": "TYPE_CODE_TEST",
            "requestGrpStatusCode": "STATUS_CODE_TEST",
            "payments": [
                {
                    "lastUpdateUser": "999999000",
                    "lastUpdateDate": "12 Oct 2016",
                    "createDate": "12 Oct 2016",
                    "createUser": "999999000",
                    "paymentRequestId": 23,
                    "requestGrpId": null,
                    "vendorAccountDetailId": null,
                    "paymentRef1": "PaymentRef1_Test",
                    "paymentRef2": "PaymentRef2_Test",
                    "isPayeeExternal": "Test",
                    "isUrgent": "Test",
                    "manualPymtRsnCode": "Reason Test",
                    "dateToExecute": "11 Oct 2016",
                    "valueDate": "11 Oct 2016",
                    "direction": "Test",
                    "paeryAmount": 1,
                    "payerCurrency": "MXN",
                    "payeeAmount": "Test",
                    "payeeCurrency": "MXN",
                    "paymentStatusCode": "Status_Test",
                    "nettingInd": null,
                    "activityList": [
                        {
                            "lastUpdateUser": "999999000",
                            "lastUpdateDate": "12 Oct 2016",
                            "createDate": "12 Oct 2016",
                            "createUser": "999999000",
                            "paymentActivityId": 3,
                            "paymentRequestId": 23,
                            "ssoId": "999999000",
                            "userGroupName": "Requestor",
                            "paymentAction": "Draft",
                            "comments": "Payment Request Draft Created"
                        }
                    ]
                }
            ]
        };

        $httpBackend.when('GET', config.apiBasePath + 'api/fx/v1/requestGroups/requester/123').respond(mockdata);
        $httpBackend.when('GET', config.apiBasePath + 'api/fx/v1/requestGroups/approvals/123').respond(mockdata);

        //$httpBackend.when('POST', config.apiBasePath + 'api/fx/v1/requestGroups/approvals/123/approve').respond(mockdata);


    });
