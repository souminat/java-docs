angular.module('app.services.about.mock', ['ngMock', 'app.config'])

.run(function($httpBackend, config) {
	var mockData = ["\n Manifest-Version = 1.0\n Implementation-Title = NGTRSWeb\n Build-Version = 02-11-2015 22:28:44\n Environment = dev"];

	$httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/appInfo').respond(mockData);

});
