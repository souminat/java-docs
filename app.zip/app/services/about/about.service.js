angular.module('app.services.about', ['ui.bootstrap', 'ngResource','app.config'])

.factory('About', function($resource, config) {

	var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/appInfo');

	return function() {
		return _resource.query();
	};
})
.service('aboutManager', function (About) {
	var aboutManager = this;
	
	aboutManager.get = function() {
		return new About();
	};
});
