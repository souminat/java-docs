describe("app.services.lov.spec", function() {

	var $httpBackend, $rootScope, lov;

	beforeEach(module('app.services.lov.mock'));
	beforeEach(module('app.services.lov'));

	beforeEach(inject(function($injector){

		$httpBackend = $injector.get('$httpBackend');
		$rootScope = $injector.get('$rootScope');
		lov = $injector.get('lov');

		$httpBackend.flush();

	}));

	it('gets the lov object for SELL', function() {

		var res = lov.getLookupCode('BUYORSELL_SELL');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res.lookupType).toBe("BUYSELL_TYPE");
		expect(res.displayName).toBe("Sell");

	});
	
	it('just returns back the code as displayName for misses', function() {

		var res = lov.getLookupCode('RANDOM CODE');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res.displayName).toBe('RANDOM CODE');

	});

	it('gets active lovs for BUYSELL_TYPE', function() {

		var res = lov.getByLookupType('BUYSELL_TYPE');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res.length).toBe(2);

	});

	it('gets inactive lovs for BUYSELL_TYPE', function() {

		var res = lov.getByLookupTypeByActivity('BUYSELL_TYPE', 'N');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res.length).toBe(1);

	});
	
	it('gets lovs by displayName', function() {

		var res = lov.getLookupByDisplayName('Execute Upon Approval', 'EXEC_DATE_TYPE');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res.lookupCode).toBe('EXECDTTYPE_UPONAPPROV');

	});
	
	it('does not return lovs for miss matched type', function() {

		var res = lov.getLookupByDisplayName('Execute Upon Approval', 'BAD_TYPE_HERE');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res).toBeUndefined();

	});
	
	it('does not return lovs for bad displayName', function() {

		var res = lov.getLookupByDisplayName('not a valid displayName here folks', 'EXEC_DATE_TYPE');
		res.then(function(resolved) {
			res = resolved;
		});
		$rootScope.$apply();
		expect(res).toBeUndefined();

	});
	
	// it('get list of genet dates', function() {
	// 	var res = lov.GENetDates();
	// 	$httpBackend.flush();
	// 	expect(res.length).toBe(119);
	// });

});
