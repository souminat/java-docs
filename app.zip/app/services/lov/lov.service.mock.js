angular.module('app.services.lov.mock', ['ngMock','app.config'])

.run(function($httpBackend, config) {
	var mockGeNetDates = ["23 JUN 2015","27 JUL 2015","25 AUG 2015","22 SEP 2015","26 OCT 2015","25 NOV 2015","23 DEC 2015","25 JAN 2016","23 FEB 2016","23 MAR 2016","26 APR 2016","25 MAY 2016","22 JUN 2016","27 JUL 2016","24 AUG 2016","22 SEP 2016","25 OCT 2016","25 NOV 2016","20 DEC 2016","24 JAN 2017","23 FEB 2017","21 MAR 2017","26 APR 2017","24 MAY 2017","22 JUN 2017","24 JUL 2017","23 AUG 2017","22 SEP 2017","23 OCT 2017","23 NOV 2017","19 DEC 2017","23 JAN 2018","22 FEB 2018","21 MAR 2018","24 APR 2018","24 MAY 2018","21 JUN 2018","23 JUL 2018","22 AUG 2018","24 SEP 2018","22 OCT 2018","22 NOV 2018","20 DEC 2018","23 JAN 2019","21 FEB 2019","21 MAR 2019","23 APR 2019","23 MAY 2019","24 JUN 2019","21 JUL 2019","22 AUG 2019","23 SEP 2019","21 OCT 2019","25 NOV 2019","20 DEC 2019","23 JAN 2020","24 FEB 2020","23 MAR 2020","23 APR 2020","25 MAY 2020","23 JUN 2020","23 JUL 2020","24 AUG 2020","22 SEP 2020","22 OCT 2020","24 NOV 2020","21 DEC 2020","22 FEB 2021","22 MAR 2021","22 APR 2021","25 MAY 2021","22 JUN 2021","22 JUL 2021","23 AUG 2021","22 SEP 2021","25 OCT 2021","24 NOV 2021","21 DEC 2021","21 DEC 2021","24 JAN 2022","22 FEB 2022","22 MAR 2022","25 APR 2022","23 MAY 2022","22 JUN 2022","25 JUL 2022","23 AUG 2022","22 SEP 2022","24 OCT 2022","24 NOV 2022","21 DEC 2022","23 JAN 2023","22 FEB 2023","22 MAR 2023","25 APR 2023","24 MAY 2023","22 JUN 2023","25 JUL 2023","23 AUG 2023","22 SEP 2023","23 OCT 2023","23 NOV 2023","21 DEC 2023","22 JAN 2024","22 FEB 2024","21 MAR 2024","23 APR 2024","23 MAY 2024","24 JUN 2024","22 JUL 2024","22 AUG 2024","23 SEP 2024","22 OCT 2024","25 NOV 2024","19 DEC 2024","21 JAN 2025","24 FEB 2025","24 MAR 2025","23 APR 2025"];
	var mockLov = [
			{
					"lookupCode": "BUYORSELL_BUY",
					"lookupType": "BUYSELL_TYPE",
					"description": "Buy",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "Buy",
					"displayOrder": "1"
			},
			{
					"lookupCode": "BUYORSELL_SELL",
					"lookupType": "BUYSELL_TYPE",
					"description": "Sell",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "Sell",
					"displayOrder": "2"
			},
			{
					"lookupCode": "BUYORSELL_JUNK",
					"lookupType": "BUYSELL_TYPE",
					"description": "For unit testing only",
					"isActive": "N",
					"isMandatory": "N",
					"displayName": "Junk",
					"displayOrder": "3"
			},
			{
					"lookupCode": "TRDREQTYPE_STRIP",
					"lookupType": "REQUEST_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "Strip",
					"displayOrder": null
			},
			{
					"lookupCode": "TRDREQTYPE_INDIVID",
					"lookupType": "REQUEST_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": " ",
					"displayOrder": null
			},
			{
					"lookupCode": "INST_FXFORWARD",
					"lookupType": "INSTRUMENT_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "FX Forward",
					"displayOrder": null
			},
			{
					"lookupCode": "INST_FXSPOT",
					"lookupType": "INSTRUMENT_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "FX Spot",
					"displayOrder": null
			},
			{
					"lookupCode": "INST_FXSWAP",
					"lookupType": "INSTRUMENT_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "FX Swap",
					"displayOrder": null
			},
			{
					"lookupCode": "TRDEVENT_FULLROLLBACK",
					"lookupType": "TRADE_EVENT_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "Full Rollback",
					"displayOrder": null
			},
			{
					"lookupCode": "TRDEVENT_AUTOCLOSEOUT",
					"lookupType": "TRADE_EVENT_TYPE",
					"isActive": "Y",
					"isMandatory": "Y",
					"displayName": "Auto Closeout",
					"displayOrder": null
			},
			{
					"lookupCode": "EXECDTTYPE_UPONAPPROV",
					"lookupType": "EXEC_DATE_TYPE",
					"description": "Execute Upon Approval",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Execute Upon Approval",
					"displayOrder": "1"
			},
			{
					"lookupCode": "MATURITYDT_SPOT",
					"lookupType": "MATURITY_DATE_TYPE",
					"description": "",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Spot",
					"displayOrder": "1"
			},
			{
					"lookupCode": "CLOSEOUTDT_CASH",
					"lookupType": "CLOSEOUT_DATE_TYPE",
					"description": "Cash Settlement (Physical Delivery)",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Cash Settlement (Physical Delivery)",
					"displayOrder": "1"
			},
			{
					"lookupCode": "CLOSEOUTDT_AUTOSPECIFY",
					"lookupType": "CLOSEOUT_DATE_TYPE",
					"description": "Auto Closeout - Specify Date",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Auto Closeout - Specify Date",
					"displayOrder": "1"
			},
			{
					"lookupCode": "CLOSEOUTDT_AUTOSPOT",
					"lookupType": "CLOSEOUT_DATE_TYPE",
					"description": "Auto Closeout - Spot",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Auto Closeout - Spot",
					"displayOrder": "2"
			},
			{
					"lookupCode": "HEDGE_CASHFLOW",
					"lookupType": "HEDGE_DESIGNATION",
					"description": "Cashflow",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Cashflow",
					"displayOrder": "2"
			},
			{
					"lookupCode": "HEDGE_STANDALONE",
					"lookupType": "HEDGE_DESIGNATION",
					"description": "Stand-Alone",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Stand-Alone",
					"displayOrder": "2"
			},
			{
					"lookupCode": "TAXHEDGE_NETINCHDG",
					"lookupType": "TAX_HEDGE_ID",
					"description": "Net Income hedge",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Net Income hedge",
					"displayOrder": "2"
			},
			{
					"lookupCode": "TAXHEDGE_OTHER",
					"lookupType": "TAX_HEDGE_ID",
					"description": "Other",
					"isActive": "Y",
					"isMandatory": "N",
					"displayName": "Other",
					"displayOrder": "2"
			},
			{
				"lookupCode": "INVOICEHEDGE_NO",
				"lookupType": "INVOICEHEDGE_TYPE",
				"description": "No",
				"isActive": "Y",
				"isMandatory": "N",
				"displayName": "No",
				"displayOrder": "2"
		},
		{
				"lookupCode": "INVOICEHEDGE_INTERCOMPINV",
				"lookupType": "INVOICEHEDGE_TYPE",
				"description": "Intercompany invoice only",
				"isActive": "Y",
				"isMandatory": "N",
				"displayName": "Intercompany invoice only",
				"displayOrder": "2"
		},
		{
				"lookupCode": "INVOICEHEDGE_INTERCOMPINVGENET",
				"lookupType": "INVOICEHEDGE_TYPE",
				"description": "Intercompany invoice through GENet",
				"isActive": "Y",
				"isMandatory": "N",
				"displayName": "Intercompany invoice through GENet",
				"displayOrder": "2"
		}
			
			
	];
	
	$httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/lov').respond(mockLov);
	$httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/lov/getGeNETDates').respond(mockGeNetDates);
});
