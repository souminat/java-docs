angular.module('app.services.lov', ['ngResource', 'app.config'])

    .factory('LovModel', function ($resource, config) {

        //setup custom action
        var _actions = {
            getAll: {
                method: 'GET',
                isArray: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: '' //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/lov', {}, _actions);

        return function () {
            return _resource;
        }
    })

    .factory('GENetList', function ($resource, config) {

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/lov/getGeNETDates');

        return function () {
            return _resource;
        }
    })

    .service('lov', function (LovModel, GENetList, $q) {

        var lov = this;

        lov.lovsArray = new LovModel().getAll();

        lov.getByLookupType = function (lookupType) {
            return this.getByLookupTypeByActivity(lookupType, 'Y');
        };

        lov.getByLookupTypeByActivity = function (lookupType, active) {
            var deferred = $q.defer();

            lov.lovsArray.$promise.then(function (data) {
                deferred.resolve(_.where(data, {lookupType: lookupType, isActive: active}));
            });

            return deferred.promise;
        };

        lov.getByLookupTypeExclude = function (lookupType, exclude) {
            var deferred = $q.defer(), lovs = this.getByLookupTypeByActivity(lookupType, 'Y');

            lovs.then(function (data) {
                deferred.resolve(_.filter(data, function (obj) {
                    return obj.lookupCode !== exclude;
                }));
            });

            return deferred.promise;
        };

        lov.getLookupCode = function (lookupCode) {
            var deferred = $q.defer();

            lov.lovsArray.$promise.then(function (data) {
                var res = _.findWhere(data, {lookupCode: lookupCode});
                deferred.resolve(res ? res : {displayName: lookupCode});
            });

            return deferred.promise;
        };

        lov.getLookupByDisplayName = function (displayName, lookupType) {
            var deferred = $q.defer();

            lov.lovsArray.$promise.then(function (data) {
                deferred.resolve(_.findWhere(data, {displayName: displayName, lookupType: lookupType}))
            });

            return deferred.promise;
        };

        lov.GENetDates = function () {
            return new GENetList().query();
        };
    });
