angular.module('app.services.holidayCalendar.mock', ['ngMock', 'app.config'])

    .service('holidayCalendarManagerMock', function (HolidayCalendar) {
        var mockDate = new Date(),
            holidayCalendarManagerMock = this,
            mockElement;

        mockElement = {
            "curr_end_date": null,
            "new_event_desc": "Weekend",
            "cntry_desc": "Unknown",
            "curr_id": 1001262,
            "curr_cd": "EUR",
            "curr_desc": "Euro",
            "new_event_cd": 712,
            "fin_cntr_nm": "TARGET holidays",
            "hol_dt": null,
            "cal_event_status": "Active",
            "mdm_id": "Tgt",
            "cntry_id": 1163,
            "fin_cntr_type_nm": "Bank",
            "fin_cntr_code": "Tgt",
            "cntry_iso_2_cd": "UN"
        };

        angular.extend(holidayCalendarManagerMock, {
            nextWeekendDate: function () {
                var daysUntilSaturday = 6 - mockDate.getDay();
                mockDate.setDate(mockDate.getDate() + (daysUntilSaturday || 1)); // If already Saturday, add 1 to return Sunday

                return mockDate.toString();
            },

            /**
             * Get a number of mocked elements. Cab be called with any of the following:
             *
             *  - To specify how many elements (dates will be the next X holidays)
             *      holidayCalendarManagerMock.mockElements(4);
             *
             *  - To return X elements with dates specified.
             *      holidayCalendarManagerMock.mockElements([date1, date2, date3]);
             *
             *      (dates given in array can either be a date string or a date object. Any empty values
             *      in the array will be parsed as the next weekend date)
             *
             * @param {number|Date[]|Array} dates
             * @returns {{elements: Array}}
             */
            mockElements: function(dates) {
                var elements = [], i, numElements;
                if (angular.isNumber(dates)) {
                    numElements = parseInt(dates);
                    dates = [];
                    for (i = 0; i < numElements; i++) {
                        dates[0] = holidayCalendarManagerMock.nextWeekendDate();
                    }
                }

                _.each(dates, function(dte) {
                    var element = angular.copy(mockElement),
                        elDate = angular.isDate(dte) ? dte : new Date(dte || holidayCalendarManagerMock.nextWeekendDate());
                    element.hol_dt = elDate.toString();
                    elements.push(element);
                });

                return {'elements': elements};
            },

            /**
             * Reset private date variable back to today's date
             */
            reset: function () {
                mockDate = new Date();
            }
        });

    })

    .run(function ($httpBackend, config, holidayCalendarManagerMock) {
        $httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/holiday').respond(holidayCalendarManagerMock.mockElements(4));
    });
