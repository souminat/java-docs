describe("app.services.holidayCalendar.spec", function() {

	var $httpBackend, config;
	
	beforeEach(module('templates'));
	beforeEach(module('app.services.holidayCalendar.mock'));
	beforeEach(module('app.services.holidayCalendar'));
	beforeEach(module('app.config'));

	beforeEach(inject(function($injector){
		$httpBackend = $injector.get('$httpBackend');
		holidayCalendarManagerMock = $injector.get('holidayCalendarManagerMock');
		holidayCalendarManager = $injector.get('holidayCalendarManager');
		config = $injector.get('config');
	}));


	afterEach(function () {
		holidayCalendarManagerMock.reset();
	});

	describe('holidayCalendar.parseDates', function() {
		var mockDates, mockElements;

		beforeEach(function () {
			// Array of date STRINGS, not date OBJECTS
			mockDates = [
				holidayCalendarManagerMock.nextWeekendDate(),
				holidayCalendarManagerMock.nextWeekendDate(),
				holidayCalendarManagerMock.nextWeekendDate(),
				holidayCalendarManagerMock.nextWeekendDate()
			];
			mockElements = holidayCalendarManagerMock.mockElements(mockDates);
		});

		it('can parse date objects from an array of holiday responses', function () {
			var parsed = holidayCalendarManager.parseDates(mockElements);
			for (var i = 0; i < parsed.length; i++) {
				expect(parsed[i].toString()).toBe(new Date(mockDates[i]).toString());
			}
		});

		it('can be given a pre-parsed array of date objects and will return the same', function () {
			var preParsedDates = [], i, parsed;
			for (i = 0; i < mockDates.length; i++) {
				preParsedDates[i] = new Date(mockDates[i]);
			}

			parsed = holidayCalendarManager.parseDates(preParsedDates);
			for (i = 0; i < parsed.length; i++) {
				expect(parsed[i].toString()).toBe(new Date(mockDates[i]).toString());
			}
		});
	});

	describe('holidayCalendar.isHoliday', function() {

		it('returns whether a given date is within the array of defined holidays', function() {
			var holidays = [new Date('2016-12-25'), new Date('2016-12-26')],
				holidayResponse = holidayCalendarManagerMock.mockElements(holidays);

			// Should be true for dates that have been specified as holidays...
			expect(holidayCalendarManager.isHoliday(holidays[0], holidayResponse)).toBeTruthy();
			expect(holidayCalendarManager.isHoliday(holidays[1], holidayResponse)).toBeTruthy();

			// But false for ones that haven't (e.g. Tuesday 27th December 2016)
			expect(holidayCalendarManager.isHoliday(new Date('2016-12-27'), holidayResponse)).toBeFalsy();
		});

		it('can treat weekends as holidays if specified', function() {
			var weekendDate = new Date(holidayCalendarManagerMock.nextWeekendDate()), weekdayDate;

			// Should return false when haven't specified to include weekends
			expect(holidayCalendarManager.isHoliday(weekendDate, [])).toBeFalsy();

			// Should return true when including weekends
			expect(holidayCalendarManager.isHoliday(weekendDate, [], true)).toBeTruthy();

			// And just to make sure, it should always return false for a weekday...
			weekdayDate = angular.copy(weekendDate);
			weekdayDate.setDate(weekendDate.getDate() + 3); // 3 days after Saturday or Sunday will be a weekday
			expect(holidayCalendarManager.isHoliday(weekdayDate, [], true)).toBeFalsy();
		});
	});

	describe('holidayCalendar.addBusinessDays', function() {

		it('returns the current date when it is not a holiday', function () {
			var input = new Date();
			expect(holidayCalendarManager.addBusinessDays(input, []).toString()).toBe(input.toString());
		});

		it('returns the next non-holiday date when current date is a holiday', function () {
			var input = new Date(), expected;
			expected = angular.copy(input);
			expected.setDate(input.getDate() + 1);
			expect(holidayCalendarManager.addBusinessDays(input, [input]).toString()).toBe(expected.toString());
		});

		it('adds only the given number of days when the are all business days', function () {
			var input = new Date('2016-11-28'), // Monday
				expected;
			expected = angular.copy(input);
			expected.setDate(input.getDate() + 4);
			expect(holidayCalendarManager.addBusinessDays(input, [], 4).toString()).toBe(expected.toString());
		});

		it('does not consider weekends as business days', function () {
            var input = new Date('2016-12-02'), // Friday
                expected;
            expected = angular.copy(input);
            expected.setDate(input.getDate() + 4); // Expect to add 4 days when adding 2 "business" days
            expect(holidayCalendarManager.addBusinessDays(input, [], 2).toString()).toBe(expected.toString());
		});

		it('does not consider weekends or holidays as business days', function () {
            var input = new Date('2016-12-23'), // Friday
                expected;
            expected = angular.copy(input);
            expected.setDate(input.getDate() + 5); // Expect to add 5 days when adding 2 "business" days
            expect(holidayCalendarManager.addBusinessDays(input, [new Date('2016-12-26')], 2).toString()).toBe(expected.toString());
		});
	});
});
