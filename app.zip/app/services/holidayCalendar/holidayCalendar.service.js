angular.module('app.services.holidayCalendar', ['ngResource', 'app.config'])

    .factory('HolidayCalendar', function ($resource, config) {
        //setup custom action
        var _actions = {
            getHolidays: {
                method: 'GET',
                params: {
                    calendarName: '@calendarName'
                },
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/holiday', {}, _actions);

        return function () {
            return _resource;
        }
    })

    .service('holidayCalendarManager', function (HolidayCalendar) {
        var holidayCalendarManager = this,
            holidayCalendar;

        holidayCalendar = new HolidayCalendar();

        // Public properties/methods
        angular.extend(holidayCalendarManager, {
            /**
             * Asynchronously load holidays from a calendar name, or array of calendar names
             * @param calendarName
             * @returns {*|{method, params, headers, data}}
             */
            getHolidaysByCalendarName: function (calendarName) {
                return holidayCalendar.getHolidays({calendarName: calendarName});
            },

            /**
             * Get an array of date objects from a raw array of elements from the holiday calendar service
             *
             * @param holidays
             * @returns {Array}
             */
            parseDates: function (holidays) {
                var dates = [];
                if (angular.isObject(holidays) && _.has(holidays, 'elements')) {
                    holidays = holidays.elements;
                }
                _.each(holidays, function(holiday) {
                    if (_.has(holiday, 'hol_dt')) {
                        dates.push(new Date(holiday.hol_dt));
                    } else if (angular.isDate(holiday)) {
                        // Perhaps the list of holidays was already parsed as dates.
                        dates.push(holiday);
                    }
                });

                return dates;
            },

            /**
             *
             * @param {Date} input
             * @param {*|Date[]} holidays - collection of date objects or raw JSON collection
             * @param {boolean} orWeekend - optionally treat weekends as holidays as well
             * @returns {boolean}
             */
            isHoliday: function (input, holidays, orWeekend) {
                if (orWeekend && _.contains([0, 6], input.getDay())) {
                    return true;
                }

                return !!_.find(this.parseDates(holidays), function(holiday) {
                    return angular.isDate(holiday) && (holiday.toDateString() === input.toDateString());
                });
            },

            /**
             * Given a proposed date, return the same date or the closest available that is not a holiday
             * @param {Date} from
             * @param {Date[]} holidays
             * @param {Number} addDays
             * @return {Date}
             */
            addBusinessDays: function (from, holidays, addDays) {
                var available = angular.copy(from),
                    numHolidays = 0,
                    i;
                // Start from a business day...
                while (this.isHoliday(available, holidays)) {
                    available.setDate(available.getDate() + 1);
                }
                // And then add given number of days...
                for (i = 0; i < addDays; i++) {
                    available.setDate(available.getDate() + 1);
                    if (this.isHoliday(available, holidays, true)) {
                        numHolidays++;
                    }
                }

                // Recursively add days until no more holidays/weekends were parsed
                return numHolidays ? this.addBusinessDays(available, holidays, numHolidays) : available;
            }
        });
    });
