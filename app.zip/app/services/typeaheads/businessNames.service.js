angular.module('app.services.businessNames', ['ngResource', 'app.config'])

    .factory('BusinessNamesFactory', function ($resource, config) {
        var _actions = {
            getMDMBusiness: {
                method: 'GET',
                cache: true,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getMDMBusiness', {}, _actions);

        return function () {
            return _resource;
        };
    })
    .factory('BusinessNamesFactoryERP', function ($resource, config) {
        var _actions = {
            getMDMBusiness: {
                method: 'GET',
                cache: true,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getMDMBusinessERP', {}, _actions);

        return function () {
            return _resource;
        };
    })

    .service('businessNamesManager', function (BusinessNamesFactory,BusinessNamesFactoryERP) {
        var businessNamesManager = this;

        // get all the business names with sub-business
        businessNamesManager.all = function () {
            return new BusinessNamesFactory().getMDMBusiness();
        };
        
        // get all the business names with sub-business for ERP
        businessNamesManager.allERP = function () {
            return new BusinessNamesFactoryERP().getMDMBusiness();
        };
    });