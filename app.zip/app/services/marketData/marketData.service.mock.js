angular.module('app.services.marketData.mock', ['ngMock'])

    .run(function ($httpBackend, config) {
        var mockMarketDataRequest = {
            "subscriber": {
                "subscriberName": "MKTDATASRVC_SUBSCRIBER_NAME",
                "authenticationToken": "MKTDATASRVC_AUTH_TOKEN"
            },
            "dateSetRequestList": [
                {
                    "baseCurrencyCode": "EUR",
                    "againstCurrencyCode": "USD",
                    "currencyPairCode": "EURUSD",
                    "tenor": [
                        "02/25/2015"
                    ],
                    "provider": "MKTDATASRVC_PROVIDER",
                    "interpolation": "true"
                }
            ]
        };
        var mockMarketDataResponse = {
            "marketDataServiceRequest": {},
            "responseID": 0,
            "serviceCallStatus": {
                "statusCode": 0,
                "statusDescription": "SUCCESS"
            },
            "dateSetResponseList": [
                {
                    "baseCurrencyCode": "EUR",
                    "againstCurrencyCode": "USD",
                    "currencyPairCode": "EURUSD",
                    "provider": "Bloomberg",
                    "rateUnit": null,
                    "rateValue": "1.1386",
                    "inverseRateValue": "0.8782715615668364",
                    "tenor": "02/25/2015",
                    "tenorInDays": null,
                    "marketLastUpdatedDate": "02/17/2015 10:30:27.0",
                    "pullDate": "02/17/2015 10:32:06.0",
                    "pullErrorReason": "Interpolation",
                    "inverseMatch": false
                }
            ],
            "availableCurrencyResponseList": []
        };
        var mockInvertedMarketDataRequest = {
            "subscriber": {
                "subscriberName": "MKTDATASRVC_SUBSCRIBER_NAME",
                "authenticationToken": "MKTDATASRVC_AUTH_TOKEN"
            },
            "dateSetRequestList": [
                {
                    "baseCurrencyCode": "USD",
                    "againstCurrencyCode": "CAD",
                    "currencyPairCode": "USDCAD",
                    "tenor": [
                        "02/25/2015"
                    ],
                    "provider": "MKTDATASRVC_PROVIDER",
                    "interpolation": "true"
                }
            ]
        };
        var mockInvertedMarketDataResponse = {
            "marketDataServiceRequest": {},
            "responseID": 0,
            "serviceCallStatus": {
                "statusCode": 0,
                "statusDescription": "SUCCESS"
            },
            "dateSetResponseList": [
                {
                    "baseCurrencyCode": "USD",
                    "againstCurrencyCode": "CAD",
                    "currencyPairCode": "USDCAD",
                    "provider": "Bloomberg",
                    "rateUnit": null,
                    "rateValue": "1.2459532",
                    "inverseRateValue": "0.8025983640477026",
                    "tenor": "08/03/2015",
                    "tenorInDays": null,
                    "marketLastUpdatedDate": "02/17/2015 10:30:29.0",
                    "pullDate": "02/17/2015 10:32:06.0",
                    "pullErrorReason": "Interpolation",
                    "inverseMatch": true
                }
            ]
        };

        // $httpBackend.when('GET', 'dist/app/apis/marketRate.json', mockMarketDataRequest).respond(mockMarketDataResponse);
        // $httpBackend.when('GET', 'dist/app/apis/marketRate.json', mockInvertedMarketDataRequest).respond(mockInvertedMarketDataResponse);
        $httpBackend.when('POST', config.apiBasePath + 'api/mypayments/v1/retrieveMarketRate', mockMarketDataRequest).respond(mockMarketDataResponse);
        $httpBackend.when('POST', config.apiBasePath + 'api/mypayments/v1/retrieveMarketRate', mockInvertedMarketDataRequest).respond(mockInvertedMarketDataResponse);
        //$httpBackend.when('POST', '/MarketDataService/retrieveMarketRate').respond(mockMarketDataResponse);
    });
