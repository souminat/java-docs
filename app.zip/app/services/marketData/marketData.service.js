angular.module('app.services.marketData', ['ngResource', 'app.services.lov'])

	.factory('SpotRateFactory', function ($resource, config) {
	    var _actions = {
	        getRate: {
	            method: 'GET',
	            cache: true,
	            headers: {
	                'Content-Type': 'application/json'
	            },
	            data: {} //you have data present for content-type header to be applied
	        }
	    };
	
	    var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/spotRate', {}, _actions);
	
	    return function () {
	        return _resource;
	    };
	})

    .factory('MarketDataModel', function ($resource, lov, config) {

        //setup custom action
        var _marketDataActions = {
            getRate: {
                method: 'POST',
                cache: true,
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/retrieveMarketRate', {}, _marketDataActions);

        // TODO get config item from LOV
        // var _SUBSCRIBER_NAME = lov.getLookupCode('MKTDATASRVC_SUBSCRIBER_NAME').dispname;
        // var _AUTH_TOKEN = lov.getLookupCode('MKTDATASRVC_AUTH_TOKEN').dispname;
        // var _PROVIDER = lov.getLookupCode('MKTDATASRVC_PROVIDER').dispname;
        var _SUBSCRIBER_NAME = 'TRS';
        var _AUTH_TOKEN = 'trs';
        var _PROVIDER = 'Bloomberg';

        //private helper functions
        var _marketRequestObj = function () {
            return {
                "subscriber": {
                    "subscriberName": _SUBSCRIBER_NAME,
                    "authenticationToken": _AUTH_TOKEN
                },
                "dateSetRequestList": []
            };
        };
        var _addRateRequest = function (marketRequestObj, currFrom, currTo) {
            marketRequestObj.dateSetRequestList.push({
                baseCurrencyCode: currFrom,
                againstCurrencyCode: currTo,
                currencyPairCode: currFrom + currTo,
                tenor: ['SPOT'], // TODO - can this change??
                provider: _PROVIDER,
                interpolation: 'true'
            });
        };

        //public model functions
        return function () {

            this.marketRequest = _marketRequestObj();

            this.addRateRequest = function (currFrom, currTo) {
                _addRateRequest(this.marketRequest, currFrom, currTo)
            };

            this.getRate = function () {
                return _resource.getRate(this.marketRequest);
            };
        }
    })

    .service('marketData', function (MarketDataModel, SpotRateFactory) {

        var marketData = this;

        marketData.getMarketRate = function (currFrom, currTo) {
            var marketDataModel = new MarketDataModel();
            marketDataModel.addRateRequest(currFrom, currTo);

            return marketDataModel.getRate();
        };

        marketData.getMarketRateList = function (pairs) {

            var marketDataModel = new MarketDataModel();

            for (var i in pairs) {
                marketDataModel.addRateRequest({
                    mdmTradeCurrCode: pairs[i].mdmTradeCurrCode,
                    mdmAgainstCurrCode: pairs[i].mdmAgainstCurrCode,
                    instrument: 'INST_FXSPOT',
                    lovMaturityTypeCode: 'MATURITYDT_SPOT'
                });
            }

            return marketDataModel.getRate();
        };
        
        marketData.getSpotRate = function(payerCurrency, payeeCurrency) {
        	var params = {
        		payerCurrency: payerCurrency,
        		payeeCurrency: payeeCurrency
        	};
        	return new SpotRateFactory().getRate(params);
        };

    });