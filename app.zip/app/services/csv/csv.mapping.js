angular.module('app.services.csv.mapping',[])

.service('csvMapping', function () {
	var csvMapping = this;
		
	csvMapping.rules = {
		'ACTION': 				[{name:'action', rule:'lookup', ruleType:'EXPOSURE_ACTION'}],
		'EXPOSURE ID': 			[{name:'exposureId', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_NEW']},
		               	 		 {name:'exposureId', rule:'exposure', ruleType:'exposureId',action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'EXPOSURE TYPE':  		[{name:'exposureType', rule:'lookup', ruleType:'EXPOSURE_TYPE'}, 
	                      		{name:'exposureType', rule:'type', ruleType:'empty', action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'PORTFOLIO CODE': 		[{name:'portfolioCode', rule:'portfolio', ruleType:'portfolioCode'},
	    						 {name:'portfolioCode', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'FUNCTIONAL CURRENCY': 	[{name:'funcionalCurrency', rule:'currency', ruleType:'code'},
	    						 {name:'funcionalCurrency', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'EXPOSURE CURRENCY': 	[{name:'exposureCurrency', rule:'currency', ruleType:'code'},
	    						 {name:'exposureCurrency', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'MATURITY DATE': 		[ {name:'maturityDate', rule: 'maturityDate', ruleType: 'maturityDate'},
	                     		 {name:'maturityDate', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'NOTIONAL AMOUNT': 		[{name:'notionalAmt', rule: 'currency', ruleType: 'amt'},
	                       		{name:'notionalAmt', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'PROGRAM ID': 			[{name:'programId', rule: 'type', ruleType: 'empty'},
	                  			{name:'programId', rule: 'type', ruleType: 'alphanumeric'}],
	    'ACTUAL AMOUNT': 		[{name:'actualAmt', rule: 'currency', ruleType: 'amt'},
	                     		{name:'actualAmt', rule:'type', ruleType:'empty',action:['EXPOSUREACTION_NEW','EXPOSUREACTION_UPDATE','EXPOSUREACTION_CANCEL','EXPOSUREACTION_COMPLETE']}],
	    'COMMENT': 				[{name:'comment', rule: 'type', ruleType: 'stringRequired' ,action:['EXPOSUREACTION_CANCEL']},
	               				{name:'comment', rule: 'type', ruleType: 'empty' ,action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_NEW','EXPOSUREACTION_COMPLETE']},
	               				{name:'comment', rule: 'type', ruleType: 'stringRequired' ,action:['EXPOSUREACTION_UPDATE','EXPOSUREACTION_NEW','EXPOSUREACTION_COMPLETE']},], 
	    'EFFECTIVE DATE': 		[{name:'effectiveDate', rule: 'maturityDate', ruleType: 'effectiveDate'},
	               		        {name:'effectiveDate', rule:'type', ruleType:'empty'}],           				
	};
	
	csvMapping.importNewExposure = [
	    'ACTION',
	    'EXPOSURE ID',
	    'EXPOSURE TYPE',
	    'PORTFOLIO CODE',
	    'FUNCTIONAL CURRENCY',
	    'EXPOSURE CURRENCY',
	    'MATURITY DATE',
	    'NOTIONAL AMOUNT',
	    'PROGRAM ID',
	    'ACTUAL AMOUNT',
	    'COMMENT',
	    'EFFECTIVE DATE'
 	];
	
	//Needed only for validation
	csvMapping.newColumnAllowed = [
	    'ACTION',
	    'EXPOSURE TYPE',
	    'PORTFOLIO CODE',
	    'FUNCTIONAL CURRENCY',
		'EXPOSURE CURRENCY',
		'MATURITY DATE',
		'NOTIONAL AMOUNT',
		'PROGRAM ID',
		'ACTUAL AMOUNT',
		'COMMENT',
		'EFFECTIVE DATE'
	];
	csvMapping.cancelColumnAllowed = [
		'ACTION',
		'EXPOSURE ID',
		'PROGRAM ID',
		'COMMENT'
	];
		
});