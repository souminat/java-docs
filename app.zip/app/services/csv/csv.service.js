angular.module('app.services.csv',[
'app.services.csv.mapping',
'app.services.validation',
'app.messages'
])

.service('csv', function ($q, csvMapping, validation,  messages) {
	var csv = this;
	
	//have PapaParse do its thing. csvFile can be fileobj or string
	csv.parse = function(csvFile) {
		
		var deferred = $q.defer();
		
		Papa.parse(csvFile,
			{
				header: true,
				skipEmptyLines: true,
				complete: function(results) {
					deferred.resolve(results);
				}
			}
		);
		
		return deferred.promise;
	};
	
	csv.prepareValidation = function() {
		return validation.loadPrequisites();
	};
	
	csv.cleanupValidation = function() {
		validation.unloadPrequisites();
	};
	
	//file upload of full trade
	csv.importNewExposure = function(parseResults) {
		return csv.import(parseResults, csvMapping.importNewExposure, true);
	};	
		

	
	//read csv papaParse result to json array
	csv.import = function(parseResults, requiredColumns) {
		
		//return obj
		var importResult = {
			valid: true, //assume its valid, it will get marked bad
			validData: true, //assume its valid, it will get marked bad when GENet has error
			errors: [],
			rows: [],
			policy: {}
		};
		
		//make sure csv parsed good
		var parseErrors = csv.hasParseErrors(parseResults, requiredColumns);
		if(parseErrors.length > 0) {
			importResult.valid = false;
			importResult.errors = parseErrors;
			return importResult;
		}
		
		//check for required fields
		var requiredErrors = csv.hasRequiredFields(parseResults, requiredColumns);
		if(requiredErrors.length > 0) {
			importResult.valid = false;
			importResult.errors = requiredErrors;
			return importResult;
		}
		
		//check for required fields data by action
		var requiredActionErrors = csv.validateDataByAction(parseResults, requiredColumns);
		if(requiredActionErrors.length > 0) {
			importResult.valid = false;
			importResult.errors = requiredActionErrors;
			return importResult;
		}
		
		//validate and parse into object
		for(var row in parseResults.data) {
			try {
				var currentRowHasError = false;
				
				//this will be the object for this row
				var exposureRow = {};
				
				for(var index in requiredColumns) {
					var importColResult = csv.importColumn(parseResults.data[row], requiredColumns[index], exposureRow);
					
					if(importColResult.valid===false) {
						currentRowHasError = true;
						importResult.valid = false;
						importResult.errors.push({ row: parseInt(row)+1, column: requiredColumns[index], error:importColResult.message });
					}
				}				
				
				// Add original maturity date format
				exposureRow.maturityDateOriginal = parseResults.data[row]['MATURITY DATE']; 
				importResult.rows.push(exposureRow);				
			}
			catch(exeception) {				
				importResult.valid = false;
				importResult.errors.push({ row: parseInt(row)+1, column: 'EXCEPTION', error:"Unhandled exception, contact system admin if this continues." });
			}
		}
		
		if(importResult.valid && !importResult.validData){
			importResult.valid = false;
		}
		return importResult;
	};
	
	//returns row/column/error array
	csv.hasParseErrors = function(parseResults) {
		
		var columnErrors = [];
		
		for(var index in parseResults.errors) {
			columnErrors.push({row: 0, column: 'file', error: parseResults.errors[index].type + 'parse error: ' + parseResults.errors[index].message });
		}
		
		return columnErrors;
	};
	
	//returns row/column/error array
	csv.hasRequiredFields = function(parseResults, requiredColumns) {
		
		var columnErrors = [];
		
		for(var index in requiredColumns) {
			if(_.indexOf(parseResults.meta.fields, requiredColumns[index]) === -1) {
				columnErrors.push({row: 0, column: 'header', error: 'Missing required column: ' + requiredColumns[index]});
			}
		}
		
		return columnErrors;
	};
 	
	//Writes directly to the destiniationObject, returns validation retsult.
	csv.importColumn = function(row, columnName, destinationObject) {
		var importResult = {};
		var columnRules = csvMapping.rules[columnName];
		
		if(columnRules && _.isArray(columnRules)) {
			
			var validateResult = csv.validate(columnRules, destinationObject, row[columnName], row);
			
			if(validateResult.matchedMapping) {
				
				// if mapping was found, set the object property
				csv.setObjectProperty(destinationObject, validateResult.matchedMapping.name, validateResult.testResults.pop().result);				
				
				//found rule and parsed to property
				importResult.valid = true;
			}
			else {
				// if no matching mapping was found, do nothing
				importResult.valid = false;
				importResult.message = _.pluck(validateResult.testResults, "result").join(' or ');
			}

		}
		else {
			importResult.valid = false;
			importResult.message = 'Unknown column: ' +  columnName;
		}
		
		return importResult;
	};
	
	//run single validation and return result
	csv.validate = function(columnRules, destinationObject, value, rowValue) {
		
		var testResults = [];
		
		// first mapping to met above criteria is should be used
		var matchedMapping = _.find(columnRules, function(mapping) {
				
			// check for matching action (no action means any action is ok)
			if(!mapping.action || _.indexOf(mapping.action, destinationObject.action) > -1 || !destinationObject.action){
				
				//test the unfomat using the rule and ruleType
				var test = validation.test(mapping.rule, mapping.ruleType, value, rowValue);
				
				testResults.push(test);
				return test.worked;
			}
			else {
				
				return false;
			}
		
		
		});
		
		return {testResults: testResults, matchedMapping: matchedMapping};
	};
 	
 	//write to object (supports property name or multiple level deep i.e. 'prop.subname.subsubname')
	csv.setObjectProperty = function(destinationObject, propertyName, value) {
		
		propertyNameSplit = propertyName.split('.');
		
		var targetObj = destinationObject;
		
		//create sub objects as needed
		for(var i=1;i<propertyNameSplit.length;i++){
			if(!targetObj[propertyNameSplit[i-1]]) {
				targetObj[propertyNameSplit[i-1]] = {};
			}
			targetObj = targetObj[propertyNameSplit[i-1]];
		}
		
		//set the property
		targetObj[propertyNameSplit[propertyNameSplit.length-1]] = value;
	};
	
	//get an object (supports property name or multiple level deep i.e. 'prop.subname.subsubname')
	csv.getObjectProperty = function(refObject, propertyName) {
		
		propertyNameSplit = propertyName.split('.');
		
		var targetObj = refObject;
		
		//create sub objects as needed
		for(var i=1;i<propertyNameSplit.length;i++){
			if(!targetObj[propertyNameSplit[i-1]]) {
				return null;
			}
			targetObj = targetObj[propertyNameSplit[i-1]];
		}
		
		//return the property
		return targetObj[propertyNameSplit[propertyNameSplit.length-1]];
	};
	
	csv.hasColumn = function(result, feildName) {
		return _.indexOf(result.meta.fields, feildName) > -1;
	};

	//Validate rows with only required values by action
	csv.validateDataByAction = function(parseResults, requiredColumns){
		var allErrors = [];
		
		for (var row in parseResults.data){
			if(parseResults.data[row]['ACTION'] !== null && parseResults.data[row]['ACTION'] !== ''){
				var requiredByAction = null;
				if(parseResults.data[row]['ACTION'] === 'Cancel'){
					requiredByAction = csvMapping.cancelColumnAllowed;
				}else if (parseResults.data[row]['ACTION'] === 'New') {
					requiredByAction = csvMapping.newColumnAllowed;
				}
				if(requiredByAction !== null){
					for(var index in requiredColumns){
						if(parseResults.data[row][requiredColumns[index]] !== ''
							&& requiredByAction.indexOf(requiredColumns[index]) === -1){
							allErrors.push({ row:  parseInt(row)+1, column: requiredColumns[index], error: 'Field should be empty for this particular action'});
						};
					};
				};
			};
		}
		
		return allErrors;
	};
});