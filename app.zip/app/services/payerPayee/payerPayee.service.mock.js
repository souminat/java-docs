angular.module('app.services.payerPayee.mock', ['ngMock', 'app.config'])

    .run(function ($httpBackend, config) {
        var mockdata = [
            {
                umbrellaName: "GE Power",
                tradeEntityName: "GE Hungary Gas",
                portfolioCode: "CC2020-GEAVIO-BR0000-EUR",
                tCode: "HN71"
            },
            {
                umbrellaName: "GE Power",
                tradeEntityName: "GE Hungary Oil",
                portfolioCode: "CC2020-GEAVIO-BR0000-EUR",
                tCode: "HN71"
            },
            {
                umbrellaName: "GE Capital EFS",
                tradeEntityName: "EFS Guayama P.R. Holdings B.V. C41AAA KB9 TI",
                portfolioCode: "GC0900-C41AAA-BR0000-USD",
                tCode: "KA21"
            },
            {
                umbrellaName: "GE Capital EFS",
                tradeEntityName: "EFS Guayama Oil",
                portfolioCode: "GC0901-C41AAA-BR0000-USD",
                tCode: "KA22"
            }
        ];

        // $httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/payerpayee?searchTerm=eur').respond(mockdata);
        $httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/payerpayee').respond(mockdata);

    });
