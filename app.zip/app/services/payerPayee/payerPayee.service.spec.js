describe("app.services.payerPayee.spec", function() {

    var $httpBackend, payerPayeeManager, config;

    beforeEach(module('templates'));
    beforeEach(module('app.services.payerPayee.mock'));
    beforeEach(module('app.services.payerPayee'));
    beforeEach(module('app.config'));

    beforeEach(inject(function($injector){
        $httpBackend = $injector.get('$httpBackend');
        payerPayeeManager = $injector.get('payerPayeeManager');
        config = $injector.get('config');
    }));

    it('searches all the payerPayees for a user', function() {
        $httpBackend.expectGET(config.apiBasePath + 'api/mypayments/v1/payerpayee');
        payerPayeeManager.all();
        $httpBackend.flush();
    });

    it('umbrella matches with payerPayee', function() {
        var payerPayee = {};
        payerPayee.umbrellaName = 'GE Aviation';
        expect(payerPayeeManager.umbrellaMatchForThisPayerPayee(payerPayee, 'GE Aviation')).toBe(true);
        expect(payerPayeeManager.umbrellaMatchForThisPayerPayee(payerPayee, 'GE Oil and Gas HQ')).toBe(false);
    });

    describe('advanced search', function() {
        var expected = [{
            "tradeEntityName": "EFS Guayama P.R. Holdings B.V. C41AAA KB9 TI",
            "tCode": "KA21",
            "bankAcct": {"currencyCode": "GBP"}
        }];

        it('can search for a single field', function() {
            var actual;
            $httpBackend.expectGET(config.apiBasePath + 'api/mypayments/v1/advancedSearch?tCode=KA21').respond(200, expected);
            actual = payerPayeeManager.advancedSearch({tCode: 'KA21'});
            $httpBackend.flush();
            expect(actual.length).toBe(1);
            expect(actual[0].tCode).toBe('KA21');
        });

        it('can search for multiple fields', function () {
            var actual;
            $httpBackend.expectGET(config.apiBasePath + 'api/mypayments/v1/advancedSearch?entityName=EFS&tCode=KA21').respond(200, expected);
            actual = payerPayeeManager.advancedSearch({tCode: 'KA21', entityName: 'EFS'});
            $httpBackend.flush();
            expect(actual.length).toBe(1);
            expect(actual[0].tCode).toBe('KA21');
        });
    });
});
