angular.module('app.services.payerPayee', ['ngResource', 'app.config'])

    .factory('PayerPayee', function ($resource, config) {

        //setup custom action
        var _actions = {
            search: {
                method: 'GET',
                isArray: true,
                cache: true,
                params: {  //default parameters
                    searchTerm: null
                },
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            },
            advancedSearch: {
                method: 'GET',
                url: config.apiBasePath + 'api/mypayments/v1/advancedSearch',
                isArray: true,
                params: {  //default parameters
                    entityName: null,
                    tCode: null,
                    currencyCode: null
                },
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {} //you have data present for content-type header to be applied
            }
        };

        var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/payerpayee', {}, _actions);

        return function () {
            return _resource;
        };
    })

    .service('payerPayeeManager', function ($q, PayerPayee) {
        var payerPayeeManager = this,
            umbrellaSort;

        umbrellaSort = function (a, b) {
            var umbrellaA = a.umbrellaName.toLowerCase(), umbrellaB = b.umbrellaName.toLowerCase();
            if (umbrellaA < umbrellaB) //sort string ascending
                return -1;
            if (umbrellaA > umbrellaB)
                return 1;
            return 0; //default return value (no sorting)
        };

        payerPayeeManager.all = function () {
            var deferred = $q.defer(),
                results = new PayerPayee().search();

            results.$promise.then(function (results) {
                results.sort(umbrellaSort);
                deferred.resolve(results);
            });

            return deferred.promise;
        };

        payerPayeeManager.search = function (criteria) {
            var deferred = $q.defer(),
                results = new PayerPayee().search({searchTerm: criteria});

            results.$promise.then(function (results) {
                results.sort(umbrellaSort);
                deferred.resolve(results);
            });

            return deferred.promise;
        };

        payerPayeeManager.advancedSearch = function (criteria) {
            return new PayerPayee().advancedSearch(criteria);
        };

        payerPayeeManager.getByPortfolioCode = function (payerPayees, code) {
            return _.findWhere(payerPayees, {portfolioCode: code});
        };

        payerPayeeManager.getUmbrellas = function (payerPayees) {
            var umbrellas = [];

            _.each(payerPayees, function (value, key, list) {

                var currentUmbrella = {
                    // umbrellaId: 		value.umbrellaId,
                    umbrellaName: value.umbrellaName
                };

                var isAdded = _.findWhere(umbrellas, currentUmbrella);

                if (!isAdded) {
                    umbrellas.push(currentUmbrella);
                }
            });

            return umbrellas;
        };

        payerPayeeManager.umbrellaMatchForThisPayerPayee = function (payerPayee, umbrellaName) {
            return !!(payerPayee && (payerPayee.umbrellaName === umbrellaName));
        };

        payerPayeeManager.onShoreDocFlags = ["YES", "NO"];

    });