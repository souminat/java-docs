angular.module('app.services.user', ['ngResource', 'app.config'])

.factory('User', function($resource, config) {

	var _resourceAll = $resource(config.apiBasePath + 'api/mypayments/v1/userLookUp');
	var _resourceCurrentUser = $resource(config.apiBasePath + 'api/mypayments/v1/getUserSession');
	
	return function(sso) {
		if(sso){//to get other users 
			return _resourceAll.get({code: sso});
		}else{//to get current user 
			return _resourceCurrentUser.get();
		}
	}
	
})

.service('userManager', function (User, $cacheFactory) {
	var userManager = this;
	
	var userCache = $cacheFactory('userCache');
	
	userManager.get = function(sso, options) {
		
		if(!options) {
			options = {};
		}
		
		if(options.allowCache) {
			var cacheUser = userCache.get(sso);
			if(cacheUser) {
				return cacheUser;
			}
			else {
				var newuser = new User(sso);
				userCache.put(sso, newuser);
				
				return newuser;
			}
		}
		else {
			return new User(sso);
		}
		
	};
});