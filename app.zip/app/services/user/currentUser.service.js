angular.module('app.services.currentUser', ['ngResource', 'app.services.user'])

.service('currentUser', function (User) {

	var currentUser = this;

	var _userPreferenceDefaults = {
		homePage: 'pages.payments',
		theme: 'lightsOff'
	};

	currentUser.me = new User();
	
	currentUser.getAppPermission = function(appPermission) {
		var permission = undefined;
		angular.forEach(currentUser.me.permission, function(currentPermission) {
			if (currentPermission === appPermission) {
				permission = currentPermission;
			}
		});
		return permission;
	};

	currentUser.hasPermission = function(permission) {
		return currentUser.getAppPermission(permission) !== undefined;
	};
		
	currentUser.hasPermissionForState = function($state) {

		if($state.includes("fx.approvals") && !currentUser.hasOneOfTheseRoles(['SystemAdmin','Approver'])) {
			return false;
		}
		else if($state.includes("fx.requests") && !currentUser.hasOneOfTheseRoles(['SystemAdmin','Requester'])) {
			return false;
		}

		return true;
	};

	currentUser.homePage = function() {
		return currentUser.getPreferenceOrDefault('homePage');
	};

	currentUser.getPreferenceOrDefault = function(prefName) {
		var preferenceModel = currentUser.getPreference(prefName);

		if (preferenceModel) {
			return preferenceModel.preferenceValue;
		}
		if (!prefName in _userPreferenceDefaults) {
			return null;
		}

		return _userPreferenceDefaults[prefName];
	};

	currentUser.getPreference = function(myPreferenceName) {
		// Temporarily commenting out until user preferences are available
		// return _.findWhere(currentUser.me.userPreferencesList, { preferenceName: myPreferenceName });
		return null;
	};

});
