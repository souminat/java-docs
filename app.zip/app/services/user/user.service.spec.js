describe("user service", function() {

	var $httpBackend, currentUser, userManager;

	beforeEach(module('app.services.user.mock'));
	beforeEach(module('app.services.user'));
	beforeEach(module('app.services.currentUser'));

	beforeEach(inject(function ($injector) {

		$httpBackend = $injector.get('$httpBackend');
		currentUser = $injector.get('currentUser');
		userManager = $injector.get('userManager');

		$httpBackend.flush(); //wait for user me

	}));

	it('fetches user model for current user', function () {

		expect(currentUser.me.sso).toBe('999999001');

	});
});