angular.module('app.services.user.mock', ['ngMock', 'app.config'])

    .run(function($httpBackend, config) {
        var mockMe = {
            "requestData": null,
            "status": null,
            "statusMessage": null,
            "responseData": null,
            "sso": "999999001",
            "appRole": "REQUESTER",
            "umbrellas": ["GE Aviation"]
        };

        $httpBackend.when('GET', config.apiBasePath + 'api/mypayments/v1/getUserSession').respond(mockMe);

    });
