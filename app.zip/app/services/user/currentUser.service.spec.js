describe("app.services.currentUser.spec", function() {

	var $httpBackend, currentUser, userManager, requestGroupManager;

	beforeEach(module('app.services.user.mock'));
	beforeEach(module('app.services.currentUser'));

	beforeEach(inject(function ($injector) {
		$httpBackend = $injector.get('$httpBackend');
		currentUser = $injector.get('currentUser');

		$httpBackend.flush(); //wait for user me
	}));

	it('uses default homePage when not defined as a user preference', function () {

		expect(currentUser.homePage()).toBe('pages.payments');

	});
});