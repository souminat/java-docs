angular.module('app.services.payments', ['ngResource', 'app.config'])

	.factory('PaymentRequestFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			create: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/createPaymentRequest_v2', {}, _actions);

		return function (payment) {
			return _resource.create(payment);
		}
	})
	.factory('ERPPaymentRequestFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			createERPPaymentRequest: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/createPaymentRequest_v2', {}, _actions);

		return function (payment) {
			return _resource.createERPPaymentRequest(payment);
		}
	})
	.factory('PaymentSearchFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			getDashboardResults: {
				method: 'POST',
				isArray: true,
				headers: {
					'Content-Type': 'application/json'
				}
			}
		};
		
		var _resource = $resource(config.apiBasePath + 'api/dashboard/v1/getDashboardResults', {} , _actions);
	 	
		return function (paginatedResultList) {
			return _resource.save(paginatedResultList);
		};
	}) 
	.factory('ApprovalDashboardSearchFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			getDashboardResults: {
				method: 'POST',
				isArray: true,
				headers: {
					'Content-Type': 'application/json'
				}
			}
		};
		
		var _resource = $resource(config.apiBasePath + 'api/dashboard/v1/getDashboardResults', {} , _actions);
	 	
		return function (paginatedResultList) {
			return _resource.save(paginatedResultList);
		};
	}) 
	.factory('PaymentFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			getPaymentById: {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/retrivePaymentRequest', {}, _actions);

		return function () {
			return _resource;
		};
	})
	.factory('ApprovalFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			approvePayment: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {}
			}
		};
		
		var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/approvePaymentRequest', {} , _actions);
		
		return function (paymentRequest) {
			return _resource.approvePayment(paymentRequest);
		};
	})
	.factory('RejectFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			rejectPayment: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {}
			}
		};
		
		var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/rejectPaymentRequest', {} , _actions);
    	
		return function (paymentRequest) {
			return _resource.rejectPayment(paymentRequest);
		};
	})
	.factory('CancelFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			cancelPayment: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {}
			}
		};
		
		var _resource = $resource(config.apiBasePath + 'api/trigger-workflows/v1/cancelPaymentRequest', {} , _actions);
    	
		return function (paymentRequest) {
			return _resource.cancelPayment(paymentRequest);
		};
	})
    .factory('AssignToPersonFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		assignToPerson: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
    			data: {}
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/dashboard/v1/assignPersonToReq', {} , _actions);
    	
    	return function (obj) {
    		return _resource;
    	};
    })
    .factory('PrepareFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		preparePayment: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
    			data: {}
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/trigger-workflows/v1/preparePaymentRequest', {} , _actions);
    	
    	return function (paymentRequest) {
    		return _resource.preparePayment(paymentRequest);
    	};
    })
    .factory('RejectPrepareFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		rejectPreparePayment: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
    			data: {}
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/trigger-workflows/v1/rejectPaymentRequest', {} , _actions);
    	
    	return function (paymentRequest) {
    		return _resource.rejectPreparePayment(paymentRequest);
    	};
    })
    .factory('ReleaseFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		releasePayment: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
    			data: {}
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/trigger-workflows/v1/prepareReleaseRequest', {} , _actions);
    	
    	return function (paymentRequest) {
    		return _resource.releasePayment(paymentRequest);
    	};
    })
    .factory('RejectReleaseFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		rejectReleasePayment: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
    			data: {}
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/trigger-workflows/v1/rejectPaymentRequest', {} , _actions);
    	
    	return function (paymentRequest) {
    		return _resource.rejectReleasePayment(paymentRequest);
    	};
    })
    .factory('PayeeFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		getPayeeList: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
    			params: {
    				payerSearchValue: '@payerSearchValue'
    			},
    			data: {} //you have data present for content-type header to be applied
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getPayeeFilterResult',{} , _actions);
    	
    	return function (filters) {
    		return _resource.getPayeeList(filters);
    	};
    })
    .factory('PayerFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		getPayerList: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
        	    data: {} //you have data present for content-type header to be applied
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getPayerFilterResult',{} , _actions);
    	
    	return function (filters) {
        		return _resource.getPayerList(filters);
    	};
    })
    .factory('RequestTypeFactory', function ($resource, config) {
    	//setup custom action
    	var _actions = {
    		getRequests: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
        	    data: {} //you have data present for content-type header to be applied
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getRequestTypeResult',{} , _actions);
    	
    	return function (filters) {
    		return _resource.getRequests(filters);
    	};
    })
    .factory('confirmPaymentRequestFactory', function ($resource, config) {
    	var _actions = {
    		confirmPaymentRequest: {
    			method: 'POST',
    			headers: {
    				'Content-Type': 'application/json'
    			},
        	    data: {} //you have data present for content-type header to be applied
    		}
    	};
    	
    	var _resource = $resource(config.apiBasePath + 'api/trigger-workflows/v1/saveManualConfirmation',{} , _actions);
    	
    	return function (paymentRequest) {
    		return _resource.confirmPaymentRequest(paymentRequest);
    	};
    })
    
    .factory('myApprovalDashboardSearchFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				getMyApprovalDashboardResults: {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json'
				}
			}
		};
		
		var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/getApprovers', {} , _actions);
	 	
		return function () {
			return _resource.getMyApprovalDashboardResults();
		};
	})  
	
	.factory('staticUrlFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				getStaticUrls: {
				method: 'GET',
				headers: {
					'Content-Type': 'application/json'
				}
			}
		};
		
		var _resource = $resource(config.apiBasePath + '/fetch-static-urls', {} , _actions);
	 	
		return function () {
			return _resource.getStaticUrls();
		};
	})  
    .service('paymentRequestManager', function (PaymentRequestFactory,ERPPaymentRequestFactory, PaymentSearchFactory,ApprovalDashboardSearchFactory, PaymentFactory, ApprovalFactory, RejectFactory, PrepareFactory, RejectPrepareFactory, ReleaseFactory, RejectReleaseFactory, PayeeFactory, PayerFactory, RequestTypeFactory, AssignToPersonFactory, confirmPaymentRequestFactory, myApprovalDashboardSearchFactory, CancelFactory,staticUrlFactory) {
    	var paymentRequestManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(paymentRequestManager, {
        	/**
        	 * Insert a payment request into DB
        	 */
        	createPaymentRequest: function (payment) {
        		return new PaymentRequestFactory(payment);
        	},
        	/**
        	 * Insert a ERP payment request into DB
        	 */
        	createERPPaymentRequest: function (payment) {
        		return new ERPPaymentRequestFactory(payment);
        	},
        	/**
        	 * Get the payment dashboard
        	 */
        	getDashboardResults : function (paginatedResultList) {
        		return new PaymentSearchFactory(paginatedResultList);//.getDashboardResults();
        	},
            /**
             * Get the payment dashboard
             */
        	getApprovalDashboardResults : function (paginatedResultList) {
        		return new ApprovalDashboardSearchFactory(paginatedResultList);//.getDashboardResults();
        	},
        	/**
        	 * Get a payment by id
        	 */
        	getPaymentRequestById: function(paymentRequestId) {
        		return new PaymentFactory().getPaymentById({
        			paymentRequestId: paymentRequestId
        		});
        	},
            /**
             * Approve a payment request
             */
        	approvePaymentRequest: function(paymentRequest) {
        		return new ApprovalFactory(paymentRequest);
        	},
        	/**
        	 * Reject a payment request
        	 */
        	rejectPaymentRequest: function(paymentRequest) {
        		return new RejectFactory(paymentRequest);
        	},
        	/**
        	 * Prepare a payment request
        	 */
        	preparePaymentRequest: function(paymentRequest) {
        		return new PrepareFactory(paymentRequest);
        	},
        	/**
        	 * Release a payment request
        	 */
        	releasePaymentRequest: function(paymentRequest) {
        		return new ReleaseFactory(paymentRequest);
        	},
            /**
             * Reject a payment request
             */
        	rejectPreparePaymentRequest: function(paymentRequest) {
        		return new RejectPrepareFactory(paymentRequest);
        	},
            /**
             * Reject a release payment request
             */
        	rejectReleasePaymentRequest: function(paymentRequest) {
        		return new RejectReleaseFactory(paymentRequest);
        	},
            /**
             * Cancel a payment request
             */
        	cancelPaymentRequest: function(paymentRequest) {
        		return new CancelFactory(paymentRequest);
        	},
        	/**
        	 * Assing the request to a person
        	 */
            assignPersonToRequest: function(obj){
            	return new AssignToPersonFactory().assignToPerson({
            		requestId: obj.requestId,
            		assignToSSO: obj.assignToSSO
            	});
            },
            /**
             * Get the payee list
             */
            getPayeeList : function(filters) {	
            	criteria = clearFilters(filters);
            	var searchList = new PayeeFactory(criteria);
        		return searchList;
            },
            /**
             * Get the payer list
             */
            getPayerList : function(filters) {	
            	criteria = clearFilters(filters);
            	var searchList = new PayerFactory(criteria);
            	return searchList;
            },
            /**
             * Get the request type options
             */
         	getRequestTypeOptions : function(filters){
         		criteria = clearFilters(filters);
         		var searchList = new RequestTypeFactory(criteria);
         		return searchList;
         	},
         	/**
         	 * Confirm a payment request
         	 */
         	confirmPaymentRequest: function(paymentRequest) {
         		return new confirmPaymentRequestFactory(paymentRequest);
         	},
         	getMyApprovalDashboardResults : function () {
        		return new myApprovalDashboardSearchFactory();//.getDashboardResults();
        	},
        	getStaticUrls : function () {
        		
        		if(typeof this.cached == 'undefined'){
        			this.cached = new staticUrlFactory();
            		return this.cached;//.getDashboardResults();
        		}else{
        			return this.cached;
        		}
        	}
         	         	
        });
    });