angular.module('app.services.processingQueue',[
	'ngResource',
	'app.config'
])
.factory('ProcessingQueueFactory', function($resource, config) {
	
	var _actions = {
		getProcessingQueue: {
			method: 				'GET',			
			params: {  //default parameters
				start: 1,
				limit: config.PAGINATION_SIZE,
				orderBy: 'FILE_UPLOAD_ID',
				direction: 'DESC'
			},
			headers: {
				'Content-Type': 	undefined //required for file upload to work
			},
			data: {}
		}
	};
	var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/FileUpload', {}, _actions);

	return function(offset) {		
		return _resource.getProcessingQueue({start: offset});
	}
})

.service('processingQueueManager', function (ProcessingQueueFactory) {
	var processingQueueManager = this;
	
	processingQueueManager.getProcessingQueue = function(offset) {
		return new ProcessingQueueFactory(offset);
	};
})
