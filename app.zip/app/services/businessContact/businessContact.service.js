angular.module('app.services.businessContact', ['ngResource', 'app.config'])

	.factory('businessContactModel', function ($resource, config) {
	
	    //setup custom action
	    var _actions = {
	    		getContact: {
	            method: 'GET',
	            isArray: true,
	            params:{
	            	code:''
	            },
	            data: {} //you have data present for content-type header to be applied
	        }
	    };
	    
	    var _resource = $resource(config.apiBasePath + 'api/mypayments/v1/userLookUpAssignTo', {}, _actions);
	
	    return function () {
	        return _resource;
	    }
	})

.service('businessContact', function (businessContactModel,  $q) {

    var self = this;
    self.entityArray;
    self.getbusinessContact = function (name) {
    	var contact = name.replace(/[^a-zA-Z0-9]/g, '').replace(/\s+/g, '');
    	
    	 return new businessContactModel().getContact({code:contact});
    	 }

});