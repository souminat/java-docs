angular.module('app.filters.account.filter', [])
	.filter('accountFilter', function() {
	    return function(accountNumber) {
	        var convertedText = undefined;
	        if(accountNumber) {
	        	convertedText = accountNumber.replace(/.(?=.{4})/g, 'X');
	        }
	        return convertedText;
	    }
	});