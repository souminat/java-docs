angular.module('app', [
'ui.router',
'ux.util.idleTimer',
'ux.form.simpleModal',
'ux.form.inputModal',
'app.messages',
'app.pages'
])

.config(function ($provide, $locationProvider, $urlRouterProvider, $stateProvider, $httpProvider, messagesProvider) {

	$locationProvider.html5Mode({enabled:true, rewriteLinks:false});
	
	//handle route misses
	$urlRouterProvider.otherwise('/home');
	
	//handle global ajax errors
	$provide.factory('myHttpInterceptor', function($q, $injector) {
		return {
			'responseError': function(rejection) {
				
				//inject this late, otherwise you get a dependancy loop
				var simpleModal = $injector.get('simpleModal');
				
				console.log('responseError: ' + rejection.status);
				
				//Scenario 1: There was an internal server error and we are hearing it from baseController
				/*if(rejection.status===500 && rejection.statusText === "Internal Server Error") {
					simpleModal.open({
						title:'Error Occured', 
						body: messagesProvider.error.internalServerError
					});
				}*/
				
				//Scenario 2: Production SSO - The user session is invalid and a service was attempted to be redirected to SSO Login (status === 0)
				if(rejection.status===0) {
					simpleModal.open({
						title:'Session Timeout', 
						body: messagesProvider.error.invalidSession
					}).result.then(function () {
						//reload the page. This should result in a round trip to SSO login and then back to the current page
						window.location.reload(true);
					});
				}
				
				//Scenario 3: Local Development - The user session is invalid (status === 500)
				else if(rejection.status===500) {
					simpleModal.open({
						title:'Error Occured', 
						body: messagesProvider.error.unknownServerError
					});
				}
				
				//Scenario 4: There was an bad request error and have status text from baseController
				else if(rejection.status===400) {
					if(rejection.data.includes('errorCode') && rejection.data.includes('errorMessage')){
						 var errorJSON;
			                var unknownErrors = '';

			                try {
			                    errorJSON = JSON.parse(rejection.data);
			                }
			                catch(err) {
			                    unknownErrors = errors.data;
			                }

			                if(unknownErrors !== '') {
			                    simpleModal.open({bodyHTML:unknownErrors});
			                }else{
			                	simpleModal.open({
									title:'Validation Error', 
									body: errorJSON.errorMessage
								});
			                }

			                //$('.ng-invalid').focus();
					}else{
						simpleModal.open({
							title:'Error Occured', 
							body: rejection.data
						});
					}
				}
		
				return $q.reject(rejection);
			}
		};
	});
	$httpProvider.interceptors.push('myHttpInterceptor');
	
	//***cache buster****//
	//initialize get if not there
	if (!$httpProvider.defaults.headers.get) {
		$httpProvider.defaults.headers.get = {};
	}
	$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
	$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
	$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
	
	var defaultTransformResponse = $httpProvider.defaults.transformResponse[0];
	
	function EMdefaultTransform(data, headers, status) {
		//success codes, allow transform to json
		if(200 <= status && status < 300) {
			return defaultTransformResponse(data, headers);
		}
		//error codes, no transforming
		else return data;
	}
	
	//overwrite the defaults transform
	$httpProvider.defaults.transformResponse = [EMdefaultTransform];
	
})

.run(function($rootScope, $state, messages, simpleModal, config) {
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){ 
		config.mobileMenuShown = false;
	});
	$rootScope.$on('$stateChangeSuccess',function(event, toState, toParams, fromState, fromParams){
		 $rootScope.$state = $state;
	});
	
})