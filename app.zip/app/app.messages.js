angular.module('app.messages',[])

.provider('messages', function() {
	var messages = this;
	
	messages.validation = {};
	messages.validation.empty = "This field is required";
	messages.validation.afterDay = "Date must be after {1}";
	messages.validation.afterEqualDay = "Date must be after or equal to {1}";
	messages.validation.beforeDay = "Date must be before {1}";
	messages.validation.beforeEqualDay = "Date must be before or equal to {1}";
	messages.validation.currencySame = "Currencies cannot be the same";
	messages.validation.currencyInvalid = "Currency typed is not a valid currency";
	messages.validation.specifyDateFormatMonth = "Please specify the date in MMM YYYY format";
	messages.validation.greaterThanZero = "Please enter a value greater than or equal to {0}";
	messages.validation.lessThanZero = "Please enter a value less than or equal to {0}";
	messages.validation.emptyPayer = "Please select a payer";
	
	messages.error = {};
	messages.error.gotoidNumber = 'You can only enter a trade request ID (must be a number).';
	messages.error.navigationError = 'Navigation error. Unable to navigate to "{0}".';
	messages.error.internalServerError = 'Internal Server Error. Please contact system administrator if this continues.';
	messages.error.unknownServerError = 'There was an unknown server error processing your request. Please contact system administrator if this continues.';
	messages.error.invalidSession = 'Session is invalid, you must log in again.';
	messages.error.userPermissionCashflowOnly = 'User does not have permission to create requests for this instrument because they cannot create Standalone Hedges (Cashflow only)';
	messages.error.noMatchingTrade = 'No matching Trade Request ID found. Please confirm the ID and re-enter';
	messages.error.invalidExtension ='Please upload .csv files only';
	messages.error.parentTradeNotFound = 'Parent Trade Id not found.';
	messages.error.cannotCreateTradeEvent = 'Trade Event is not permitted for this Parent Trade.';
	messages.error.greaterAmoutThanNotional = 'Closeout Amount should not be greater than Parent Notional Amount.';
	messages.error.partialCloseoutNotAllowed = 'Partial Closeouts are not allowed for this trade';
	messages.error.rollbackDateGreater = 'Rollback date should be less than Parent Maturity Date.';
	messages.error.rolloverDateSmaller = 'Rollover date should be greater than Parent Maturity Date.';
	messages.error.hedgePermissionForUser = 'User does not have permission to create for this hedge:';
	messages.error.dataNotLoaded = 'Please wait until all MDM data is loaded';
	
	messages.success = {};
	messages.success.saveDraftTradeSuccess='Trade has been successfully saved';
	messages.success.saveDraftSuccess='Request Group has been successfully saved';
	messages.success.cancellationRequestSuccess='Request Group has been successfully canceled';
	messages.success.submitRequestSuccess='Request Group has been successfully sent for approval';
	messages.success.approvalRequestSuccess='Request Group has been successfully approved';
	
	messages.request = {};
	messages.request.cancellationRequest='Cancellation request has been sent for approval';
	messages.request.approvalRequest='Request has been sent for approval';
	messages.request.rejectRequest='Request Group will be sent back to requestor';
	messages.request.exportRequest='Preparing export...';
	messages.request.exportPendingRequest="Marking today's trades as pending and preparing export...";
	messages.request.uploadTradeRequest="Uploading executed trades...";
	messages.request.discardRequest='You are sure you want to discard this request?';
	messages.request.submitRequest='Submitting Request...';
	messages.request.noMatchingReqgrpId='No matching Request Group ID found.';
	messages.request.cancelTradeRequest='Discarding Trade...';
	messages.request.cancelCloseout='You are sure you want to cancel this closeout event?';
	messages.request.cancellingCloseout='Cancelling Event...';
		
	this.$get = function() {
		return messages;
	};
});

