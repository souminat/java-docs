package com.example.model;

import java.util.Date;

public class Employee {

	int empID;
	String empName;
	String doj;
	String empTech;
	String level;
	String day;
	public Employee() {
		super();
	}
	
	/*public Employee(int empID, String empName, Date date, String tech,
			String grade) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.date = date;
		this.tech = tech;
		this.grade = grade;
	}*/
	/*public Employee(int empID, String empName) {
		super();
		this.empID = empID;
		this.empName = empName;
	}*/
	public int getEmpID() {
		return empID;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getEmpTech() {
		return empTech;
	}

	public void setEmpTech(String empTech) {
		this.empTech = empTech;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + ", doj="
				+ doj + ", empTech=" + empTech + ", level=" + level + "]";
	}

	
	
	
	
}
