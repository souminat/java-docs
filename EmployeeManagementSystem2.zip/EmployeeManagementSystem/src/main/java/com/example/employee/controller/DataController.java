package com.example.employee.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping("/employee")
public class DataController {
	
	List<String> techList = new ArrayList<String>();
	
	@RequestMapping(value="/techList",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public List<String> technologyDropDown(){
		initializeTechList();
		System.out.println("Inside dropdown controller");
		
		return techList;
	}
	
	private void initializeTechList(){
		
		techList.add("Java");
		techList.add("C#");
		techList.add("Python");
		techList.add("Mainframe");
		techList.add("C++");
		techList.add("PHP");
		techList.add("SAP");
	}
}
