package com.example.employee.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.model.Employee;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	List<Employee> empList = new ArrayList<Employee>();
	Set<String> techList = new HashSet<String>();
	Set<String> gradeList = new HashSet<String>();
	
	@RequestMapping(value="/insertEmployee",method=RequestMethod.POST,consumes="application/json")
	@ResponseBody
	public void createEmployee(@RequestBody Employee employee){
		System.out.println("Inside createEmployee");
		System.out.println(employee);
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		Date formatetdDate;
		try {
			formatetdDate = dateFormatter.parse(employee.getDoj());
			System.out.println(employee.getDay());
			employee.setDay(employee.getDay());
			System.out.println(formatetdDate.getDate() + 1);
			
			String finalDate = "" + (formatetdDate.getMonth() + 1) + "/"  + (formatetdDate.getDate() + 1) + "/" + (formatetdDate.getYear() + 1900);
			System.out.println(finalDate);
			
			employee.setDoj(finalDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//employee.setDoj(formatetdDate);
		
		//String stringDate = employee.getDoj().toString();
		//String formattedDate = stringDate.replace();
		
		
		
		storeEmployee(employee);
	}
	
	@RequestMapping(value="/showEmployees",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public List<Employee> showEmployees(){
		/*System.out.println(empList);
		Employee employee = new Employee();
		employee.setEmpID(1001);
		employee.setEmpName("Soumik");
		storeEmployee(employee);
		Employee employee1 = new Employee();
		employee1.setEmpID(1002);
		employee1.setEmpName("Sourav");
		storeEmployee(employee1);*/
		for(Employee emp:empList){
			System.out.println(emp.getDay());
		}
		return empList;
	}
	
	@RequestMapping(value="/deleteEmployee",method=RequestMethod.POST,consumes="application/json")
	@ResponseBody
	public void deleteEmployee(@RequestBody Employee employee){
		
		System.out.println("Inside deleteController");
		System.out.println(employee);
		for(Employee emp:empList){
			if(emp.getEmpID() == employee.getEmpID() && (emp.getEmpName()).equals(employee.getEmpName())){
				System.out.println("Inside If");
				empList.remove(emp);
				break;
			}
		}
		System.out.println("Printing the List");
		for(Employee emp:empList){
			System.out.println(emp);
		}
		//return empList;
	}
	
	@RequestMapping(value="/updateEmployee",method=RequestMethod.POST,consumes="application/json")
	@ResponseBody
	public List<Employee> updateEmployee(@RequestBody Employee employee){
		
		System.out.println("Inside updateController");
		System.out.println(employee);
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		Date formatetdDate;
		try{
			formatetdDate = dateFormatter.parse(employee.getDoj());
			System.out.println(employee.getDay());
			employee.setDay(employee.getDay());
			System.out.println(formatetdDate.getDate() + 1);
			
			String finalDate = "" + (formatetdDate.getMonth() + 1) + "/"  + (formatetdDate.getDate() + 1) + "/" + (formatetdDate.getYear() + 1900);
		
			employee.setDoj(finalDate);
		}catch(ParseException e){
			System.out.println(e);
		}
		
		int index = 0;
		
		for(Employee emp:empList){
			//index++;
			if(emp.getEmpID() == employee.getEmpID()){
					System.out.println("Inside update employee");
					System.out.println(employee);
					//emp.setEmpName(employee.getEmpName());
					empList.set(empList.indexOf(emp),employee);
					break;
			}
		}
		
		System.out.println("Printing the list");
		for(Employee emp:empList){
			System.out.println(emp);
		}
			return empList;
	}
	
	@RequestMapping(value="/viewEmployeeDetails/{empID}",method=RequestMethod.GET)
	@ResponseBody
	public Employee viewEmpDetails(@PathVariable("empID") int empID){
		
		Employee employee  = new Employee();
		for(Employee emp:empList){
			if(emp.getEmpID() == empID){
				employee.setEmpID(emp.getEmpID());
				employee.setEmpName(emp.getEmpName());
				employee.setDoj(emp.getDoj());
				employee.setEmpTech(emp.getEmpTech());
				employee.setLevel(emp.getLevel());
			}
		}
			return employee;
	}
	@RequestMapping(value="/techList",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Set<String> technologyDropDown(){
		initializeTechList();
		System.out.println("Inside dropdown controller");
		
		return techList;
	}
	
	@RequestMapping(value="/gradeList",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Set<String> gradeDropDown(){
		initializeGradeList();
		
		return gradeList;
	}
	
    private void initializeTechList(){
		
		techList.add("Java");
		techList.add("C#");
		techList.add("Python");
		techList.add("Mainframe");
		techList.add("C++");
		techList.add("PHP");
		techList.add("SAP");
	}
	
    private void initializeGradeList(){
    	gradeList.add("P4");
    	gradeList.add("P3");
    	gradeList.add("B2");
    	gradeList.add("B1");
    	gradeList.add("A2");
    	gradeList.add("A1");
    }
    
	private void storeEmployee(Employee employee){
		empList.add(employee);
	}
}
