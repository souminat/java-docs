/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.constants;

/**
 * Contains the constants for currency fields
 *
 * @author MyPayments Dev Team
 *
 */
public interface MDMConstants {

    public static final String MY_PAYMENT = "MyPayment";
    public static final String CONTACT_ATTRIBUTES = "Contact Attributes";
    public static final String CORE_ATTRIBUTES = "Core Attributes";


    public static final String BUSINESS_BUSINESS_ACCOUNT_GROUP = "BUS_ACCT_GRP";
    public static final String BUSINESS_SUBBUSINESS_ACCOUNT_GROUP = "SUB_BUS_ACCT_GRP";
    public static final String BUS_ACCT_GRP_STATUS = "BUS_ACCT_GRP_STATUS";
    public static final String SUB_BUS_ACCT_GRP_STATUS = "SUB_BUS_ACCT_GRP_STATUS";

    public static final String S = "S";
    public static final String S0 = S + "0";
    public static final String S1 = S + "1";
    public static final String S2 = S + "2";
    public static final String S3 = S + "3";

    public static final String ACTIVE = "Active";
    
    public static final String OPEN = "Open";
    public static final String DIVESTED = "Divested";

    public static final String ENTITY_NAME_CURRENCY = "Currency";
    public static final String ENTITY_NAME_BANK_BRANCH = "Bank-Branch";
    public static final String ENTITY_NAME_BUSINESS = "Business";

    public static final String OPERATOR_EQUALS = "=";
    public static final String QUOTE = "'";
    public static final String OPERATOR_GREATER_THAN = "gt";
    public static final String OPERATOR_LESS_THAN = "lt";
    public static final String OPERATOR_LIKE = "like";
    public static final String OPERATOR_OR = "OR";
    public static final String OPERATOR_AND = "AND";

    public static final String ORDER_ASCENDING = "asc";
    public static final String ORDER_DESCENDING = "desc";

    public static final String CURRENCY_CURRENCY_STATUS = "STATUS";
    public static final String CURRENCY_MDM_CODE = "CURR_CODE";

    public static final String ENTITY_SEARCH_TERM = "searchTerm";
    public static final String TCODE_FILTER = "tCode";
    public static final String ENTITY_FILTER = "entityName";
    public static final String CURRENCY_FILTER = "currencyCode";
    
    public static final String COUNTRY_STATUS = "CNTRY_STATUS";

    public static final String LE_PRIMARY_ALT_CODE = "PRIMRY_ALT_CODE";
    public static final String LE_PARTY_NM = "PARTY_NM";
    public static final String LE_PARTY_LONG_NM = "PARTY_LONG_NM";
    public static final String LE_PRIMRY_SCOURCE_SYSTEM = "PRIMRY_SRCE_SYS";
    public static final String LE_PARTY_STATUS = "PARTY_STATUS";
    
    public static final String UPPER_1 = ") = UPPER('";
	public static final String UPPER_2 = "UPPER(";
	public static final String FILTER_CONST = "$filter";
	public static final String ELEMENTS = "elements";
	public static final String UPPER_3 = ") like UPPER('%";
	public static final Object AND_STRING = " and ";
	public static final String TOTAL_COUNT_REQUIRED = "$totalCountRequired";
	public static final String CHAR_EXPR = "\\r|\\n";
	
	public static final String UTF_ENCODING = "UTF-8";
	
	public static final String MDM_QUERY_PARAM = "requestData";
	public static final String JSON_GET_MESSAGE = "message";
    public static final String JSON_GET_STATUS_MESSAGE = "statusMessage";
    public static final String JSON_GET_STATUS = "status";
    
    public static final String MDM_ERROR = "MDM ERROR: ";
}
