/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.domain;

import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Attributes needed for FineGrainAuth response
 * 
 * @author MyPayments Dev Team
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FineGrainResponse {

	private String appName;
	private Collection<FineGrainRole> roles;
	private String sso;

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(final String appName) {
		this.appName = appName;
	}

	public Collection<FineGrainRole> getRoles() {
		return roles;
	}

	public void setRoles(final Collection<FineGrainRole> roles) {
		this.roles = roles;
	}
}