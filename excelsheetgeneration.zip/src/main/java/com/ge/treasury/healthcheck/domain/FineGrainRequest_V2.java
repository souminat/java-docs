/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Attributes needed for FineGrainAuth functionality
 * 
 * @author MyPayments Dev Team
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FineGrainRequest_V2 {

	private String appName;
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public FineGrainRequest_V2() {
		super();
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName
	 *            the appName to set
	 */
	public void setAppName(final String appName) {
		this.appName = appName;
	}

}
