package com.ge.treasury.healthcheck.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ServiceCheck implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 3138088552635671856L;
    
    private String applicationName;
    private String environment;
    private String endPoint;
    private String filterDescription;
    private String paymentRequestId;
    private String ssoId;
    Map <String, StatusTime> statusMap;
    List <Map<String, StatusTime>> statusList;
    
    public String getApplicationName() {
        return applicationName;
    }
    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }
    public String getEnvironment() {
        return environment;
    }
    public void setEnvironment(String environment) {
        this.environment = environment;
    }
    public String getEndPoint() {
        return endPoint;
    }
    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }
    public String getFilterDescription() {
        return filterDescription;
    }
    public void setFilterDescription(String filterDescription) {
        this.filterDescription = filterDescription;
    }
    public Map<String, StatusTime> getStatusMap() {
        return statusMap;
    }
    public void setStatusMap(Map<String, StatusTime> statusMap) {
        this.statusMap = statusMap;
    }
    public List<Map<String, StatusTime>> getStatusList() {
        return statusList;
    }
    public void setStatusList(List<Map<String, StatusTime>> statusList) {
        this.statusList = statusList;
    }
    public String getPaymentRequestId() {
        return paymentRequestId;
    }
    public void setPaymentRequestId(String paymentRequestId) {
        this.paymentRequestId = paymentRequestId;
    }
    public String getSsoId() {
        return ssoId;
    }
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }
  
}
