package com.ge.treasury.healthcheck.domain;

import java.util.Comparator;

public class CreateUserInput {
	private String sso;
	private String isReconciler;
	private String isContingentWorker;
	private String function;
	private String role;
	private String business;
	private String subBusiness;
	private String tCodeSvcCenter;

	public CreateUserInput() {
	}

	public CreateUserInput(String sso, String isReconciler, String isContingentWorker, String function, String role,
			String business, String subBusiness, String tCodeSvcCenter) {
		super();
		this.sso = sso;
		this.isReconciler = isReconciler;
		this.isContingentWorker = isContingentWorker;
		this.function = function;
		this.role = role;
		this.business = business;
		this.subBusiness = subBusiness;
		this.tCodeSvcCenter = tCodeSvcCenter;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public String getIsReconciler() {
		return isReconciler;
	}

	public void setIsReconciler(String isReconciler) {
		this.isReconciler = isReconciler;
	}

	public String getIsContingentWorker() {
		return isContingentWorker;
	}

	public void setIsContingentWorker(String isContingentWorker) {
		this.isContingentWorker = isContingentWorker;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getSubBusiness() {
		return subBusiness;
	}

	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}

	public String gettCodeSvcCenter() {
		return tCodeSvcCenter;
	}

	public void settCodeSvcCenter(String tCodeSvcCenter) {
		this.tCodeSvcCenter = tCodeSvcCenter;
	}

	@Override
	public String toString() {
		return "CreateUserInput [sso=" + sso + ", isReconciler=" + isReconciler + ", isContingentWorker="
				+ isContingentWorker + ", function=" + function + ", role=" + role + ", business=" + business
				+ ", subBusiness=" + subBusiness + ", tCodeSvcCenter=" + tCodeSvcCenter + "]";
	}

	public static Comparator<CreateUserInput> CreateUserInputComparator = new Comparator<CreateUserInput>() {
		public int compare(CreateUserInput createUserInput1, CreateUserInput createUserInput2) {
			String sso1 = createUserInput1.getSso();
			String sso2 = createUserInput2.getSso();
			return sso1.compareTo(sso2);

		}

	};
	
	public static Comparator<CreateUserInput> CreateUserInputRoleComparator = new Comparator<CreateUserInput>() {
		public int compare(CreateUserInput createUserInput1, CreateUserInput createUserInput2) {
			String role1 = createUserInput1.getRole();
			String role2 = createUserInput2.getRole();
			return role1.compareTo(role2);

		}

	};

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((business == null) ? 0 : business.hashCode());
		result = prime * result + ((function == null) ? 0 : function.hashCode());
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		result = prime * result + ((sso == null) ? 0 : sso.hashCode());
		result = prime * result + ((subBusiness == null) ? 0 : subBusiness.hashCode());
		result = prime * result + ((tCodeSvcCenter == null) ? 0 : tCodeSvcCenter.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreateUserInput other = (CreateUserInput) obj;
		if (business == null) {
			if (other.business != null)
				return false;
		} else if (!business.equals(other.business))
			return false;
		if (function == null) {
			if (other.function != null)
				return false;
		} else if (!function.equals(other.function))
			return false;
		if (role == null) {
			if (other.role != null)
				return false;
		} else if (!role.equals(other.role))
			return false;
		if (sso == null) {
			if (other.sso != null)
				return false;
		} else if (!sso.equals(other.sso))
			return false;
		if (subBusiness == null) {
			if (other.subBusiness != null)
				return false;
		} else if (!subBusiness.equals(other.subBusiness))
			return false;
		if (tCodeSvcCenter == null) {
			if (other.tCodeSvcCenter != null)
				return false;
		} else if (!tCodeSvcCenter.equals(other.tCodeSvcCenter))
			return false;
		return true;
	}

	
	
}
