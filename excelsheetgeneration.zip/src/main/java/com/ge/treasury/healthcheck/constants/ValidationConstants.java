/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.constants;

/**
 * List of Constants needed for Validation
 * 
 * @author MyPayments Dev Team
 *
 */
public interface ValidationConstants {

    public static final String FILE_EXT_REGEX = "^[^\\/:\"*?<>|]+(.csv)$";
    
    public static final String ALPHANUMERIC_REGEX = "^[-_.,;()a-zA-Z0-9 ]*$";
    
    public static final String MANIFEST_REGEX = "^[-_.,:;a-zA-Z0-9 ]*$";
    
    public static final String ALPHANUMERIC_COLUMNNAME_REGEX = "^[_a-zA-Z0-9]*$";

    public static final String ALPHANUMERIC_ONLY_REGEX = "^[a-zA-Z0-9]*$";

    public static final String ANYTHING_BUT_REGEX = "^[^<<>|*/%>]+$";
    
    public static final String ALPHANUMERIC_COMMA_REGEX = "^([ -_.()a-zA-Z0-9]+,?)+$";

    public static final String IDM_APPNAME = "MyPayments";
    public static final String IDM_STATUSACTIVE = "ACTIVE";
    public static final String IDM_STATUSRESPONSE = "SUCCESS";
    public static final String USERPROFILE_GENERIC_ERROR = "Unable to Get ACL User information";

    public static final String INVALID_DEFAULT_MESSAGE = "Field is empty or value is invalid.";

    public static final String MATURITY_DATE_FORMAT = "MM/DD/YYYY";
    public static final String DATE_FORMAT = "dd MMM yyyy";
    public static final String MONTH_FORMAT = "MMM";
    public static final String DATE_TIME_FORMAT = "dd MMM yyyy HH:mm:ss aaa";
    public static final String DATE_ACT_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String MDMDATE_FORMAT = "yyyy-MM-dd";
    public static final String CREATEDATE_FORMAT = "EEE MMM dd HH:mm:ss zzzz yyyy";
    public static final String DBDATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSSSS";

    public static final String AUDIT_DOMAIN = "MyPayments";
    public static final String AUDIT_ENTITY = "Payment Request";
    public static final String AUDIT_PARENT_ADDED = "Added";
    public static final String AUDIT_PARENT_UPDATED = "Updated";
    public static final String AUDIT_PARENT_DELETED = "Deleted";

    public static final String AUDIT_PAYMENT_STATUS = "paymentStatus";

    public static final String MDM_REQUESTOR = "MyPayments";
    public static final String MDM_ENTITY_BNKACCTCENTRALIZE = "BankAccountCentralize";
    public static final String MDM_STATUS_RESPONSE = "SUCCESS";
    public static final String MDM_QUERY_PARAM = "requestData";

    public static final String REQUEST_TYPE_CODE = "REQUEST_TYPE";

    public static final String RECORD_NOTFOUND = "Record Not Found";

    public static final String DEFAULT_LOV_LOOKUPTYPE_ORDER = "LOOKUP_TYPE,DISPLAY_ORDER";
    public static final String DEFAULT_ASC_DIRECTION = "ASC";

    public static final String FORMAT_KEY = "format";

    public static final String START_FILEUPLOAD_KEY = "start";
    public static final String START_FILEUPLOAD_VALUE = "1";
    public static final String LIMIT_FILEUPLOAD_KEY = "limit";
    public static final String LIMIT_FILEUPLOAD_VALUE = "10";

    public static final String JSON_GET_STATUS = "status";
    public static final String JSON_GET_MESSAGE = "message";
    public static final String JSON_GET_STATUS_MESSAGE = "statusMessage";
    public static final String JSON_GET_STATUS_OK = "OK 200";
    public static final String JSON_GET_DATA = "data";
    
    public static final String MYPAYMENTS_AUDIT_DOMAIN = "MyPayments";
    public static final String MYPAYMENTS_AUDIT_ENTITY = "Payment Request";
    public static final String MYPAYMENTS_AUDIT_PARENT_ADDED = "Added";
    public static final String MYPAYMENTS_AUDIT_PARENT_UPDATED = "Updated";
    public static final String MYPAYMENTS_AUDIT_PARENT_DELETED = "Deleted";
    public static final String ACCOUNT_STATUS = "requestStatus";
    
	public static final String DOCUMENTS = "documents";
	public static final String SIGNERS = "signers";
	public static final String NULL_EQUAL = "=null";

}
