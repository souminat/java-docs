package com.ge.treasury.healthcheck.controller;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.beanio.stream.csv.CsvWriter;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ge.treasury.healthcheck.domain.CreateUserInput;
import com.ge.treasury.healthcheck.domain.DataContent;
import com.ge.treasury.healthcheck.domain.FileUpload;
import com.ge.treasury.healthcheck.service.impl.UploadFileService;

@RestController
@RequestMapping("/api/createUser/v1")
public class CreateUsersController {
	
	
	@RequestMapping(value="/createCSV",method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody FileUpload createCSVFile(@RequestParam("file") MultipartFile file, HttpServletResponse response) throws IOException{
		System.out.println("- Creating Users started...");
		System.out.println(file.getOriginalFilename());
		//String filePath = args[0];// file from command prompt
		String filePath = ("C:\\Users\\souminat\\Documents\\UserData\\PilotProject\\" + file.getOriginalFilename());
		File uploadFile = new File(filePath);// fetch the file
		File userLoadProd = null;
		FileUpload file1 = new FileUpload();
		ByteArrayInputStream bis = null;
		if (uploadFile.exists()) {
			InputStream inputFS = null;
			List<CreateUserInput> createUserInputList = new ArrayList<CreateUserInput>();
			Map<String, List<CreateUserInput>> processEntity = null;
			
			try {
				inputFS = new FileInputStream(uploadFile);
				BufferedReader br = new BufferedReader(new InputStreamReader(inputFS));
				createUserInputList = br.lines().skip(1).map(mapToItem).collect(Collectors.toList());
				processEntity = new HashMap<String, List<CreateUserInput>>();

				// Sort Records on SSO
				// Collections.sort(createUserInputList,
				// CreateUserInput.CreateUserInputComparator);
				createUserInputList.sort((i1, i2) -> i1.getSso().compareTo(i2.getSso()));

				// Formulate process objects
				for (CreateUserInput i : createUserInputList) {
					// System.out.println("->"+i.getSso() + " -> Role :" +
					// i.getRole());
					if (processEntity.containsKey(i.getSso())) {
						processEntity.get(i.getSso()).add(i);
					} else {
						processEntity.put(i.getSso(), new ArrayList<CreateUserInput>());
						processEntity.get(i.getSso()).add(i);
					}
				}

 				Iterator it = processEntity.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pair = (Map.Entry) it.next();
					List<CreateUserInput> list = (List<CreateUserInput>) pair.getValue();
					System.out.println("Key -> " + pair.getKey() + " and size : " + list.size());
				}

				/*
				 * 1. Validate every user and its rows 2. Reject if incorrect
				 * --- Define error Map 3. Create XML request for every row 3.
				 * Call rest endpoint and create the user
				 */

				// validate records
				
				Map<String,String> finalOutputMap = new HashMap<String,String>();
				Map<String,String> csvData = new HashMap<String,String>();
				List<DataContent> dataMap= new ArrayList<DataContent>();
				try {
					dataMap = UploadFileService.validateInput(processEntity);
					
					//Iterate Finaloutput Map:
					Iterator opIt = finalOutputMap.entrySet().iterator();
					while (opIt.hasNext()) {
						Map.Entry pair = (Map.Entry) opIt.next();
						//System.out.println("---------------------------------------------------");
						//System.out.println("SSO:" + pair.getKey());
						String actualString = (String)pair.getValue();
						//System.out.println("Value:" + pair.getValue());
						csvData.put(pair.getKey().toString(),actualString);
						//System.out.println("---------------------------------------------------");
					}
					file1.setContent(dataMap);
					
					//Write to CSV 
					userLoadProd = new File ("C:\\Users\\souminat\\Desktop\\postman.csv");
					file1.setFile(userLoadProd.getAbsolutePath());
					//CsvWriter writer = new CsvWriter(new FileWriter(userLoadProd));
					Iterator itNew = csvData.entrySet().iterator();
					String FILE_HEADER = "SSO,ROLE,BUSINESS,SUB-BUSINESS,FUNCTION,TCODE,BUS-5-ID,BUS-6-ID";
					FileWriter fileWriter = new FileWriter(userLoadProd);
					fileWriter.append(FILE_HEADER.toString());
					
					//Add a new line separator after the header
					fileWriter.append("\n");
					while (itNew.hasNext()) {
						Map.Entry pair = (Map.Entry) itNew.next();
						fileWriter.append(pair.getKey().toString());
						fileWriter.append(",");
						fileWriter.append(pair.getValue().toString());
						fileWriter.append("\n");
					}
					fileWriter.flush();
					fileWriter.close();
					System.out.println("----Process complete");
					
					/*byte fileData[]  =  file1.getFile().getBytes();
					
					bis = new ByteArrayInputStream(fileData);
					int len = 0;
					byte[] buf = new byte[1024];
					
						while ((len = bis.read(buf)) > 0) {

							response.getOutputStream().write(buf, 0, len);

						}
*/
					
				} catch (Exception e) {
					System.out.println("Exception->" + e.getMessage());
					System.exit(0);
				}

				System.out.println("Validation Completed Successfully");

				// sample code to be removed

				// System.out.println(" --> " + uploadFileService);

				inputFS.close();
				br.close();
			} catch (Exception e) {
				// String exception =
				e.printStackTrace();
			}

		} else {
			System.out.println("Upload File at " + filePath + " does not exist.");
		}
		System.out.println("- Creating Users ended...");
		return file1;
	}

	private static Function<String, CreateUserInput> mapToItem = (line) -> {
		//System.out.println("-->" + line);
		String[] lineArr = line.split(",");// a CSV has comma separated lines
		CreateUserInput item = new CreateUserInput();
		item.setSso(lineArr[0]);
		item.setIsReconciler(lineArr[1]);
		item.setIsContingentWorker(lineArr[2]);
		item.setFunction(lineArr[3]);
		item.setRole(lineArr[4]);
		item.setBusiness(lineArr[5]);
		item.setSubBusiness(lineArr[6]);
		item.settCodeSvcCenter(lineArr[7]);
		return item;
	};

	private static boolean isValidEntity(List<CreateUserInput> sourceList) {
		return false;
	}
}
