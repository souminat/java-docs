package com.ge.treasury.healthcheck;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ge.treasury.healthcheck" })
@SpringBootApplication
public class HealthCheckApplication extends SpringBootServletInitializer {

    private static final String SPRING_CONFIG_PARAMETER = "spring.config.location";
    
	public static void main(String[] args) {
		SpringApplication.run(HealthCheckApplication.class, args);
	}
	
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        Map<String, Object> defaultProperties = new HashMap<String, Object>();
        String env = System.getProperty("env");

        if (null == env)
            defaultProperties.put(SPRING_CONFIG_PARAMETER, "application.yml");
        
        return application.sources(HealthCheckApplication.class).properties(defaultProperties);
    }
}
