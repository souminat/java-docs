/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;


import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestOperations;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.treasury.healthcheck.constants.MDMConstants;
import com.ge.treasury.healthcheck.constants.ValidationConstants;
import com.ge.treasury.healthcheck.domain.Audit;
import com.ge.treasury.healthcheck.domain.FineGrainRequest;
import com.ge.treasury.healthcheck.domain.FineGrainRequest_V2;
import com.ge.treasury.healthcheck.domain.FineGrainResponse;
import com.ge.treasury.healthcheck.domain.FineGrainUser;
import com.ge.treasury.healthcheck.domain.ServiceCheck;
import com.ge.treasury.healthcheck.domain.StatusTime;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



/**
 * @author MyPayments Dev Team
 * 
 */
@RestController
@EnableAsync
public abstract class BaseController {

    @Autowired
    protected OAuth2RestOperations mdmServiceRestTemplate;
    
    @Autowired
    protected OAuth2RestOperations mdmServiceTemplate;
    
    @Autowired
    private OAuth2RestOperations msAuditRestTemplate;
    
    @Autowired
    private OAuth2RestOperations msProdAuditRestTemplate;
    
    @Autowired
    private OAuth2RestOperations msFineGrainRestTemplate;
    
    @Autowired
    private OAuth2RestOperations msProdFineGrainRestTemplate;
    
    @Autowired
    private OAuth2RestOperations msDevHrApiRestTemplate;
   
    @Autowired
    private OAuth2RestOperations msQaHrApiRestTemplate;
    
    @Autowired
    private OAuth2RestOperations msProdHrApiRestTemplate;
    
    @Value("${mdm.ms.security}")
    protected String mdmSecurity;

    @Value("${mdm.ms.bankAccount}")
    protected String accountUrl;

    @Value("${mdm.ms.bankBranch}")
    protected String bankBranchUrl;
    
    @Value("${env.qa.audit.ms.baseUrl}")
    private String qaAuditBaseUrl;
    
    @Value("${env.dev.audit.ms.baseUrl}")
    private String devAuditBaseUrl;
    
    @Value("${env.prod.audit.ms.baseUrl}")
    private String prodAuditBaseUrl;
    
    @Value("${env.dev.audit.direct.baseUrl}")
    private String directDevAuditBaseUrl;
    
    @Value("${env.qa.audit.direct.baseUrl}")
    private String directQaAuditBaseUrl;
    
    @Value("${env.prod.audit.direct.baseUrl}")
    private String directProdAuditBaseUrl;
    
    @Value("${audit.ms.getAudits}")
    private String getAudits;
    
    @Value("${env.dev.finegrain-auth.url.get-auth}")
    private String msDevFineGrainAuthUrl;
    
    @Value("${env.qa.finegrain-auth.url.get-auth}")
    private String msQaFineGrainAuthUrl;
    
    @Value("${env.prod.finegrain-auth.url.get-auth}")
    private String msProdFineGrainAuthUrl;
    
    @Value("${env.qa.finegrain-auth.url.direct.get-auth}")
    private String directQaFineGrainAuthUrl;
    
    @Value("${env.dev.finegrain-auth.url.direct.get-auth}")
    private String directDevFineGrainAuthUrl;
    
    @Value("${env.prod.finegrain-auth.url.direct.get-auth}")
    private String directProdFineGrainAuthUrl;
   
    
    @Value("${env.dev.finegrain-auth-url-get-users}")
    private String getDevUsersURL;
    
    @Value("${env.qa.finegrain-auth-url-get-users}")
    private String getQaUsersURL;
    
    @Value("${env.prod.finegrain-auth-url-get-users}")
    private String getProdUsersURL;
    
    @Value("${env.dev.finegrain-auth-url-direct-get-users}")
    private String getDirectDevUsersURL;
    
    @Value("${env.qa.finegrain-auth-url-direct-get-users}")
    private String getDirectQaUsersURL;
    
    @Value("${env.prod.finegrain-auth-url-direct-get-users}")
    private String getDirectProdUsersURL;
    
    @Value("${env.dev.user-lookup.url.lookup}")
    private String getDevHrapiURL;
    
    @Value("${env.qa.user-lookup.url.lookup}")
    private String getQaHrapiURL;
    
    @Value("${env.prod.user-lookup.url.lookup}")
    private String getProdHrapiURL;
    
    private String userLookupBaseUrl;
    
    private String getUsersURL;
    
    private String msFineGrainAuthUrl;
    
    private String auditBaseUrl;

    private static final Logger LOGGER = LogManager.getLogger(BaseController.class);

    private List<Map<String, StatusTime>> statusList = new ArrayList<>();
    
    /**
     * @param url
     * @param method
     * @param validateResponse
     * @param statusList 
     * @param template
     *
     * @return String response from MDM service
     * @throws Exception 
     */
    @Async
    protected String callMDMDenodo(Map<String, String> params, final String url, final HttpMethod method,
            final boolean validateResponse,ServiceCheck serviceCheck, List<Map<String, StatusTime>> statusList) throws Exception {

        final HttpEntity<String> entity;
        final HttpHeaders headers = new HttpHeaders();
        final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        if (null != params) {
            for (String paramName : params.keySet()) {
                builder.queryParam(paramName, params.get(paramName));
            }
        }
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        entity = new HttpEntity<String>(headers);
        
        String response = null;
        
        if("prod".equalsIgnoreCase(serviceCheck.getEnvironment())){
            response  = executeCall(this.mdmServiceTemplate, builder, method, entity, validateResponse, serviceCheck, statusList,url);
        }else{
            response  = executeCall(this.mdmServiceRestTemplate, builder, method, entity, validateResponse, serviceCheck, statusList,url);
        }
        return response;

    }

    /**
     * Helper method to execute the RestOperation for the microservices calls
     *
     * @param ro
     * @param builder
     * @param method
     * @param entity
     * @param validateResponse
     * @param statusList 
     *
     * @return
     * @throws Exception 
     */
    @Async
    protected String executeCall(final RestOperations ro, final UriComponentsBuilder builder, final HttpMethod method,
            final HttpEntity<String> entity, final boolean validateResponse, ServiceCheck serviceCheck, List<Map<String, StatusTime>> statusList, final String url) {
        Map<String, StatusTime> statusMap = new HashMap<String, StatusTime>();
        StatusTime statusTime = new StatusTime();
        
        final String responseBody;

        try {
            long time;
            time = System.currentTimeMillis();
            final ResponseEntity<String> response = ro.exchange(builder.build().encode().toUri(), method, entity,
                    String.class);
            long totalTime = System.currentTimeMillis() - time;
            statusTime.setResponseTime(totalTime);
            
            if (response.getStatusCode() == HttpStatus.OK) {
                responseBody = response.getBody();
                statusTime.setServiceResponse(responseBody);
                statusTime.setStatus("OK");
                statusTime.setUrlHit(url);
                if (validateResponse) {
                    validateJSONResponse(responseBody);
                }
            } else {
                
                statusTime.setStatus("Not OK");
                statusTime.setUrlHit(url);
                throw new Exception(
                        MDMConstants.MDM_ERROR + "ResponseStatusCode: " + response.getStatusCode());
            }

        } catch (final Exception e) {
            statusTime.setStatus(e.getMessage());
            statusTime.setUrlHit(url);
            statusMap.put(serviceCheck.getEndPoint(), statusTime);
            statusList.add(statusMap);
            serviceCheck.setStatusList(statusList);
            throw new SystemException(
                    MDMConstants.MDM_ERROR + "Error when connecting to the MDM Microservice", e);
        }
        statusMap.put(serviceCheck.getEndPoint(), statusTime);
        statusList.add(statusMap);

        serviceCheck.setStatusList(statusList);

        return responseBody;
    }

    /**
     * Validate the responseBoby by checking the Status
     *
     * @param responseBody
     */
    protected void validateJSONResponse(final String responseBody) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(responseBody);
            JsonNode messageNode = rootNode.path(MDMConstants.JSON_GET_MESSAGE);
            JsonNode statusMessageNode = rootNode.path(MDMConstants.JSON_GET_STATUS_MESSAGE);
            JsonNode statusNode = rootNode.path(MDMConstants.JSON_GET_STATUS);

            if (null != statusNode && ("Bad request 400".equalsIgnoreCase(statusNode.asText())
                    || "failure".equalsIgnoreCase(statusNode.asText()))) {
                if (null == StringUtils.trimToNull(messageNode.asText())) {
                    throw new SystemException(MDMConstants.MDM_ERROR + statusMessageNode.asText());
                } else {
                    throw new SystemException(MDMConstants.MDM_ERROR + messageNode.asText());
                }
            }
        } catch (final IOException e) {
            LOGGER.info("Unable to get message and status from response", e);
        }
    }
    
    
    /**
     * Read Audit Data
     *
     * @param responseBody
     * @throws IOException 
     * @throws JsonMappingException 
     * @throws JsonParseException 
     */
    @Async
    public String getAudits(HttpServletRequest request, String domainKey, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws JsonParseException, JsonMappingException, IOException {
        /* User user = (User) request.getSession().getAttribute("User"); */
        Map<String, StatusTime> statusMap = new HashMap<String, StatusTime>();
        StatusTime statusTime = new StatusTime();
        String auditResponse = null;
        try {
            long startTime = System.currentTimeMillis();
            ObjectMapper mapper = new ObjectMapper();

            Audit audit = new Audit();
            String json = "";
            com.fasterxml.jackson.databind.ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            try {
                json = ow.writeValueAsString(audit);
            } catch (IOException e) {
            }
            
            /*if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                auditBaseUrl = devAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
            } else {
                if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    auditBaseUrl = qaAuditBaseUrl;
                    statusTime.setUrlHit(auditBaseUrl);
                } else {
                    auditBaseUrl = prodAuditBaseUrl;
                    statusTime.setUrlHit(auditBaseUrl);
                }
            }*/
            
            
            if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                auditBaseUrl = devAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
                // execute your code
            } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                auditBaseUrl = qaAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
                // execute your code
            } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                auditBaseUrl = prodAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
                // execute your code
            } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
                auditBaseUrl = directDevAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
                // execute your code
            } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
                auditBaseUrl = directQaAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
            } else {
                auditBaseUrl = directProdAuditBaseUrl;
                statusTime.setUrlHit(auditBaseUrl);
            }

            // List<Audit> auditResult = new ArrayList<Audit>();
            /* try { */
            HttpHeaders headers = new HttpHeaders();
            ResponseEntity<String> response = null;
            headers.setContentType(MediaType.APPLICATION_JSON);

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(auditBaseUrl + getAudits)
                    .queryParam("domain", ValidationConstants.MYPAYMENTS_AUDIT_DOMAIN)
                    .queryParam("domainKey", domainKey)
                    .queryParam("entity", ValidationConstants.MYPAYMENTS_AUDIT_ENTITY);

            HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), headers);

            long time;
            time = System.currentTimeMillis();
            if("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directqa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directdev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directprod".equalsIgnoreCase(serviceCheck.getEnvironment())){
                 response = msAuditRestTemplate.exchange(builder.build().encode().toUri(),
                        HttpMethod.GET, httpEntity, String.class);
            } else {
                response = msProdAuditRestTemplate.exchange(builder.build().encode().toUri(),
                        HttpMethod.GET, httpEntity, String.class);
            }
            
            long totalTime = System.currentTimeMillis() - time;
            if (response.getStatusCode() == HttpStatus.OK) {
                auditResponse = response.getBody();
                statusTime.setServiceResponse(auditResponse);
                statusTime.setStatus("OK");
                statusTime.setResponseTime(totalTime);
            } else {

                statusTime.setStatus("Not OK");
                throw new Exception(MDMConstants.MDM_ERROR + "ResponseStatusCode: " + response.getStatusCode());
            }
        } catch (Exception e) {
            statusTime.setStatus(e.getMessage());
            statusMap.put(serviceCheck.getEndPoint(), statusTime);
            statusList.add(statusMap);
            serviceCheck.setStatusList(statusList);
            e.printStackTrace();
            return auditResponse;
        }
        statusMap.put(serviceCheck.getEndPoint(), statusTime);
        statusList.add(statusMap);

        serviceCheck.setStatusList(statusList);
        return auditResponse;
    }
    
    /**
     * Calls to FineGrainAuth microservice
     * 
     * @param sso
     * @return
     * @throws Exception 
     */
    @Async
    public String getAuth(final String sso,ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {
        
        Map<String, StatusTime> statusMap = new HashMap<String, StatusTime>();
        StatusTime statusTime = new StatusTime();
        final FineGrainRequest request = new FineGrainRequest();
        
        String fineGrainResponse = null;
        
        request.setSso(sso);
        request.setAppName("mypayments");
        request.setStatus("ACTIVE");
        FineGrainUser user;
        
            /*if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                msFineGrainAuthUrl = msDevFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
            } else {
                if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    msFineGrainAuthUrl = msQaFineGrainAuthUrl;
                    statusTime.setUrlHit(msFineGrainAuthUrl);
                } else {
                    msFineGrainAuthUrl = msProdFineGrainAuthUrl;
                    statusTime.setUrlHit(msFineGrainAuthUrl);
                }
            }*/
            
            if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                msFineGrainAuthUrl = msDevFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
                // execute your code
            } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                msFineGrainAuthUrl = msQaFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
                // execute your code
            } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                msFineGrainAuthUrl = msProdFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
                // execute your code
            } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
                msFineGrainAuthUrl = directDevFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
                // execute your code
            } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
                msFineGrainAuthUrl = directQaFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
            } else {
                msFineGrainAuthUrl = directProdFineGrainAuthUrl;
                statusTime.setUrlHit(msFineGrainAuthUrl);
            }
         try {  
            long time;
            time = System.currentTimeMillis();
            //user = msFineGrainRestTemplate.postForObject(msFineGrainAuthUrl, request, FineGrainUser.class);
            if("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directqa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directdev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directprod".equalsIgnoreCase(serviceCheck.getEnvironment())){
                user = msFineGrainRestTemplate.postForObject(msFineGrainAuthUrl, request, FineGrainUser.class);
           } else {
               user = msProdFineGrainRestTemplate.postForObject(msFineGrainAuthUrl, request, FineGrainUser.class);
               
           }
            long totalTime = System.currentTimeMillis() - time;
            
            if ("SUCCESS".equalsIgnoreCase(user.getStatus())) {
                Gson gson = new GsonBuilder().create();
                
                List<FineGrainResponse> list = new ArrayList<FineGrainResponse>(user.getResponseData());
                
                fineGrainResponse = gson.toJson(list);
                //fineGrainResponse = user.getResponseData();
                statusTime.setServiceResponse(fineGrainResponse);
                statusTime.setStatus("OK");
                statusTime.setResponseTime(totalTime);
            } else {

                statusTime.setStatus("Not OK");
                throw new Exception(MDMConstants.MDM_ERROR + "ResponseStatusCode: " + user.getStatus());
            }

        } catch (Exception e) {
            //(this, sso.concat(" has Recieved exception calling Fine Grain Microservice: ").concat(ex.getResponseBodyAsString()));
            user = new FineGrainUser();
            final FineGrainRequest requestData = new FineGrainRequest();
            requestData.setSso(sso);
            user.setRequestData(requestData);
            statusTime.setStatus(e.getMessage());
            statusMap.put(serviceCheck.getEndPoint(), statusTime);
            statusList.add(statusMap);
            serviceCheck.setStatusList(statusList);
            return fineGrainResponse;
        }
        statusMap.put(serviceCheck.getEndPoint(), statusTime);
        statusList.add(statusMap);

        serviceCheck.setStatusList(statusList);
        return fineGrainResponse;
    }
    
    @Async
    public String loadUsersList(ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) {
        Map<String, StatusTime> statusMap = new HashMap<String, StatusTime>();
        StatusTime statusTime = new StatusTime();
        
        String allUsersResponse = null;
        
        FineGrainRequest_V2 fgRequest = new FineGrainRequest_V2();
        fgRequest.setAppName("MYPAYMENTS");
        //fgRequest.setRole("Payment Approver");
        
        
           /* if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                getUsersURL = getDevUsersURL;
                statusTime.setUrlHit(getUsersURL);
            } else {
                if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    getUsersURL = getQaUsersURL;
                    statusTime.setUrlHit(getUsersURL);
                } else {
                    getUsersURL = getProdUsersURL;
                    statusTime.setUrlHit(getUsersURL);
                }
            }*/
            
            
            if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                getUsersURL = getDevUsersURL;
                statusTime.setUrlHit(getUsersURL);
            } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                getUsersURL = getQaUsersURL;
                statusTime.setUrlHit(getUsersURL);
            } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                getUsersURL = getProdUsersURL;
                statusTime.setUrlHit(getUsersURL);
            } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
                getUsersURL = getDirectDevUsersURL;
                statusTime.setUrlHit(getUsersURL);
            } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
                getUsersURL = getDirectQaUsersURL;
                statusTime.setUrlHit(getUsersURL);
            } else {
                getUsersURL = getDirectProdUsersURL;
                statusTime.setUrlHit(getUsersURL);
            }
         try {    
            long time;
            time = System.currentTimeMillis();
            //user = msFineGrainRestTemplate.postForObject(msFineGrainAuthUrl, request, FineGrainUser.class);
            if("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directqa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directdev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "directprod".equalsIgnoreCase(serviceCheck.getEnvironment())){
                allUsersResponse = this.msFineGrainRestTemplate.postForObject(getUsersURL, fgRequest, String.class);
           } else {
               allUsersResponse = this.msProdFineGrainRestTemplate.postForObject(getUsersURL, fgRequest, String.class);
           }
            long totalTime = System.currentTimeMillis() - time;
            
            if (null != allUsersResponse && !allUsersResponse.isEmpty()) {
                
                //fineGrainResponse = user.getResponseData();
                statusTime.setServiceResponse(allUsersResponse);
                statusTime.setStatus("OK");
                statusTime.setResponseTime(totalTime);
            } else {
                statusTime.setStatus("Not OK");
                //throw new Exception(MDMConstants.MDM_ERROR + "ResponseStatusCode: " + user.getStatus());
            }
        
        //allUsersResponse = this.msFineGrainRestTemplate.postForObject(getUsersURL, fgRequest, String.class);
        
        } catch (Exception e) {
            statusTime.setStatus(e.getMessage());
            statusMap.put(serviceCheck.getEndPoint(), statusTime);
            statusList.add(statusMap);
            serviceCheck.setStatusList(statusList);
            return allUsersResponse;
        }
        statusMap.put(serviceCheck.getEndPoint(), statusTime);
        statusList.add(statusMap);

        serviceCheck.setStatusList(statusList);
       /* Gson gson = new GsonBuilder().create();
        FineGrainResponse_V2 reponse = gson.fromJson(response, FineGrainResponse_V2.class);
        paymentRequestManagerService.transformData(reponse);*/
        return allUsersResponse;
    }
    
    
    
    /**
     * Calls to FineGrainAuth microservice
     * 
     * @param sso
     * @return
     * @throws Exception 
     */
    @Async
    public String getHrApi(ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {
        
        Map<String, StatusTime> statusMap = new HashMap<String, StatusTime>();
        StatusTime statusTime = new StatusTime();
        final FineGrainRequest request = new FineGrainRequest();
        String ssoId="999999001";
        if(null != serviceCheck.getSsoId()){
            ssoId = serviceCheck.getSsoId();
        }
        String json = null;
        
        //request.setSso(sso);
        //request.setAppName("mypayments");
        //request.setStatus("ACTIVE");
        FineGrainUser user;
        
            if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                userLookupBaseUrl = getDevHrapiURL;
                statusTime.setUrlHit(userLookupBaseUrl);
            } else {
                if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    userLookupBaseUrl = getQaHrapiURL;
                    statusTime.setUrlHit(userLookupBaseUrl);
                } else {
                    userLookupBaseUrl = getProdHrapiURL;
                    statusTime.setUrlHit(userLookupBaseUrl);
                }
            }
         try {  
            long time;
            time = System.currentTimeMillis();
            if("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) /*"qa".equalsIgnoreCase(serviceCheck.getEnvironment())*/){
                json = msDevHrApiRestTemplate.getForObject(userLookupBaseUrl + serviceCheck.getSsoId(), String.class);
           } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                json= msQaHrApiRestTemplate.getForObject(userLookupBaseUrl + ssoId, String.class);
           } else {
                json= msProdHrApiRestTemplate.getForObject(userLookupBaseUrl + ssoId, String.class);
           }
            long totalTime = System.currentTimeMillis() - time;
            
            if (!json.isEmpty()) {
                statusTime.setServiceResponse(json);
                statusTime.setStatus("OK");
                statusTime.setResponseTime(totalTime);
           } else {

                statusTime.setStatus("Not OK");
                //throw new Exception(MDMConstants.MDM_ERROR + "ResponseStatusCode: " + user.getStatus());
           }

        } catch (Exception e) {
            //(this, sso.concat(" has Recieved exception calling Fine Grain Microservice: ").concat(ex.getResponseBodyAsString()));
            user = new FineGrainUser();
            final FineGrainRequest requestData = new FineGrainRequest();
            user.setRequestData(requestData);
            statusTime.setStatus(e.getMessage());
            statusMap.put(serviceCheck.getEndPoint(), statusTime);
            statusList.add(statusMap);
            serviceCheck.setStatusList(statusList);
            return json;
        }
        statusMap.put(serviceCheck.getEndPoint(), statusTime);
        statusList.add(statusMap);

        serviceCheck.setStatusList(statusList);
        return json;
    }

}
