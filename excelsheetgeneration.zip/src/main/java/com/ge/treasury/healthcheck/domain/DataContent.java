package com.ge.treasury.healthcheck.domain;

public class DataContent {

    private String SSO;
    private String role;
    private String Business;
    private String subBusiness;
    private String function;
    private String tCodeSC;
    private String busLevel5ID;
    private String busLevel6ID;
    
    
    public String getSSO() {
        return SSO;
    }
    public void setSSO(String sSO) {
        SSO = sSO;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getBusiness() {
        return Business;
    }
    public void setBusiness(String business) {
        Business = business;
    }
    public String getSubBusiness() {
        return subBusiness;
    }
    public void setSubBusiness(String subBusiness) {
        this.subBusiness = subBusiness;
    }
    public String getFunction() {
        return function;
    }
    public void setFunction(String function) {
        this.function = function;
    }
    public String gettCodeSC() {
        return tCodeSC;
    }
    public void settCodeSC(String tCodeSC) {
        this.tCodeSC = tCodeSC;
    }
    public String getBusLevel5ID() {
        return busLevel5ID;
    }
    public void setBusLevel5ID(String busLevel5ID) {
        this.busLevel5ID = busLevel5ID;
    }
    public String getBusLevel6ID() {
        return busLevel6ID;
    }
    public void setBusLevel6ID(String busLevel6ID) {
        this.busLevel6ID = busLevel6ID;
    }
    
}
