package com.ge.treasury.healthcheck.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ge.treasury.healthcheck.constants.MDMConstants;
import com.ge.treasury.healthcheck.constants.ValidationConstants;
import com.ge.treasury.healthcheck.domain.Audit;
import com.ge.treasury.healthcheck.domain.ServiceCheck;
import com.ge.treasury.healthcheck.domain.StatusTime;

@RestController
@RequestMapping("/api/myServiceCheck/v1")
@EnableAsync
public class ServiceCheckController extends BaseController implements MDMConstants {

    @Value("${env.dev.mdm.direct.baseUrl}")
    protected String directDevMdmBaseUrl;
    
    @Value("${env.qa.mdm.direct.baseUrl}")
    protected String directQaMdmBaseUrl;
    
    @Value("${env.prod.mdm.direct.baseUrl}")
    protected String directProdMdmBaseUrl;
    
    @Value("${env.dev.mdm.ms.baseUrl}")
    protected String devMdmBaseUrl;

    @Value("${env.qa.mdm.ms.baseUrl}")
    protected String qaMdmBaseUrl;

    @Value("${env.prod.mdm.ms.baseUrl}")
    protected String prodMdmBaseUrl;

    @Value("${mdm.ms.currency}")
    private String currencyakanaUrl;
    
    @Value("${mdm.direct.currency}")
    private String currencyDirectUrl;
    
    @Value("${mdm.direct.holiday}")
    private String holidayDirectUrl;

    @Value("${mdm.ms.holiday}")
    private String holidayAkanaUrl;

    @Value("${mdm.ms.country}")
    private String countryAkanaUrl;
    
    @Value("${mdm.direct.country}")
    private String countryDirectUrl;

    @Value("${mdm.ms.business}")
    private String businessAkanaUrl;
    
    @Value("${mdm.direct.business}")
    private String businessDirectUrl;

    @Value("${mdm.ms.marketData}")
    private String marketDataAkanaUrl;
    
    @Value("${mdm.direct.marketData}")
    private String marketDataDirectUrl;

    @Value("${mdm.ms.le}")
    private String leAkanaUrl;
    
    @Value("${mdm.direct.le}")
    private String leDirectUrl;

    @Value("${mdm.ms.bankRouteCode}")
    private String bankRouteCodeAkanaUrl;
    
    @Value("${mdm.direct.bankRouteCode}")
    private String bankRouteCodeDirectUrl;
    
    @Value("${mdm.ms.bankAccount}")
    private String bankAccountAkanaUrl;
    
    @Value("${mdm.direct.bankAccount}")
    private String bankAccountDirectUrl;
    
    @Value("${mdm.ms.bankBranch}")
    private String bankBranchAkanaUrl;
    
    @Value("${mdm.direct.bankBranch}")
    private String bankBranchDirectUrl;
    
    private String accountUrl;
    
    private String bankBranchUrl;
    
    private String countryUrl;
    
    private String businessUrl;
    
    private String marketDataUrl;
    
    private String leUrl;
    
    private String bankRouteCodeUrl;
    
    private String holidayUrl;
    
    private String currencyUrl;
    
    private String mdmBaseUrl;

    @RequestMapping(value = "/checkServiceRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkServiceRequest(HttpServletRequest request, @RequestBody ServiceCheck serviceCheck) {
        String responseMdm = null;
        List<Map<String, StatusTime>> statusList = new ArrayList<>();

       /* if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else {
            if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                mdmBaseUrl = qaMdmBaseUrl;
            } else {
                mdmBaseUrl = prodMdmBaseUrl;
            }
        }*/
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
        }

        try {

            if ("currency".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    currencyUrl = currencyakanaUrl;
                } else {
                    currencyUrl = currencyDirectUrl;
                }
                responseMdm = getMDMCurrency(request, serviceCheck, statusList);
            }

            if ("holiday".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    holidayUrl = holidayAkanaUrl;
                } else {
                    holidayUrl = holidayDirectUrl;
                }
                responseMdm = getHolidayCalendar(request, null, responseMdm, responseMdm, serviceCheck, statusList);
            }

            if ("bankAccount".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    accountUrl = bankAccountAkanaUrl;
                } else {
                    accountUrl = bankAccountDirectUrl;
                }
                responseMdm = searchMDMBankAccounts(request, serviceCheck, statusList);
            }

            if ("bankBranch".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    bankBranchUrl = bankBranchAkanaUrl;
                } else {
                    bankBranchUrl = bankBranchDirectUrl;
                }
                responseMdm = getMDMBankBranch(request, null, serviceCheck, statusList);
            }

            if ("country".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    countryUrl = countryAkanaUrl;
                } else {
                    countryUrl = countryDirectUrl;
                }
                responseMdm = getMDMCountry(request, serviceCheck, statusList);
            }

            if ("business".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    businessUrl = businessAkanaUrl;
                } else {
                    businessUrl = businessDirectUrl;
                }
                responseMdm = getMDMBusiness(request, serviceCheck, statusList);
            }

            if ("marketData".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    marketDataUrl = marketDataAkanaUrl;
                } else {
                    marketDataUrl = marketDataDirectUrl;
                }
                responseMdm = getSpotRate(request, serviceCheck, statusList);
            }

            if ("le".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    leUrl = leAkanaUrl;
                } else {
                    leUrl = leDirectUrl;
                }
                responseMdm = getGoldLeNames(request, serviceCheck, statusList);
            }

            if ("bankRouteCode".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                    bankRouteCodeUrl = bankRouteCodeAkanaUrl;
                } else {
                    bankRouteCodeUrl = bankRouteCodeDirectUrl;
                }
                responseMdm = getMDMBankRouteCode(request, serviceCheck, statusList);
            }
            
            if ("ReadAudit".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                String paymentId = null;
                if(null != serviceCheck.getPaymentRequestId()){
                    paymentId = serviceCheck.getPaymentRequestId();
                }
                responseMdm = getAudits(request,paymentId,serviceCheck, statusList);
            }
            
            if ("FineGrain".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                String ssoId = null;
                if(null != serviceCheck.getSsoId()){
                    ssoId = serviceCheck.getSsoId();
                }
                responseMdm = getAuth(ssoId,serviceCheck,statusList);
            }
            
            if ("HrApi".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                responseMdm = getHrApi(serviceCheck,statusList);
            }
            
            if ("GetUsers".equalsIgnoreCase(serviceCheck.getEndPoint())) {
                responseMdm = loadUsersList(serviceCheck,statusList);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return serviceCheck;

    }

    @RequestMapping(value = "/checkMultipleServiceRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkMultipleServiceRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        String str;
        String responseMdm = null;
        List<Map<String, StatusTime>> statusList = new ArrayList<>();

        /**
         * Setting Base URL
         */
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else {
            if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                mdmBaseUrl = qaMdmBaseUrl;
            } else {
                mdmBaseUrl = prodMdmBaseUrl;
            }
        }
        try {
            /*serviceCheck.setEndPoint("currency");
            try {
                str = getMDMCurrency(request, serviceCheck, statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }*/

            /*String holidayResponseMdm = null;
            serviceCheck.setEndPoint("holiday");
            try {
                holidayResponseMdm = getHolidayCalendar(request, null, responseMdm, responseMdm, serviceCheck,
                        statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }*/

            /*
             * String bankAccountResponse =null;
             * serviceCheck.setEndPoint("mdmBankAccount"); try {
             * bankAccountResponse=searchMDMBankAccounts(request, serviceCheck,
             * statusList); } catch (Exception e) { e.printStackTrace(); }
             */

            /*
             * String bankBranchResponse =null;
             * serviceCheck.setEndPoint("mdmBankBranch"); try {
             * bankBranchResponse=getMDMBankBranch(request, null ,serviceCheck,
             * statusList); } catch (Exception e) { e.printStackTrace(); }
             */

            /*String countryResponse = null;
            serviceCheck.setEndPoint("country");
            try {
                countryResponse = getMDMCountry(request, serviceCheck, statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String businessResponse = null;
            serviceCheck.setEndPoint("business");
            try {
                businessResponse = getMDMBusiness(request, serviceCheck, statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String marketDataResponse = null;
            serviceCheck.setEndPoint("MarketData");
            try {
                marketDataResponse = getSpotRate(request, serviceCheck, statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }*/

            /*
             * String goldLeResponse=null; serviceCheck.setEndPoint("GoldLe");
             * try { goldLeResponse = getGoldLeNames(request,serviceCheck,
             * statusList); } catch (Exception e) { e.printStackTrace(); }
             */

            /*
             * String routeCodeResponse=null;
             * serviceCheck.setEndPoint("Bank Route Code"); try {
             * routeCodeResponse = getMDMBankRouteCode(request,serviceCheck,
             * statusList); } catch (Exception e) { e.printStackTrace(); }
             */
            /*String auditResponse = null;
            serviceCheck.setEndPoint("Read Audit");
            try {
                auditResponse = getAudits(request,"1541",serviceCheck, statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }
            */
            /*String fineGrainResponse = null;
            serviceCheck.setEndPoint("Fine Grain");
            try {
                fineGrainResponse = getAuth("999999001",serviceCheck,statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            String allUsersResponse = null;
            serviceCheck.setEndPoint("Get Users");
            try {
                allUsersResponse = loadUsersList(serviceCheck,statusList);
            } catch (Exception e) {
                e.printStackTrace();
            }*/

        } catch (Exception e) {
            e.printStackTrace();
        }
        return serviceCheck;

    }

    /**
     * Fetch holiday calendar for currency and country pairs and date range
     *
     * @param request
     * @param calendarNames
     * @param lowerDateStr
     * @param greaterDateStr
     * @param statusList
     *
     * @return
     * @throws Exception
     */
   
    @Async
    public String getHolidayCalendar(final HttpServletRequest request,
            @RequestParam(value = "calendarName", required = true) final List<String> calendarNames,
            @RequestParam(value = "lowerDate", required = false) final String lowerDateStr,
            @RequestParam(value = "greaterDate", required = false) final String greaterDateStr,
            ServiceCheck serviceCheck, List<Map<String, StatusTime>> statusList) throws Exception {

        String holidayResponse;
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String filter = "(fin_cntr_code='MeB' and formatdate('dd-MM-yyyy', hol_dt) = '15-12-2018')";
        HashMap<String, String> params = new HashMap<>();
        //params.put(FILTER_CONST, filter.toString());
        
        params.put(FILTER_CONST, (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!filter.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter) : filter);
        holidayResponse = callMDMDenodo(params, mdmBaseUrl + holidayUrl, HttpMethod.GET, true, serviceCheck,
                statusList);
        return holidayResponse;
    }

    /**
     * Fetch currency
     * 
     * @param statusList
     *
     * @return
     */
    @Async
    public String getMDMCurrency(final HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        final StringBuilder filter = new StringBuilder();
        filter.append("(");
        filter.append(UPPER_2 + CURRENCY_CURRENCY_STATUS + UPPER_1 + ACTIVE + "')");
        filter.append(")");
        
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        //System.out.println(checkFilter[1]);
        String currencyTest = filter.toString();
        
        HashMap<String, String> params = new HashMap<>();
        //params.put(FILTER_CONST, filter.toString());
        
        params.put(FILTER_CONST, (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!currencyTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());
        String currencyResponse;
        currencyResponse = callMDMDenodo(params, mdmBaseUrl + currencyUrl, HttpMethod.GET, true, serviceCheck,
                statusList);
        return currencyResponse;
    }

    /**
     * Controller to get MDM Bank Account
     *
     * @param request
     *
     * @return String - JSON results from the MDM Service Rest call
     * @throws Exception
     */
  
    @Async
    public String searchMDMBankAccounts(final HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {
        String startIndex = request.getParameter("start_Index");
        String count = request.getParameter("count");
        String sortBy = request.getParameter("sortBy");
        String sortOrder = request.getParameter("sortOrder");

        final StringBuilder filter = new StringBuilder();
        filter.append("(tcode = 'JE12')");
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String bankAccountTest = filter.toString();

        HashMap<String, String> params = new HashMap<>();
        params.put("$filter", (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!bankAccountTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());

        
        //System.out.println(bankAccountTest);
        String bankAccountOutput = callMDMDenodo(params, mdmBaseUrl + accountUrl, HttpMethod.GET, true, serviceCheck,
                statusList);

        return bankAccountOutput;
    }

    /**
     * Controller to get MDM Bank Details
     *
     * @param request
     * @param mdmId
     *
     * @return String - JSON results from the MDM Service Rest call
     * @throws Exception
     */
    @Async
    public String getMDMBankBranch(final HttpServletRequest request,
            @RequestParam(value = "mdmId", required = true) final String mdmId, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        final StringBuilder filter = new StringBuilder();
        filter.append("(bank_status='Active')");
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String bankBranchTest = filter.toString();
        
        HashMap<String, String> params = new HashMap<>();
        params.put("$filter", (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!bankBranchTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());

        String bankBranchOutput = callMDMDenodo(params, mdmBaseUrl + bankBranchUrl, HttpMethod.GET, false, serviceCheck,
                statusList);

        return bankBranchOutput;
    }

    /**
     * Controller to get MDM COUTNRY list
     *
     * @param request
     *
     * @return String - JSON results from the MDM Service Rest call
     * @throws Exception
     */
    @Async
    public String getMDMCountry(final HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        final StringBuilder filter = new StringBuilder();
        filter.append("(");
        filter.append(UPPER_2 + COUNTRY_STATUS + UPPER_1 + ACTIVE + "')");
        filter.append(")");
        
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String countryTest = filter.toString();
        
        HashMap<String, String> params = new HashMap<>();
        
        params.put(FILTER_CONST, (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!countryTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());
        String countryOutput = callMDMDenodo(params, mdmBaseUrl + countryUrl, HttpMethod.GET, true, serviceCheck,
                statusList);

        return countryOutput;
    }

    /**
     * Controller to get MDM business list
     *
     * @return String
     * @throws Exception
     */
    @Async
    public String getMDMBusiness(HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        HashMap<String, String> params = new HashMap<>();
        setMDMBusinessParams(request, params,serviceCheck);

        String businessOutput = callMDMDenodo(params, mdmBaseUrl + businessUrl, HttpMethod.GET, true, serviceCheck,
                statusList);

        return businessOutput;

    }

    private void setMDMBusinessParams(HttpServletRequest request, HashMap<String, String> params ,ServiceCheck serviceCheck) {
        final StringBuilder filter = new StringBuilder();
        filter.append("(bus_sbus_rel_status='Active')");
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String businessTest = filter.toString();

        params.put("$filter", (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!businessTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());
    }

    /**
     * Controller to get MDM MDS FX Rate
     *
     * @param request
     * @param payerCurrency
     * @param payeeCurrency
     *
     * @return String - json response from MDS
     * @throws Exception
     *
     */
    @Async
    public String getSpotRate(final HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        final StringBuilder filter = new StringBuilder();
        filter.append("(ds_code='MOREXRTTREAX' and rec_nm = 'EUR-USD' and sbscr_code = 'ALOC')");
        String marketTest = filter.toString();
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        
        HashMap<String, String> params = new HashMap<>();
        params.put(FILTER_CONST, (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!marketTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());

        String marketDataOutput = callMDMDenodo(params, mdmBaseUrl + marketDataUrl, HttpMethod.GET, true, serviceCheck,
                statusList);

        return marketDataOutput;
    }

    /**
     * Controller to get MDM MDS FX Rate
     *
     * @param request
     * @param goldLeName
     *
     * @return String - json response from MDS
     * @throws Exception
     *
     */
    @Async
    public String getGoldLeNames(final HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        final StringBuilder filter = new StringBuilder();
        HashMap<String, String> params = new HashMap<>();
        filter.append(
                "((primry_alt_code like '%ge%' or party_long_nm like '%ge%') and primry_srce_sys = 'GOLD' and party_status = 'ACTIVE')");
        
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String goldTest = filter.toString();
        
        params.put(FILTER_CONST, (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!goldTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());

        String goldLeOutput = callMDMDenodo(params, mdmBaseUrl + leUrl, HttpMethod.GET, true, serviceCheck, statusList);

        return goldLeOutput;
    }

    /**
     * Controller to get MDM Bank Route Code details
     *
     * @param request
     *
     * @return String - JSON results from the MDM Service Rest call
     * @throws Exception
     */
    @Async
    public String getMDMBankRouteCode(final HttpServletRequest request, ServiceCheck serviceCheck,
            List<Map<String, StatusTime>> statusList) throws Exception {

        final StringBuilder filter = new StringBuilder();
        HashMap<String, String> params = new HashMap<>();
        filter.append("(UPPER(rte_code) like UPPER('CITIUS33CRP'))");
        
        String [] checkFilter= serviceCheck.getFilterDescription().split("=",2);
        String routeTest = filter.toString();
        
        params.put(FILTER_CONST, (!"all".equalsIgnoreCase(serviceCheck.getFilterDescription())) ? ((!routeTest.equalsIgnoreCase(checkFilter[1])) ? checkFilter[1] : filter.toString()) : filter.toString());
        String routeCodeOutput = callMDMDenodo(params, mdmBaseUrl + bankRouteCodeUrl, HttpMethod.GET, false,
                serviceCheck, statusList);

        return routeCodeOutput;
    }
    
    
    //Currency Controller
    @RequestMapping(value = "/checkCurrencyRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkCurrencyRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
       /* if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment()) || "qa".equalsIgnoreCase(serviceCheck.getEnvironment()) || "prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            currencyUrl = currencyakanaUrl;
        } else {
            currencyUrl = currencyDirectUrl;
        }*/
        
        /*if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else {
            if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                mdmBaseUrl = qaMdmBaseUrl;
            } else {
                mdmBaseUrl = prodMdmBaseUrl;
            }
        }*/
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            currencyUrl = currencyakanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            currencyUrl = currencyakanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            currencyUrl = currencyakanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            currencyUrl = currencyDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            currencyUrl = currencyDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            currencyUrl = currencyDirectUrl;
        }
        
       /* if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            currencyUrl = currencyakanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            currencyUrl = currencyakanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            currencyUrl = currencyakanaUrl;
            // execute your code
        } else {
            mdmBaseUrl = directDevMdmBaseUrl;
            currencyUrl = currencyDirectUrl;
            // execute your code
        }*/
        
        
        String str;
        //String responseMdm = null;
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        serviceCheck.setEndPoint("currency");
        try {
            str = getMDMCurrency(request, serviceCheck, statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return serviceCheck;
    }
    
    
    //Holiday Controller
    @RequestMapping(value = "/checkHolidayRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkHolidayRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            holidayUrl = holidayAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            holidayUrl = holidayAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            holidayUrl = holidayAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            holidayUrl = holidayDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            holidayUrl = holidayDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            holidayUrl = holidayDirectUrl;
        }
        
        String responseMdm = null;
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String holidayResponseMdm = null;
        serviceCheck.setEndPoint("holiday");
        try {
            holidayResponseMdm = getHolidayCalendar(request, null, responseMdm, responseMdm, serviceCheck,
                    statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return serviceCheck;
    }
    
    //bank account controller
    @RequestMapping(value = "/checkBankAccountRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkBankaccountRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            accountUrl = bankAccountAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            accountUrl = bankAccountAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            accountUrl = bankAccountAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            accountUrl = bankAccountDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            accountUrl = bankAccountDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            accountUrl = bankAccountDirectUrl;
        }
        
        String responseMdm = null;
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        
         String bankAccountResponse =null;
         serviceCheck.setEndPoint("mdmBankAccount"); 
         try {
         bankAccountResponse=searchMDMBankAccounts(request, serviceCheck,statusList); 
         } catch (Exception e) { 
             e.printStackTrace(); 
         }
        return serviceCheck;
    }
    
    
  //bank branch controller
    @RequestMapping(value = "/checkBankBranchRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkBankbranchRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            bankBranchUrl = bankBranchAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            bankBranchUrl = bankBranchAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            bankBranchUrl = bankBranchAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            bankBranchUrl = bankBranchDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            bankBranchUrl = bankBranchDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            bankBranchUrl = bankBranchDirectUrl;
        }
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
          String bankBranchResponse =null;
          serviceCheck.setEndPoint("mdmBankBranch"); try {
          bankBranchResponse=getMDMBankBranch(request, null ,serviceCheck,statusList); 
          } catch (Exception e) { 
              e.printStackTrace(); 
          }
         
         
        return serviceCheck;
    }
    
    
    //country controller
    @RequestMapping(value = "/checkCountryRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkCountryRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            countryUrl = countryAkanaUrl;
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            countryUrl = countryAkanaUrl;
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            countryUrl = countryAkanaUrl;
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            countryUrl = countryDirectUrl;
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            countryUrl = countryDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            countryUrl = countryDirectUrl;
        }
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String countryResponse = null;
        serviceCheck.setEndPoint("country");
        try {
            countryResponse = getMDMCountry(request, serviceCheck, statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
         
        return serviceCheck;
    }
    
    
    //Business controller
    @RequestMapping(value = "/checkBusinessRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkBusinessRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            businessUrl = businessAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            businessUrl = businessAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            businessUrl = businessAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            businessUrl = businessDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            businessUrl = businessDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            businessUrl = businessDirectUrl;
        }
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String businessResponse = null;
        serviceCheck.setEndPoint("business");
        try {
            businessResponse = getMDMBusiness(request, serviceCheck, statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
         
        return serviceCheck;
    }
    
    
    // MArket data controller
    @RequestMapping(value = "/checkMarketRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkMarketRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            marketDataUrl = marketDataAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            marketDataUrl = marketDataAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            marketDataUrl = marketDataAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            marketDataUrl = marketDataDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            marketDataUrl = marketDataDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            marketDataUrl = marketDataDirectUrl;
        }
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String marketDataResponse = null;
        serviceCheck.setEndPoint("MarketData");
        try {
            marketDataResponse = getSpotRate(request, serviceCheck, statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
         
        return serviceCheck;
    }
    
    
 // MArket data controller
    @RequestMapping(value = "/checkGoldRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkGoldRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            leUrl = leAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            leUrl = leAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            leUrl = leAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            leUrl = leDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            leUrl = leDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            leUrl = leDirectUrl;
        }
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
         String goldLeResponse=null; 
         serviceCheck.setEndPoint("GoldLe");
         try { 
             goldLeResponse = getGoldLeNames(request,serviceCheck,statusList); 
         } catch (Exception e) { 
            e.printStackTrace(); 
         }
        
         
        return serviceCheck;
    }
    
    // bank route controller
    @RequestMapping(value = "/checkBankrouteRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkBankrouteRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
            bankRouteCodeUrl = bankRouteCodeAkanaUrl;
            // execute your code
        } else if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = qaMdmBaseUrl;
            bankRouteCodeUrl = bankRouteCodeAkanaUrl;
            // execute your code
        } else if ("prod".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = prodMdmBaseUrl;
            bankRouteCodeUrl = bankRouteCodeAkanaUrl;
            // execute your code
        } else if ("directdev".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directDevMdmBaseUrl;
            bankRouteCodeUrl = bankRouteCodeDirectUrl;
            // execute your code
        } else if ("directqa".equalsIgnoreCase(serviceCheck.getEnvironment())){
            mdmBaseUrl = directQaMdmBaseUrl;
            bankRouteCodeUrl = bankRouteCodeDirectUrl;
        } else {
            mdmBaseUrl = directProdMdmBaseUrl;
            bankRouteCodeUrl = bankRouteCodeDirectUrl;
        }
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String routeCodeResponse=null;
        serviceCheck.setEndPoint("BankRouteCode"); 
        try {
        routeCodeResponse = getMDMBankRouteCode(request,serviceCheck,
        statusList); 
        } catch (Exception e) { 
         e.printStackTrace(); 
         }
        
        return serviceCheck;
    }
    
    
 // Audit controller
    @RequestMapping(value = "/checkAuditRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkAuditRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        /*if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else {
            if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                mdmBaseUrl = qaMdmBaseUrl;
            } else {
                mdmBaseUrl = prodMdmBaseUrl;
            }
        }*/
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String auditResponse = null;
        serviceCheck.setEndPoint("Audit");
        try {
            auditResponse = getAudits(request,"1541",serviceCheck, statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return serviceCheck;
    }
    
    
    // Finegrain controller
    @RequestMapping(value = "/checkFineGrainRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkfinegrainRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String fineGrainResponse = null;
        serviceCheck.setEndPoint("FineGrain");
        try {
            fineGrainResponse = getAuth("999999001",serviceCheck,statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return serviceCheck;
    }
    
 // Finegrain controller
    @RequestMapping(value = "/checkHrApiRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkhrapiRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        /*if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else {
            if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                mdmBaseUrl = qaMdmBaseUrl;
            } else {
                mdmBaseUrl = prodMdmBaseUrl;
            }
        }*/
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String hrApiResponse = null;
        serviceCheck.setEndPoint("HrApi");
        try {
            hrApiResponse = getHrApi(serviceCheck,statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return serviceCheck;
    }
    
    
    // All Users controller
    @RequestMapping(value = "/checkUsersRequest", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ServiceCheck checkusersRequest(HttpServletRequest request,
            @RequestBody ServiceCheck serviceCheck) {
        
        /*if ("dev".equalsIgnoreCase(serviceCheck.getEnvironment())) {
            mdmBaseUrl = devMdmBaseUrl;
        } else {
            if ("qa".equalsIgnoreCase(serviceCheck.getEnvironment())) {
                mdmBaseUrl = qaMdmBaseUrl;
            } else {
                mdmBaseUrl = prodMdmBaseUrl;
            }
        }*/
        
        List<Map<String, StatusTime>> statusList = new ArrayList<>();
        
        String allUsersResponse = null;
        serviceCheck.setEndPoint("GetUsers");
        try {
            allUsersResponse = loadUsersList(serviceCheck,statusList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return serviceCheck;
    }
}
