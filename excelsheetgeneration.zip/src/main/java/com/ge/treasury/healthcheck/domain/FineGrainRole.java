/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Attributes needed for FineGrainAuth role
 * 
 * @author MyPayments Dev Team *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FineGrainRole {

    private String appRole;
    private String statusRole;
    @JsonProperty("FG")
    private List<FineGrainUserInfo> FG;
    private String busLevel5Name;
    private String busLevel6Name;
    private String function;
    private String busLevel5ID;
    private String busLevel6ID;
    private String tCodeSC;
    

    public String gettCodeSC() {
		return tCodeSC;
	}

	public void settCodeSC(String tCodeSC) {
		this.tCodeSC = tCodeSC;
	}

	@JsonProperty("FG")
	public List<FineGrainUserInfo> getFG() {
		return FG;
	}

	public void setFG(List<FineGrainUserInfo> fG) {
		FG = fG;
	}

	public String getBusLevel5Name() {
		return busLevel5Name;
	}

	public void setBusLevel5Name(String busLevel5Name) {
		this.busLevel5Name = busLevel5Name;
	}

	public String getBusLevel6Name() {
		return busLevel6Name;
	}

	public void setBusLevel6Name(String busLevel6Name) {
		this.busLevel6Name = busLevel6Name;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getBusLevel5ID() {
		return busLevel5ID;
	}

	public void setBusLevel5ID(String busLevel5ID) {
		this.busLevel5ID = busLevel5ID;
	}

	public String getBusLevel6ID() {
		return busLevel6ID;
	}

	public void setBusLevel6ID(String busLevel6ID) {
		this.busLevel6ID = busLevel6ID;
	}

	public String getAppRole() {
        return appRole;
    }

    public void setAppRole(final String appRole) {
        this.appRole = appRole;
    }

    public String getStatusRole() {
        return statusRole;
    }

    public void setStatusRole(final String statusRole) {
        this.statusRole = statusRole;
    }
}
