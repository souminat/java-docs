/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ge.treasury.healthcheck.constants.SecurityConstants;

/**
 * Attributes needed for FineGrainAuth functionality
 * 
 * @author MyPayments Dev Team
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FineGrainRequest{

    private String sso;
    private String appName = SecurityConstants.APPNAME;
    private String status = "ACTIVE";
    private String appRole;
    

    public String getAppRole() {
		return appRole;
	}

	public void setAppRole(String appRole) {
		this.appRole = appRole;
	}

	public FineGrainRequest() {
        super();
    }

    /**
     * @return the sso
     */
    public String getSso() {
        return sso;
    }

    /**
     * @param sso the sso to set
     */
    public void setSso(final String sso) {
        this.sso = sso;
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName the appName to set
     */
    public void setAppName(final String appName) {
        this.appName = appName;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

}
