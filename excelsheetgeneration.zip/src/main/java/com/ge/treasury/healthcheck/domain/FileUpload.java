package com.ge.treasury.healthcheck.domain;

import java.util.List;
import java.util.Map;

public class FileUpload{

	public List<DataContent> getContent() {
		return content;
	}

	public void setContent(List<DataContent> content) {
		this.content = content;
	}

	private String file;
	private List<DataContent> content;
	

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}


	public FileUpload(String file) {
		super();
		this.file = file;
	}

	public FileUpload() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FileUpload [file=" + file + "]";
	}
	
	
}