/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.domain;

import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Attributes needed for FineGrainAuth user
 * 
 * @author MyPayments Dev Team
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FineGrainUser {

    private FineGrainRequest requestData;
    private Collection<FineGrainResponse> responseData;
    private String status;
    private String statusMessage;

    public FineGrainRequest getRequestData() {
        return requestData;
    }

    public void setRequestData(final FineGrainRequest requestData) {
        this.requestData = requestData;
    }

    public Collection<FineGrainResponse> getResponseData() {
        return responseData;
    }

    public void setResponseData(final Collection<FineGrainResponse> responseData) {
        this.responseData = responseData;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(final String statusMessage) {
        this.statusMessage = statusMessage;
    }
}
