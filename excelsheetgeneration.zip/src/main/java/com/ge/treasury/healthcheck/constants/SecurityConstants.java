/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.constants;

/**
 * Contains the constants for security functionality
 * 
 * @author MyPayments Dev Team
 * 
 */
public class SecurityConstants {
    public static final boolean ENABLED = true;
    public static final String PWD = "password";
    public static final boolean ACCOUNTNONEXPIRED = true;
    public static final boolean CREDENTIALSNONEXPIRED = true;
    public static final boolean ACCOUNTNONLOCKED = true;
    public static final String OBJECTCLASS = "objectclass";
    public static final String PERSON = "person";
    public static final String MEMBEROF = "memberof";
    public static final String CN = "cn";
    public static final String APPNAME = "mypayments";
    public static final String INPUTPASSWORD = "F49da_6s";
    
    private SecurityConstants() {
        super();
    }
}
