/**
 * Copyright GE
 */
package com.ge.treasury.healthcheck.oauth;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;

/**
 * Configuration class for Spring OAuth Security
 * 
 * @author MyPayments Dev Team
 * 
 */
@EnableOAuth2Client
@Configuration
public class OAuthConfig {

    @Value("${mdm.ms.scope}")
    private String mdmServiceScope;

    @Value("${mypayments.oauth.accessTokenUri}")
    private String accessTokenUri;

    @Value("${mypayments.oauth.clientId}")
    private String clientId;

    @Value("${mypayments.oauth.clientSecret}")
    private String clientSecret;
    
    @Value("${audit.ms.scope}")
    private String msAuditScope;
    
    @Value("${env.prod.mypayments.oauth.clientSecret}")
    private String prodClientSecret;

    @Value("${mypayments.oauth.grantType}")
    private String grantType;
    
    @Value("${finegrain-auth.url.scope}")
    private String msFineGrainAuthScope;
    
    @Value("${user-lookup.oauth.scope}")
    private String hrApiAuthScope;
    
    @Value("${env.dev.user-lookup.oauth.clientId}")
    private String hrApiDevAuthClientId;
    
    @Value("${env.dev.user-lookup.oauth.clientSecret}")
    private String hrApiDevAuthClientSecret;
    
    @Value("${env.qa.user-lookup.oauth.clientId}")
    private String hrApiQaAuthClientId;
    
    @Value("${env.qa.user-lookup.oauth.clientSecret}")
    private String hrApiQaAuthClientSecret;
    
    @Value("${env.prod.user-lookup.oauth.clientId}")
    private String hrApiProdAuthClientId;
    
    @Value("${env.prod.user-lookup.oauth.clientSecret}")
    private String hrApiProdAuthClientSecret;
    
    /**
     * Oauth config for Hrapi Microservices
     * 
     * @return
     */
    @Bean
    protected OAuth2RestOperations msDevHrApiRestTemplate() {
        return getmsDevHrApiTemplate(hrApiAuthScope);
    }
    
    @Bean
    protected OAuth2RestOperations msQaHrApiRestTemplate() {
        return getmsQaHrApiTemplate(hrApiAuthScope);
    }
    
    
    @Bean
    protected OAuth2RestOperations msProdHrApiRestTemplate() {
        return getmsProdHrApiTemplate(hrApiAuthScope);
    }
    
    
    /**
     * Oauth config for FineGrain Microservice
     * 
     * @return
     */
    @Bean
    protected OAuth2RestOperations msFineGrainRestTemplate() {
        return getBaseRestTemplate(msFineGrainAuthScope);
    }
    
    
    /**
     * Oauth config for FineGrain Microservice
     * 
     * @return
     */
    @Bean
    protected OAuth2RestOperations msProdFineGrainRestTemplate() {
        return getMdmServiceTemplate(msFineGrainAuthScope);
    }

    /**
     * Oauth config for Audit Microservice
     * 
     * @return
     */
    @Bean
    public OAuth2RestOperations msAuditRestTemplate() {
        return getBaseRestTemplate(msAuditScope);
    }
    
    
    /**
     * Oauth config for Audit Microservice
     * 
     * @return
     */
    @Bean
    public OAuth2RestOperations msProdAuditRestTemplate() {
        return getMdmServiceTemplate(msAuditScope);
    }
    

    /**
     * Oauth config for MDM service calls
     * 
     * @return
     */
    @Bean
    protected OAuth2RestOperations mdmServiceRestTemplate() {
        return getBaseRestTemplate(mdmServiceScope);
    }

    /**
     * Oauth config for MDM service calls
     * 
     * @return
     */
    @Bean
    protected OAuth2RestOperations mdsServiceRestTemplate() {
        return getBaseRestTemplate(null);
    }

    @Bean
    protected OAuth2RestOperations mdmServiceTemplate() {
        return getMdmServiceTemplate(mdmServiceScope);
    }
    
    private OAuth2RestOperations getMdmServiceTemplate(String scopeStr) {

        final OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();

        final ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();

        resource.setAccessTokenUri(accessTokenUri);
        resource.setClientId(clientId);
        resource.setClientSecret(prodClientSecret);
        resource.setGrantType(grantType);

        if( scopeStr != null ){
            final List<String> scopes = new ArrayList<String>();
            scopes.add(scopeStr);
            resource.setScope(scopes);
        }
        
        return new OAuth2RestTemplate(resource, oauth2ClientContext);
    
    }


    /**
     * Base Oauth config
     * 
     * @param scopeStr
     * @return
     */
    private OAuth2RestOperations getBaseRestTemplate(final String scopeStr){
        final OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();

        final ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();

        resource.setAccessTokenUri(accessTokenUri);
        resource.setClientId(clientId);
        resource.setClientSecret(clientSecret);
        resource.setGrantType(grantType);

        if( scopeStr != null ){
            final List<String> scopes = new ArrayList<String>();
            scopes.add(scopeStr);
            resource.setScope(scopes);
        }
        
        return new OAuth2RestTemplate(resource, oauth2ClientContext);
    }
    
    
    /**
     * Base Oauth config
     * 
     * @param scopeStr
     * @return
     */
    private OAuth2RestOperations getmsDevHrApiTemplate(final String scopeStr){
        final OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();

        final ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();

        resource.setAccessTokenUri(accessTokenUri);
        resource.setClientId(hrApiDevAuthClientId);
        resource.setClientSecret(hrApiDevAuthClientSecret);
        resource.setGrantType(grantType);

        if( scopeStr != null ){
            final List<String> scopes = new ArrayList<String>();
            scopes.add(scopeStr);
            resource.setScope(scopes);
        }
        
        return new OAuth2RestTemplate(resource, oauth2ClientContext);
    }
    
    
    /**
     * Base Oauth config
     * 
     * @param scopeStr
     * @return
     */
    private OAuth2RestOperations getmsQaHrApiTemplate(final String scopeStr){
        final OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();

        final ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();

        resource.setAccessTokenUri(accessTokenUri);
        resource.setClientId(hrApiQaAuthClientId);
        resource.setClientSecret(hrApiQaAuthClientSecret);
        resource.setGrantType(grantType);

        if( scopeStr != null ){
            final List<String> scopes = new ArrayList<String>();
            scopes.add(scopeStr);
            resource.setScope(scopes);
        }
        
        return new OAuth2RestTemplate(resource, oauth2ClientContext);
    }
    
    
    /**
     * Base Oauth config
     * 
     * @param scopeStr
     * @return
     */
    private OAuth2RestOperations getmsProdHrApiTemplate(final String scopeStr){
        final OAuth2ClientContext oauth2ClientContext = new DefaultOAuth2ClientContext();

        final ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();

        resource.setAccessTokenUri(accessTokenUri);
        resource.setClientId(hrApiProdAuthClientId);
        resource.setClientSecret(hrApiProdAuthClientSecret);
        resource.setGrantType(grantType);

        if( scopeStr != null ){
            final List<String> scopes = new ArrayList<String>();
            scopes.add(scopeStr);
            resource.setScope(scopes);
        }
        
        return new OAuth2RestTemplate(resource, oauth2ClientContext);
    }
}
