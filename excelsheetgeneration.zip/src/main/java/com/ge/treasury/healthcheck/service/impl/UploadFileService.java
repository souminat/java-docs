package com.ge.treasury.healthcheck.service.impl;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;

import com.ge.treasury.healthcheck.domain.CreateUserInput;
import com.ge.treasury.healthcheck.domain.DataContent;

public class UploadFileService {

	private static final Map<String, Integer> BUSINESS_MAP;
    static {
        Map<String, Integer> aMap = new HashMap<String,Integer>();
        aMap.put("Test Business".toUpperCase(),	12);
        aMap.put("Renewables".toUpperCase(),	114);
        aMap.put("GECC Discontinued Operations".toUpperCase(),	178);
        aMap.put("OTHER CAPITAL CONTINUING".toUpperCase(),	184);
        aMap.put("Transportation".toUpperCase(),	37);
        aMap.put("CAPITAL VERTICALS".toUpperCase(),	171);
        aMap.put("Aviation".toUpperCase(),	33);
        aMap.put("Oil and Gas".toUpperCase(),	181);
        aMap.put("Corporate Components".toUpperCase(),	218);
        aMap.put("Energy Infra".toUpperCase(),	154);
        aMap.put("Renewable".toUpperCase(),	190);
        aMap.put("Energy Connections and Lighting".toUpperCase(),	175);
        aMap.put("POWER".toUpperCase(),	187);
        aMap.put("Total Healthcare".toUpperCase(),	193);

        BUSINESS_MAP = Collections.unmodifiableMap(aMap);
    }
    
    
    private static final Map<String, Integer> SUB_BUSINESS_MAP;
    static {
        Map<String, Integer> aMap = new HashMap<String,Integer>();
        aMap.put("Test Sub Business".toUpperCase(),	13);
        aMap.put("Aviation (CC7000)".toUpperCase(),	34);
        aMap.put("Transportation (CC2000)".toUpperCase(),	38);
        aMap.put("Energy Financial Services (EFS)".toUpperCase(),	43);
        aMap.put("GE Capital Aviation Services (GECAS)".toUpperCase(),	58);
        aMap.put("Corporate Operating".toUpperCase(),	75);
        aMap.put("Total Company Components".toUpperCase(),	82);
        aMap.put("Renewables".toUpperCase(),	115);
        aMap.put("Energy".toUpperCase(),	155);
        aMap.put("Additive Manufacturing".toUpperCase(),	161);
        aMap.put("Aviation Digital Solutions".toUpperCase(),	162);
        aMap.put("AVIO".toUpperCase(),	163);
        aMap.put("Avionics & Digital Solutions".toUpperCase(),	164);
        aMap.put("Business- General Aviation & Integrated Systems".toUpperCase(),	165);
        aMap.put("Commercial Engines".toUpperCase(),	166);
        aMap.put("Engine Services".toUpperCase(),	167);
        aMap.put("Military Systems".toUpperCase(),	168);
        aMap.put("Supply Chain/Engineering/Other".toUpperCase(),	169);
        aMap.put("Capital Residual Insurance".toUpperCase(),	172);
        aMap.put("Home & Business Solutions".toUpperCase(),	176);
        aMap.put("CLL - Discontinued Operations".toUpperCase(),	179);
        aMap.put("HQ OTHER - OIL AND GAS".toUpperCase(),	182);
        aMap.put("GECC Total Corporate Components".toUpperCase(),	185);
        aMap.put("POWER EX RENEWABLES".toUpperCase(),	188);
        aMap.put("GE RENEWABLES".toUpperCase(),	191);
        aMap.put("GE Healthcare".toUpperCase(),	194);
        aMap.put("Global Locomotives".toUpperCase(),	195);
        aMap.put("Global Services".toUpperCase(),	196);
        aMap.put("Global Signaling".toUpperCase(),	197);
        aMap.put("Other / HQ".toUpperCase(),	198);
        aMap.put("Propulsion & Specialty Services".toUpperCase(),	199);
        aMap.put("Transportation Adjacencies".toUpperCase(),	200);
        aMap.put("INDUSTRIAL FINANCE".toUpperCase(),	201);
        aMap.put("Commercial Real Estate (CRE)".toUpperCase(),	202);
        aMap.put("Consumer Finance".toUpperCase(),	203);
        aMap.put("Consumer Singapore Disc Ops-Total".toUpperCase(),	204);
        aMap.put("Lake Discontinued Ops".toUpperCase(),	205);
        aMap.put("Mexico Disc Ops Parent".toUpperCase(),	206);
        aMap.put("Russia Discontinued Operations - Total".toUpperCase(),	207);
        aMap.put("RVM Disc Ops".toUpperCase(),	208);
        aMap.put("Total DiscOps Consumer Home Lending Australia & New Zealand".toUpperCase(),	209);
        aMap.put("WMC Discontinued Ops-Total".toUpperCase(),	210);
        aMap.put("Measurement and Control".toUpperCase(),	211);
        aMap.put("Oil and Gas Transition".toUpperCase(),	212);
        aMap.put("SUBSEA SYSTEMS AND DRILLING".toUpperCase(),	213);
        aMap.put("SURFACE".toUpperCase(),	214);
        aMap.put("Turbomachinery Solutions".toUpperCase(),	215);
        aMap.put("Treasury".toUpperCase(),	216);
        aMap.put("ENERGY CONNECTIONS".toUpperCase(),	219);
        aMap.put("Avionics".toUpperCase(),	228);


        SUB_BUSINESS_MAP = Collections.unmodifiableMap(aMap);
    }
	
	
	public static List<DataContent> validateInput(Map<String, List<CreateUserInput>> createUserInputList) throws Exception {

		Map<String,String> finalOutputMap = new HashMap<String,String>();
		List<DataContent> dataMap= new ArrayList<DataContent>();
		
		Iterator it = createUserInputList.entrySet().iterator();
		List<CreateUserInput> list = null;
		while (it.hasNext()) {
			list = new ArrayList<CreateUserInput>();
			Map.Entry pair = (Map.Entry) it.next();

			//System.out.println("Executing SSO :" + pair.getKey());
			List<CreateUserInput> accessList = (List<CreateUserInput>) pair.getValue();
			for (CreateUserInput o : accessList) {
				// check duplicate rows
				if (list.contains(o)) {
					//System.out.println("Error for  " + pair.getKey() + " - Duplicate entries found");
					
				//	System.out.println(" Validation Error : Duplicate entries found for SSO - " + o.getSso()
					//+ " -" + o.getBusiness() + " - " + o.getSubBusiness() + " - " + o.gettCodeSvcCenter());
//					throw new Exception(" Validation Error : Duplicate entries found for SSO - " + o.getSso()
//					+ " -" + o.getBusiness() + " - " + o.getSubBusiness() + " - " + o.gettCodeSvcCenter());
				} else {
					list.add(o);
				}
			}

			// check invalid rows

			// sort by role
			accessList.sort((i1, i2) -> i1.getRole().compareTo(i2.getRole()));

			boolean isRoleChanged = false;
			Map<String, List<CreateUserInput>> roleMap = new HashMap<>();
			for (CreateUserInput o : accessList) {

				if (roleMap.containsKey(o.getRole())) {
					roleMap.get(o.getRole()).add(o);
				} else {
					List<CreateUserInput> tempList = new ArrayList<CreateUserInput>();
					tempList.add(o);
					roleMap.put(o.getRole(), tempList);
				}
			}
			
			//Validate role wise data
			Iterator roleIteratior = roleMap.entrySet().iterator();
			while (roleIteratior.hasNext()) {
				Map.Entry rolePair = (Map.Entry) roleIteratior.next();
				List<CreateUserInput> roleValList = (List<CreateUserInput>) rolePair.getValue();
				try {
					isDataValid(roleValList);
				} catch (Exception e) {
					throw e;
				}

			}

			// We Assume that Validations have passed and we want to execute the
			// requests
			roleIteratior = roleMap.entrySet().iterator();
			StringBuilder roleString = new StringBuilder();
			while (roleIteratior.hasNext()) {
				Map.Entry rolePair = (Map.Entry) roleIteratior.next();
				//System.out.println("Processing role : " + rolePair.getKey());
				List<CreateUserInput> roleValList = (List<CreateUserInput>) rolePair.getValue();
				
				if(!CollectionUtils.isEmpty(roleValList)){
					for(CreateUserInput o : roleValList){
						
						if(!o.getSubBusiness().contains("DISCARD")){
							DataContent data = new DataContent();
							VelocityEngine ve = new VelocityEngine();
					        //ve.init();
					        ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
							ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
							ve.init();
					        // Getting the Template
					        Template temp = ve.getTemplate("createXML.vm");
					        
					        VelocityContext context = new VelocityContext();
					        
					     /*   context.put("feed", o);*/
					        context.put("DELIMETER", "|");
					        context.put("NEWLINE", "\n");
					        context.put("NEWCOLUMN", "\t");
					        
					        context.put("Role", o.getRole());
					        context.put("business", o.getBusiness());
					        context.put("subbusiness",o.getSubBusiness());
					        context.put("function", o.getFunction());
					        
					        data.setSSO(o.getSso());
					        data.setBusiness(o.getBusiness());
					        data.setSubBusiness(o.getSubBusiness());
					        data.setFunction(o.getFunction());
					        
					        String tsc = o.gettCodeSvcCenter().equalsIgnoreCase("BLANK") ? "" : o.gettCodeSvcCenter();
					        context.put("tsc", tsc);
					        data.settCodeSC(tsc);
					        String bus5Id = StringUtils.trimToNull(String.valueOf(BUSINESS_MAP.get(o.getBusiness().trim().toUpperCase())));
					        data.setBusLevel5ID(bus5Id);
					        String bus6Id = StringUtils.trimToNull(String.valueOf(SUB_BUSINESS_MAP.get(o.getSubBusiness().trim().toUpperCase())));
					        data.setBusLevel6ID(bus6Id);
					       // System.out.println(o.getBusiness() + " -BUS-> " + bus5Id);
					       // System.out.println(o.getSubBusiness() + "-SUB -> " + bus6Id);
					        
					        if(null == bus5Id || bus5Id.equalsIgnoreCase("null")){
					        	
					        	//System.out.println(o.getBusiness());
					        }
					        
					        if(null == bus6Id || bus6Id.equalsIgnoreCase("null")){
					        	System.out.println(o.getSubBusiness().trim());
					        }
					        
					        context.put("bus5id", bus5Id);
					        context.put("bus6id", bus6Id);
					        
					        StringWriter wr = new StringWriter();
					        temp.merge( context, wr );
					        String roleStr = wr.toString();
					        //System.out.println(roleStr);
					        roleString.append(roleStr);
					        dataMap.add(data);
						}
					}
				}
				
				
				
				

			}
			System.out.println(roleString.toString());
			finalOutputMap.put(pair.getKey().toString(), roleString.toString());
		}
		return dataMap;

	}

	private static boolean isDataValid(List<CreateUserInput> sourceList) throws Exception {

		List<String> businessList = sourceList.stream().map(CreateUserInput::getBusiness).collect(Collectors.toList());

		// is business valid
		boolean isAllBusinessPresent = false;
		boolean isAllSubBusinessPresent = false;
		boolean isAllTcodeSvcCenterPresent = false;
		if (businessList.contains("All")) {
			isAllBusinessPresent = true;
			businessList.remove("All");
			if (businessList.size() > 0) {
				throw new Exception("Validation Error : Business not Valid");
			}
		}

		List<String> subBusinessList = sourceList.stream().map(CreateUserInput::getSubBusiness)
				.collect(Collectors.toList());

		// is sub business valid
		if (subBusinessList.contains("All")) {
			isAllSubBusinessPresent = true;
			subBusinessList.remove("All");
			if (subBusinessList.size() > 0) {
				throw new Exception("Validation Error : Sub Business not Valid");
			}
		} else if (isAllBusinessPresent && !subBusinessList.contains("All")) {
			throw new Exception("Validation Error : Sub Business are not Valid");
		}

		List<String> tcodeSvcCenterList = sourceList.stream().map(CreateUserInput::gettCodeSvcCenter)
				.collect(Collectors.toList());

		// tcodeSvcCenterList sub business valid
		if (tcodeSvcCenterList.contains("All")) {
			isAllTcodeSvcCenterPresent = true;
			tcodeSvcCenterList.remove("All");
			if (tcodeSvcCenterList.size() > 0) {
				throw new Exception("Validation Error : TCode Service Centers are not Valid");
			}
		}

		return true;

	}

}
