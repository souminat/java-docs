package com.ge.treasury.healthcheck.domain;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FineGrainUserInfo{

	@JsonProperty("approvalRange")
	private String approvalRange;

	@JsonProperty("paymentType")
	private String paymentType;
	
	@JsonProperty("requestType")
	private String requestType;
	
	public FineGrainUserInfo(){}

	public String getApprovalRange() {
		return approvalRange;
	}

	public void setApprovalRange(String approvalRange) {
		this.approvalRange = approvalRange;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	public List<Double> getApprovalRangeForSQL(){
		if(null != approvalRange){
			List<Double> rangeDouble = new ArrayList<Double>();
			String[] range = approvalRange.split("-");
			rangeDouble.add(Double.valueOf(range[0]));
			rangeDouble.add(Double.valueOf(range[1]));
			return rangeDouble;
		}else{
			return null;
		}
	}

	@Override
	public String toString() {
		return "FineGrainUserInfo [approvalRange=" + approvalRange + ", paymentType=" + paymentType + ", requestType="
				+ requestType + "]";
	}


}
