package com.ge.treasury.healthcheck.domain;

import java.io.Serializable;

public class StatusTime implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 6355250786642216128L;
    
    private String Status;
    private long responseTime;
    private String urlHit;
    private String serviceResponse;
    
    public String getStatus() {
        return Status;
    }
    public void setStatus(String status) {
        Status = status;
    }
    public long getResponseTime() {
        return responseTime;
    }
    public void setResponseTime(long responseTime) {
        this.responseTime = responseTime;
    }
    public String getUrlHit() {
        return urlHit;
    }
    public void setUrlHit(String urlHit) {
        this.urlHit = urlHit;
    }
    public String getServiceResponse() {
        return serviceResponse;
    }
    public void setServiceResponse(String serviceResponse) {
        this.serviceResponse = serviceResponse;
    }
    
}
