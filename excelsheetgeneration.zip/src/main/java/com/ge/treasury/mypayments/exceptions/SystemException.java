/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.exceptions;

import com.ge.treasury.mypayments.exceptions.BusinessExceptionConstants;

/**
 * SystemException
 * 
 * @author MyPayments Dev Team
 * 
 */
public class SystemException extends RuntimeException {

    private static final long serialVersionUID = -6398244598919850159L;
    private final int errorCode;

    /**
     * Constructor with no arguments
     */
    public SystemException() {
        super();
        this.errorCode = BusinessExceptionConstants.SYSTEM_EXCEPTION_CODE;
    }

    /**
     * @param errorCode
     */
    public SystemException(int errorCode) {
        super();
        this.errorCode = errorCode;
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public SystemException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.errorCode = BusinessExceptionConstants.SYSTEM_EXCEPTION_CODE;
    }

    /**
     * @param message
     * @param cause
     */
    public SystemException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = BusinessExceptionConstants.SYSTEM_EXCEPTION_CODE;
    }

    /**
     * @param message
     */
    public SystemException(String message) {
        super(message);
        this.errorCode = BusinessExceptionConstants.SYSTEM_EXCEPTION_CODE;
    }

    /**
     * @param cause
     */
    public SystemException(Throwable cause) {
        super(cause);
        this.errorCode = BusinessExceptionConstants.SYSTEM_EXCEPTION_CODE;
    }

    /**
     * Constructor with only code and message as arguments
     * 
     * @param code
     * @param message
     */
    public SystemException(int code, String message) {
        super(message);
        this.errorCode = code;
    }

    /**
     * @return the errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }
}
