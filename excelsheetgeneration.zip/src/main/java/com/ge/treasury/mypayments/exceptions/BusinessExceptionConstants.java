/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.exceptions;

/**
 * Contains constants for error codes
 * 
 * @author MyPayments Dev Team
 *
 */
public class BusinessExceptionConstants {
    public static final String DEFAULT_SYSTEM_ID = "MyPayments";

    public static final int BUSINESS_ERROR_CODE = 100;
    public static final int ERROR_CODE = -1;

    public static final int UNEXPECTED_RUNTIME_EXCEPTION = 50;
    public static final int DB_EXCEPTION_CODE = 200;
    public static final int NOT_FOUND_EXCEPTION_CODE = 201;
    public static final int JSON_PARSE_ERROR = 300;
    public static final int INVALID_FORMAT_MAPPING = 301;
    public static final int SYSTEM_EXCEPTION_CODE = 310;
    
    private BusinessExceptionConstants() {
        super();
    }

}
