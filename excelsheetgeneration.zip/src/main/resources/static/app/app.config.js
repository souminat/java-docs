angular.module('app.config',[])

.provider('config', function() {
	var config = this;
	
	
	config.apiBasePath = "/";
	config.templateBasePath = '/';
	
	config.timeoutInMinutes = 29;
	config.redirectUrl = config.apiBasePath + "logout";
	
	config.MAX_TRADE_SIZE = 800;
	
	config.PAGINATION_SIZE = 10;
	
	config.mobileMenuShown = false;
	
	this.$get = function() {
		return config;
	};
});

