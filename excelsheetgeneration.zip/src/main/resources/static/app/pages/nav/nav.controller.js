angular.module('app.pages.nav.controller',[
	'app.services'
])
.controller('navController', function ($scope) {
	var nav = this;
});