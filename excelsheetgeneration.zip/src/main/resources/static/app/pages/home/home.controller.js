angular.module('app.pages.home.controller',['ui.router'])

.config(function ($stateProvider) {

	$stateProvider
		.state('pages.home', {
			url: "/home",
			views: {
				'content': {
					template: "redirecting to pinned home...{{ home.page }}",
					controller: 'homeController as home'
				}
			}
		})
})

.controller('homeController', function ($location, $timeout, $state) {
	var home = this;

	home.page = "pages.microservices";
	//$state.go('pages.microservices');

});