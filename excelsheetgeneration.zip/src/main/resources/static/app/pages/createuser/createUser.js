angular.module('app.createUsercontroller', [ 'app.components.fileUpload.directive','app.services','ux.form.simpleModal','ui.bootstrap','app.components.loadingOverlay'])

.controller('createUserController', function($scope,createUserManager,simpleModal,csv) {
	var createUser = this;
/*	var file = $scope.file;
	var name = file.name;
	console.log(name);*/
	angular.extend(createUser, {
		
		downloadFile : function(file) {
			//var loadingModal = simpleModal.loading('Exporting data...');
			console.log(file);
			var response = createUserManager.downloadFile(file);
			response.$promise.then(function(result) {
				/*C:\Users\souminat\Desktop*/
				
				/*var fileContent = "";
				console.log(result[0]);
				for(i=0;i<result.length;++i){
					fileContent = fileContent + result[i];
				}
				console.log(fileContent);*/
				//console.log(result.file1.file);
				outText = csv.exportFile(result.content);
				//loadingModal.close();
				var blob = new Blob([outText], {type: "text/plain;charset=utf-8"});
				saveAs(blob, 'Report.csv');
				/*simpleModal.open({title:'success', 
								  body:'File downloaded successfully.'});*/
			});		
		}
	});
	
});