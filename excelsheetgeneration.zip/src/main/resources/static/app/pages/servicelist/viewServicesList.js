angular.module('app.controller', [ 'app.components.formItem.directive','app.services','ux.form.simpleModal','ui.bootstrap','app.components.loadingOverlay','app.components.exportCsv.factory'])
	
.controller('listController', function($scope,$timeout,checkUsersManager,checkHrApiManager,checkFineGrainManager,checkAuditManager,checkMarketManager,checkGoldManager,checkBankrouteManager,checkBusinessManager,checkCountryManager,checkBankbranchManager,checkBankaccountManager,checkHolidayManager,checkCurrencyManager , checkServiceManager,checkMultipleServiceManager,$uibModal,simpleModal,Excel) {
		var serviceList = this;
		 angular.extend(serviceList, {
			 headingTitle: "Micro Services List",
			 appTypes: [ 'My Bank', 'My Payments' ],
		     envTypes: [ 'DEV', 'QA', 'PROD','DirectDev','DirectQa','DirectProd'],
		     waiting: 'waiting',
		     endPointTypes: [{
					name : 'All',
					description : 'All'
				},{
					name : 'currency',
					description : '$filter=(STATUS=\'Active\')'
				}, {
					name : 'holiday',
					description : '$filter=(fin_cntr_code=\'MeB\' and formatdate(\'dd-MM-yyyy\', hol_dt) = \'15-12-2018\')'
				}, {
					name : 'bankAccount',
					description : '$filter=(tcode = \'JE12\')'
				}, {
					name : 'bankBranch',
					description : '$filter=(bank_status=\'Active\')'
				}, {
					name : 'country',
					description : '$filter=(UPPER(CNTRY_STATUS) = UPPER(\'Active\'))'
				}, {
					name : 'business',
					description : '$filter=(bus_sbus_rel_status=\'Active\')'
				}, {
					name : 'marketData',
					description : '$filter=(ds_code=\'MOREXRTTREAX\' and rec_nm = \'EUR-USD\' and sbscr_code = \'ALOC\')'
				}, {
					name : 'le',
					description : '$filter=((primry_alt_code like \'%ge%\' or party_long_nm like \'%ge%\') and primry_srce_sys = \'GOLD\' and party_status = \'ACTIVE\')'
				}, {
					name : 'bankRouteCode',
					description : '$filter=(UPPER(rte_code) like UPPER(\'CITIUS33CRP\'))'
				},{
					 name : 'ReadAudit',
					description : 'ReadAudit'
				},{
					name : 'FineGrain',
					description : 'FineGrain'
				},{
					name : 'GetUsers',
					description : 'GetUsers'
				},{
					name : 'HrApi',
					description : 'HrApi'
				},{
					name : 'Box',
					description : 'Box'
				}],
				callSingleService : function(){
					serviceList.filterDescription = serviceList.endpoint.description;
					serviceList.endPoint = serviceList.endpoint.name;
					//serviceList.isLoading = true;
					var response =  checkServiceManager.checkServiceRequest(serviceList);
					response.$promise.then(function(result) {
						//serviceList.isLoading = false;
						serviceList.serviceResult = result.statusList;
						serviceList.shwPaymentMethodMsg(serviceList.serviceResult);
				});
		  },
		  callMultipleService : function(){
			  serviceList.allService = [];
			  serviceList.isLoading = true;
			  serviceList.filterDescription = serviceList.endpoint.description;
				/*var response =  checkMultipleServiceManager.checkMultipleServiceRequest(serviceList);
				response.$promise.then(function(result) {
					//serviceList.isLoading = false;
					serviceList.serviceResult = result;
					serviceList.allService=result.statusList;
				});*/
				
				var response =  checkCurrencyManager.CurrencyServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					serviceList.serviceResult = result.endPoint;
					serviceList.allService.push(result.statusList[0]);
					var currnecydtls = result.statusList[0];;
					serviceList.currencyUrl = currnecydtls.currency.urlHit;
					serviceList.currencyServiceName = result.endPoint;
					serviceList.currencyResponseTime = currnecydtls.currency.responseTime;
					serviceList.currencyStatus = currnecydtls.currency.status;
					serviceList.currencyResponse = currnecydtls.currency.serviceResponse;
				});
				
				var response =  checkHolidayManager.HolidayServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var holidaydetails = result.statusList[0];;
					serviceList.holidayUrl = holidaydetails.holiday.urlHit;
					serviceList.holidayServiceName = result.endPoint;
					serviceList.holidayResponseTime = holidaydetails.holiday.responseTime;
					serviceList.holidayStatus = holidaydetails.holiday.status;
					serviceList.holidayResponse = holidaydetails.holiday.serviceResponse;
				});
				
				var response =  checkBankaccountManager.BankaccountServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var bankaccdetails = result.statusList[0];;
					serviceList.bankaccUrl = bankaccdetails.mdmBankAccount.urlHit;
					serviceList.bankaccName = result.endPoint;
					serviceList.bankaccResponseTime = bankaccdetails.mdmBankAccount.responseTime;
					serviceList.bankaccStatus = bankaccdetails.mdmBankAccount.status;
					serviceList.bankaccResponse = bankaccdetails.mdmBankAccount.serviceResponse;
				});
				
				
				var response =  checkBankbranchManager.BankbranchServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var bankBrchdetails = result.statusList[0];;
					serviceList.bankBrchUrl = bankBrchdetails.mdmBankBranch.urlHit;
					serviceList.bankBrchName = result.endPoint;
					serviceList.bankBrchResponseTime = bankBrchdetails.mdmBankBranch.responseTime;
					serviceList.bankBrchStatus = bankBrchdetails.mdmBankBranch.status;
					serviceList.bankBrchResponse = bankBrchdetails.mdmBankBranch.serviceResponse;
				});
				
				var response =  checkCountryManager.CountryServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var countrydetails = result.statusList[0];;
					serviceList.countryUrl = countrydetails.country.urlHit;
					serviceList.countryName = result.endPoint;
					serviceList.countryResponseTime = countrydetails.country.responseTime;
					serviceList.countryStatus = countrydetails.country.status;
					serviceList.countryResponse = countrydetails.country.serviceResponse;
				});
				
				var response =  checkBusinessManager.BusinessServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var businessdtls = result.statusList[0];;
					serviceList.businessUrl = businessdtls.business.urlHit;
					serviceList.businessServiceName = result.endPoint;
					serviceList.businessResponseTime = businessdtls.business.responseTime;
					serviceList.businessStatus = businessdtls.business.status;
					serviceList.businessResponse = businessdtls.business.serviceResponse;
				});
				
				var response =  checkMarketManager.MarketServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var marketdetails = result.statusList[0];;
					serviceList.marketUrl = marketdetails.MarketData.urlHit;
					serviceList.marketName = result.endPoint;
					serviceList.marketResponseTime = marketdetails.MarketData.responseTime;
					serviceList.marketStatus = marketdetails.MarketData.status;
					serviceList.marketResponse = marketdetails.MarketData.serviceResponse;
				});
				
				var response =  checkGoldManager.GoldServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var golddetails = result.statusList[0];;
					serviceList.goldUrl = golddetails.GoldLe.urlHit;
					serviceList.goldName = result.endPoint;
					serviceList.goldResponseTime = golddetails.GoldLe.responseTime;
					serviceList.goldStatus = golddetails.GoldLe.status;
					serviceList.goldResponse = golddetails.GoldLe.serviceResponse;
				});
				
				var response =  checkBankrouteManager.BankrouteServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var bankroutedetails = result.statusList[0];;
					serviceList.bankRouteUrl = bankroutedetails.BankRouteCode.urlHit;
					serviceList.bankRouteName = result.endPoint;
					serviceList.bankRouteResponseTime = bankroutedetails.BankRouteCode.responseTime;
					serviceList.bankRouteStatus = bankroutedetails.BankRouteCode.status;
					serviceList.bankRouteResponse = bankroutedetails.BankRouteCode.serviceResponse;
				});
				
				var response =  checkAuditManager.AuditServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var auditdetails = result.statusList[0];;
					serviceList.auditUrl = auditdetails.Audit.urlHit;
					serviceList.auditName = result.endPoint;
					serviceList.auditResponseTime = auditdetails.Audit.responseTime;
					serviceList.auditStatus = auditdetails.Audit.status;
					serviceList.auditResponse = auditdetails.Audit.serviceResponse;
				});
				
				var response =  checkFineGrainManager.FineGrainServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var finegraindetails = result.statusList[0];;
					serviceList.finegrainUrl = finegraindetails.FineGrain.urlHit;
					serviceList.finegrainName = result.endPoint;
					serviceList.finegrainResponseTime = finegraindetails.FineGrain.responseTime;
					serviceList.finegrainStatus = finegraindetails.FineGrain.status;
					serviceList.finegrainResponse = finegraindetails.FineGrain.serviceResponse;
				});
				
				var response =  checkHrApiManager.HrApiServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var hrapidetails = result.statusList[0];;
					serviceList.hrapiUrl = hrapidetails.HrApi.urlHit;
					serviceList.hrapiName = result.endPoint;
					serviceList.hrapiResponseTime = hrapidetails.HrApi.responseTime;
					serviceList.hrapiStatus = hrapidetails.HrApi.status;
					serviceList.hrapiResponse = hrapidetails.HrApi.serviceResponse;
				});
				
				var response =  checkUsersManager.UsersServiceRequest(serviceList);
				response.$promise.then(function(result) {
					serviceList.isLoading = false;
					var usersdetails = result.statusList[0];;
					serviceList.usersUrl = usersdetails.GetUsers.urlHit;
					serviceList.usersName = result.endPoint;
					serviceList.usersResponseTime = usersdetails.GetUsers.responseTime;
					serviceList.usersStatus = usersdetails.GetUsers.status;
					serviceList.usersResponse = usersdetails.GetUsers.serviceResponse;
				});
		  },
		  checkEndPoint : function(){
			  if(_.isUndefined(serviceList.endpoint) || _.isEmpty(serviceList.endpoint) || (_.isEqual(serviceList.endpoint.name,'All')) || (_.isEqual(serviceList.endpoint.name,'ReadAudit')) || (_.isEqual(serviceList.endpoint.name,'FineGrain')) || (_.isEqual(serviceList.endpoint.name,'GetUsers')) || (_.isEqual(serviceList.endpoint.name,'HrApi'))){
				  return false;  
			  }else{
				  return true;
			  }
		  },
		  checkSingleButton :function(){
			  if(!_.isEqual(serviceList.endpoint.name,'All')){
				  if(_.isEqual(serviceList.endpoint.name,"ReadAudit")){
					  if(!_.isUndefined(serviceList.paymentRequestId) && _.isNumber(serviceList.paymentRequestId)) {
						  return false;
					  } else {
						  return true;
					  }
				  } else if (_.isEqual(serviceList.endpoint.name,"FineGrain")) {
					  if(!_.isUndefined(serviceList.ssoId) && _.isNumber(serviceList.ssoId)) {
						  return false;
					  } else {
						  return true;
					  }
				  }
			  }else{
				  return true;
			  }
		  },
		  checkMultipleButton :function(){
			  if(_.isEqual(serviceList.endpoint.name,'All')){
				  return false;
			  }else{
				  return true;
			  }
		  },
		  displayButtonPanel : function(){
			 if(_.isUndefined(serviceList.applicationName) || _.isUndefined(serviceList.environment) || _.isUndefined(serviceList.endpoint.name)){
				 return false;
			 } else {
				 return true;
			 }
		  },
		  displayTable : function (){
			  if(_.isEqual(serviceList.endpoint.name,'All')){
				  return true;
			  } else {
				  return false;
			  }
		  },
		  shwPaymentMethodMsg : function (serviceResult){
			  if (!_.isUndefined(serviceResult) || !_.isEmpty(serviceResult)) {
          		var options = {
              			title:'Single Service Response', 
              			body:'',
              			bodyHTML: '',
              			allowClose: true,
              			copyText: 'Copy to Clipboard',
              			allowDismiss: true,
              			dismissText: 'Close',
              			loading: false
              		};
              	$uibModal.open({
          			templateUrl: '/app/pages/modal/serviceModal.controller.html',
          			controller: ["$scope","$uibModalInstance", "$sce","options", function($scope, $uibModalInstance,$sce,options) {
          				$scope.serviceList = serviceResult;
          				$scope.iterate = function (){
          					var text ='';
          					var Time =''
          				    angular.forEach($scope.serviceList, function(value, key){
          				    	angular.forEach(value, function(v, k){
          				    		text = "\n SERVICE NAME : "+ k + "\n URL HIT : " + v.urlHit  + "\n RESPONSE TIME : " + v.responseTime + "\n STATUS : " + v.status + "\n SERVICE RESPONSE : "+ v.serviceResponse
          				    	});
          				    });

          				    return text;
          				};
          				$scope.options = options;
          				$scope.options.htmlTrustedContent = $sce.trustAsHtml(options.bodyHTML);
          				$scope.copiedMessageFlag = false;
          				$scope.copyText = function () {
          					$timeout(function() {
          						$scope.copiedMessageFlag = true;
          				      },100);
          					var copyTextareaBtn = document.querySelector('.js-textareacopybtn');

          					  var copyTextarea = document.querySelector('.js-copytextarea');
          					  copyTextarea.select();
          					$timeout(function() {
          						$scope.copiedMessageFlag = false;
          				      },5000);
          					
          					  try {
          					    var successful = document.execCommand('copy');
          					    var msg = successful ? 'successful' : 'unsuccessful';
          					    console.log('Copying text command was ' + msg);
          					  } catch (err) {
          					    console.log('Oops, unable to copy');
          					  }
          					 
          				};
          				$scope.close = function () {
          					$uibModalInstance.close()
          				};
          			}],
          			resolve: {
          				options: function () {
          					return options;
          				}
          			}
          		});
				}
		  },
		  exportToExcel : function(tableId){ 
	            var exportHref=Excel.tableToExcel(tableId,'ServicesReportData');
	            $timeout(function(){ 
	            	var env = serviceList.environment;
	            	var anchorTag = document.createElement('a');
	            	anchorTag.href=exportHref;
	            	anchorTag.download = "ServicesReport_" + env +".xls";
	            	document.body.appendChild(anchorTag);
	            	anchorTag.click();
	            	anchorTag.remove();
		  		},100);
	      },
	      showResponse : function (uiKey,serviceResult){
	    	  console.log(uiKey);
	    	  console.log(serviceResult);
	    	  if (!_.isUndefined(serviceResult) || !_.isEmpty(serviceResult)) {
	          		var options = {
	              			title: uiKey +' Response', 
	              			body:'',
	              			bodyHTML: '',
	              			allowClose: true,
	              			copyText: 'Copy to Clipboard',
	              			allowDismiss: true,
	              			dismissText: 'Close',
	              			loading: false
	              		};
	              	$uibModal.open({
	          			templateUrl: '/app/pages/modal/responseModal.controller.html',
	          			controller: ["$scope","$uibModalInstance", "$sce","options", function($scope, $uibModalInstance,$sce,options) {
	          				$scope.checkKey = uiKey;
	          				$scope.serviceList = serviceResult;
	          				$scope.iterate = serviceResult;
	          				$scope.options = options;
	          				$scope.options.htmlTrustedContent = $sce.trustAsHtml(options.bodyHTML);
	          				$scope.copiedMessageFlag = false;
	          				$scope.copyText = function () {
	          					$timeout(function() {
	          						$scope.copiedMessageFlag = true;
	          				      },100);
	          					var copyTextareaBtn = document.querySelector('.js-textareacopybtn');

	          					  var copyTextarea = document.querySelector('.js-copytextarea');
	          					  copyTextarea.select();
	          					$timeout(function() {
	          						$scope.copiedMessageFlag = false;
	          				      },5000);
	          					
	          					  try {
	          					    var successful = document.execCommand('copy');
	          					    var msg = successful ? 'successful' : 'unsuccessful';
	          					    console.log('Copying text command was ' + msg);
	          					  } catch (err) {
	          					    console.log('Oops, unable to copy');
	          					  }
	          					 
	          				};
	          				$scope.close = function () {
	          					$uibModalInstance.close()
	          				};
	          			}],
	          			resolve: {
	          				options: function () {
	          					return options;
	          				}
	          			}
	          		});
				}
	      },
	      //show Response function ending
	      checkAudit : function () {
	    	  if(_.isEqual(serviceList.endpoint.name,"ReadAudit")){
				  return true;
			  }else{
				  return false;
			  }
	      },
	      checkSso : function () {
	    	  if(_.isEqual(serviceList.endpoint.name,"FineGrain") || _.isEqual(serviceList.endpoint.name,"HrApi")){
				  return true;
			  }else{
				  return false;
			  }
	      },
	      validateReqNumber : function()
	      {
	    	  if(!_.isNumber(serviceList.paymentRequestId)) {
	    		  serviceList.PayReqNumber = true;
	    	  } else {
	    		  serviceList.PayReqNumber =  false;
	    	  }
	      },
	      validateSso : function()
	      {
	    	  if(!_.isNumber(serviceList.ssoId)) {
	    		  serviceList.PayReqNumber = true;
	    	  } else {
	    		  serviceList.PayReqNumber =  false;
	    	  }
	      }
	});
});