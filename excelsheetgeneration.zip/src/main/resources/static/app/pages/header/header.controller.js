angular.module(
		'app.pages.header.controller',
		[ 'app.config', 'app.services',
				 ])

.controller(
		'headerController',
		function($q) {
			var header = this;

			// header.currentUser = currentUser;

			header.dropShown = false;
			header.searchTerm = '';

			header.toggleDrop = function() {
				header.dropShown = !header.dropShown;
			}
			header.toggleMenu = function() {
				config.mobileMenuShown = !config.mobileMenuShown;
			}

			
		/*	// Initialization of user
			header.initUser = function() {
				var defer = $q.defer();

				var ssoPromise = userManager.get();

				ssoPromise.$promise.then(function(result) {
					var sso = result.sso;
					if (!_.isUndefined(sso)) {
						var userPromise = userManager.get(sso);
						userPromise.$promise.then(function(result) {

							// Set the current user to be displayed in header
							header.currentUser = result;

							defer.resolve(result);
						}, function(reason) {
							window.location = config.redirectUrl;

						});
					} else {
						window.location = config.redirectUrl;
					}

				}, function(reason) {
					window.location = config.redirectUrl;

				});

				return defer.promise;
			}

			// Initialization method
			header.init = function() {
				// Initialization of user
				header.initUser();
			};

			// Initialization method that runs when controller loads
			header.init();*/
		});
