/*angular.module('app', [
'ui.router',
'app.pages'
])

.config(function ($provide, $locationProvider ,$urlRouterProvider , $stateProvider, $httpProvider) {

	$locationProvider.html5Mode({enabled:true, rewriteLinks:false});
	
	//handle route misses
	

	$urlRouterProvider.when(/error/, '/error').otherwise('/home');

	
	//handle global ajax errors
	$provide.factory('myHttpInterceptor', function($q, $injector) {
		return {
			'responseError': ""
		};
	});
	$httpProvider.interceptors.push('myHttpInterceptor');
	
	
	if (!$httpProvider.defaults.headers.get) {
		$httpProvider.defaults.headers.get = {};
	}
	$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
	$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
	$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
	
	var defaultTransformResponse = $httpProvider.defaults.transformResponse[0];
	
	function EMdefaultTransform(data, headers, status) {
		//success codes, allow transform to json
		if(200 <= status && status < 300) {
			return defaultTransformResponse(data, headers);
		}
		//error codes, no transforming
		else return data;
	}
	
	//overwrite the defaults transform
	$httpProvider.defaults.transformResponse = [EMdefaultTransform];
	
})

.run(function($rootScope, $state) {
	$state.go('pages.microservices');
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){ 
		config.mobileMenuShown = false;
	});
	$rootScope.$on('$stateChangeSuccess',function(event, toState, toParams, fromState, fromParams){
		 $rootScope.$state = $state;
	});
	$rootScope.callErrorController = function () {
		$state.go('pages.error');
	}
	
})*/