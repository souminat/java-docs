angular.module('app.components.formItem.directive',[])

.directive('applicationFormItem', function () {
	return {
		restrict: 'E',
		transclude: true,
		scope: {
			label: '@',
			ngClass: '=',
			controlClass: '@',
			asterisk: '=',
			shwhide:	'='
		},
		templateUrl: '/app/components/formItem/formItem.directive.html'
	};
});
