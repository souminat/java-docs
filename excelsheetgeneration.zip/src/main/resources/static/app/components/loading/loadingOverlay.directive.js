angular.module('app.components.loadingOverlay', [])

    .directive('ctLoadingOverlay', function() {
        return {
            restrict: 'E',
            transclude: true,
            scope: {
                size: '@',
                ngIf: '@'
            },

            template: '<div class="ct-loading-overlay" ng-class="{\'spinner-sm\': size === \'sm\', \'spinner-lg\': size === \'lg\'}" ng-if="ngIf">' +
                          '<i class="fa fa-spinner fa-pulse fa-fw text-secondary"></i><br />' +
                          '<div class="loading-message" ng-transclude></div>' +
                      '</div>',

            link: function (scope, element, attrs, ctrl, transclude) {
                element.parent().addClass('ct-loading-container');
            }
        };
    });