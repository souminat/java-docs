var lovFilter = angular.module('app.filters.lov.filter', [
	'app.services.lov'
]);
lovFilter.filter('lovFilter', function($q, lov) {
	
	var cached = {};
	var resultData = null;
	
	function myFilter(lookupCode) {
		if(lookupCode) {
			if(lookupCode in cached) {
				// avoid returning a promise!
				return typeof cached[lookupCode].then !== 'function' ? cached[lookupCode].displayName : undefined;
			} else {
				var promise = lov.getLookupCode(lookupCode);
	    		promise.then(function(result) {
	    			cached[lookupCode] = result;
	    		});
			}
		}
	}; 
	
	myFilter.$stateful = true;
	return myFilter; 
	
});