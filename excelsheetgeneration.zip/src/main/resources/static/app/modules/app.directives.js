angular.module('app.directives',[
	'app.components.formItem.directive','app.components.fileUpload.directive'
]);