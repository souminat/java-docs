angular.module('app.services.createUsers', ['ngResource', 'app.config'])

.factory('formDataObject', function() {
	return function(data) {
		var fd = new FormData();
		angular.forEach(data, function(value, key) {
			fd.append(key, value);
		});
		return fd;
	};
})
/*	.factory('createUserServiceFactory', function ($resource, formDataObject, config) {
		//setup custom action
		var _actions = {
			createCSV: {
				method: 'POST',
				headers: {
					'Content-Type': undefined //required for file upload to work
				},
				transformRequest: formDataObject
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/createUser/v1/createCSV', {}, _actions);

		return function (file) {
			return _resource.createCSV(file);
		}
	})
	 .service('createUserManager', function (createUserServiceFactory) {
    	var createUserManager = this;

    	// Public properties/methods
        angular.extend(createUserManager, {
        	*//**
        	 * fetch service result
        	 *//*
        	downloadFile: function (file) {
        		return new createUserServiceFactory({file : file});
        	}
        });
    });*/


.factory('createUserServiceFactory', function ($resource, formDataObject,config) {
	//setup custom action
	var _actions = {
			createCSV: {
			method: 'POST',
			headers: {
				'Content-Type': undefined
			},
			transformRequest: formDataObject
			//data: {} //you have data present for content-type header to be applied
		}
	};

	var _resource = $resource(config.apiBasePath + 'api/createUser/v1/createCSV', {}, _actions);

	return function (file) {
		return _resource.createCSV(file);
	}
})
.service('createUserManager', function (createUserServiceFactory) {
	var createUserManager = this;
	var cached = {};
	
	// Private method used to clear empty parameters 
	var clearFilters = function(filters) {
		for(var filter in filters) {
			var value = filters[filter];
			if(_.isUndefined(value) || _.isEqual(value, '')) {
				delete filters[filter];
			}
		}
		return filters;
	};
    
	// Public properties/methods
    angular.extend(createUserManager, {
    	/**
    	 * fetch service result
    	 */
    	/*GoldServiceRequest: function (serviceList) {
    		return new GoldFactory(serviceList);*/
    		
    		downloadFile: function (file) {
        		return new createUserServiceFactory({file : file});
    	}
    });
});