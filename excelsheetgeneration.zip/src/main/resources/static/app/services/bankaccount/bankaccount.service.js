angular.module('app.services.bankaccount', ['ngResource', 'app.config'])

	.factory('BankAccountFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				serviceBankaccountCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkBankAccountRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceBankaccountCheck(serviceList);
		}
	})
    .service('checkBankaccountManager', function (BankAccountFactory) {
    	var checkBankaccountManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkBankaccountManager, {
        	/**
        	 * fetch service result
        	 */
        	BankaccountServiceRequest: function (serviceList) {
        		return new BankAccountFactory(serviceList);
        	}
        });
    });