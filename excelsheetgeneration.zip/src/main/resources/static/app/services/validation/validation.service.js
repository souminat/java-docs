angular.module('app.services.validation',[
'app.services.validation.type'
])

.service('validation', function ($q, typeValidation) {
	var validation = this;

	validation.format = function(rule, ruleType, value) {
		
		//find the right validator and run format
		return validation.getValidationService(rule).format(ruleType, value);
		
	}
	
	validation.getValidationService = function(rule) {		
			
		 if(rule === 'type') { 
			 return typeValidation; 
		 }
		else {
			throw new Error('validator not found for the rule: ' + rule);
		}
	}
})