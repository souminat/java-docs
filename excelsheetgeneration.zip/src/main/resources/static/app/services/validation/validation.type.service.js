angular.module('app.services.validation.type',[])

//ruleTypes: currency, number, date, string, empty
.service('typeValidation', function () {
	var typeValidation = this;
	
	typeValidation.format = function(ruleType, value) {
		
		if(ruleType === 'string') {
			//do not format blank values
			return value;
		}
		
	}
})