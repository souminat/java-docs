angular.module('app.services.holiday', ['ngResource', 'app.config'])

	.factory('HolidayFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				serviceHolidayCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkHolidayRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceHolidayCheck(serviceList);
		}
	})
    .service('checkHolidayManager', function (HolidayFactory) {
    	var checkHolidayManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkHolidayManager, {
        	/**
        	 * fetch service result
        	 */
        	HolidayServiceRequest: function (serviceList) {
        		return new HolidayFactory(serviceList);
        	}
        });
    });