angular.module('app.services.csv.mapping',[])

.service('csvMapping', function () {
	var csvMapping = this;
/*	SSO,ROLE,BUSINESS,SUB-BUSINESS,FUNCTION,TCODE,BUS-5-ID,BUS-6-ID
	private String sso;
	private String isReconciler;
	private String isContingentWorker;
	private String function;
	private String role;
	private String business;
	private String subBusiness;
	private String tCodeSvcCenter;*/
	csvMapping.rules = {
			'SSO': [{name:'sso', rule:'type', ruleType:'string'}],
			'ROLE': [{name:'role', rule:'type', ruleType:'string'}],
			'BUSINESS': [{name:'business', rule:'type', ruleType:'string'}],
			'SUB-BUSINESS': [{name:'subBusiness', rule:'type', ruleType:'string'}],
			'FUNCTION': [{name:'function', rule:'type', ruleType:'string'}],
			'TCODE': [{name:'tCodeSC', rule:'type', ruleType:'string'}],
			'BUS-5-ID': [{name:'busLevel5ID', rule:'type', ruleType:'string'}],
			'BUS-6-ID': [{name:'busLevel6ID', rule:'type', ruleType:'string'}]
			
	};
	
	csvMapping.exportCoulmns = [
	                            'SSO',
	                    		'ROLE',
	                    		'BUSINESS',
	                    		'SUB-BUSINESS',
	                    		'FUNCTION',
	                    		'TCODE',
	                    		'BUS-5-ID',
	                    		'BUS-6-ID'
     ];
	
	
});