angular.module('app.services.csv',[
'app.services.csv.mapping',
'app.services.validation'
])
.service('csv', function ($q, csvMapping,validation) {
var csv = this;
	
	//have PapaParse do its thing. csvFile can be fileobj or string
	csv.parse = function(csvFile) {
		
		var deferred = $q.defer();
		
		Papa.parse(csvFile,
			{
				header: true,
				skipEmptyLines: true,
				complete: function(results) {
					deferred.resolve(results);
				}
			}
		);
		
		return deferred.promise;
	}
	
	csv.exportFile = function(rows) { 
		var csvOutput = csv.exportRowsByMapping(rows, csvMapping.exportCoulmns); 
		return csvOutput;
	};
	
	csv.exportRowsByMapping = function(rows, columns) {
		var csvOutput = '';
		//var errMapping = (errMapping == undefined)?false:errMapping;

		//out headers
		for(var index in columns) {
			csvOutput += '"' + columns[index] + '",';
		}
		csvOutput += '\r\n';
		
		//for each row export per mapping rules
		for(var rowNum in rows) {
			var rowData = rows[rowNum];
			
			for(var index in columns) {
				var columnName = columns[index];
				
				
				var columnRules = null;			
				
				columnRules = csvMapping.rules[columnName];
		
				
				var ruleMatch = null;
				
				// for each column that you are exporting, loop through each possible mapping (most have one)
				for(var ruleNum in columnRules) {
					var currentRule = columnRules[ruleNum];
					ruleMatch = currentRule;		
				}
				// if mapping was found use the rule and ruleType to format the export
				// if no matching mapping was found, export nothing for that column
				if(ruleMatch) {
					var val = csv.getObjectProperty(rowData, ruleMatch.name);
					var formatResult = validation.format(ruleMatch.rule, ruleMatch.ruleType, val);
					if(formatResult || formatResult == 0) {						
						csvOutput += '"';
						formatResult = formatResult.toString();
						csvOutput += formatResult.replace(/"/g, '""'); //replacing " to "" to prevent breaking in MS excel						
						csvOutput += '\t"'; //adding tab to make it look like string type in MS Excel												
					}
				}
				csvOutput += ',';
			}
			csvOutput += '\r\n';
		}
		
		return csvOutput;
	};
	
	csv.getObjectProperty = function(refObject, propertyName) {
		
		propertyNameSplit = propertyName.split('.');
		
		var targetObj = refObject;
		
		//create sub objects as needed
		for(var i=1;i<propertyNameSplit.length;i++){
			if(!targetObj[propertyNameSplit[i-1]]) {
				return null;
			}
			targetObj = targetObj[propertyNameSplit[i-1]];
		}
		
		//return the property
		return targetObj[propertyNameSplit[propertyNameSplit.length-1]];
	};
});