angular.module('app.services.gold', ['ngResource', 'app.config'])

	.factory('GoldFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				serviceGoldCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkGoldRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceGoldCheck(serviceList);
		}
	})
    .service('checkGoldManager', function (GoldFactory) {
    	var checkGoldManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkGoldManager, {
        	/**
        	 * fetch service result
        	 */
        	GoldServiceRequest: function (serviceList) {
        		return new GoldFactory(serviceList);
        	}
        });
    });