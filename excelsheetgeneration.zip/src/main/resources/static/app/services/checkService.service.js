angular.module('app.services.checkService', ['ngResource', 'app.config'])

	.factory('CheckServiceFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
			serviceCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkServiceRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceCheck(serviceList);
		}
	})
	.factory('CheckMultipleServiceFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				serviceMultipleCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkMultipleServiceRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceMultipleCheck(serviceList);
		}
	})
    .service('checkServiceManager', function (CheckServiceFactory) {
    	var checkServiceManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkServiceManager, {
        	/**
        	 * fetch service result
        	 */
        	checkServiceRequest: function (serviceList) {
        		return new CheckServiceFactory(serviceList);
        	}
        });
    })
    .service('checkMultipleServiceManager', function (CheckMultipleServiceFactory) {
    	var checkMultipleServiceManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkMultipleServiceManager, {
        	/**
        	 * fetch service result
        	 */
        	checkMultipleServiceRequest: function (serviceList) {
        		return new CheckMultipleServiceFactory(serviceList);
        	}
        });
    });