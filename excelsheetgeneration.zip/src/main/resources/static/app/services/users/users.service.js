angular.module('app.services.users', ['ngResource', 'app.config'])

	.factory('UsersFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				serviceUsersCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkUsersRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceUsersCheck(serviceList);
		}
	})
    .service('checkUsersManager', function (UsersFactory) {
    	var checkUsersManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkUsersManager, {
        	/**
        	 * fetch service result
        	 */
        	UsersServiceRequest: function (serviceList) {
        		return new UsersFactory(serviceList);
        	}
        });
    });