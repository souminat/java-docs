angular.module('app.services.hrapi', ['ngResource', 'app.config'])

	.factory('HrApiFactory', function ($resource, config) {
		//setup custom action
		var _actions = {
				serviceHrApiCheck: {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				data: {} //you have data present for content-type header to be applied
			}
		};

		var _resource = $resource(config.apiBasePath + 'api/myServiceCheck/v1/checkHrApiRequest', {}, _actions);

		return function (serviceList) {
			return _resource.serviceHrApiCheck(serviceList);
		}
	})
    .service('checkHrApiManager', function (HrApiFactory) {
    	var checkHrApiManager = this;
    	var cached = {};
    	
    	// Private method used to clear empty parameters 
    	var clearFilters = function(filters) {
    		for(var filter in filters) {
    			var value = filters[filter];
    			if(_.isUndefined(value) || _.isEqual(value, '')) {
    				delete filters[filter];
    			}
    		}
    		return filters;
    	};
        
    	// Public properties/methods
        angular.extend(checkHrApiManager, {
        	/**
        	 * fetch service result
        	 */
        	HrApiServiceRequest: function (serviceList) {
        		return new HrApiFactory(serviceList);
        	}
        });
    });