angular.module('ux.form.fileChange.directive', [])

.directive('fileChange', function($parse) {

	return {
		restrict: 'A',
		link: function ($scope, element, attrs) {
		
			var attrHandler = $parse(attrs['fileChange']);
		
			// This is a wrapper handler which will be attached to the
			// HTML change event.
			var handler = function (e) {
				$scope.$apply(function () {
					attrHandler($scope, { $event: e, files: e.target.files });
				});
			};
		
			// Attach the handler to the HTML change event 
			element[0].addEventListener('change', handler, false);
		}
	};
});