angular.module('ux.form.inputModal',['ui.bootstrap', 'app.config', 'ux.form.inputModal.controller'])

.service('inputModal', function ($rootScope, $modal, config) {
	var inputModel = this;
	
	var defaultOptions = {
		title:'Message', 
		body: '',
		bodyHTML: '',
		allowClose: true,
		closeText: 'Ok',
		allowDismiss: false,
		dismissText: 'Cancel',
		loading: false
	};
	
	inputModel.open = function(options) {
		
		_.defaults(options, defaultOptions);
		
		return $modal.open({
			templateUrl: config.templateBasePath + 'lib_components/ux-form/inputModel/inputModal.controller.html',
			controller: 'inputModalController as modal',
			keyboard: options.allowDismiss,
			resolve: {
				options: function () {
					return options;
				}
			}
		});
	}
	inputModel.loading = function(text) {
		return inputModel.open({
			title: text, 
			loading: true,
			allowClose: false
		});
	}
})