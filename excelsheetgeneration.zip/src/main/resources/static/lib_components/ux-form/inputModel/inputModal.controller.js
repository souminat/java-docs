angular.module('ux.form.inputModal.controller', [])

    .controller('inputModalController', function ($uibModalInstance, $sce, options, $scope) {
        var modal = this;

        modal.options = options;

        //have to do this to allow html content
        modal.htmlTrustedContent = $sce.trustAsHtml(options.bodyHTML);

        modal.close = function () {
            var rejectReason = $scope.rejectReason;
            $uibModalInstance.close(rejectReason);
        };
        modal.dismiss = function () {
            $uibModalInstance.dismiss();
        };
    });