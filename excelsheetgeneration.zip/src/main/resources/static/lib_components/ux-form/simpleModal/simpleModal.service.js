angular.module('ux.form.simpleModal',['ui.bootstrap', 'app.config', 'ux.form.simpleModal.controller'])

.service('simpleModal', function ($rootScope, $uibModal, config) {
	var simpleModal = this;
	
	var defaultOptions = {
		title:'Message', 
		body: '',
		bodyHTML: '',
		allowClose: true,
		closeText: 'Ok',
		allowDismiss: false,
		dismissText: 'Cancel',
		loading: false
	};
	
	simpleModal.open = function(options) {
		
		_.defaults(options, defaultOptions);
		
		return $uibModal.open({
			templateUrl: config.templateBasePath + 'lib_components/ux-form/simpleModal/simpleModal.controller.html',
			controller: 'simpleModalController as modal',
			keyboard: options.allowDismiss,
			resolve: {
				options: function () {
					return options;
				}
			}
		});
	};
	simpleModal.loading = function(text) {
		return simpleModal.open({
			title: text, 
			loading: true,
			allowClose: false
		});
	};
});