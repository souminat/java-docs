angular.module('ux.form.simpleModal.controller', [])

    .controller('simpleModalController', function ($uibModalInstance, $sce, options) {
        var modal = this;

        modal.options = options;

        //have to do this to allow html content
        modal.htmlTrustedContent = $sce.trustAsHtml(options.bodyHTML);

        modal.close = function () {
            $uibModalInstance.close();
        };
        modal.dismiss = function () {
            $uibModalInstance.dismiss();
        };

    });