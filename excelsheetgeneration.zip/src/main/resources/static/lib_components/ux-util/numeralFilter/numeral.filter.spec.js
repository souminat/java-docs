describe("ux.util.numeralFilter.spec", function() {

	var $filter;

	beforeEach(module('ux.util.numeralFilter'));

	beforeEach(inject(function($injector){

		$filter = $injector.get('$filter');
		//numeral.defaultFormat('0,0.00[00]');

	}));

	it('formats large decimals', function() {
		var numeralFilter = $filter('numeralFilter');
		expect(numeralFilter(12345.54321)).toEqual('12,345.5432');
	});

	it('formats large numbers', function() {
		var numeralFilter = $filter('numeralFilter');
		expect(numeralFilter(1234567890.12)).toEqual('1,234,567,890.12');
	});

	it('formats missing decimals', function() {
		var numeralFilter = $filter('numeralFilter');
		expect(numeralFilter(1)).toEqual('1.00');
	});

	it('handles null', function() {
		var numeralFilter = $filter('numeralFilter');
		expect(numeralFilter(null)).toEqual(null);
	});

});
