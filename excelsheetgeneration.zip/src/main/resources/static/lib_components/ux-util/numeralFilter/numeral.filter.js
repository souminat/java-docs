angular.module('ux.util.numeralFilter', [])

.run(function() {
	numeral.defaultFormat('0,0.00[00]');
})

.filter('numeralFilter', function () {
	return function (input, format) {
		if (input == null) {
			return input;
		}
		return numeral(input).format(format);
	};
})
.directive('applicationCurrency', [function () {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
      if (!ctrl) return;
      
      //If we do not have jQuery then replace JQLite
      if(elem.context === undefined){
        elem = $(elem[0]);
      }
      //right align text
      elem.context.style.textAlign = "right";
      
      var formatStr = attrs.mytrsCurrency || '0,0[.]0[000]';
      
	    //this is what the user sees (only formats on first render, otherwise updated in $parser below)
      ctrl.$formatters.unshift(function (rawNumber) {
        if(rawNumber > 0) {
          return numeral(rawNumber).format(formatStr);
        }
        else return '';
      });
	  
	    //this is what we store
      ctrl.$parsers.unshift(function (val) {
        var rawNumber = numeral().unformat(val);
        //only format the text box if last typed key was not '.' or '.0' or '.00' or '.000'
        if(val.indexOf('.', val.length - 1) === -1 && val.indexOf('.0', val.length - 2) === -1 && val.indexOf('.00', val.length - 3) === -1 && val.indexOf('.000', val.length - 4) === -1) {
          elem.val(numeral(rawNumber).format(formatStr));
        }
        return rawNumber;
      });
    }
  };
}])
 .directive('onlyIntegers', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9]/g, '');

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseFloat(digits);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
 })