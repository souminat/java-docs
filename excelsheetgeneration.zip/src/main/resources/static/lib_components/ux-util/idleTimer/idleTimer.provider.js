angular.module('ux.util.idleTimer', ['app.config'])

.config(function ($provide, $httpProvider, idleTimerProvider) {
	
	idleTimerProvider.start();

	//handle global ajax
	$provide.factory('idleHttpInterceptor', function() {
		return {
			'request': function(config) {
				idleTimerProvider.reset();
				return config;
			}
		};
	});
	$httpProvider.interceptors.push('idleHttpInterceptor');
	
})


.provider('idleTimer', function (configProvider) {

	var idleTimer = this;
	
	idleTimer.timeoutInMinutes = configProvider.timeoutInMinutes;
	idleTimer.redirectUrl = configProvider.redirectUrl;
	idleTimer.started = false;
	idleTimer.idleMinutes = 0;
	
	idleTimer.start = function() {
		console.log('idle timeout start');
		if(!idleTimer.started) {
			idleTimer.started = true;
			idleTimer.reset();
			idleTimer.intervalId = setInterval(idleTimer._timerTick, 60000); //tick once a minute
		}
	};
		
	idleTimer.stop = function() {
		if(idleTimer.intervalId && idleTimer.started) {
			clearInterval(idleTimer.intervalId);
			idleTimer.started = false;
			idleTimer.intervalId = false;
		}
	};
		
	idleTimer.reset = function() {
		idleTimer.idleMinutes = 0;
	};
		
	idleTimer._timerTick = function() {
		idleTimer.idleMinutes++;
		console.log('idle for ' + idleTimer.idleMinutes + ' minutes. timout at ' + idleTimer.timeoutInMinutes + ' minutes.');
		if(idleTimer.idleMinutes >= idleTimer.timeoutInMinutes) {
			console.log('idle timeout reached, redirecting');
			idleTimer.redirect();
		}
	};
		
	idleTimer.redirect = function() {
		window.location = idleTimer.redirectUrl;
	};
	
	this.$get = function() {
		return idleTimer;
	};

});