describe("ux.util.whenScrolled.spec", function() {

	var $compile, $rootScope;

	beforeEach(module('ux.util.whenScrolled'));

	beforeEach(inject(function($injector){
		$compile = $injector.get('$compile');
		$rootScope = $injector.get('$rootScope');
	}));

	it('works', function() {
		//this currently is just a feel good test to verify the directive works
		var element = $compile("<div when-scrolled='callMe'></div>")($rootScope);
		$rootScope.$digest();

		expect(element.html()).toBe("");

	});

});
