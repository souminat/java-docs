var app = angular.module('app', ['ngRoute','ngResource','app.controller','app.createUsercontroller']);

app.config(function($routeProvider,$locationProvider){
	$locationProvider.hashPrefix('');
    $routeProvider
        .when('/CheckServices',{
            templateUrl: '/app/pages/servicelist/viewServicesList.html',
            controller: 'listController as serviceList'
        })
        .when('/CreateUserRequest',{
        	templateUrl: '/app/pages/createuser/createUser.html',
        	controller: 'createUserController as createUser'
        })
        .otherwise(
            { redirectTo: '/'}
        );
});
