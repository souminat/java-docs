package com.ge.treasury.mypayments.controllers.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PaginatedResultList<T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4414455806731455477L;

	int totalRecords;
	String offset;
	String next;
	private String orderByColumn;
	private String orderBy;
	private String requestQueryString;
	//Sonar Fixes: Field names should comply with a naming convention
	private String sso;
	private boolean sortingOrder;
	private Map<String, String> searchMap = new HashMap<String, String>();
	private String requestId;
	private String requestDate;
	private String requestType;
	private String payerDescription;
	private String payeeDescripton;
	private String payeeBankCountry;
	private String payeeCurrency;
	private String payeeAmount;
	private String valueDate;
	private String requester;
	private String assignedTo;
	private String status;
	private String enterpriseDesc;
	private String paymentType;
	private boolean isApprovalRangePresent;

	public boolean isApprovalRangePresent() {
		return isApprovalRangePresent;
	}

	public void setApprovalRangePresent(boolean isApprovalRangePresent) {
		this.isApprovalRangePresent = isApprovalRangePresent;
	}

	public String getEnterpriseDesc() {
		return enterpriseDesc;
	}

	public void setEnterpriseDesc(String enterpriseDesc) {
		this.enterpriseDesc = enterpriseDesc;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	private List<String> preparerList;
	private List<String> releaserList;
	private List<String> approverList;
	private String pageType;

	public boolean getSortingOrder() {
		return sortingOrder;
	}

	public void setSortingOrder(boolean sortingOrder) {
		this.sortingOrder = sortingOrder;
	}

	public String getPageType() {
		return pageType;
	}

	public void setPageType(String pageType) {
		this.pageType = pageType;
	}

	public List<String> getApproverList() {
		return approverList;
	}

	public void setApproverList(List<String> approverList) {
		this.approverList = approverList;
	}

	public List<String> getPreparerList() {
		return preparerList;
	}

	public void setPreparerList(List<String> preparerList) {
		this.preparerList = preparerList;
	}

	public List<String> getReleaserList() {
		return releaserList;
	}

	public void setReleaserList(List<String> releaserList) {
		this.releaserList = releaserList;
	}

	public Map<String, String> getSearchMap() {
		return searchMap;
	}

	public void setSearchMap(Map<String, String> searchMap) {
		this.searchMap = searchMap;
	}

	public String getSSO() {
		return sso;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getPayerDescription() {
		return payerDescription;
	}

	public void setPayerDescription(String payerDescription) {
		this.payerDescription = payerDescription;
	}

	public String getPayeeDescripton() {
		return payeeDescripton;
	}

	public void setPayeeDescripton(String payeeDescripton) {
		this.payeeDescripton = payeeDescripton;
	}

	public String getPayeeBankCountry() {
		return payeeBankCountry;
	}

	public void setPayeeBankCountry(String payeeBankCountry) {
		this.payeeBankCountry = payeeBankCountry;
	}

	public String getPayeeCurrency() {
		return payeeCurrency;
	}

	public void setPayeeCurrency(String payeeCurrency) {
		this.payeeCurrency = payeeCurrency;
	}

	public String getPayeeAmount() {
		return payeeAmount;
	}

	public void setPayeeAmount(String payeeAmount) {
		this.payeeAmount = payeeAmount;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getRequester() {
		return requester;
	}

	public void setRequester(String requester) {
		this.requester = requester;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setSSO(String sSO) {
		sso = sSO;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

	public String getNext() {
		return next;
	}

	public void setNext(String next) {
		this.next = next;
	}

	public String getOrderByColumn() {
		return orderByColumn;
	}

	public void setOrderByColumn(String orderByColumn) {
		this.orderByColumn = orderByColumn;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	transient List<T> resultList;

	/**
	 * @return the totalRecords
	 */
	public int getTotalRecords() {
		return totalRecords;
	}

	/**
	 * @param totalRecords
	 *            the totalRecords to set
	 */
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	/**
	 * @return the requestQueryString
	 */
	public String getRequestQueryString() {
		return requestQueryString;
	}

	/**
	 * @param requestQueryString
	 *            the requestQueryString to set
	 */
	public void setRequestQueryString(String requestQueryString) {
		this.requestQueryString = requestQueryString;
	}

	/**
	 * @return the resultList
	 */
	public List<T> getResultList() {
		return resultList;
	}

	/**
	 * @param resultList
	 *            the resultList to set
	 */
	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}
}