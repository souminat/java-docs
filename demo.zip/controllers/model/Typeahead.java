package com.ge.treasury.mypayments.controllers.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Typeahead implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1093206886132674640L;

	//Sonar Fixes: Field names should comply with a naming convention
	private List<String> payerName = new ArrayList<String>();
	private List<String> payeeName = new ArrayList<String>();
	private List<String> RequestType = new ArrayList<String>();
	private List<String> enterpriseDesc = new ArrayList<String>();
	public List<String> getEnterpriseDesc() {
		return enterpriseDesc;
	}

	public void setEnterpriseDesc(List<String> enterpriseDesc) {
		this.enterpriseDesc = enterpriseDesc;
	}

	private List<String> status = new ArrayList<String>();

	public List<String> getPayerName() {
		return payerName;
	}

	public void setPayerName(List<String> payerName) {
		payerName = payerName;
	}

	public List<String> getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(List<String> payeeName) {
		payeeName = payeeName;
	}

	public List<String> getRequestType() {
		return RequestType;
	}

	public void setRequestType(List<String> requestType) {
		RequestType = requestType;
	}

	public List<String> getStatus() {
		return status;
	}

	public void setStatus(List<String> status) {
		this.status = status;
	}

}