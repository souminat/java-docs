package com.ge.treasury.mypayments.controllers.model;

import java.io.Serializable;
import java.util.Map;


public class PaymentInstructionsResult implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2823444775896712634L;

	private Map<String,String> errorMessage;
	private Boolean sftpUpload;
	private String fileName;
	private String fileContent;
	private String fileHash;
	private Long requestId;
	

	public Map<String,String> getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(Map<String,String> errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Boolean getSftpUpload() {
		return sftpUpload;
	}

	public void setSftpUpload(Boolean sftpUpload) {
		this.sftpUpload = sftpUpload;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileContent() {
		return fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}

	public String getFileHash() {
		return fileHash;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	@Override
	public String toString() {
		return "PaymentInstructionsResult [errorMessage=" + errorMessage + ", requestId=" + requestId
				+ ", sftpUpload=" + sftpUpload + ", fileName=" + fileName + ", fileContent=" + fileContent
				+ ", fileHash=" + fileHash + "]";
	}


}
