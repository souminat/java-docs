/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestOperations;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.treasury.mypayments.constants.ControllersConstants;
import com.ge.treasury.mypayments.constants.ExceptionConstants;
import com.ge.treasury.mypayments.constants.ValidationConstants;
import com.ge.treasury.mypayments.constants.WorkflowConstants;
import com.ge.treasury.mypayments.corems.domain.FineGrainESResponse;
import com.ge.treasury.mypayments.dao.LovDao;
import com.ge.treasury.mypayments.domain.EnterpriseStandards;
import com.ge.treasury.mypayments.domain.PaymentDocument;
import com.ge.treasury.mypayments.domain.PaymentRequest;
import com.ge.treasury.mypayments.domain.RequestActivity;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.mapper.payment.PaymentRequestMapper;
import com.ge.treasury.mypayments.service.AuditService;
import com.ge.treasury.mypayments.service.PaymentRequestManagerService;
import com.ge.treasury.mypayments.utils.MessageValidator;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.ge.treasury.mypayments.validation.ERPPaymentRequestValidator;
import com.ge.treasury.mypayments.validation.PaymentRequestValidator;

/**
 * REST services for create/edit/obtain request groups
 * 
 * @author MyPayments Dev Team
 *
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class ERPPaymentRequestController extends BaseController {

	@Autowired
	PaymentRequestManagerService paymentService;
	
	@Autowired
	PaymentRequestMapper mapper;

	@Autowired
	MessageValidator messageValidator;

	@Autowired
	private AuditService auditService;
	
	@Autowired
	private OAuth2RestOperations mdmServiceRestTemplate;
	
	@Autowired
	LovDao lovDao;
	
	@Value("${finegrain-auth-url-get-espayments}")
	private String esDataUrl;
	
	@Value("#{'${akana.folderId}'}")
	private String folderId;
	
	

	
	private String callMDMDenodo(Map<String, String> params, final String url, final HttpMethod method,
			final boolean validateResponse) {

		final HttpEntity<String> entity;
		final HttpHeaders headers = new HttpHeaders();
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		if(null!=params){
			for (String paramName : params.keySet()) {
				builder.queryParam(paramName, params.get(paramName));
			}
		}
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		entity = new HttpEntity<String>(headers);
		return executeCall(this.mdmServiceRestTemplate, builder, method, entity, validateResponse);

	}
	
	private String executeCall(final RestOperations ro, final UriComponentsBuilder builder, final HttpMethod method,
			final HttpEntity<String> entity, final boolean validateResponse) {
		try {
			final ResponseEntity<String> response = ro.exchange(builder.build().encode().toUri(), method, entity,
					String.class);

			final String responseBody;
			if (response.getStatusCode() == HttpStatus.OK) {
				responseBody = response.getBody();
				if (validateResponse) {
					validateJSONResponse(responseBody);
				}
			} else {
				throw new SystemException(
						ControllersConstants.MDM_ERROR + "ResponseStatusCode: " + response.getStatusCode());
			}

			return responseBody;
		} catch (final RestClientException e) {
			throw new SystemException(ControllersConstants.MDM_ERROR + "Error when connecting to the MDM Microservice",
					e);
		}
	}
	
	private void validateJSONResponse(final String responseBody) {

		try {
			final JSONObject jsonObject = new JSONObject(responseBody);

			final JSONObject responseData = (JSONObject) jsonObject.get(ValidationConstants.JSON_GET_RESPONSEDATA);

			final Object message = responseData.get(ValidationConstants.JSON_GET_MESSAGE);
			final Object mdmStatus = responseData.get(ValidationConstants.JSON_GET_STATUS);

			if ("Bad request 400".equals(mdmStatus)) {
				throw new SystemException(ControllersConstants.MDM_ERROR + message.toString());
			}
		} catch (final JSONException e) {
			throw new SystemException(ControllersConstants.MDM_ERROR + "Error when reading the JSON message.", e);
		}
	}
	
	/**
	 * @param request
	 * @param paymentRequest
	 * @return
	 * @throws ValidationFailedException
	 */
	@RequestMapping(value = "/createPaymentRequest_v2", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest createPaymentRequest_v2(HttpServletRequest request,
			@RequestBody PaymentRequest paymentRequest) throws ValidationFailedException {

		Date today = new Date();
		PaymentRequest paymentRequestResult = null;

		try {
			User user = (User) request.getSession().getAttribute("User");
			
			
		        

			if (null != paymentRequest) {
				BindingResult errors = new BeanPropertyBindingResult(paymentRequest, "paymentRequest");
				updateCommonAttributesForPayment(user, today, paymentRequest, paymentRequest.getIsManual());
				
				/*Code for inserting a new es record if not present in the Enterprise Standard Table
				 * 
				 * 
				 * 
				 * */
				List<EnterpriseStandards> exstenterpriseStandards = lovDao.getDistinctEnterpriseStandards();
				int flag = 0;
				 List<EnterpriseStandards> enterpriseStandards = null;
			        ObjectMapper objectMapper = new ObjectMapper();
			        String jsonOutput = callMDMDenodo(null, esDataUrl, HttpMethod.GET, false);
			        
			        System.out.println(jsonOutput);
			        
			        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
			        FineGrainESResponse response = objectMapper.readValue(jsonOutput, FineGrainESResponse.class);
			        enterpriseStandards = response.getResponseData();
			        	System.out.println("Checking ES value");
			        	for(EnterpriseStandards esstd : enterpriseStandards){
			        		if((esstd.getEsCode()).equals(paymentRequest.getEsCd())){
			        		flag = 1;
			        		     for(EnterpriseStandards exstsstd : exstenterpriseStandards){
			        		    	 if((esstd.getEsCode()).equals(exstsstd.getEsCode())){
			        		    		//data is present in es table
			        		    		 flag = 0;
			        		    		 break;
			        		    	 }
			        		     }
			        		     if(flag == 1){
			        		    	//insert es value into enterprise standard table 
			        		    	 paymentService.insertnewEsValue(esstd);
			        		    	 break;
			        		     }
			        		
			        		}
			        	}
				
				
				if(paymentRequest.getPayer()!=null && paymentRequest.getPayee()!=null && !(paymentRequest.getMdmPayerCurrency()).equals(null)){
				     if(paymentRequest.getMdmPayerCurrency().equals(paymentRequest.getPayeeCurrency())){
					       paymentRequest.setInstrumentType("Domestic");
				     }else{
					       paymentRequest.setInstrumentType("International");
				     }
				
              }
				
				
				if ("true".equalsIgnoreCase(paymentRequest.getIsManual())) {
					List<PaymentRequest> duplicatePaymentRequest = null;
					duplicatePaymentRequest = paymentService.checkDuplicateRequest(paymentRequest);

					if (!CollectionUtils.isEmpty(duplicatePaymentRequest)) {
						errors.reject("Duplicate Request", ExceptionConstants.DUPLICATE_PAYMENT_EXCEPTION
								+ duplicatePaymentRequest.get(0).getRequestId());
					}
					// Manual Create Payment
					PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);
					validator.validate(paymentRequest, errors);
					
				} else {
					// ERP Create Payment
					ERPPaymentRequestValidator validator = new ERPPaymentRequestValidator(messageValidator);
					validator.validate(paymentRequest, errors);
					
				}
				
				if (errors.hasErrors()) {
					throw new ValidationFailedException(errors);
				} else {

					// check if it is an update or an insert
					if (paymentRequest.getRequestId() <= 0) {
						paymentRequestResult = paymentService.createPaymentRequest(paymentRequest, user);
					} else {
						// Document Check
						List<String> fileIds = null;
						List<PaymentDocument> documentList = this.paymentService
								.getDocsIdList(paymentRequest.getRequestId());
						if (!CollectionUtils.isEmpty(documentList)) {
							fileIds = new ArrayList<String>();
							for (PaymentDocument pd : documentList) {
								fileIds.add(pd.getFileId());
							}
						}

						Iterator<PaymentDocument> iter = paymentRequest.getDocuments().iterator();

						while (iter.hasNext()) {
							PaymentDocument rd = iter.next();

							if (fileIds.contains(rd.getFileId()))
								iter.remove();
						}

						paymentRequestResult = paymentService.updateEntirePaymentRequest(paymentRequest, user);

						paymentRequest.setRequestStatusId(new RequestActivity());
						paymentRequest.getRequestStatusId()
								.setComments(paymentRequest.getRequestActivities().get(0).getComments());

						RequestActivity requestActivity = createRequestActivity(user, today, paymentRequest,
								WorkflowConstants.WRKFLW_STS_RE_SUBMITTED, "WRKFLW_STS_SUBMITTED", "Request Re-submitted");

						int count = this.paymentService.getRequestActivities(paymentRequest.getRequestId());
						// Sonar Violation Fix : Math operands should be cast
						// before assignment
						requestActivity.setSequenceNumber(count + 1L); // gets real time count of records
						this.paymentService.processRequestActivity(requestActivity, user);
					}
				}

				// insert Audit service
				creditAudit(user, paymentRequest);
				setLogPerfMessage(request, "Request id " + paymentRequestResult.getRequestId() + " created");
			}
		} catch (ValidationFailedException exception) {
			PaymentLogger.logError(this, "PaymentRequestServiceImpl.createPaymentRequest: " + exception.getMessage(),
					exception);
			throw exception;
		} catch (Exception e) {
			PaymentLogger.logError(this, "PaymentRequestServiceImpl.createPaymentRequest: " + e.getMessage(), e);
			throw new SystemException(e);
		}

		return paymentRequestResult;
	}
	
	private void updateCommonAttributesForPayment(User user, Date today, PaymentRequest paymentRequest,
			String isManual) {

		paymentRequest.setRequestTypeCode(WorkflowConstants.MANUAL_ERP_PAYMENT);
		paymentRequest.setPaymentSystem("");

		paymentRequest.setCreateDate(today);
		paymentRequest.setCreateUser(user.getSso());
		paymentRequest.setLastUpdateDate(today);
		paymentRequest.setLastUpdateUser(user.getSso());
		paymentRequest.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_SUBMITTED);

		// Manual logic
		if ("true".equalsIgnoreCase(isManual)) {
			if (!WorkflowConstants.PAYEE_SRC_MANUAL.equalsIgnoreCase(paymentRequest.getPayeeIdType()))
				paymentRequest.setPayeeSource(WorkflowConstants.PAYEE_SRC_ERP_MANUAL);
			paymentRequest.setRequestTypeCode(WorkflowConstants.MANUAL_PAYMENT);
		} else {
			paymentRequest.setRequestTypeCode(WorkflowConstants.MANUAL_ERP_PAYMENT);
			paymentRequest.setPayeeSource(WorkflowConstants.PAYEE_SRC_ERP_MANUAL);
		}

		if (null != paymentRequest.getPayer() && null != paymentRequest.getPayer().getPayerOrPayee()) {
			paymentRequest.getPayer().setCreateDate(today);
			paymentRequest.getPayer().setCreateUser(user.getSso());
			paymentRequest.getPayer().setLastUpdateDate(today);
			paymentRequest.getPayer().setLastUpdateUser(user.getSso());
			paymentRequest.setPaymentMethod(paymentRequest.getIsCheckPayment());
		}

		if (null != paymentRequest.getPayee() && "true".equalsIgnoreCase(isManual)) {
			paymentRequest.getPayee().setCreateDate(today);
			paymentRequest.getPayee().setCreateUser(user.getSso());
			paymentRequest.getPayee().setLastUpdateDate(today);
			paymentRequest.getPayee().setLastUpdateUser(user.getSso());
		}

		if (!CollectionUtils.isEmpty(paymentRequest.getReferences())) {
			for (int index = 0; index < paymentRequest.getReferences().size(); index++) {
				paymentRequest.getReferences().get(index).setCreateDate(today);
				paymentRequest.getReferences().get(index).setCreateUser(user.getSso());
				paymentRequest.getReferences().get(index).setLastUpdateDate(today);
				paymentRequest.getReferences().get(index).setLastUpdateUser(user.getSso());
			}

		}

		if (paymentRequest.getPaymentAccounting() != null) {
			paymentRequest.getPaymentAccounting().setCreateDate(today);
			paymentRequest.getPaymentAccounting().setCreateUser(user.getSso());
			paymentRequest.getPaymentAccounting().setLastUpdateDate(today);
			paymentRequest.getPaymentAccounting().setLastUpdateUser(user.getSso());
		}

		if (!CollectionUtils.isEmpty(paymentRequest.getDocuments())) {
			for (int index = 0; index < paymentRequest.getDocuments().size(); index++) {
				paymentRequest.getDocuments().get(index).setCreateDate(today);
				paymentRequest.getDocuments().get(index).setCreateUser(user.getSso());
				paymentRequest.getDocuments().get(index).setLastUpdateDate(today);
				paymentRequest.getDocuments().get(index).setLastUpdateUser(user.getSso());
				paymentRequest.getDocuments().get(index).setFolderId(folderId);
			}

		}

		if (!CollectionUtils.isEmpty(paymentRequest.getRequestActivities())) {
			for (int index = 0; index < paymentRequest.getRequestActivities().size(); index++) {

				paymentRequest.getRequestActivities().get(index).setUserName(user.getName());
				paymentRequest.getRequestActivities().get(index).setUserEmail(user.geteMail());
				paymentRequest.getRequestActivities().get(index).setUserRole(user.getAppRole());
				paymentRequest.getRequestActivities().get(index).setSsoId(user.getSso());
				paymentRequest.getRequestActivities().get(index).setCreateDate(today);
				paymentRequest.getRequestActivities().get(index).setCreateUser(user.getSso());
				paymentRequest.getRequestActivities().get(index).setLastUpdateUser(user.getSso());
				paymentRequest.getRequestActivities().get(index).setLastUpdateDate(today);
				paymentRequest.getRequestActivities().get(index).setUserAction(WorkflowConstants.WRKFLW_STS_SUBMITTED);
				paymentRequest.getRequestActivities().get(index).setPaymentStatusCode("WRKFLW_STS_SUBMITTED");

			}
		}

	}

	private void creditAudit(User user, PaymentRequest paymentRequest) {
		PaymentRequest oldObject = new PaymentRequest();
		try {
			auditService.createAudit(user, oldObject, paymentRequest);
		} catch (InterruptedException e) {
			PaymentLogger.logError(this, "WorkFlowActionController:: creditAudit " + e.getMessage(), e);
			throw new SystemException(e);
		}
	}

}
