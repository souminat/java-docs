/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import com.ge.treasury.mypayments.constants.GELibrariesAPIConstants;
import com.ge.treasury.mypayments.domain.PaymentDocument;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.BusinessException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.libraries.domain.GELibrariesAPIParameters;
import com.ge.treasury.mypayments.libraries.service.GELibrariesAPIService;
import com.ge.treasury.mypayments.utils.DateFunctionsUtil;
import com.ge.treasury.mypayments.utils.PaymentLogger;

/**
 * REST services for upload/download/delete document
 * 
 * @author MyPayments Dev Team
 *
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class DocumentUploadController extends BaseController implements
        GELibrariesAPIConstants {

    @Autowired
    GELibrariesAPIService apiService;
    
    @Value(APPLICATIONID)
    private String applicationId;
    @Value(USERID)
    private String defaultUserId;
    @Value(PSSWD)
    private String applicationPassword;
    @Value(LOCALDIRECTORY)
    private String localDirectory;
    @Value(DEFAULTFOLDERID)
    private String defaultFolderId;
    @Value("#{'${geapi.gelib.mimetype.whitelist}'.split(';')}")
    private List<String> mimeWhiteList;
    @Value("#{'${geapi.gelib.extension.whitelist}'.split(';')}")
    private List<String> extensionWhiteList;
    
    /**
     * Method to upload a specific file into GE library
     * 
     * @param request
     * @param file
     * @param acctReqID
     * @param docType
     * @return
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws BusinessException
     * @throws ValidationFailedException
     */
    @RequestMapping(value = "/fileUpload", method = RequestMethod.POST)
    @ResponseBody
    public PaymentDocument postFileUpload(HttpServletRequest request,
            @RequestParam(FILE) final MultipartFile file,
            @RequestParam(PAYREQID) final String paymentReqId,
            @RequestParam(DOCTYPE) final String docType) throws ValidationFailedException{
        
        if (!mimeWhiteList.contains(file.getContentType()) 
                || !extensionWhiteList.contains(FilenameUtils
                        .getExtension(file.getOriginalFilename()
                                .toLowerCase()))) {
            
            BindingResult errors = new BeanPropertyBindingResult(file,
                    "file");
            errors.reject("file.mimetype.rejected", "File is not in an acceptable format");
            throw new ValidationFailedException("File is not in an acceptable format", errors);
        }

        User user = (User) request.getSession().getAttribute(USER);
        
        PaymentDocument paymentDocument = new PaymentDocument();
        GELibrariesAPIParameters response = null;
        String name = StringEscapeUtils.escapeHtml(FilenameUtils.getName(file.getOriginalFilename()));
        
        if (name != null) {
            if (!file.isEmpty()) {
                try {
                    String updatedFileName = FilenameUtils.removeExtension(name)
                            + UNDERSCORE
                            + DateFunctionsUtil.dateFormatter(FILE_NAME_DATE_FORMAT) + DOT
                            + FilenameUtils.getExtension(name);

                    String orginalName = file.getOriginalFilename();
                    String filePath = localDirectory+orginalName;
                    File destination = new File(filePath);
                    file.transferTo(destination);
                    
                    String subFolderID = null;
                    File source = new File(destination.getAbsolutePath());
                    File dest = new File(localDirectory + updatedFileName);
					tempDeleteFile(source, dest, destination);
                    if (paymentReqId == null || paymentReqId.equals(NULL_VALUE)) {
                        paymentDocument.setDocumentName(updatedFileName);
                        paymentDocument.setDocUrl(dest.getAbsolutePath());
                        paymentDocument.setFileId(new String(NUM_ONE) );
                        paymentDocument.setFolderId(new String(NUM_ONE));
                    } else {
                        // Call libraries api instead of service
                        subFolderID = apiService.findSubFolder(
                                paymentReqId.toString(), defaultFolderId,
                                defaultUserId, applicationId,
                                applicationPassword);
                        if (subFolderID == null || subFolderID.isEmpty()) {
                            subFolderID = apiService.createSubFolder(
                                    paymentReqId.toString(), defaultFolderId,
                                    defaultUserId, applicationId,
                                    applicationPassword);
                        }
                        response = apiService.uploadFile(
                                paymentReqId.toString(), updatedFileName, docType,
                                user.getSso(), subFolderID,
                                dest.getAbsolutePath(), defaultUserId,
                                applicationId, applicationPassword);
                        if (response.getErrorMessage() != null
                                && response.getErrorMessage()
                                        .equals(FILE_EXIST)) {
                         
                            PaymentLogger.logError(this, UPLOAD_FAIL_MESSAGE + name);
                            throw new BusinessException(FILE_EXIST_MESSAGE);
                        }
                        if (response != null && response.getFileID() != null) {
                            paymentDocument.setDocumentName(updatedFileName);
                            paymentDocument.setDocUrl(response.getFileURL());
                          
                                    
                            paymentDocument.setFileId(new String(response
                                    .getFileID()));
                            paymentDocument.setFolderId(new String(
                                    subFolderID));
                        }                    
                       boolean isFileDeleted =  apiService.deleteLocalFile(dest);
                        if(isFileDeleted)
                            PaymentLogger.logInfo(this, FILE_DELETED_SUCCESS);
                        else
                            PaymentLogger.logInfo(this, UNABLE_DELETE);
                    }

                    PaymentLogger.logDebug(this, UPLOAD_SUCCESS_MESSAGE + name);
                } catch (IOException e) {
                    PaymentLogger.logError(this, UPLOAD_FAIL_MESSAGE + name
                            + " => " + e.getMessage());
                    throw new BusinessException(UPLOAD_FAIL_MESSAGE + name
                            + " => " + e.getMessage(), e);
                }
            } else {
                PaymentLogger.logError(this, UPLOAD_FAIL_MESSAGE + name
                        + EMPTY_FILE);
                throw new BusinessException(UPLOAD_FAIL_MESSAGE + name
                        + EMPTY_FILE);
            }
        } else {
            PaymentLogger.logError(this, EXTENSION + name + NOT_CORRECT);
            throw new BusinessException(EXTENSION + name + NOT_CORRECT);
        }

        return paymentDocument;

    }
    
    /**
     * Method to delete specific file from a given folder
     * 
     * @param folderId
     * @param fileId
     * @param fileName
     * @return - Returns true if delete is success otherwise returns false
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws BusinessException
     */
    @RequestMapping(value = "/fileUpload/delete", method = RequestMethod.GET)
    @ResponseBody
    public Boolean cancelFileUpload(HttpServletRequest request,
            @RequestParam(FILEID) final String fileId,
            @RequestParam(FOLDERID) final String folderId,
            @RequestParam(FILENAME) final String fileName){
        
        Boolean isAccountDocumentDeleted;
        if (fileId.equals(NUM_ONE)) {
            Path path = Paths.get(localDirectory + fileName);

            try {
                if (Files.deleteIfExists(path)) {
                    return true;
                } else {
                    throw new BusinessException(FILE_NOT_EXIST);
                }
            } catch (IOException e) {
                throw new BusinessException(FILE_NOT_EXIST, e);
            }
        } else {
            isAccountDocumentDeleted = apiService.deleteFile(
                    folderId, fileId, defaultUserId, applicationId,
                    applicationPassword);
            if (!isAccountDocumentDeleted) {
                throw new BusinessException(UNABLE_DELETE);
            }
        }

        return isAccountDocumentDeleted;

    }
    
    
    /**
     * Method downloads specific file from GE library onto given folder
     * location.
     * 
     * @param fileId
     * @param fileName
     * @return - Returns FileUploadParameters
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws BusinessException
     */
    @RequestMapping(value = "/fileDownload", method = RequestMethod.GET)
    @ResponseBody
    public GELibrariesAPIParameters downloadUploadedFile(HttpServletRequest request,
            HttpServletResponse response,
            @RequestParam(FILEID) final String fileId,
            @RequestParam(FILENAME) String fileName1) throws IOException{
        
        String fileName = StringEscapeUtils.escapeHtml(FilenameUtils.getName(fileName1));
        GELibrariesAPIParameters parameters = new GELibrariesAPIParameters();
        
        Boolean isAccountDocumentDownloaded;
        if (fileId.equals(NUM_ONE)) {
            apiService.downloadFileByOutputStream(response, fileName,
                    localDirectory);
        } else {
            try {
                isAccountDocumentDownloaded = apiService
                        .downloadFileById(fileId, fileName, localDirectory,
                                defaultUserId, applicationId,
                                applicationPassword);
                if (!isAccountDocumentDownloaded) {
                    throw new BusinessException(UNABLE_DOWNLOAD + fileName);
                } else {
                    apiService.downloadFileByOutputStream(response,
                            fileName, localDirectory);
                }
                parameters
                        .setFileDownloaded(isAccountDocumentDownloaded);
                parameters.setFileURL(localDirectory + fileName);
                File file = new File(localDirectory + fileName);
                boolean isFileDeleted = apiService.deleteLocalFile(file);
                if(isFileDeleted)
                 PaymentLogger.logInfo(this, FILE_DELETED_SUCCESS);
               else
                   PaymentLogger.logInfo(this, UNABLE_DELETE);
            } catch (IOException e) {
                throw new BusinessException(UNABLE_DOWNLOAD + fileName, e);
            }
        }
       
        return parameters;
    }
    
    private void tempDeleteFile(File source, File dest ,File destination){
    	try {
            FileUtils.copyFile(source, dest);
            boolean isTempFileDeleted = apiService.deleteLocalFile(new File(destination.getAbsolutePath()));
            if(isTempFileDeleted)
                PaymentLogger.logInfo(this, FILE_DELETED_SUCCESS);
            else
                PaymentLogger.logInfo(this, UNABLE_DELETE);
        } catch (IOException e) {
            PaymentLogger.logError(this, FILE_COPY);
            throw new BusinessException(FILE_COPY, e);
        }
    }
    
}
