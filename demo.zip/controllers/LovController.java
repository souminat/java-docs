/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.ge.treasury.mypayments.domain.EnterpriseStandards;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mypayments.constants.ControllersConstants;
import com.ge.treasury.mypayments.dao.LovDao;
import com.ge.treasury.mypayments.domain.Lov;
import com.ge.treasury.mypayments.utils.StringHelper;

/**
 * REST services for lookup functionality
 * 
 * @author MyPayments Dev Team
 *
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class LovController extends BaseController {

    @Autowired
    LovDao lovDao;

    /**
     * Get all lookup codes information
     * 
     * @param orderBy
     * @param direction
     * @return
     */
    @RequestMapping(value = "/lov", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    @ResponseBody
    public List<Lov> getLovs(HttpServletRequest request) {

        int recordsFound = 0;

        final List<Lov> lovResponse = lovDao.getAllLov(
                ControllersConstants.DEFAULT_LOV_LOOKUPTYPE_ORDER,
                ControllersConstants.DEFAULT_ASC_DIRECTION);

        if (lovResponse != null && !lovResponse.isEmpty()) {
            recordsFound = lovResponse.size();
        }

        setLogPerfMessage(request, "getLovs: " + recordsFound
                + " Loookup found");

        return lovResponse;
    }

    /**
     * Get information by list of codes separated by comma
     * 
     * @param request
     * @param lovCodes
     * @return
     */
    @RequestMapping(value = "/lov/lovCodes", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    @ResponseBody
    public List<Lov> getLovsLookupByCode(HttpServletRequest request,
            @RequestParam(value = "lovCodes") String lovCodes) {

        int recordsFound = 0;

        final String clean = StringHelper.getValidatedStringCommaSeparated(lovCodes);
        
        final List<Lov> lovResponse = lovDao.getLovsByCode(clean,
                ControllersConstants.DEFAULT_LOV_LOOKUPTYPE_ORDER,
                ControllersConstants.DEFAULT_ASC_DIRECTION);

        if (lovResponse != null && !lovResponse.isEmpty()) {
            recordsFound = lovResponse.size();
        }

        setLogPerfMessage(request, "getLovsLookupByCode: " + recordsFound
                + " Loookup by code found");

        return lovResponse;
    }

    /**
     * Get information by list of types separated by comma
     * 
     * @param request
     * @param lovTypes
     * @return
     */
    @RequestMapping(value = "/lov/lovTypes", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    @ResponseBody
    public List<Lov> getLovsLookupByType(HttpServletRequest request,
            @RequestParam(value = "lovTypes") String lovTypes) {

        int recordsFound = 0;

        final String clean = StringHelper.getValidatedStringCommaSeparated(lovTypes);

        final List<Lov> lovResponse = lovDao.getLovsByType(clean,
                ControllersConstants.DEFAULT_LOV_LOOKUPTYPE_ORDER,
                ControllersConstants.DEFAULT_ASC_DIRECTION);

        if (lovResponse != null && !lovResponse.isEmpty()) {
            recordsFound = lovResponse.size();
        }

        setLogPerfMessage(request, "getLovsLookupByType: " + recordsFound
                + " Loookup by type found");

        return lovResponse;
    }

    /**
     * Get distinct enterprise standards
     * @return
     */
    @RequestMapping(value = "/lov/enterpriseStandards", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    @ResponseBody
    public List<EnterpriseStandards> getDistinctEnterpriseStandards(HttpServletRequest request) {

        int recordsFound = 0;
        final List<EnterpriseStandards> enterpriseStandards = lovDao.getDistinctEnterpriseStandards();

        if (enterpriseStandards != null && !enterpriseStandards.isEmpty()) {
            recordsFound = enterpriseStandards.size();
        }

        setLogPerfMessage(request, "getDistinctEnterpriseStandards: " + recordsFound
                + " distinct enterprise standards found");

        return enterpriseStandards;
    }

    /**
     * Get distinct enterprise standards
     * @param esCode
     * @return
     */
    @RequestMapping(value = "/lov/paymentTypes", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    // 200
    @ResponseBody
    public List<EnterpriseStandards> getPaymentTypes(HttpServletRequest request, @RequestParam(value = "esCode") String esCode) {

        int recordsFound = 0;

        final List<EnterpriseStandards> enterpriseStandards = lovDao.getPaymentTypes(esCode);

        if (enterpriseStandards != null && !enterpriseStandards.isEmpty()) {
            recordsFound = enterpriseStandards.size();
        }

        setLogPerfMessage(request, "getPaymentTypes: " + recordsFound
                + " payment types found");

        return enterpriseStandards;
    }

}
