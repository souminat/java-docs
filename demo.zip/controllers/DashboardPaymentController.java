package com.ge.treasury.mypayments.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mypayments.constants.PaymentRequestConstants;
import com.ge.treasury.mypayments.controllers.model.PaginatedResultList;
import com.ge.treasury.mypayments.domain.DashboardResult;
import com.ge.treasury.mypayments.domain.PaymentRequest;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.DBException;
import com.ge.treasury.mypayments.utils.MyPaymentsUtil;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.ge.treasury.mypayments.utils.service.NotificationService;

@Controller
@RequestMapping("/api/dashboard/v1")
public class DashboardPaymentController extends BaseDashboardController {
	
	@Autowired
	NotificationService notificationService;

	@RequestMapping(value = "/getDashboardResults", method = RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaginatedResultList getDashboardResults(HttpServletRequest request,
			@RequestBody PaginatedResultList paginatedResultList) {

		User user = (User) request.getSession().getAttribute("User");
		if (null != user) {
			paginatedResultList.setSSO(user.getSso());

			paginatedResultList.setPreparerList(user.getPreparerList());
			paginatedResultList.setReleaserList(user.getReleaserList());
			paginatedResultList.setApproverList(user.getApproverList());

		}
		Map<String, String> searchMap = new HashMap<String, String>(paginatedResultList.getSearchMap());

		String orderByColumnValue = "";

		if (paginatedResultList.getNext() == null) {
			setDefaults(paginatedResultList);
		} else {
			if (null != paginatedResultList.getOrderByColumn()
					&& !("").equalsIgnoreCase(paginatedResultList.getOrderByColumn())) {
				paginatedResultList.setOrderByColumn(fetchSortingColumn(paginatedResultList.getOrderByColumn()));
			} else {
				paginatedResultList.setOrderByColumn(fetchSortingColumn(orderByColumnValue));
			}
			searchMap.put("orderByColumn", paginatedResultList.getOrderByColumn());
			if (paginatedResultList.getSortingOrder())
				paginatedResultList.setOrderBy("ASC");
			else
				paginatedResultList.setOrderBy("DESC");
			searchMap.put("OrderBy", paginatedResultList.getOrderBy());
		}
		paymentListFilter(paginatedResultList, searchMap);
		searchMap.put("next", paginatedResultList.getNext());
		if (paginatedResultList.getOffset() == null) {
			paginatedResultList.setOffset("0");
		}
		searchMap.put("offset", paginatedResultList.getOffset());
		searchMap.put("orderByColumn", paginatedResultList.getOrderByColumn());
		List<DashboardResult> dashboardResults = null;
		try {
			
			//Add user Filters 
			this.addUserFilters(searchMap, paginatedResultList.getPageType(),user);
			System.out.println(searchMap.get("OrderBy"));
			dashboardResults = paymentService.getDashboardResults(paginatedResultList, searchMap);
			paginatedResultList.setTotalRecords((dashboardResults == null || dashboardResults.isEmpty()) ? 0
					: dashboardResults.get(0).getTotalRecords());
			paginatedResultList.setResultList(dashboardResults);

			//is Approval Range Present:
			paginatedResultList.setApprovalRangePresent(MyPaymentsUtil.isApprovalRangePresent(user.getFineGrainInfo()));
			
		} catch (Exception ex) {
			PaymentLogger.logError(this, ex.getMessage(), ex);
			throw new DBException("Unable to getDashboardResults information.");
		}
		return paginatedResultList;

	}

	@RequestMapping(value = "/assignPersonToReq", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public void assignPersonToRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest) {

		User user = (User) request.getSession().getAttribute("User");
		String Sso = user.getSso();
		Date currentDay = new Date();

		paymentRequest.setLastUpdateDate(currentDay);
		paymentRequest.setLastUpdateUser(Sso);

		try {
			paymentService.assignRequestToPerson(paymentRequest);

		} catch (Exception ex) {
			PaymentLogger.logError(this, ex.getMessage(), ex);
			throw new DBException("Unable to update Assign To");
		}
	}
	
	@RequestMapping(value = "/trigger-email-DOA", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String triggerEmailToDOAAdmin(HttpServletRequest request) throws Exception{
		
		Map<String,String> doaAdminList = (Map<String,String>) request.getSession().getAttribute("doaAdminList");
		User user = (User) request.getSession().getAttribute("User");
		
		List<String> toAddress = new ArrayList<String>();
		if(null!=doaAdminList && doaAdminList.size() > 0){
			for (Map.Entry<String, String> entry : doaAdminList.entrySet()){
				toAddress.add(entry.getValue());
			}
			String toMailString = toAddress.stream()
                    .collect(Collectors.joining(","));
			//notificationService.sendHtmlNotification(toMailString,"'"+ user.getName() + " : "+ user.getSso() + "' does not have any Delegation of Authority Payment Types assigned. Please assign from Admin Portal");
			notificationService.sendHtmlNotification(toMailString, "' "+ user.getName() + " : "+ user.getSso() + "' does not have any Delegation of Authority Payment Types assigned. Please assign from Admin Portal", PaymentRequestConstants.WORKFLOW_DOA_TEMPLATE, null);
		}
		
		
		return "success";
	}

}
