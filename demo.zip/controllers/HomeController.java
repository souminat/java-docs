/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.treasury.mypayments.constants.ControllersConstants;
import com.ge.treasury.mypayments.corems.domain.FineGrainRequest_V2;
import com.ge.treasury.mypayments.corems.domain.FineGrainResponse;
import com.ge.treasury.mypayments.corems.domain.FineGrainResponseData;
import com.ge.treasury.mypayments.corems.domain.FineGrainResponse_V2;
import com.ge.treasury.mypayments.corems.domain.FineGrainRole;
import com.ge.treasury.mypayments.corems.domain.FineGrainRole_V2;
import com.ge.treasury.mypayments.corems.domain.FineGrainUser;
import com.ge.treasury.mypayments.domain.PaymentGrantedAuthority;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.service.CustomUserDetails;
import com.ge.treasury.mypayments.service.MyPaymentsUserDetailsService;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
/**
 * @author MyPayments Dev Team
 * 
 */
@Controller
public class HomeController {

	@Value("${mypayments.url.accessdenied}")
	private String accessDeniedUrl;

	@Value("${mypayments.url.logout}")
	private String logoutMsg;

	@Value("${finegrain-auth.url.get-auth}")
	private String msFineGrainAuthUrl;
	
	@Value("${mypayments.highriskworkflow.url}")
	private String highriskworkflowUrl;
	
	@Value("${mypayments.trstradingentity.url}")
	private String trstradingentityUrl;
	
	@Value("${finegrain-auth-url-get-users}")
	private String getUsersURL;

	@Autowired
	private OAuth2RestOperations msFineGrainRestTemplate;
	
	@Autowired
	private OAuth2RestOperations myPaymentRestTemplate;

	@Value("${user-lookup.url.lookup}")
	private String userLookupBaseUrl;

	

	@Autowired
	private MyPaymentsUserDetailsService myPaymentsUserDetailsService;

	private List<String> preparerList;

	private List<String> releaserList;

	private List<String> approverList;

	/**
	 * @return the accessDeniedUrl
	 */
	public String getAccessDeniedUrl() {
		return accessDeniedUrl;
	}

	/**
	 * @param accessDeniedUrl
	 *            the accessDeniedUrl to set
	 */
	public void setAccessDeniedUrl(final String accessDeniedUrl) {
		this.accessDeniedUrl = accessDeniedUrl;
	}

	/**
	 * @return the logoutMsg
	 */
	public String getLogoutMsg() {
		return logoutMsg;
	}

	/**
	 * @param logoutMsg
	 *            the logoutMsg to set
	 */
	public void setLogoutMsg(final String logoutMsg) {
		this.logoutMsg = logoutMsg;
	}

	/**
	 * Home
	 * 
	 * @return
	 */
	@RequestMapping(value = { "/", "/home" })
	public String home(final HttpSession session) {
		
		ExecutorService executor = Executors.newFixedThreadPool(5);
		List<Future<Collection<FineGrainResponseData>>> resultList = new ArrayList<>();
		
		
		
		
		Future<Collection<FineGrainResponseData>> result = executor.submit(new ThreadExecutor(session, this.getUsersURL, msFineGrainRestTemplate));
		resultList.add(result);
		executor.shutdown();
        while (!executor.isTerminated()) {
        }
        
        
        
        
        System.out.println("Finished all threads" + resultList.size());
        //Collection<FineGrainResponseData> coll = (Collection<FineGrainResponseData>) resultList.get(0).get();
       
        
        try {
        	 populateUsersList(session, resultList.get(0).get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return loadFrontEndView(session, "/index.html");
	}
	
	
	private void populateUsersList(HttpSession session,Collection<FineGrainResponseData> fineGrainList){
		Map<String,String> approverList = new HashMap<String,String>();
		Map<String,String> preparerList = new HashMap<String,String>();
		Map<String,String> releaserList = new HashMap<String,String>();
		Map<String,String> doaAdminList = new HashMap<String,String>();
		
		if(null!=fineGrainList){
			for(FineGrainResponseData data :  fineGrainList){
				Collection<FineGrainRole_V2> roles = data.getRoles();
				String json = myPaymentRestTemplate.getForObject(userLookupBaseUrl + data.getSso(), String.class);
				
				
				JSONObject object = new JSONObject(json);
				JSONArray jsonarr= object.getJSONArray("data");
				
				//JSONObject data_o = object.getJSONObject("data");
				//String address = jsonarr.getJSONObject(0).getString("addressLine1");
				
				if(jsonarr.length() > 0){
					String emailAddress = jsonarr.getJSONObject(0).getString(("emailAddress"));
					
					if(null!=roles){
						for(FineGrainRole_V2 role : roles){
							if(role.getAppRole().equalsIgnoreCase("DOA Admin")){
								
								doaAdminList.put(data.getSso(),emailAddress);
								
							}else if(role.getAppRole().equalsIgnoreCase("Payment Approver")){
								
								approverList.put(data.getSso(),emailAddress);
								
							} else if(role.getAppRole().equalsIgnoreCase("ERP Manual Payment File Requester")){
								
								
								
							}else if(role.getAppRole().equalsIgnoreCase("Support - ReadOnly")){
								
							}else if(role.getAppRole().equalsIgnoreCase("Global Treasury Preparer")){
								
								preparerList.put(data.getSso(),emailAddress);
								
							}else if(role.getAppRole().equalsIgnoreCase("Global Treasury Releaser")){
								
								releaserList.put(data.getSso(),emailAddress);
							}
						}
						
					}
				}
				
				
			}
		}
		
		session.setAttribute("approverList", approverList);
		session.setAttribute("preparerList", preparerList);
		session.setAttribute("releaserList", releaserList);
		session.setAttribute("doaAdminList", doaAdminList);
		
	}

	/**
	 * helper to check user session and load the front end template
	 */
	@SuppressWarnings("unused")
	private String loadFrontEndView(final HttpSession session, final String view) {

		// Check for granted authorities-roles, if no roles found redirect to
		// logout
		@SuppressWarnings("unchecked")
		Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder.getContext()
				.getAuthentication().getAuthorities();

		List<String> umbrellas = ((CustomUserDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal()).getUmbrellas();

		final FineGrainUser fineGrainUser = myPaymentsUserDetailsService.getAuth("");
		if (fineGrainUser != null) {
			try {
				for (FineGrainResponse responseData : fineGrainUser.getResponseData()) {
					roleBasedList(responseData);
				}
			} catch (final Exception ex) {
				PaymentLogger.logError(this, "Exception in finding appropriate role: " + ex);
			}
		}

		PaymentGrantedAuthority expau;
		String userRole = null;
		for (Iterator<GrantedAuthority> iterator = authorities.iterator(); iterator.hasNext();) {
			expau = (PaymentGrantedAuthority) iterator.next();
			userRole = expau.getAuthority();
		}

		String url = "";
		if (authorities != null && !authorities.isEmpty()) {

			Authentication auth = SecurityContextHolder.getContext().getAuthentication();

			User user = new User();
			user.setSso(auth.getName());
			user.setAppRole(userRole);
			user.setUmbrellas(umbrellas);
			user.setPreparerList(preparerList);
			user.setReleaserList(releaserList);
			user.setApproverList(approverList);

			//add finegraininfo details
			
			CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();
			
			user.setFineGrainInfo(userDetails.getFineGrainInfo());
			
			session.setAttribute("User", user);

			if (user != null) {
				url = view;
			} else {
				session.invalidate();
				url = ControllersConstants.REDIRECT + getAccessDeniedUrl();
			}
		} else {
			session.invalidate();
			url = ControllersConstants.REDIRECT + getAccessDeniedUrl();
		}
		return url;
	}

	/**
	 * Accessdenied
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/accessdenied", method = RequestMethod.GET)
	public String accessdenied(final HttpServletRequest request) {

		return "/accessDenied.html";
	}

	/**
	 * Logout
	 * 
	 * @return
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(final HttpSession session) {

		if (session != null) {
			session.invalidate();
		}
		return ControllersConstants.REDIRECT + getLogoutMsg();
	}
	
	private void roleBasedList(FineGrainResponse responseData){
		this.preparerList = new ArrayList<>();
		this.releaserList = new ArrayList<>();
		this.approverList = new ArrayList<>();
		
		for (FineGrainRole role : responseData.getRoles()) {
			if ("preparer".equalsIgnoreCase(role.getAppRole())) {
				preparerList.add(responseData.getSso());
			}
			if ("releaser".equalsIgnoreCase(role.getAppRole())) {
				releaserList.add(responseData.getSso());
			}
			if ("Payment Approver".equalsIgnoreCase(role.getAppRole())) {
				approverList.add(responseData.getSso());
			}
		}
	}
	
	@RequestMapping(value = "/fetch-static-urls", method = RequestMethod.GET)
	@ResponseBody
	public String fetchStaticUrls(final HttpSession session) throws Exception {
		
		HashMap<String,String> urlMap = new HashMap<String,String>();
		urlMap.put("trsUrl",trstradingentityUrl);
		urlMap.put("highRiskUrl",highriskworkflowUrl);
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(urlMap);
	}
	
	public class ThreadExecutor implements Callable<Collection<FineGrainResponseData>>{

		HttpSession session;
		
		String url;
		
		OAuth2RestOperations msFineGrainRestTemplate;
		
		public ThreadExecutor(HttpSession session, String url, OAuth2RestOperations msFineGrainRestTemplate) {
			// TODO Auto-generated constructor stub
			
			this.session = session;
			this.url = url;
			this.msFineGrainRestTemplate = msFineGrainRestTemplate;
		}
		
		@Override
		public Collection<FineGrainResponseData> call() {
			// TODO Auto-generated method stub
			System.out.println("------------ Thread request Recieved");
			
			FineGrainRequest_V2 fgRequest = new FineGrainRequest_V2();
			fgRequest.setAppName("MYPAYMENTS");
			fgRequest.setRole("Payment Approver");
			String response = this.msFineGrainRestTemplate.postForObject(this.url, fgRequest, String.class);
			Gson gson = new GsonBuilder().create();
			FineGrainResponse_V2 fineGrainResponse_V2 = gson.fromJson(response, FineGrainResponse_V2.class);
			
			System.out.println("Response : " + fineGrainResponse_V2);
			
			if(null != fineGrainResponse_V2.getRequest()){
				session.setAttribute("users-list", fineGrainResponse_V2.getRequest());
			}
			
			return fineGrainResponse_V2.getResponseData();
			
		}

	}
}