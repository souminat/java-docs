/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mypayments.constants.ExceptionConstants;
import com.ge.treasury.mypayments.constants.PaymentRequestConstants;
import com.ge.treasury.mypayments.constants.WorkflowConstants;
import com.ge.treasury.mypayments.controllers.model.Typeahead;
import com.ge.treasury.mypayments.dao.PaymentRequestDao;
import com.ge.treasury.mypayments.domain.BankIntermediary;
import com.ge.treasury.mypayments.domain.PaymentRequest;
import com.ge.treasury.mypayments.domain.RequestActivity;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.DBException;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.service.RouterService;
import com.ge.treasury.mypayments.utils.MyPaymentsUtil;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.ge.treasury.mypayments.validation.PaymentRequestValidator;

/**
 * REST services for create/edit/obtain request groups
 * 
 * @author MyPayments Dev Team
 *
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class PaymentRequestController extends BaseController {

	@Autowired
	private RouterService routerService;
	
	@Autowired
	private PaymentRequestDao paymentDao;

	@Value("#{'${akana.folderId}'}")
	private String folderId;

	
	/**
	 * Save request group (Payment Submission)
	 *
	 * @param request
	 * @param paymentRequest
	 * @return
	 * @throws ValidationFailedException
	 */
	@RequestMapping(value = "/preparePaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest preparePaymentRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest)
			throws ValidationFailedException {

		User user = (User) request.getSession().getAttribute("User");

		BindingResult errors = new BeanPropertyBindingResult(paymentRequest, PaymentRequestConstants.PAY_REQ);
		PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

		validator.validate(paymentRequest, errors);
		PaymentRequest paymentRequestResult = null;

		BankIntermediary bankIntermediary = null;
		RequestActivity requestActivity = null;

		if (errors.hasErrors()) {
			throw new ValidationFailedException(errors);
		} else {
			if (paymentRequest != null) {
				for (int index = WorkflowConstants.ZERO; index < paymentRequest.getIntermediaries().size(); index++) {
					bankIntermediary = paymentRequest.getIntermediaries().get(index);
					bankIntermediary = paymentService.preparePaymentRequest(bankIntermediary, user);
				}
				paymentRequest.setLastUpdateDate(new Date());
				paymentRequestResult = paymentService.updatePayRequest(paymentRequest, user);

				requestActivity = paymentRequest.getRequestActivities().get(WorkflowConstants.ZERO);
				requestActivity = paymentService.saveworkFlowRequest(requestActivity, user);
			}
		}

		setLogPerfMessage(request, "BankIntermediary id" + bankIntermediary.getpaymentRequestId());
		setLogPerfMessage(request, "Payment Request id Update" + paymentRequestResult.getRequestId());
		setLogPerfMessage(request, "Work Flow Status Code " + requestActivity.getPaymentStatusCode());

		creditAudit(user, paymentRequest);
		return paymentRequestResult;

	}

	/**
	 * Save WorkFlow Activity for Release Payment(releasePaymentRequest)
	 * 
	 * @param
	 * @param
	 * @return
	 * @throws ValidationFailedException
	 * 
	 */
	@RequestMapping(value = "/releasePaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest releasePaymentRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest)
			throws ValidationFailedException {
		// Insert an activity in Request Activity
		// Update the Paymentrequest in accordance with paymentrequestid as
		// status release
		// WorkFlow Status Code as Release

		User user = (User) request.getSession().getAttribute("User");

		BindingResult errors = new BeanPropertyBindingResult(paymentRequest, PaymentRequestConstants.PAY_REQ);
		PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

		validator.validate(paymentRequest, errors);
		PaymentRequest releasePaymentRequest = null;
		RequestActivity requestActivity = null;
		if (errors.hasErrors()) {
			throw new ValidationFailedException(errors);
		} else {
			if (paymentRequest != null) {
				releasePaymentRequest = paymentService.updatePayRequest(paymentRequest, user);
				requestActivity = paymentRequest.getRequestActivities().get(WorkflowConstants.ZERO);
				requestActivity = paymentService.saveworkFlowRequest(requestActivity, user);

			}
		}

		creditAudit(user, paymentRequest);
		return releasePaymentRequest;

	}

	@RequestMapping(value = "/approvePaymentRequest_v2", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest approvePaymentRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest)
			throws ValidationFailedException {

		// *****************************************************************************************
		// Insert record in Request Activity
		// Update the Payment Request status as APPROVED according to to a given
		// payment request id.
		// WorkFlow Status Code as Approved
		// *****************************************************************************************
		User user = (User) request.getSession().getAttribute("User");
		String Sso = user.getSso();
		Date currentDay = new Date();

		BindingResult errors = new BeanPropertyBindingResult(paymentRequest, PaymentRequestConstants.PAY_REQ);
		PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

		validator.validate(paymentRequest, errors);
		PaymentRequest approvedPaymentRequest = null;

		if (errors.hasErrors()) {
			throw new ValidationFailedException(errors);
		} else {
			if (null != paymentRequest && !CollectionUtils.isEmpty(paymentRequest.getRequestActivities())) {

				paymentRequest.setLastUpdateDate(currentDay);
				paymentRequest.setLastUpdateUser(Sso);
				paymentRequest.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_APPROVED);
					for (int index = 0; index < paymentRequest.getRequestActivities().size(); index++) {
						paymentRequest.getRequestActivities().get(index).setUserName(user.getName());
						paymentRequest.getRequestActivities().get(index).setUserEmail(user.geteMail());
						paymentRequest.getRequestActivities().get(index).setUserRole(user.getAppRole());
						paymentRequest.getRequestActivities().get(index).setSsoId(Sso);
						paymentRequest.getRequestActivities().get(index).setCreateDate(currentDay);
						paymentRequest.getRequestActivities().get(index).setCreateUser(Sso);
						paymentRequest.getRequestActivities().get(index).setLastUpdateUser(Sso);
						paymentRequest.getRequestActivities().get(index).setLastUpdateDate(currentDay);
						paymentRequest.getRequestActivities().get(index)
								.setUserAction(WorkflowConstants.WRKFLW_STS_APPROVED);
						paymentRequest.getRequestActivities().get(index).setPaymentStatusCode("WRKFLW_STS_APPROVED");
				}

				approvedPaymentRequest = paymentService.approvePaymentRequest(paymentRequest, user);
				creditAudit(user, paymentRequest);

			}
		}
		return approvedPaymentRequest;

	}

	@RequestMapping(value = "/approvePaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest approvePaymentRequestV2(HttpServletRequest request, @RequestBody PaymentRequest target)
			throws ValidationFailedException{

		User user = (User) request.getSession().getAttribute("User");
		Date today = new Date();

		BindingResult errors = new BeanPropertyBindingResult(target, PaymentRequestConstants.PAY_REQ);
		PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);
		if ("true".equalsIgnoreCase(target.getIsManual())) {
		List<PaymentRequest> duplicatePaymentRequest = null;
		duplicatePaymentRequest = paymentService.checkDuplicateRequest(target);
		if (!CollectionUtils.isEmpty(duplicatePaymentRequest)) {
			for (PaymentRequest requestIdCheck : duplicatePaymentRequest) {
				if (!(requestIdCheck.getRequestId() == target.getRequestId()))
					errors.reject("Duplicate Request", ExceptionConstants.DUPLICATE_PAYMENT_EXCEPTION
							+ duplicatePaymentRequest.get(0).getRequestId());
				}
			}
		}
		validator.validatePaymentRequestForApproval(errors, target);

		if (errors.hasErrors()) {
			throw new ValidationFailedException(errors);
		} else {

			// validate if the request is ready to get approved
			PaymentRequest source = this.paymentService.fetchPaymentRequestByID(target.getRequestId());
			if (null != source && "SUBMITTED".equalsIgnoreCase(source.getPaymentStatusCode())) {
				// Detect changes if any

				if (null == source.getPayer()) {
					// payer was absent from requester, insert the new payer
					// from the approver
					target.getPayer().setPaymentRequestId(target.getRequestId());
					target.getPayer().setPayerOrPayee("PAYER");
					this.paymentService.savePayerPayee(target.getPayer(), user);
					
				} else {
					// changed payer
					payerChange(source, target, user);
				}
				//set the instrument type once the payer object is set
				if(target.getMdmPayerCurrency().equals(target.getPayeeCurrency())){
				       target.setInstrumentType("Domestic");
			     }else{
				       target.setInstrumentType("International");
			     }
				target.setPaymentSystem(routerService.getPaymentSystem(target));
				// Is Data changed?
				boolean requestDataChanged = source.equals(target);
				if (requestDataChanged) {
					this.paymentService.saveApprovalChanges(target, user);
				}

				RequestActivity activity = createRequestActivity(user, today, target,
						WorkflowConstants.WRKFLW_STS_APPROVED, "WRKFLW_STS_APPROVED", "");

				if (!CollectionUtils.isEmpty(target.getRequestActivities())) {
					// Sonar Violation Fix : Math operands should be cast before
					// assignment
					activity.setSequenceNumber(target.getRequestActivities().size() + 1L);
				}
				
				activity.setValueDate(target.getPaymentDate());
				activity.setPaymentMethodCode(target.getPaymentSystem());
				target.setLastUpdateDate(today);
				target.setLastUpdateUser(user.getSso());
				target.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_APPROVED);
				paymentService.processApprovalRequest(target, user, activity);

				// insert audit
				creditAudit(user, target);
				// TODO: Email Notification
			}

		}
		return target;

	}

	/**
	 * 
	 * rejectPaymentRequest
	 * 
	 * @param request
	 * @param paymentRequest
	 * @return
	 * @throws ValidationFailedException
	 */

	@RequestMapping(value = "/rejectPaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest rejectPaymentRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest)
			throws ValidationFailedException {

		// *****************************************************************************************
		// Insert record in Request Activity
		// Update the Payment Request status as Rejected according to to a given
		// payment request id.
		// WorkFlow Status Code as Rejected
		// *****************************************************************************************
		User user = (User) request.getSession().getAttribute("User");
		Date today = new Date();
		PaymentRequest rejectedPaymenRequest = null;
		RequestActivity requestActivity = null;
		try {
			BindingResult errors = new BeanPropertyBindingResult(paymentRequest, PaymentRequestConstants.PAY_REQ);
			PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

			validator.validatePaymentRequestForRejection(errors, paymentRequest);

			if (errors.hasErrors()) {
				throw new ValidationFailedException(errors);
			} else {
				PaymentRequest source = this.paymentService.fetchPaymentRequestByID(paymentRequest.getRequestId());
				if ("SUBMITTED".equalsIgnoreCase(source.getPaymentStatusCode())
						|| "PREPARED".equalsIgnoreCase(source.getPaymentStatusCode())) {
					requestActivity = sequenceNumSet(paymentRequest, today, user);
					rejectedPaymenRequest = paymentService.processRejectCancelRequest(paymentRequest, user,
							requestActivity);
					creditAudit(user, paymentRequest);
				}

				// comments
			}
		} catch (Exception e) {
			PaymentLogger.logError(this, "PaymentRequestController.rejectPaymentRequest()" + e.getMessage(), e);
			throw new SystemException(e);
		}
		return rejectedPaymenRequest;

	}

	/**
	 * Retrieves the payment request and writes to outboubd view if the hash is
	 * not already available. Payment request received should be in released
	 * state and payer, payee currency should be different.
	 *
	 * @param paymentRequestId
	 * @return
	 */
	@RequestMapping(value = "/retrivePaymentRequest", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest retrivePaymentRequest(HttpServletRequest request, @RequestParam Long paymentRequestId) {
		PaymentRequest paymentRequest = null;
		try {
			if (paymentRequestId != null) {
				paymentRequest = paymentDao.loadPaymentRequest(paymentRequestId);
				User user = (User) request.getSession().getAttribute("User");
				paymentRequest.setValidForApproval(MyPaymentsUtil.isApprovalValid(paymentRequest,user.getFineGrainInfo()));
			}
		} catch (Exception ex) {
			PaymentLogger.logError(this, ex.getMessage(), ex);
			throw new DBException("Unable to load PaymentRequest ");
		}
		
		
		
		return paymentRequest;
	}

	@RequestMapping(value = "/getPayeeFilterResult", method = RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public Typeahead getPayeeFilterResult(@RequestBody String payeeSearchValue) {
		Typeahead typeahead = new Typeahead();
		String query = "'%" + payeeSearchValue + "%'";
		typeahead.setPayeeName(paymentService.getPayeeName(query));

		return typeahead;
	}

	@RequestMapping(value = "/getPayerFilterResult", method = RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public Typeahead getPayerFilterResult(@RequestBody String payerSearchValue) {
		Typeahead typeahead = new Typeahead();
		String query = "'%" + payerSearchValue + "%'";
		typeahead.setPayerName(paymentService.getPayerName(query));

		return typeahead;
	}

	@RequestMapping(value = "/getRequestTypeResult", method = RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public Typeahead getRequestTypeResult(@RequestBody String requestTypeSearchValue) {
		Typeahead typeahead = new Typeahead();
		String query = "'%" + requestTypeSearchValue + "%'";
		typeahead.setRequestType(paymentService.getRequestType(query));

		return typeahead;
	}
	
	
	@RequestMapping(value = "/getEnterpriseDesc", method = RequestMethod.POST, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public Typeahead getEnterpriseDesc(@RequestBody String enterpriseDescSearchValue) {
		Typeahead typeahead = new Typeahead();
		String query = "'%" + enterpriseDescSearchValue + "%'";
		typeahead.setEnterpriseDesc(paymentService.getEnterpriseDesc(query));
		
		return typeahead;
	}

	private void creditAudit(User user, PaymentRequest paymentRequest) {
		PaymentRequest oldObject = new PaymentRequest();
		try {
			auditService.createAudit(user, oldObject, paymentRequest);
		} catch (InterruptedException e) {
			PaymentLogger.logError(this, "PaymentRequestController:: creditAudit " + e.getMessage(), e);
			throw new SystemException(e);
		}
	}
	
	private void payerChange(PaymentRequest source, PaymentRequest target, User user) {
		boolean payerChanged = source.getPayer().equals(target.getPayer());
		if (payerChanged) {
			this.paymentService.savedChangedPayer(target, user);
		}
	}
	
	private RequestActivity sequenceNumSet(PaymentRequest paymentRequest, Date today, User user) {
		RequestActivity requestActivity = null;
		paymentRequest.setLastUpdateDate(today);
		paymentRequest.setLastUpdateUser(user.getSso());
		paymentRequest.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_REJECTED);
		requestActivity = createRequestActivity(user, today, paymentRequest, WorkflowConstants.WRKFLW_STS_REJECTED,
				"WRKFLW_STS_REJECTED", paymentRequest.getRequestStatusId().getRejectCancelReason());
		if (!CollectionUtils.isEmpty(paymentRequest.getRequestActivities())) {
			// Sonar Violation Fix : Math operands should be cast
			// before assignment
			int count = this.paymentService.getRequestActivities(paymentRequest.getRequestId());
			requestActivity.setSequenceNumber(count + 1L);
		}
		return requestActivity;
	}
}
	