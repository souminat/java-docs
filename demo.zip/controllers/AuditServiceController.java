/**
 * 
 */
package com.ge.treasury.mypayments.controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.ge.treasury.mypayments.constants.ValidationConstants;
import com.ge.treasury.mypayments.domain.Audit;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.utils.PaymentLogger;

/**
 * @author MyBank Dev Team
 * 
 */

@Controller
@RequestMapping("/api/acct/v1")
public class AuditServiceController extends BaseController {

	@Value("${audit.ms.baseUrl}")
	private String auditBaseUrl;

	@Value("${audit.ms.getAudits}")
	private String getAudits;

	@Autowired
	private OAuth2RestOperations msAuditRestTemplate;

	@RequestMapping(value = "/getAudits", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	// 200
	//Sonar Fixes:"throws" declarations should not be superfluous
	public @ResponseBody List<Audit> getAudits(HttpServletRequest request, @RequestParam("domainKey") String domainKey)
			throws JsonMappingException {
		User user = (User) request.getSession().getAttribute("User");

		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}

		String userId = user.getSso();
		String transactionId = PaymentLogger.getTransactionId();
		long startTime = System.currentTimeMillis();
		PaymentLogger.logPerf(this, userId, transactionId, request.getRequestURL().toString(), 0L);

		ObjectMapper mapper = new ObjectMapper();

		Audit audit = new Audit();
		String json = "";
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		try {
			json = ow.writeValueAsString(audit);
		} catch (IOException e) {
			PaymentLogger.logError(this, e.getMessage(), e);
		}

		List<Audit> auditResult = new ArrayList<Audit>();
		try {
			// set headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(auditBaseUrl + getAudits)
					.queryParam("domain", ValidationConstants.MYPAYMENTS_AUDIT_DOMAIN)
					.queryParam("domainKey", domainKey)
					.queryParam("entity", ValidationConstants.MYPAYMENTS_AUDIT_ENTITY);

			HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), headers);

			// Get the response as string
			ResponseEntity<String> response = msAuditRestTemplate.exchange(builder.build().encode().toUri(),
					HttpMethod.GET, httpEntity, String.class);

			auditResult = mapper.readValue(response.getBody(), new TypeReference<List<Audit>>() {
			});
			for (Audit oneAudit : auditResult) {
				Date auditDate = oneAudit.getTms();
				SimpleDateFormat isoFormat = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
				isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
				oneAudit.setTmsString(isoFormat.format(auditDate));
			}
		} catch (HttpClientErrorException httpEx) {
			PaymentLogger.logError(this, httpEx.getMessage(), httpEx);
			return auditResult;
		} catch (Exception ex) {
			PaymentLogger.logError(this, ex.getMessage(), ex);
			return auditResult;
		}

		PaymentLogger.logPerf(this, userId, transactionId, "Retrieving Audit information successful.",
				System.currentTimeMillis() - startTime);

		return auditResult;
	}

}
