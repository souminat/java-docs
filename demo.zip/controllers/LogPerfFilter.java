/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.utils.PaymentLogger;

/**
 * 
 * Filter class
 * 
 * @author MyPayments Dev Team
 *
 */
@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class LogPerfFilter implements Filter {

    private static final String LOG_PERF_MESSAGE_IND = "logPerfMessage";
    private static final String LOG_PERF_CALLER_CLASS = "logPerfCallerClass";

    @Override
    public void init(final FilterConfig arg0) throws ServletException {
        // Method not needed to be implemented
    }

    @Override
    public void destroy() {
        // Method not needed to be implemented
    }

    /**
     * doFilter
     */
    @Override
    public void doFilter(final ServletRequest request,
            final ServletResponse response, final FilterChain chain)
            throws IOException, ServletException {

        if (PaymentLogger.isLogPerfEnabled(this)) {
            final HttpServletRequest httpRequest = (HttpServletRequest) request;
            final String requestURL = httpRequest.getRequestURL().toString();

            final boolean isControllerURL = !( // Exclusions
            requestURL.contains("/mypayments/dist/") || requestURL
                    .contains("/mypayments/index.html"));

            String userId = getUserId(httpRequest);
            final String transactionId = PaymentLogger.getTransactionId();
            final long startTime = System.currentTimeMillis();

            if (isControllerURL) {
                PaymentLogger.logPerf(this, userId, transactionId, requestURL,
                        0L);
            }

            try {

                chain.doFilter(request, response);

            } finally {
                if (isControllerURL) {

                    if ("NOUSERID".equals(userId)) {
                        userId = getUserId(httpRequest);
                    }

                    String logPerfMessage = (String) httpRequest
                            .getAttribute(LOG_PERF_MESSAGE_IND);

                    if (logPerfMessage == null) {
                        logPerfMessage = "No Message Set for this controller";
                    }

                    Object callerClass = httpRequest
                            .getAttribute(LOG_PERF_CALLER_CLASS);

                    if (callerClass == null) {
                        callerClass = this;
                    }

                    PaymentLogger.logPerf(callerClass, userId, transactionId,
                            logPerfMessage, System.currentTimeMillis()
                                    - startTime);
                }
            }
        } else {
            chain.doFilter(request, response);
        }
    }

    /**
     * Get user id
     * 
     * @param request
     * @return
     */
    private String getUserId(final HttpServletRequest request) {
        final User user = (User) request.getSession().getAttribute("User");
        return (user != null) ? user.getSso() : "NOUSERID";
    }

    /**
     * Set message
     * 
     * @param request
     * @param message
     * @param caller
     */
    public static void setMessage(final HttpServletRequest request,
            final String message, final Object caller) {
        request.setAttribute(LOG_PERF_MESSAGE_IND, message);
        request.setAttribute(LOG_PERF_CALLER_CLASS, caller);
    }

}
