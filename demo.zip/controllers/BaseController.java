/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mypayments.domain.PaymentRequest;
import com.ge.treasury.mypayments.domain.RequestActivity;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.BusinessException;
import com.ge.treasury.mypayments.exceptions.DBException;
import com.ge.treasury.mypayments.exceptions.ResourceNotFoundException;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.service.AuditService;
import com.ge.treasury.mypayments.service.PaymentRequestManagerService;
import com.ge.treasury.mypayments.service.RouterService;
import com.ge.treasury.mypayments.utils.MessageValidator;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.ge.treasury.mypayments.validation.RequestValidation;
import com.ge.treasury.mypayments.validation.ResultValidation;
import com.ge.treasury.mypayments.validation.Validation;

/**
 * @author MyPayments Dev Team
 * 
 */
@Controller
public abstract class BaseController {

	@Autowired
	protected MessageValidator messageValidator;

	@Autowired
	protected PaymentRequestManagerService paymentService;

	@Autowired
	protected AuditService auditService;

	@Autowired
	protected RouterService routerService;

	/**
	 * Handle DBException
	 * 
	 * @param ex
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@ExceptionHandler(DBException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public String handleDBException(Exception ex) throws IOException {
		PaymentLogger.logError(this, "Database Exception:" + ex.getMessage(), ex);
		return "Database Exception : " + ex.getMessage();
	}

	/**
	 * Handle BusinessException
	 * 
	 * @param ex
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@ExceptionHandler(BusinessException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public String handleBusinessException(Exception ex) throws IOException {
		PaymentLogger.logError(this, "Business Exception:" + ex.getMessage(), ex);
		return "Business Exception : " + ex.getMessage();
	}

	/**
	 * Handle SystemException
	 * 
	 * @param ex
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@ExceptionHandler(SystemException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public String handleSystemException(Exception ex) throws IOException {
		PaymentLogger.logError(this, "System Exception:" + ex.getMessage(), ex);
		return "System Exception : " + ex.getMessage();
	}

	/**
	 * Handle Exception
	 * 
	 * @param throwable
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public String handleTRSSystemException(Exception ex) throws IOException {
		PaymentLogger.logError(this, "Unhandled Exception:" + ex.getLocalizedMessage(), ex);
		return "Internal Server Error ";

	}

	/**
	 * Returns the appropriate response when resource not found.
	 * 
	 * @param ex
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	// 404
	@ResponseBody
	public String handleResourceNotFound(Exception ex) throws IOException {
		PaymentLogger.logError(this, "Resource Not Found Exception" + ex.getLocalizedMessage(), ex);
		return "Not Found Exception : " + ex.getMessage();
	}

	/**
	 * Set a custom Message for the LogFilter.LogPerfEnd Method
	 * 
	 * @param request
	 * @param message
	 */
	protected void setLogPerfMessage(final HttpServletRequest request, final String message) {
		LogPerfFilter.setMessage(request, message, this);
	}

	/**
	 * Returns message errors from validation
	 * 
	 * @param ex
	 * @return
	 * @throws IOException
	 */
	@ExceptionHandler(ValidationFailedException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ResultValidation handleValidationFailedException(ValidationFailedException ex) throws IOException {
		PaymentLogger.logError(this, "Request Group Validation Failed.");

		ResultValidation result = new ResultValidation();
		List<RequestValidation> validationList = new ArrayList<RequestValidation>();
		RequestValidation validation = null;
		List<Validation> validations = null;

		Map<String, List<Validation>> mapErrors = new LinkedHashMap<String, List<Validation>>();

		Validation val = null;
		for (ObjectError error : ex.getErrors().getAllErrors()) {
			PaymentLogger.logError(this, "Validation Error : " + error.getCode() + " " + error.getDefaultMessage());
			if (!error.getCode().contains("[")) {
				result.setErrorCode(error.getCode());
				result.setErrorMessage(error.getDefaultMessage());
			} else {
				val = new Validation();
				val.setFieldname(error.getCode());
				val.setValidationMessage(error.getDefaultMessage());
				String header = error.getCode().substring((error.getCode()).indexOf('[') + 1,
						(error.getCode()).indexOf(']'));
				validations = mapErrors.get(header);
				validations.add(val);
			}
		}

		for (String number : mapErrors.keySet()) {
			validations = mapErrors.get(number);
			validation = new RequestValidation();
			validation.setValidations(validations);
			validationList.add(validation);
		}

		result.setRequests(validationList);
		return result;
	}

	protected RequestActivity createRequestActivity(User user, Date today, PaymentRequest paymentRequest, String status,
			String statusCode, String reason) {
		RequestActivity requestAct = new RequestActivity();
		requestAct.setPaymentRequestId(paymentRequest.getRequestId());
		requestAct.setUserName(user.getName());
		requestAct.setUserEmail(user.geteMail());
		requestAct.setUserRole(user.getAppRole());
		requestAct.setSsoId(user.getSso());
		requestAct.setCreateDate(today);
		requestAct.setCreateUser(user.getSso());
		requestAct.setLastUpdateUser(user.getSso());
		requestAct.setLastUpdateDate(today);
		requestAct.setUserAction(status);
		requestAct.setPaymentStatusCode(statusCode);
		requestAct.setRejectCancelReason(reason);
		requestAct.setComments(paymentRequest.getRequestStatusId().getComments());
		return requestAct;
	}

}
