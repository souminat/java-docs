package com.ge.treasury.mypayments.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ge.treasury.mypayments.constants.PaymentRequestConstants;
import com.ge.treasury.mypayments.controllers.model.PaginatedResultList;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.service.PaymentRequestManagerService;
import com.ge.treasury.mypayments.utils.MessageValidator;
import com.ge.treasury.mypayments.utils.MyPaymentsUtil;

@Controller
public abstract class BaseDashboardController {

	@Autowired
	protected MessageValidator messageValidator;

	@Autowired
	protected PaymentRequestManagerService paymentService;
	
	private Set<String> businesslist;
	private Set<String> subBusinessList;
	private Set<String> paymentTypeList;
	private Set<String> tCodeSvcList;
	

	protected PaginatedResultList setDefaults(PaginatedResultList paginatedResultList) {

		String defaultOffset = "0";
		String defaultNext = "10";
		String defaultOrderByColumn = PaymentRequestConstants.PAYMENT_REQUEST_ID;

		paginatedResultList.setOffset(defaultOffset);
		paginatedResultList.setNext(defaultNext);
		paginatedResultList.setOrderByColumn(defaultOrderByColumn);
		paginatedResultList.setOrderBy("DESC");
		return paginatedResultList;

	}

	protected String fetchSortingColumn(String orderByColumnVal) {
		String orderByColumnValue = "";

		switch (orderByColumnVal) {
		case "Request ID":
			orderByColumnValue = "PAYMENT_REQUEST_ID";
			break;
		case "Request Date":
			orderByColumnValue = "CREATE_TIMESTAMP";
			break;
		case "Request Type":
			orderByColumnValue = "PAYMENT_TYPE_CD";
			break;
		case "Payer":
			orderByColumnValue = "PAYER_PAYEE_SRC_ID";
			break;
		case "Payee":
			orderByColumnValue = "PAYEE_PAYEE_SRC_ID";
			break;
		case "Country":
			orderByColumnValue = "Country";
			break;
		case "Currency":
			orderByColumnValue = "PAYEE_CURRENCY";
			break;
		case "Amount":
			orderByColumnValue = "PAYEE_AMOUNT";
			break;
		case "Value Date":
			orderByColumnValue = "PAYMENT_DATE";
			break;
		case "Requester":
			orderByColumnValue = "CREATE_USER";
			break;
		case "Assigned to":
			orderByColumnValue = "ASSIGNED_TO";
			break;
		case "Status":
			orderByColumnValue = "DISPLAY_NAME";
			break;

		case "Payment Type Code":
			orderByColumnValue = "REQUEST_TYPE_CODE";
			break;

		default:
			orderByColumnValue = "PAYMENT_REQUEST_ID";
		}
		return orderByColumnValue;
	}

	protected void paymentListFilter(PaginatedResultList paginatedResultList, Map<String, String> searchMap) {
		if (null != paginatedResultList.getRequestId() && !("").equalsIgnoreCase(paginatedResultList.getRequestId())) {
			// Request Id
			searchMap.put("request_Id", paginatedResultList.getRequestId());
		}

		if (null != paginatedResultList.getRequestDate()
				&& !("").equalsIgnoreCase(paginatedResultList.getRequestDate())) {
			// Request Date
			searchMap.put("request_Date", "'" + paginatedResultList.getRequestDate() + "'");
		}

		if (null != paginatedResultList.getValueDate() && !("").equalsIgnoreCase(paginatedResultList.getValueDate())) {
			// Value Date
			searchMap.put("value_Date", "'" + paginatedResultList.getValueDate() + "'");
		}

		if (paginatedResultList.getRequestType() != null
				&& !("").equalsIgnoreCase(paginatedResultList.getRequestType())) {
			List<String> requestType = new ArrayList<String>();

			Scanner scan = new Scanner(paginatedResultList.getRequestType());
			scan.useDelimiter("-");
			while (scan.hasNext()) {
				requestType.add(scan.next());
			}

			searchMap.put("ES_Desc", "'" + requestType.get(0).toString().trim() + "'");
			searchMap.put("PAYMENT_TYPE_DESC", "'" + requestType.get(1).toString().trim() + "'");

		}
		 if (null != paginatedResultList.getEnterpriseDesc() && !("").equalsIgnoreCase(paginatedResultList.getEnterpriseDesc()))
		 {
			 searchMap.put("ES_Desc", "'"+paginatedResultList.getEnterpriseDesc()+"'");
		 }
		 
		 if (null != paginatedResultList.getPaymentType() && !("").equalsIgnoreCase(paginatedResultList.getPaymentType()))
		 {
			 searchMap.put("PAYMENT_TYPE_DESC", "'"+paginatedResultList.getPaymentType()+"'");
		 }

		if (null != paginatedResultList.getPayeeDescripton()
				&& !("").equalsIgnoreCase(paginatedResultList.getPayeeDescripton())) {
			// Payee
			List<String> payeeDetails = new ArrayList<String>();
			Scanner scan = new Scanner(paginatedResultList.getPayeeDescripton());
			scan.useDelimiter("/");
			while (scan.hasNext()) {
				payeeDetails.add(scan.next());
			}
				
			
				searchMap.put("payeeSrcId", "'" + payeeDetails.get(0).trim()+ "'");
			searchMap.put("payeeMdmGoldId", "'" + payeeDetails.get(1).trim() + "'");
			
			searchMap.put("payeeMdmLeName", "'" + payeeDetails.get(2).trim() + "'");
			searchMap.put("payeeDescription", paginatedResultList.getPayeeDescripton());
			if(searchMap.get("payeeSrcId").equalsIgnoreCase("''"))
			{
				searchMap.put("payeeSrcId", null);
			}
			
			if(searchMap.get("payeeMdmGoldId").equalsIgnoreCase("''"))
			{
				searchMap.put("payeeMdmGoldId", null);
			}
		}

		if (null != paginatedResultList.getPayerDescription()
				&& !("").equalsIgnoreCase(paginatedResultList.getPayerDescription())) {
			// Payer
			List<String> payerDetails = new ArrayList<String>();
			Scanner scan = new Scanner(paginatedResultList.getPayerDescription());
			scan.useDelimiter("/");
			while (scan.hasNext()) {
				payerDetails.add(scan.next());
			}
			searchMap.put("payerSrcId", "'" + payerDetails.get(0).trim()+ "'");
			searchMap.put("payerMdmGoldId", "'" + payerDetails.get(1).trim() + "'");
			searchMap.put("payerMdmLeName", "'" + payerDetails.get(2).trim() + "'");
			searchMap.put("payerDescription", "'" + paginatedResultList.getPayerDescription() + "'");
		}

		if (null != paginatedResultList.getPayeeBankCountry()
				&& !("").equalsIgnoreCase(paginatedResultList.getPayeeBankCountry())) {
			// Country
			searchMap.put("country", "'" + paginatedResultList.getPayeeBankCountry() + "'");
		}

		if (null != paginatedResultList.getPayeeAmount()
				&& !("").equalsIgnoreCase(paginatedResultList.getPayeeAmount())) {
			// Amount
			searchMap.put("amount", "'" + paginatedResultList.getPayeeAmount() + "'");
		}

		if (paginatedResultList.getPayeeCurrency() != null
				&& !("").equalsIgnoreCase(paginatedResultList.getPayeeCurrency())) {
			searchMap.put("currency", "'" + paginatedResultList.getPayeeCurrency().toString() + "'");
		}
		if (paginatedResultList.getRequester() != null && !("").equalsIgnoreCase(paginatedResultList.getRequester())) {
			searchMap.put("requester", "'%" + paginatedResultList.getRequester().toString() + "%'");
		}
		if (paginatedResultList.getAssignedTo() != null
				&& !("").equalsIgnoreCase(paginatedResultList.getAssignedTo())) {
			searchMap.put("assigned_To", "'%" + paginatedResultList.getAssignedTo().toString() + "%'");
		}
		if (paginatedResultList.getStatus() != null && !("").equalsIgnoreCase(paginatedResultList.getStatus())) {
			searchMap.put("status", "'" + paginatedResultList.getStatus().trim() + "'");
		}

		if ("Approval".equalsIgnoreCase(paginatedResultList.getPageType())) {
			paginatedResultList.setSSO(null);// Add by Hersh
			searchMap.put(PaymentRequestConstants.DISPLAY_NAME, "'Submitted'");
		} else {
			if ("Prepare".equalsIgnoreCase(paginatedResultList.getPageType())) {
				searchMap.put(PaymentRequestConstants.DISPLAY_NAME, "'Approved'");
				paginatedResultList.setSSO(null);// Add by Hersh
			} else {
				if ("Release".equalsIgnoreCase(paginatedResultList.getPageType())) {
					searchMap.put(PaymentRequestConstants.DISPLAY_NAME,
							"'Prepared'");
					paginatedResultList.setSSO(null);// Add by Hersh
				} else {
					if ("Confirmation".equalsIgnoreCase(paginatedResultList.getPageType())){
						searchMap.put(PaymentRequestConstants.DISPLAY_NAME,
								"'Released','Payment Delivered','Confirmed','Pending Confirmation', Payment Delivery Failed");
						paginatedResultList.setSSO(null);
					}
				}
			}
		}

	}

	protected void addUserFilters(Map<String, String> searchMap, String pageType, User user) {

		String caseType = pageType == null ? "default" : pageType;

		switch (caseType.toUpperCase()) {

		case "APPROVAL":
			fetchApproval(searchMap, user);
			break;

		case "PREPARE":
			fetchPrepare(searchMap, user);
			break;

		case "RELEASE":
			fetchRelease(searchMap, user);
			break;

		default:
			break;
		}

	}

	private void fetchApproval(Map<String, String> searchMap, User user) {
		
		Set<String> requestTypeList = null;
		fetchBusiness(searchMap, user);
		paymentTypeList = MyPaymentsUtil.fetchPaymentTypesForUser(user.getFineGrainInfo());
		if (!CollectionUtils.isEmpty(paymentTypeList)) {
			searchMap.put("payment_type", StringUtils.join(paymentTypeList, ","));
		}
		
		requestTypeList = MyPaymentsUtil.fetchRequestTypesForUser(user.getFineGrainInfo());
		if (!CollectionUtils.isEmpty(requestTypeList)) {
			searchMap.put("request_type", StringUtils.join(requestTypeList, ","));
		}
	}

	private void fetchPrepare(Map<String, String> searchMap, User user) {
		fetchBusiness(searchMap, user);
		tCodeSvcList = MyPaymentsUtil.fetchTcodeServiceCenter(user.getFineGrainInfo());
		if (!CollectionUtils.isEmpty(tCodeSvcList)) {
			searchMap.put("tcode_svc_list", StringUtils.join(tCodeSvcList, ","));
		}

	}

	private void fetchRelease(Map<String, String> searchMap, User user) {
		fetchBusiness(searchMap, user);
		tCodeSvcList = MyPaymentsUtil.fetchTcodeServiceCenter(user.getFineGrainInfo());
		if (!CollectionUtils.isEmpty(tCodeSvcList)) {
			searchMap.put("tcode_svc_list", StringUtils.join(tCodeSvcList, ","));
		}

	}

	private void fetchBusiness(Map<String, String> searchMap, User user) {
		businesslist = MyPaymentsUtil.fetchBusinessesForUser(user.getFineGrainInfo());
		if (!CollectionUtils.isEmpty(businesslist) && !businesslist.contains("ALL")) {
			searchMap.put("business_name", StringUtils.join(businesslist, ","));
		}

		subBusinessList = MyPaymentsUtil.fetchSubBusinessesForUser(user.getFineGrainInfo());
		if (!CollectionUtils.isEmpty(subBusinessList) && !subBusinessList.contains("ALL")) {
			searchMap.put("sub_business_name", StringUtils.join(subBusinessList, ","));
		}
	}
}
