/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mypayments.dao.PaymentVendorDaoImpl;
import com.ge.treasury.mypayments.domain.PaymentVendorBankAct;
import com.ge.treasury.mypayments.utils.PaymentLogger;

/**
 * Payment Vendor Controller Class
 * 
 * @author MyPayments Dev Team
 * 
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class PaymentVendorController {
    
    @Autowired
    private PaymentVendorDaoImpl vendorDao;

    /**
     * Get Vendor Bank Account list by filter - Free Text
     * 
     * @param filterStr
     * @return
     */
    @RequestMapping(value = "/getVendorBankActFilter", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public List<PaymentVendorBankAct> getVendorBankActByFilter(
            @RequestParam(value = "filter", required = true) final List<String> filters) {
        PaymentLogger.logInfo(this, "filter: " + filters);

        return vendorDao.findVendorAccountsByFilter(filters);
    }

    /**
     * Get Vendor Bank Account list by criteria - Multiple parameters
     * 
     * @param request
     * @return
     */
    @RequestMapping(value = "/getVendorBankActAdvanced", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public List<PaymentVendorBankAct> getVendorBankActByFilter(
            @RequestParam(value = "vendorName", required = false) final List<String> vendorName,
            @RequestParam(value = "vendorBankAct", required = false) final String vendorBankAct,
            @RequestParam(value = "vendorBankCurr", required = false) final String vendorBankCurr,
            @RequestParam(value = "vendorBankCountry", required = false) final String vendorBankCountry) {

        final Map<String, String> params = new HashMap<String, String>();
        
        if(vendorBankAct!=null) {
            params.put("vendorBankAct", vendorBankAct);
        }
        
        if(vendorBankCurr!=null) {
            params.put("vendorBankCurr", vendorBankCurr);
        }
        
        if(vendorBankCountry!=null) {
            params.put("vendorBankCountry", vendorBankCountry);
        }
        
        return vendorDao.findVendorAccountsByCriteria(params, vendorName);
    }
}
