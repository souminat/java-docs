package com.ge.treasury.mypayments.controllers;

import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ge.treasury.mypayments.constants.PaymentRequestConstants;
import com.ge.treasury.mypayments.constants.WorkflowConstants;
import com.ge.treasury.mypayments.domain.BankIntermediary;
import com.ge.treasury.mypayments.domain.ManualConfirmation;
import com.ge.treasury.mypayments.domain.PaymentReference;
import com.ge.treasury.mypayments.domain.PaymentRequest;
import com.ge.treasury.mypayments.domain.RequestActivity;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.DBException;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.ge.treasury.mypayments.validation.PaymentRequestValidator;

@Controller
@RequestMapping("/api/trigger-workflows/v1")
public class WorkFlowActionController extends BaseController {

	@RequestMapping(value = "/preparePaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest preparePaymentRequest(HttpServletRequest request, @RequestBody PaymentRequest source)
			throws ValidationFailedException {
		User user = (User) request.getSession().getAttribute("User");
		Date today = new Date();

		BindingResult errors = new BeanPropertyBindingResult(source, WorkflowConstants.PAY_REQ);
		PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

		validator.validatePaymentRequestForPrepare(errors, source);

		if (errors.hasErrors()) {
			throw new ValidationFailedException(errors);
		} else {
			PaymentRequest dbPaymentRequest = this.paymentService.fetchPaymentRequestByID(source.getRequestId());
			if (null != dbPaymentRequest && "APPROVED".equalsIgnoreCase(dbPaymentRequest.getPaymentStatusCode())) {

				// Save Date
				boolean paymentDateChanged = source.equals(dbPaymentRequest);

				if (paymentDateChanged)
					this.paymentService.updatePrepareDate(source, user);

				// Intermediaries added?
				addIntermediary(source, user);
				
				//Additonal Docs?
				this.paymentService.persistAdditionalDocs(source, user);
				
				// Insert references if any?

				List<PaymentReference> references = source.getReferences();
				if (!CollectionUtils.isEmpty(references)) {
					this.paymentService.insertPaymentReferences(references, user, source.getRequestId());
				}

				RequestActivity activity = createRequestActivity(user, today, source,
						WorkflowConstants.WRKFLW_STS_APPROVED, "WRKFLW_STS_PREPARED", "");
				if (!CollectionUtils.isEmpty(source.getRequestActivities())) {
					// Sonar Violation Fix : Math operands should be cast before
					// assignment
					activity.setSequenceNumber(source.getRequestActivities().size() + 1L);
				}
				source.setLastUpdateDate(today);
				source.setLastUpdateUser(user.getSso());
				source.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_PREPARED);

				paymentService.processApprovalRequest(source, user, activity);

				creditAudit(user, source);

			} else {
				// Not applicable for Prepare
			}
		}

		return source;
	}

	@RequestMapping(value = "/prepareReleaseRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest createReleaseRequest(HttpServletRequest request, @RequestBody PaymentRequest source)
			throws ValidationFailedException {
		User user = (User) request.getSession().getAttribute("User");
		Date today = new Date();

		BindingResult errors = new BeanPropertyBindingResult(source, WorkflowConstants.PAY_REQ);
		PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

		validator.validatePaymentRequestForPrepare(errors, source);

		if (errors.hasErrors()) {
			throw new ValidationFailedException(errors);
		} else {
			PaymentRequest dbPaymentRequest = this.paymentService.fetchPaymentRequestByID(source.getRequestId());
			if (null != dbPaymentRequest && "PREPARED".equalsIgnoreCase(dbPaymentRequest.getPaymentStatusCode())) {

				// Save Date
				boolean paymentDateChanged = source.equals(dbPaymentRequest);

				if (paymentDateChanged){
					this.paymentService.updatePrepareDate(source, user);
					dbPaymentRequest.setPaymentDate(source.getPaymentDate());
					dbPaymentRequest.setPaymentSystem(source.getPaymentSystem());
				
					try {
							paymentService.sendPaymentRequestNotification(source, user,source.getPaymentStatusCode() , PaymentRequestConstants.VALUATION_DATE_CHANGE_NOTIFICATION);
					} catch (AddressException e) {
							PaymentLogger.logError(this, e.getMessage(), e);
							throw new SystemException("Address Validation Failed"+e);
					} catch (MessagingException e) {							
						PaymentLogger.logError(this, e.getMessage(), e);
						throw new SystemException("Email notification exception"+e);
					}
					
				}
				
				//Additonal Docs?
				this.paymentService.persistAdditionalDocs(source, user);

				RequestActivity activity = createRequestActivity(user, today, source,
						WorkflowConstants.WRKFLW_STS_APPROVED, "WRKFLW_STS_RELEASED", "");
				if (!CollectionUtils.isEmpty(source.getRequestActivities())) {
					// Sonar Violation Fix : Math operands should be cast before
					// assignment
					activity.setSequenceNumber(source.getRequestActivities().size() + 1L);
				}
				source.setLastUpdateDate(today);
				source.setLastUpdateUser(user.getSso());
				source.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_RELEASED);

				paymentService.processApprovalRequest(source, user, activity);

				routerService.routePaymentInformation(dbPaymentRequest, user);

				creditAudit(user, source);

			} else {
				// Not applicable for Prepare
			}
		}

		return source;
	}

	@RequestMapping(value = "/rejectPaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public PaymentRequest rejectPrepareRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest)
			throws ValidationFailedException {

		User user = (User) request.getSession().getAttribute("User");
		Date today = new Date();
		PaymentRequest rejectedPaymenRequest = null;
		RequestActivity requestActivity = null;
		try {
			BindingResult errors = new BeanPropertyBindingResult(paymentRequest, WorkflowConstants.PAY_REQ);
			PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

			validator.validatePaymentRequestForRejection(errors, paymentRequest);

			if (errors.hasErrors()) {
				throw new ValidationFailedException(errors);
			} else {
				paymentRequest.setLastUpdateDate(today);
				paymentRequest.setLastUpdateUser(user.getSso());
				paymentRequest.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_REJECTED);
				requestActivity = createRequestActivity(user, today, paymentRequest,
						WorkflowConstants.WRKFLW_STS_REJECTED, "WRKFLW_STS_REJECTED",
						paymentRequest.getRequestStatusId().getRejectCancelReason());
				if (!CollectionUtils.isEmpty(paymentRequest.getRequestActivities())) {
					// Sonar Violation Fix : Math operands should be cast before
					// assignment
					int count = this.paymentService.getRequestActivities(paymentRequest.getRequestId());
					requestActivity.setSequenceNumber(count + 1L);
				}
				rejectedPaymenRequest = paymentService.processRejectCancelRequest(paymentRequest, user,
						requestActivity);

				creditAudit(user, paymentRequest);
			}
		} catch (Exception e) {
			PaymentLogger.logError(this, "PaymentRequestController.rejectPaymentRequest()" + e.getMessage(), e);
			throw new SystemException(e);
		}
		return rejectedPaymenRequest;
	}

	/**
	 * Save confirmation Payment(confirmPaymentRequest)
	 * 
	 * @param
	 * @param
	 * @return
	 * @throws ValidationFailedException
	 * 
	 */
	@RequestMapping(value = "/saveManualConfirmation", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ManualConfirmation saveManualConfirmation(HttpServletRequest request,
			@RequestBody ManualConfirmation confirmPayment) throws ValidationFailedException {
		// *****************************************************************************************
		// insert into confirm table
		// Insert an activity in Request Activity
		// Update the Paymentrequest in accordance with paymentrequestid as
		// status completed
		// WorkFlow Status Code as Confirmed
		// *****************************************************************************************
		Date today = new Date();
		PaymentRequest paymentRequest = null;
		RequestActivity requestActivity = new RequestActivity();
		try {
			User user = (User) request.getSession().getAttribute("User");

			confirmPayment.setBankStatusCode("WRKFLW_STS_CONFIRMED");
			confirmPayment.setCreateUser(user.getSso());
			confirmPayment.setCreateDate(today);
			confirmPayment.setLastUpdateUser(user.getSso());
			confirmPayment.setLastUpdateDate(today);
			paymentRequest.setManualConfirmation(confirmPayment);
			paymentRequest = new PaymentRequest();
			paymentRequest.setRequestId(confirmPayment.getPaymentRequestId());
			paymentRequest.setRequestActivities(confirmPayment.getRequestActivities());
			paymentRequest.setLastUpdateDate(today);
			paymentRequest.setLastUpdateUser(user.getSso());
			paymentRequest.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_CONFIRMED);
			requestActivity.setComments(confirmPayment.getComments());
			paymentRequest.setRequestStatusId(requestActivity);

			if (confirmPayment != null) {
				paymentService.saveManualConfirmation(confirmPayment);
				paymentRequest = paymentService.updatePayRequest(paymentRequest, user);
				requestActivity = createRequestActivity(user, today, paymentRequest,
						WorkflowConstants.WRKFLW_STS_CONFIRMED, "WRKFLW_STS_CONFIRMED", "");
				if (!CollectionUtils.isEmpty(paymentRequest.getRequestActivities())) {
					// Sonar Violation Fix : Math operands should be cast before
					// assignment
					int count = this.paymentService.getRequestActivities(paymentRequest.getRequestId());
					requestActivity.setSequenceNumber(count + 1L);
				}
				requestActivity = paymentService.saveworkFlowRequest(requestActivity, user);

				creditAudit(user, paymentRequest);
			}

		} catch (Exception e) {
			PaymentLogger.logError(this, e.getMessage(), e);
			throw new DBException("Unable to save payment confirmation ");
		}
		return confirmPayment;
	}

	@RequestMapping(value = "/cancelPaymentRequest", method = RequestMethod.POST, consumes = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String cancelPaymentRequest(HttpServletRequest request, @RequestBody PaymentRequest paymentRequest)
			throws ValidationFailedException {
		boolean cancelled = false;

		User user = (User) request.getSession().getAttribute("User");
		Date today = new Date();
		RequestActivity requestActivity = null;
		try {
			BindingResult errors = new BeanPropertyBindingResult(paymentRequest, WorkflowConstants.PAY_REQ);
			PaymentRequestValidator validator = new PaymentRequestValidator(messageValidator);

			validator.validatePaymentRequestForRejection(errors, paymentRequest);

			if (errors.hasErrors()) {
				throw new ValidationFailedException(errors);
			} else {
				paymentRequest.setLastUpdateDate(today);
				paymentRequest.setLastUpdateUser(user.getSso());
				paymentRequest.setPaymentStatusCode(WorkflowConstants.WRKFLW_STS_CANCELLED);
				requestActivity = createRequestActivity(user, today, paymentRequest,
						WorkflowConstants.WRKFLW_STS_CANCELLED, "WRKFLW_STS_CANCELLED",
						paymentRequest.getRequestStatusId().getRejectCancelReason());
				if (!CollectionUtils.isEmpty(paymentRequest.getRequestActivities())) {
					// Sonar Violation Fix : Math operands should be cast before
					// assignment
					int count = this.paymentService.getRequestActivities(paymentRequest.getRequestId());
					requestActivity.setSequenceNumber(count + 1L);
				}
				paymentService.processRejectCancelRequest(paymentRequest, user, requestActivity);

				creditAudit(user, paymentRequest);

			}
		} catch (Exception e) {
			PaymentLogger.logError(this, "PaymentRequestController.rejectPaymentRequest()" + e.getMessage(), e);
			throw new SystemException(e);
		}

		return String.valueOf(cancelled);
	}

	private void creditAudit(User user, PaymentRequest paymentRequest) {
		PaymentRequest oldObject = new PaymentRequest();
		try {
			auditService.createAudit(user, oldObject, paymentRequest);
		} catch (InterruptedException e) {
			PaymentLogger.logError(this, "WorkFlowActionController:: creditAudit " + e.getMessage(), e);
			throw new SystemException(e);
		}
	}
	
	private void addIntermediary(PaymentRequest source, User user) {
		List<BankIntermediary> intermediariesList = source.getIntermediaries();
		if (!CollectionUtils.isEmpty(intermediariesList)) {
			for (BankIntermediary bi : intermediariesList) {
				bi.setpaymentRequestId(source.getRequestId());
				this.paymentService.insertBankIntermerdiary(bi, user);
			}
		}
	}
}
