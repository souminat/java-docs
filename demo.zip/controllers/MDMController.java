/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.treasury.mypayments.constants.*;
import com.ge.treasury.mypayments.controllers.model.PaginatedResultList;
import com.ge.treasury.mypayments.corems.domain.FineGrainESResponse;
import com.ge.treasury.mypayments.corems.domain.FineGrainResponseData;
import com.ge.treasury.mypayments.domain.BusinessParent;
import com.ge.treasury.mypayments.domain.CoreBusiness;
import com.ge.treasury.mypayments.domain.EnterpriseStandards;
import com.ge.treasury.mypayments.domain.MDMBankAccount;
import com.ge.treasury.mypayments.domain.MDMBankBranch;
import com.ge.treasury.mypayments.domain.MDMBankLocation;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ge.treasury.mypayments.exceptions.BusinessException;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.ge.treasury.mypayments.domain.PayerPayee;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.utils.MyPaymentsUtil;
import com.ge.treasury.mypayments.utils.StringHelper;
import com.google.gson.JsonObject;

/**
 * REST services for mdm functionality
 *
 * @author MyPayments Dev Team
 *
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class MDMController extends BaseController implements MDMConstants {

	private static final String FORMAT_PATTERN = "dd-MM-yyyy";
	private static final Format DATE_FORMAT;

	static {
		final SimpleDateFormat format = new SimpleDateFormat(FORMAT_PATTERN);
		format.setLenient(false);
		DATE_FORMAT = format;
	}

	@Value("${mdm.ms.baseUrl}")
	private String mdmBaseUrl;

	@Value("${mdm.ms.currency}")
	private String currencyUrl;

	@Value("${mdm.ms.bankBranch}")
	private String bankBranchUrl;

	@Value("${mdm.ms.bankAccount}")
	private String accountUrl;

	@Value("${mdm.ms.security}")
	private String mdmSecurity;

	@Value("${mdm.ms.holiday}")
	private String holidayUrl;

	@Value("${mdm.ms.country}")
	private String countryUrl;

	@Value("${mdm.ms.business}")
	private String businessUrl;

	@Value("${mdm.ms.marketData}")
	private String marketDataUrl;

	@Value("${mdm.ms.le}")
	private String leUrl;
	
	@Value("${finegrain-auth-url-get-espayments}")
	private String esDataUrl;

	@Autowired
	private OAuth2RestOperations mdmServiceRestTemplate;

	private static Logger logger = LogManager.getLogger(MDMController.class);

	/**
	 * Controller to get MDM currency list
	 *
	 * @param request
	 *
	 * @return String - JSON results from the MDM Service Rest call
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMCurrency", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public String getMDMCurrency(final HttpServletRequest request) {

		setLogPerfMessage(request, "getMDMCurrency");

		final StringBuilder filter = new StringBuilder();

		filter.append("(");

		filter.append(UPPER_2 + CURRENCY_CURRENCY_STATUS + UPPER_1 + ACTIVE + "')");

		filter.append(")");

		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());

		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + currencyUrl, HttpMethod.GET, false);

		return jsonOutput;
	}

	/**
	 * Controller to get MDM COUTNRY list
	 *
	 * @param request
	 *
	 * @return String - JSON results from the MDM Service Rest call
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMCountry", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public String getMDMCountry(final HttpServletRequest request) {

		setLogPerfMessage(request, "getMDMCountry");

		final StringBuilder filter = new StringBuilder();

		filter.append("(");

		filter.append(UPPER_2 + COUNTRY_STATUS + ") = UPPER('" + ACTIVE + "')");

		filter.append(")");
		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());
		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + countryUrl, HttpMethod.GET, false);

		return jsonOutput;
	}

	/**
	 * Controller to get MDM Bank Details
	 *
	 * @param request
	 * @param mdmId
	 *
	 * @return String - JSON results from the MDM Service Rest call
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMBankBranch", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public MDMBankBranch getMDMBankBranch(final HttpServletRequest request,
			@RequestParam(value = "mdmId", required = true) final String mdmId) {

		setLogPerfMessage(request, "getMDMBankAccount");

		final StringBuilder filter = new StringBuilder();

		filter.append("(");
		MDMBankBranch mdmBankBranch = new MDMBankBranch();
		try {
		if (mdmId != null) {
			filter.append(UPPER_2 + MDMBankBranchConstants.MDM_ID + ") = UPPER('" + URLDecoder.decode(mdmId.toUpperCase(), "UTF-8") + "')");
		}

		filter.append(")");

		String jsonOutput = callMDM(filter.toString(), mdmBaseUrl + bankBranchUrl, HttpMethod.GET, false,
				this.mdmServiceRestTemplate);

		

		
			ObjectMapper jacksonMapper = new ObjectMapper();
			jacksonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			jacksonMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

			JSONObject jsonObject = new JSONObject(jsonOutput);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() > 0) {
				JSONObject item = elements.getJSONObject(0);
				mdmBankBranch = jacksonMapper.readValue(item.toString(), mdmBankBranch.getClass());
			}
		} catch (IOException ioException) {
			logger.error("IOException occured while hitting MDM - getMDMBankBranch ", ioException);
		} catch (Exception exception) {
			logger.error("Exception occured while hitting MDM - getMDMBankBranch ", exception);
		}

		return mdmBankBranch;
	}

	/**
	 * Controller to get MDM business list
	 *
	 * @return String
	 */
	@Cacheable(value = "dynamic", key = "#root.methodName + #code")
	@RequestMapping(value = "/getMDMBusiness", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String getMDMBusiness(HttpServletRequest request) throws BusinessException {

		String busSub = request.getParameter("busSub");
		String startIndex = request.getParameter("start_index");
		String count = request.getParameter("count");
		String sortBy = request.getParameter("sortBy");
		String sortOrder = request.getParameter("sortOrder");

		setLogPerfMessage(request, "searchMDMBankAccounts");
		HashMap<String, String> params = new HashMap<>();
		
		try {
			final StringBuilder filter = new StringBuilder();
			filter.append("(");

			if (busSub != null) {
				filter.append(UPPER_2 + BUSINESS_BUSINESS_ACCOUNT_GROUP + UPPER_3 + URLDecoder.decode(busSub, "UTF-8") + "%')");
				filter.append(AND_STRING);
				filter.append(UPPER_2 + BUSINESS_SUBBUSINESS_ACCOUNT_GROUP + UPPER_3 + URLDecoder.decode(busSub , "UTF-8")+ "%')");
			}

			if (filter.length() > 1) {
				filter.append(AND_STRING);
			}
			filter.append(UPPER_2 + BUS_ACCT_GRP_STATUS + ") = UPPER('" + ACTIVE + "')");

			if (filter.length() > 1) {
				filter.append(AND_STRING);
			}
			filter.append(UPPER_2 + SUB_BUS_ACCT_GRP_STATUS + ") = UPPER('" + ACTIVE + "')");

			filter.append(")");

			
			params.put(FILTER_CONST, filter.toString());
			// TODO: Change $totalCountRequired = true when MDM fix the error on
			// their end
			params.put(TOTAL_COUNT_REQUIRED, "false");
			if (startIndex != null) {
				params.put("$start_index", startIndex);
			}
			if (count != null) {
				params.put("$count", count);
			}
			if (null != sortBy && null != sortOrder) {
				params.put("$orderby", sortBy + "+" + sortOrder);
			}
			
		} catch (Exception e) {
			logger.error("Business Decode error",e);
		}
		

		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + businessUrl, HttpMethod.GET, false);
		
		/*//Apply Filters and security
				ObjectMapper mapper = new ObjectMapper();
				try {
					BusinessParent obj = mapper.readValue(jsonOutput, BusinessParent.class);
					User user = (User) request.getSession().getAttribute("User");
					Set<String> businessList = MyPaymentsUtil.fetchBusinessesForUser(user.getFineGrainInfo());
					Set<String> subBusinessList = MyPaymentsUtil.fetchSubBusinessesForUser(user.getFineGrainInfo());
					
					List<String> tempList = new ArrayList<String>();
					List<String> tempSubBusinessList = new ArrayList<String>();
					
					if(!CollectionUtils.isEmpty(businessList)){
						for (Iterator iterator = businessList.iterator(); iterator.hasNext();) {
							String string = (String) iterator.next();
							tempList.add(string.replaceAll("'", ""));
						}
					}
					
					if(!CollectionUtils.isEmpty(subBusinessList)){
						for (Iterator iterator = subBusinessList.iterator(); iterator.hasNext();) {
							String string = (String) iterator.next();
							tempSubBusinessList.add(string.replaceAll("'", ""));
						}
					}
					
					
					//Run security for Business
					List<CoreBusiness> businessElements = obj.getElements();
					if(!tempList.contains("ALL") && !CollectionUtils.isEmpty(businessElements)){
							for (Iterator iterator = businessElements.iterator(); iterator.hasNext();) {
								CoreBusiness coreBusiness = (CoreBusiness) iterator.next();
								if(!tempList.contains(coreBusiness.getBus_acct_grp().toUpperCase())){
									iterator.remove();
								}
						}
						jsonOutput = mapper.writeValueAsString(obj);
					}
					
					//Run security for sub-business
					List<CoreBusiness> subBusinessElements = obj.getElements();
					if (!tempSubBusinessList.contains("ALL") && !CollectionUtils.isEmpty(subBusinessElements)) {
						obj = mapper.readValue(jsonOutput, BusinessParent.class);

						for (Iterator iterator = subBusinessElements.iterator(); iterator.hasNext();) {
							CoreBusiness coreBusiness = (CoreBusiness) iterator.next();
							if (!tempList.contains(coreBusiness.getSub_bus_acct_grp().toUpperCase())) {
								iterator.remove();
							}

						}
						jsonOutput = mapper.writeValueAsString(obj);
					}
				} catch (IOException e) {
					logger.error("Error in applying security for MDM business for ERP batch payment" + e);
				}*/
		return jsonOutput;
	}
	
	@Cacheable(value = "dynamic", key = "#root.methodName + #code")
	@RequestMapping(value = "/getMDMBusinessERP", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody String getMDMBusinessERP(HttpServletRequest request) throws BusinessException {

		String busSub = request.getParameter("busSub");
		String startIndex = request.getParameter("start_index");
		String count = request.getParameter("count");
		String sortBy = request.getParameter("sortBy");
		String sortOrder = request.getParameter("sortOrder");

		setLogPerfMessage(request, "searchMDMBankAccounts");
		HashMap<String, String> params = new HashMap<>();
		
		try {
			final StringBuilder filter = new StringBuilder();
			filter.append("(");

			if (busSub != null) {
				filter.append(UPPER_2 + BUSINESS_BUSINESS_ACCOUNT_GROUP + UPPER_3 + URLDecoder.decode(busSub, "UTF-8") + "%')");
				filter.append(AND_STRING);
				filter.append(UPPER_2 + BUSINESS_SUBBUSINESS_ACCOUNT_GROUP + UPPER_3 + URLDecoder.decode(busSub , "UTF-8")+ "%')");
			}

			if (filter.length() > 1) {
				filter.append(AND_STRING);
			}
			filter.append(UPPER_2 + BUS_ACCT_GRP_STATUS + ") = UPPER('" + ACTIVE + "')");

			if (filter.length() > 1) {
				filter.append(AND_STRING);
			}
			filter.append(UPPER_2 + SUB_BUS_ACCT_GRP_STATUS + ") = UPPER('" + ACTIVE + "')");

			filter.append(")");

			
			params.put(FILTER_CONST, filter.toString());
			// TODO: Change $totalCountRequired = true when MDM fix the error on
			// their end
			params.put(TOTAL_COUNT_REQUIRED, "false");
			if (startIndex != null) {
				params.put("$start_index", startIndex);
			}
			if (count != null) {
				params.put("$count", count);
			}
			if (null != sortBy && null != sortOrder) {
				params.put("$orderby", sortBy + "+" + sortOrder);
			}
			
		} catch (Exception e) {
			logger.error("Error in Decoding :: getMDMBusinessERP ", e);
		}
		

		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + businessUrl, HttpMethod.GET, false);
		
		//Apply Filters and security
		ObjectMapper mapper = new ObjectMapper();
		try {
			BusinessParent obj = mapper.readValue(jsonOutput, BusinessParent.class);
			User user = (User) request.getSession().getAttribute("User");
			Set<String> businessList = MyPaymentsUtil.fetchBusinessesForUser(user.getFineGrainInfo());
			Set<String> subBusinessList = MyPaymentsUtil.fetchSubBusinessesForUser(user.getFineGrainInfo());
			
			List<String> tempList = new ArrayList<String>();
			List<String> tempSubBusinessList = new ArrayList<String>();
			
			if(!CollectionUtils.isEmpty(businessList)){
				for (Iterator iterator = businessList.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					tempList.add(string.replaceAll("'", ""));
				}
			}
			
			if(!CollectionUtils.isEmpty(subBusinessList)){
				for (Iterator iterator = subBusinessList.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					tempSubBusinessList.add(string.replaceAll("'", ""));
				}
			}
			
			
			//Run security for Business
			List<CoreBusiness> businessElements = obj.getElements();
			if(!tempList.contains("ALL") && !CollectionUtils.isEmpty(businessElements)){
					for (Iterator iterator = businessElements.iterator(); iterator.hasNext();) {
						CoreBusiness coreBusiness = (CoreBusiness) iterator.next();
						if(!tempList.contains(coreBusiness.getBus_acct_grp().toUpperCase())){
							iterator.remove();
						}
				}
				jsonOutput = mapper.writeValueAsString(obj);
			}
			
			//Run security for sub-business
			List<CoreBusiness> subBusinessElements = obj.getElements();
			if (!tempSubBusinessList.contains("ALL") && !CollectionUtils.isEmpty(subBusinessElements)) {
				obj = mapper.readValue(jsonOutput, BusinessParent.class);

				for (Iterator iterator = obj.getElements().iterator(); iterator.hasNext();) {
					CoreBusiness coreBusiness = (CoreBusiness) iterator.next();
					if (!tempSubBusinessList.contains(coreBusiness.getSub_bus_acct_grp().toUpperCase())) {
						iterator.remove();
					}

				}
				jsonOutput = mapper.writeValueAsString(obj);
			}
		} catch (IOException e) {
			logger.error("Error in applying security for MDM business for ERP batch payment" + e);
		}
		
		return jsonOutput;
	}

	/**
     * Controller to get MDM Bank Account
     *
     * @param request
     *
     * @return String - JSON results from the MDM Service Rest call
     */
    @Cacheable(value = "static", key = "#root.methodName")
    @RequestMapping(value = "/searchMDMBankAccounts", method = RequestMethod.GET, produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    @JsonIgnoreProperties(ignoreUnknown = true)
    // 200
    public PaginatedResultList<MDMBankAccount> searchMDMBankAccounts(final HttpServletRequest request) {
        String tCode = request.getParameter("tCode");
        String country = request.getParameter("country");
        String currency = request.getParameter("currency");
        String companyCode = request.getParameter("companyCode");
        String goldId = request.getParameter("goldId");
        String business = request.getParameter("business");
        String subBusiness = request.getParameter("subBusiness");
        String startIndex = request.getParameter("start_Index");
        String count = request.getParameter("count");
        String sortBy = request.getParameter("sortBy");
        String sortOrder = request.getParameter("sortOrder");

        setLogPerfMessage(request, "searchMDMBankAccounts");

        final StringBuilder filter = new StringBuilder();

        try {
            filter.append("(");

            if(tCode != null){
                filter.append("UPPER(" + MDMBankAccountConstants.tcode  + ") like UPPER('%" + URLDecoder.decode(tCode, "UTF-8")  + "%')");
            }

            if(country != null){
                if(filter.length() > 1){
                    filter.append(" and ");
                }
                filter.append("UPPER(" + MDMBankAccountConstants.country_code  + ") = UPPER('" + URLDecoder.decode(country, "UTF-8")  + "')");
            }

            if(currency != null){
                if(filter.length() > 1){
                    filter.append(" and ");
                }
                filter.append("UPPER(" + MDMBankAccountConstants.currency_code  + ") like UPPER('" + URLDecoder.decode(currency, "UTF-8")  + "')");
            }

            if(companyCode != null){
                if(filter.length() > 1){
                    filter.append(" and ");
                }
                filter.append("UPPER(" + MDMBankAccountConstants.company_code  + ") like UPPER('%" + URLDecoder.decode(companyCode, "UTF-8")  + "%')");
            }

            if(goldId != null){
                if(filter.length() > 1){
                    filter.append(" and ");
                }
                filter.append("UPPER(" + MDMBankAccountConstants.gold_le_code  + ") = UPPER('" + URLDecoder.decode(goldId, "UTF-8")  + "')");
            }


            if(business != null){
                if(filter.length() > 1){
                    filter.append(" and ");
                }
                filter.append("UPPER(" + MDMBankAccountConstants.business_name  + ") = UPPER('" + URLDecoder.decode(business, "UTF-8")  + "')");

            }
            if(subBusiness != null){
                if(filter.length() > 1){
                    filter.append(" and ");
                }
                filter.append("UPPER(" + MDMBankAccountConstants.sub_business_name  + ") = UPPER('" + URLDecoder.decode(subBusiness, "UTF-8")  + "')");

            }
            if(filter.length() > 1) {
                filter.append(" and ");
            }
            filter.append("UPPER(" + MDMBankAccountConstants.account_status  + ") != UPPER('" + CLOSED + "')");


            filter.append(")");
        }catch (Exception e){
        	logger.error("Error in Decoding :: searchMDMBankAccounts ", e);
        }


        HashMap<String, String> params = new HashMap<>();
        params.put("$filter", filter.toString());
        params.put("$totalCountRequired", "true");
        if(startIndex != null){
            params.put("$start_index", startIndex);
        }
        if(count != null){
            params.put("$count", count);
        }
        if(null != sortBy && null != sortOrder){
            params.put("$orderby", sortBy + "+" + sortOrder);
        }

        String jsonOutput = callMDMDenodo(params, mdmBaseUrl + accountUrl, HttpMethod.GET, false);

        List<MDMBankAccount> mdmBankAccounts = new ArrayList<MDMBankAccount>();
        try {
            ObjectMapper jacksonMapper = new ObjectMapper();
            jacksonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            jacksonMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

            JSONObject jsonObject = new JSONObject(jsonOutput);

            JSONArray elements = jsonObject.getJSONArray("elements");
            Integer totalcount = new Integer(jsonObject.get("totalcount").toString());

            PaginatedResultList<MDMBankAccount> searchResults = new PaginatedResultList<>();
            mdmBankAccounts = jacksonMapper.readValue(elements.toString(), List.class);
            searchResults.setResultList(mdmBankAccounts);
            searchResults.setTotalRecords(totalcount);

            return searchResults;

        }catch (IOException ioException){
                logger.error("IOException occured while hitting MDMDenodo - searchMDMBankAccounts ", ioException);
        }catch (Exception exception){
                logger.error("Exception occured while hitting MDMDenodo - searchMDMBankAccounts ", exception);
        }


        return  null;
    }


	/**
	 * Controller to get MDM Bank Account
	 *
	 * @param request
	 *
	 * @return String - JSON results from the MDM Service Rest call
	 */
	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getMDMBankAccount", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public MDMBankAccount getMDMBankAccount(final HttpServletRequest request,
			@RequestParam(value = "tCode", required = true) final String tCode) {

		setLogPerfMessage(request, "getMDMBankAccount");

		final StringBuilder filter = new StringBuilder();
		MDMBankAccount mdmBankAccount = new MDMBankAccount();
		try {
		filter.append("(");

		if (tCode != null) {
			filter.append(UPPER_2 + MDMBankAccountConstants.tcode + ") = UPPER('" + URLDecoder.decode(tCode.toUpperCase(), "UTF-8") + "')");
		}

		filter.append(")");

		String jsonOutput = callMDM(filter.toString(), mdmBaseUrl + accountUrl, HttpMethod.GET, false,
				this.mdmServiceRestTemplate);
		

		
			ObjectMapper jacksonMapper = new ObjectMapper();
			jacksonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			jacksonMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

			JSONObject jsonObject = new JSONObject(jsonOutput);
			JSONArray elements = jsonObject.getJSONArray(ELEMENTS);
			if (elements.length() > 0) {
				JSONObject item = elements.getJSONObject(0);
				mdmBankAccount = jacksonMapper.readValue(item.toString(), mdmBankAccount.getClass());
			}
		} catch (IOException ioException) {
			logger.error("IOException occured while hitting MDM - getMDMBankAccount ", ioException);
		} catch (Exception exception) {
			logger.error("Exception occured while hitting MDM - getMDMBankAccount ", exception);
		}

		return mdmBankAccount;
	}

	/**
	 * @param jsonString
	 * @param url
	 * @param method
	 * @param validateResponse
	 * @param template
	 *
	 * @return String response from MDM service
	 */
	private String callMDM(final String jsonString, final String url, final HttpMethod method,
			final boolean validateResponse, final OAuth2RestOperations template) {

		final HttpEntity<String> entity;
		final HttpHeaders headers = new HttpHeaders();
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		final RestOperations ro;

		if (method == HttpMethod.POST) {

			headers.setContentType(MediaType.APPLICATION_JSON);
			entity = new HttpEntity<String>(jsonString, headers);

		} else {

			headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
			entity = new HttpEntity<String>(headers);

			final String paramName;

			if (template != null) {
				paramName = FILTER_CONST;
			} else {
				paramName = ValidationConstants.MDM_QUERY_PARAM;
			}

			builder.queryParam(paramName, jsonString);
			builder.queryParam(TOTAL_COUNT_REQUIRED, "true");
		}

		if ("true".equalsIgnoreCase(mdmSecurity) && template != null) {
			ro = template;
		} else {
			ro = new RestTemplate();
		}

		return executeCall(ro, builder, method, entity, validateResponse);

	}

	/**
	 * @param url
	 * @param method
	 * @param validateResponse
	 * @param template
	 *
	 * @return String response from MDM service
	 */
	private String callMDMDenodo(Map<String, String> params, final String url, final HttpMethod method,
			final boolean validateResponse/*
											 * , final OAuth2RestOperations
											 * template
											 */) {

		final HttpEntity<String> entity;
		final HttpHeaders headers = new HttpHeaders();
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		if(null!=params){
			for (String paramName : params.keySet()) {
				builder.queryParam(paramName, params.get(paramName));
			}
		}
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		entity = new HttpEntity<String>(headers);
		return executeCall(this.mdmServiceRestTemplate, builder, method, entity, validateResponse);

	}

	/**
	 * Helper method to execute the RestOperation for the microservices calls
	 *
	 * @param ro
	 * @param builder
	 * @param method
	 * @param entity
	 * @param validateResponse
	 *
	 * @return
	 */
	private String executeCall(final RestOperations ro, final UriComponentsBuilder builder, final HttpMethod method,
			final HttpEntity<String> entity, final boolean validateResponse) {
		try {
			final ResponseEntity<String> response = ro.exchange(builder.build().encode().toUri(), method, entity,
					String.class);

			final String responseBody;
			if (response.getStatusCode() == HttpStatus.OK) {
				responseBody = response.getBody();
				if (validateResponse) {
					validateJSONResponse(responseBody);
				}
			} else {
				throw new SystemException(
						ControllersConstants.MDM_ERROR + "ResponseStatusCode: " + response.getStatusCode());
			}

			return responseBody;
		} catch (final RestClientException e) {
			throw new SystemException(ControllersConstants.MDM_ERROR + "Error when connecting to the MDM Microservice",
					e);
		}
	}

	/**
	 * Validate the responseBoby by checking the Status
	 *
	 * @param responseBody
	 */
	private void validateJSONResponse(final String responseBody) {

		try {
			final JSONObject jsonObject = new JSONObject(responseBody);

			final JSONObject responseData = (JSONObject) jsonObject.get(ValidationConstants.JSON_GET_RESPONSEDATA);

			final Object message = responseData.get(ValidationConstants.JSON_GET_MESSAGE);
			final Object mdmStatus = responseData.get(ValidationConstants.JSON_GET_STATUS);

			if ("Bad request 400".equals(mdmStatus)) {
				throw new SystemException(ControllersConstants.MDM_ERROR + message.toString());
			}
		} catch (final JSONException e) {
			throw new SystemException(ControllersConstants.MDM_ERROR + "Error when reading the JSON message.", e);
		}
	}

	/**
	 * Controller to get Payer Search Result
	 *
	 * @param request
	 *
	 * @return String - JSON results from the MDM Service Rest call
	 */

	@Cacheable(value = "static", key = "#root.methodName")
	@RequestMapping(value = "/getPayerSearchResult", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public PayerPayee getPayerSearchResult(final HttpServletRequest request) {

		String tCode = request.getParameter("tCode");

		setLogPerfMessage(request, "getPayerSearchResult");

		MDMBankAccount mdmBankAccount = getMDMBankAccount(request, tCode);

		String mdmId = mdmBankAccount.getBank_mdm_id();
		MDMBankBranch mdmBankBranch = getMDMBankBranch(request, mdmId);

		PayerPayee payerPayeeSearchDetails = new PayerPayee();
		MDMBankLocation location = mdmBankBranch.getLocations().get(0);

		payerPayeeSearchDetails.setBankAddressLine1(location.getAddress1());
		payerPayeeSearchDetails.setBankName(mdmBankBranch.getBank_legal_name());
		payerPayeeSearchDetails.setBankCity(location.getCity_name());
		payerPayeeSearchDetails.setBankPostalCode(location.getZip_code());
		payerPayeeSearchDetails.setBankState(location.getState_code());
		payerPayeeSearchDetails.setBankBranchCode(mdmBankAccount.getBranch_mdm_id());
		payerPayeeSearchDetails.setBankRoutingCode(mdmBankAccount.getRte_code());
		payerPayeeSearchDetails.setBankRoutingType(mdmBankAccount.getRte_code_type());
		payerPayeeSearchDetails.setBankCurrency(mdmBankAccount.getCurrency_code());
		payerPayeeSearchDetails.setCompanyCode(mdmBankAccount.getComponent_code());
		payerPayeeSearchDetails.setMdmGoldId(mdmBankAccount.getGold_le_code());
		payerPayeeSearchDetails.setMdmLEName(mdmBankAccount.getGold_le_name());
		payerPayeeSearchDetails.setPayerNban(mdmBankAccount.getNatl_bank_acct_nbr());
		payerPayeeSearchDetails.setIbanClabe(mdmBankAccount.getIban());
		payerPayeeSearchDetails.setPayerPayeeSrcId(mdmBankAccount.getTcode());
		payerPayeeSearchDetails.setPaymentRequestId(mdmBankAccount.getRqst_id());
		payerPayeeSearchDetails.setBankAccountNumber(mdmBankAccount.getNatl_bank_acct_nbr());
		payerPayeeSearchDetails.setMdmBusinessName(mdmBankAccount.getBusiness_name());
		payerPayeeSearchDetails.setMdmSubBusinessName(mdmBankAccount.getSub_business_name());
		payerPayeeSearchDetails.setCreateUser(mdmBankAccount.getCreat_usr_id());
		payerPayeeSearchDetails.setCreateDate(new Date());
		payerPayeeSearchDetails.setLastUpdateDate(new Date());
		payerPayeeSearchDetails.setLastUpdateUser(mdmBankAccount.getLst_upd_usr_id());
		payerPayeeSearchDetails.setPayerPayeeId(mdmBankAccount.getRqst_id());
		payerPayeeSearchDetails.setBankCountry(mdmBankAccount.getCountry_code());
		payerPayeeSearchDetails.setBankAccountTitle(mdmBankAccount.getAcct_title());
		payerPayeeSearchDetails.setServiceCenter(mdmBankAccount.getSvc_cntr());
		return payerPayeeSearchDetails;

	}

	/**
	 * Controller to get MDM MDS FX Rate
	 *
	 * @param request
	 * @param payerCurrency
	 * @param payeeCurrency
	 *
	 * @return String - json response from MDS
	 *
	 */
	@RequestMapping(value = "/spotRate", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public String getSpotRate(final HttpServletRequest request,
			@RequestParam(value = "payerCurrency", required = true) final String payerCurrency,
			@RequestParam(value = "payeeCurrency", required = true) final String payeeCurrency) {

		setLogPerfMessage(request, "getMarketRate");
		String currencyCombination = payerCurrency.toUpperCase() + "-" + payeeCurrency.toUpperCase();

		final StringBuilder filter = new StringBuilder();

		filter.append("(");

		filter.append("ds_code='MOREXRTTREAX' and ");
		filter.append("sbscr_code='ALOC' and ");
		filter.append("rec_nm='").append(currencyCombination).append("'");

		filter.append(")");

		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());

		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + marketDataUrl, HttpMethod.GET, false);
		// ds_code='MOREXRTTREAX' and rec_nm = 'EUR-USD' and sbscr_code='ALOC'
		return jsonOutput;
	}

	/**
	 * Controller to get MDM MDS FX Rate
	 *
	 * @param request
	 * @param goldLeName
	 *
	 * @return String - json response from MDS
	 *
	 */
	@RequestMapping(value = "/goldLe", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public String getGoldLeNames(final HttpServletRequest request,
			@RequestParam(value = "goldLeName", required = true) final String goldLeName) {

		setLogPerfMessage(request, "getGoldLeNames");

		final StringBuilder filter = new StringBuilder();
		HashMap<String, String> params = new HashMap<>();
		
		try {
			filter.append("(");

			filter.append("(UPPER(" + LE_PRIMARY_ALT_CODE + ") ").append(OPERATOR_LIKE)
					.append(" UPPER('%" + URLDecoder.decode(goldLeName, "UTF-8") + "%')");
			filter.append(" " + OPERATOR_OR + " ");
			filter.append(UPPER_2 + LE_PARTY_LONG_NM + ") ").append(OPERATOR_LIKE)
					.append(" UPPER('%" + URLDecoder.decode(goldLeName, "UTF-8") + "%'))");
			filter.append(" " + OPERATOR_AND + " ");
			filter.append(UPPER_2 + LE_PRIMRY_SCOURCE_SYSTEM + ") ").append(OPERATOR_EQUALS)
					.append(" UPPER('" + "GOLD" + "')");
			filter.append(" " + OPERATOR_AND + " ");
			filter.append(UPPER_2 + LE_PARTY_STATUS + ") ").append(OPERATOR_EQUALS).append(" UPPER('" + ACTIVE + "')");

			filter.append(")");

			
			params.put(FILTER_CONST, filter.toString());

			
		} catch (Exception e) {
			logger.error("Error while fetching GoldLe ",e);
		}
		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + leUrl, HttpMethod.GET, false);
		// ds_code='MOREXRTTREAX' and rec_nm = 'EUR-USD' and sbscr_code='ALOC'
		return jsonOutput;
	}

	/**
	 * Fetch holiday calendar for currency and country pairs and date range
	 *
	 * @param request
	 * @param calendarNames
	 * @param lowerDateStr
	 * @param greaterDateStr
	 *
	 * @return
	 */
	@RequestMapping(value = "/holiday", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	// 200
	public String getHolidayCalendar(final HttpServletRequest request,
			@RequestParam(value = "calendarName", required = true) final List<String> calendarNames,
			@RequestParam(value = "lowerDate", required = false) final String lowerDateStr,
			@RequestParam(value = "greaterDate", required = false) final String greaterDateStr) {

		setLogPerfMessage(request, "getHolidayCalendar");

		final String filter = getFilterForHolidayCal(calendarNames, lowerDateStr, greaterDateStr);

		HashMap<String, String> params = new HashMap<>();
		params.put(FILTER_CONST, filter.toString());

		String jsonOutput = callMDMDenodo(params, mdmBaseUrl + holidayUrl, HttpMethod.GET, false);

		return jsonOutput;
	}

	/**
	 * Method to construct the filter String used to call the Holiday Calendar
	 * microservice.
	 *
	 * @param calendarNames
	 * @param lowerDateStr
	 * @param greaterDateStr
	 *
	 * @return
	 */
	private String getFilterForHolidayCal(final List<String> calendarNames, final String lowerDateStr,
			final String greaterDateStr) {

		Date lower;
		Date greater;

		// Calculate or get the lower Date; today is taken as default if null
		if (StringUtils.trimToNull(lowerDateStr) == null) {
			lower = new Date();
		} else {
			lower = parseDate(lowerDateStr);
		}

		// Calculate or get the greater Date; lowerDate+14 is taken as default
		// if null
		if (StringUtils.trimToNull(greaterDateStr) == null) {
			final Calendar cal = GregorianCalendar.getInstance();
			cal.setTime(lower);
			cal.add(Calendar.DAY_OF_YEAR, 14);

			greater = cal.getTime();
		} else {
			greater = parseDate(greaterDateStr);
		}

		// Switch the variable values if needed
		if (lower.after(greater)) {
			final Date tmp = lower;
			lower = greater;
			greater = tmp;
		}

		final StringBuilder filter = new StringBuilder();

		/**
		 * Generated String:
		 *
		 * (fin_cntr_code = 'CN1' or fin_cntr_code = 'CN2') and cal_event_status
		 * = 'Active' and hol_dt between TO_DATE('dd-MM-yyyy
		 * HH:mm:ss','01-01-2000 00:00:00') and TO_DATE('dd-MM-yyyy
		 * HH:mm:ss','31-12-2099 23:59:59')
		 */

		filter.append("(");

		boolean firstTime = true;

		for (final String calendarName : calendarNames) {
			if (firstTime) {
				firstTime = false;
			} else {
				filter.append(" or ");
			}
			filter.append("fin_cntr_code = '").append(StringHelper.getValidatedStringAlphaOnly(calendarName))
					.append("'");
		}

		synchronized (DATE_FORMAT) {
			filter.append(") and cal_event_status = 'Active' and hol_dt between TO_DATE('").append(FORMAT_PATTERN)
					.append(" HH:mm:ss','").append(DATE_FORMAT.format(lower)).append(" 00:00:00') and TO_DATE('")
					.append(FORMAT_PATTERN).append(" HH:mm:ss','").append(DATE_FORMAT.format(greater))
					.append(" 23:59:59')");
		}

		return filter.toString();
	}

	/**
	 * Helper method to Parse and Validate the provided dates
	 *
	 * @param date
	 * @return
	 */
	private Date parseDate(final String date) {
		try {
			synchronized (DATE_FORMAT) {
				return (Date) DATE_FORMAT.parseObject(date);
			}
		} catch (final ParseException e) {
			throw new BusinessException("Invalid date Format.", e);
		}
	}
	
	/**
     * Get distinct enterprise standards
     * @return
     */
    @RequestMapping(value = "/fetchESData", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public List<EnterpriseStandards> getDistinctEnterpriseStandards(HttpServletRequest request, @RequestParam(value = "paymentType") String paymentType) throws Exception{

    /*	Map<String,String> approverList = (Map<String,String>) request.getSession().getAttribute("approverList");
    	Map<String,String> preparerList = (Map<String,String>) request.getSession().getAttribute("preparerList");
    	Map<String,String> releaserList = (Map<String,String>) request.getSession().getAttribute("releaserList");
    	Map<String,String> doaAdminList = (Map<String,String>) request.getSession().getAttribute("doaAdminList");*/
    	
        List<EnterpriseStandards> enterpriseStandards = null;
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonOutput = callMDMDenodo(null, esDataUrl, HttpMethod.GET, false);
        
        System.out.println(jsonOutput);
        FineGrainESResponse response = objectMapper.readValue(jsonOutput, FineGrainESResponse.class);
        System.out.println("after reading jsonOutput");
        enterpriseStandards = response.getResponseData();
        
        //Add in session:
        request.getSession().setAttribute("enterprise-standards", enterpriseStandards);
        
        String compareString = paymentType.equalsIgnoreCase("ERP") ? "ERP Batch" : "Manual Payment";
        
        //Remove Duplicates
        List<EnterpriseStandards> enterpriseStandardsReturn = new ArrayList<EnterpriseStandards>();
        
        for(EnterpriseStandards o : enterpriseStandards) {
        	if(!enterpriseStandardsReturn.contains(o) && o.getRequestType().equalsIgnoreCase(compareString)) {
        		enterpriseStandardsReturn.add(o);
        	}
        }
        return enterpriseStandardsReturn;
        
    }
    
    @RequestMapping(value = "/fetchPaymentTypes", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public List<EnterpriseStandards> getPaymentTypes(HttpServletRequest request, @RequestParam(value = "esCd") String esCd, @RequestParam(value = "paymentType") String paymentType) {


        List<EnterpriseStandards> enterpriseStandards = (List<EnterpriseStandards> )request.getSession().getAttribute("enterprise-standards");
        
        //Remove Duplicates
        List<EnterpriseStandards> enterpriseStandardsReturn = new ArrayList<EnterpriseStandards>();
        
        String compareString = paymentType.equalsIgnoreCase("ERP") ? "ERP Batch" : "Manual Payment";
        
        for(EnterpriseStandards o : enterpriseStandards) {
        	if(esCd.equalsIgnoreCase(o.getEsCode()) && o.getRequestType().equalsIgnoreCase(compareString)) {
        		enterpriseStandardsReturn.add(o);
        	}
        }
        return enterpriseStandardsReturn;
        
    }
    
}