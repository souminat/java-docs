/**
 * Copyright GE
 */
package com.ge.treasury.mypayments.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;

import com.ge.treasury.mypayments.constants.ExceptionConstants;
import com.ge.treasury.mypayments.corems.domain.FineGrainRequest_V2;
import com.ge.treasury.mypayments.corems.domain.FineGrainResponse_V2;
import com.ge.treasury.mypayments.domain.HrapiUser;
import com.ge.treasury.mypayments.domain.User;
import com.ge.treasury.mypayments.exceptions.DBException;
import com.ge.treasury.mypayments.exceptions.ResourceNotFoundException;
import com.ge.treasury.mypayments.exceptions.SystemException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.utils.PaymentLogger;
import com.ge.treasury.mypayments.utils.StringHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * User LookUp Controller Class
 * 
 * @author MyPayments Dev Team
 * 
 */
@Controller
@RequestMapping("/api/mypayments/v1")
public class UserLookUpController extends BaseController {
	@Autowired
	private OAuth2RestOperations myPaymentRestTemplate;

	@Value("${user-lookup.url.lookup}")
	private String userLookupBaseUrl;

	@Value("${finegrain-auth-url-get-users}")
	private String getUsersURL;

	@Autowired
	private OAuth2RestOperations msFineGrainRestTemplate;

	/**
	 * Calling User lookup service to get user information
	 * 
	 * @param code
	 * @return
	 */
	@RequestMapping(value = "/userLookUpAssignTo", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<HrapiUser> userLookUpAssignTo(HttpServletRequest request,
			@Valid @NotEmpty @RequestParam(value = "code", required = true) final String code)
			throws ResourceNotFoundException {

		String codeClean = StringHelper.getValidatedString(code);

		PaymentLogger.logInfo(this, "User SSO Received:: " + codeClean);
		String result = null;
		try {
			result = myPaymentRestTemplate.getForObject(userLookupBaseUrl + codeClean + "*", String.class);
		} catch (SystemException | ResourceAccessException | HttpClientErrorException e) {
			PaymentLogger.logError(this, "Error in userLookup method.", e);
			throw new SystemException(ExceptionConstants.USERLOOKUP_SERVICE_DOWN, e);
		} 
		return HrapiUser.getUserList(result);
	}

	/**
	 * Calling User lookup service to get user information
	 * 
	 * @param code
	 * @return
	 */
	@RequestMapping(value = "/userLookUp", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String userLookUp(@Valid @NotEmpty @RequestParam(value = "code", required = true) final String code) {

		final String clean = StringHelper.getValidatedStringAlphaOnly(code);

		PaymentLogger.logInfo(this, "User SSO Received:: " + clean);

		//Sonar Fixes: Local Variables should not be declared and then immediately returned or thrown
		return myPaymentRestTemplate.getForObject(userLookupBaseUrl + clean + "*", String.class);
	}

	/**
	 * Getting User session information
	 * 
	 * @param request
	 * @return
	 * @throws ValidationFailedException
	 * @throws DBException
	 * @throws ResourceNotFoundException
	 */
	@RequestMapping(value = "/getUserSession", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public User getUserSessionInfo(final HttpServletRequest request) {
		return (User) request.getSession().getAttribute("User");
	}

	@RequestMapping(value = "/getApprovers", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public FineGrainResponse_V2 getApprovers(final HttpServletRequest request) {
		FineGrainRequest_V2 fgRequest = new FineGrainRequest_V2();
		fgRequest.setAppName("MYPAYMENTS");
		fgRequest.setRole("Payment Approver");
		String response = this.msFineGrainRestTemplate.postForObject(this.getUsersURL, fgRequest, String.class);
		Gson gson = new GsonBuilder().create();
		
		//Sonar Fixes: Local Variables should not be declared and then immediately returned or thrown
		return gson.fromJson(response, FineGrainResponse_V2.class);
	}
}
