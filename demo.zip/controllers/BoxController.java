package com.ge.treasury.mypayments.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ge.treasury.mypayments.constants.ExceptionConstants;
import com.ge.treasury.mypayments.domain.PaymentDocument;
import com.ge.treasury.mypayments.exceptions.BusinessException;
import com.ge.treasury.mypayments.exceptions.ValidationFailedException;
import com.ge.treasury.mypayments.service.BoxService;

@RestController
@RequestMapping("/box")
public class BoxController extends BaseController {

	@Value("#{'${box.mimetype.blacklist}'.split(';')}")
	private List<String> mimeBlackList;
	@Value("#{'${box.extension.blacklist}'.split(';')}")
	private List<String> extensionBlackList;

	private @Value("#{'${box.files.maxSize}'}") long fileMaxSize;

	@Autowired
	BoxService boxServiceObj;

	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public PaymentDocument uploadFile(@RequestParam(value = "file", required = true) final MultipartFile file,
			@RequestParam(value = "isERPpayment", required = false) final String isERPpayment)
			throws ValidationFailedException {

		if (isERPpayment == "Y") {

			if (mimeBlackList.contains(file.getContentType()) || extensionBlackList
					.contains(FilenameUtils.getExtension(file.getOriginalFilename().toLowerCase()))) {

				BindingResult errors = new BeanPropertyBindingResult(file, "file");
				errors.reject("extensionWhiteList.rejected", ExceptionConstants.FILE_FORMAT_ERROR);
				throw new ValidationFailedException(ExceptionConstants.FILE_FORMAT_ERROR, errors);
			}

			if (file.getSize() > fileMaxSize) {
				BindingResult errors = new BeanPropertyBindingResult(file, "file");
				errors.reject("box.files.maxSize", ExceptionConstants.FILE_SIZE_ERROR);
				throw new ValidationFailedException(ExceptionConstants.FILE_SIZE_ERROR, errors);

			}

		}

		else {
			if (mimeBlackList.contains(file.getContentType()) || extensionBlackList
					.contains(FilenameUtils.getExtension(file.getOriginalFilename().toLowerCase()))) {

				BindingResult errors = new BeanPropertyBindingResult(file, "file");
				errors.reject("extensionWhiteList.rejected", "File is not in an acceptable format");
				throw new ValidationFailedException("File is not in an acceptable format", errors);
			}

			if (file.getSize() > fileMaxSize) {
				BindingResult errors = new BeanPropertyBindingResult(file, "file");
				errors.reject("box.files.maxSize", "File exceeds allowed size");
				throw new ValidationFailedException("File exceeds allowed size", errors);

			}

		}

		String fileId = boxServiceObj.uploadFile(file);
		if (null == fileId) {
			throw new BusinessException(ExceptionConstants.BOX_UPLOAD_ERROR);
		}
		PaymentDocument document = new PaymentDocument();
		document.setFileId(fileId);
		return document;
	}

	@RequestMapping(value = "/saveDraft", method = RequestMethod.POST)
	public void saveDraft(String fileId) {

		boxServiceObj.saveDraft(fileId);
	}

	@RequestMapping(value = "/downloadFileByFileId", method = RequestMethod.GET)
	public void downloadFileByFileId(@RequestParam("fileId") String fileId, HttpServletRequest request,
			HttpServletResponse response) {

		boxServiceObj.downloadFileByFileId(fileId, request, response);
	}

	@RequestMapping(value = "/deleteFileById", method = RequestMethod.POST)
	public boolean deleteFileById(@RequestParam("fileId") String fileId, HttpServletRequest request,
			HttpServletResponse response) {
		boolean deleteflag = false;
		deleteflag = boxServiceObj.deleteFileById(fileId);
		return deleteflag;

	}

}
