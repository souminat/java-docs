select * from employee_details;

drop table employee_details;

create table employee_details(id int,name varchar2(20),salary double);

select * from employee_details; 