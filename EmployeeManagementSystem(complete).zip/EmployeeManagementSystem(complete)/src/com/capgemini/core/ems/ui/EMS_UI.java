package com.capgemini.core.ems.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.dto.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.services.EmployeeServiceImpl;
import com.capgemini.core.ems.services.IEmployeeService;

public class EMS_UI {
	IEmployeeService employeeService = new EmployeeServiceImpl();
	public void startApp() throws EmployeeException{
		
		Scanner console = new Scanner(System.in);
		int choice = 0;
		Employee employee;
		
		System.out.println("EMS Operations:");
		
		System.out.println("1.Add Employee");
		System.out.println("2.Get Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.Remove Employee");
		System.out.println("5.View all Employees");
		System.out.println("6.Exit Application");
		
		System.out.println("Enter your choice");
		choice = console.nextInt();
		switch(choice)
		{
			case 1:
				System.out.println("Enter employee id");
				int id = console.nextInt();
				
				System.out.println("Enter employee name");
				String name = console.next();
				
				System.out.println("Enter employee salary");
				float salary = console.nextFloat();
				
			 employee = new Employee(id,name,salary);
			 //System.out.println("Employee added successfully");
			try {
				employeeService.addEmployee(employee);
			} catch (Exception e) {
				
				System.out.println("Something went wrong while adding a record");
				System.out.println("Error: "+e.getMessage());
			}
			//System.out.println("Employee added successfully");
				//break;
			case 2:
				System.out.println("Enter employee id");
				int id1 = console.nextInt();
				
			try {
				 employee =  employeeService.getEmployee(id1);
				 
				 System.out.println("Employee ID: "+employee.getId());
				 System.out.println("Employee Name: "+employee.getName());
				 System.out.println("Employee Salary: "+employee.getSalary());
			} catch (EmployeeException e) {
				
				System.out.println("Employee not found for ID: "+id1);
				System.out.println("Error: "+e.getMessage());
			}
			
				break;
			case 3:
				System.out.println("Enter employee id to update");
				int id2 = console.nextInt();
				employee = employeeService.updateDateEmployee(id2);
				
				System.out.println("Employee updated");
				System.out.println("Employee ID: "+employee.getId());
				System.out.println("Employee Name: "+employee.getName());
				System.out.println("Employee Salary: "+employee.getSalary());
				break;
			case 4:
				System.out.println("Enter id of the employee to remove");
				int id3 = console.nextInt();
				employee = employeeService.removeEmployee(id3);
				
				System.out.println("Employee deleted");
				System.out.println("Employee ID: "+employee.getId());
				System.out.println("Employee Name: "+employee.getName());
				System.out.println("Employee Salary: "+employee.getSalary());
				break;
			case 5:
			try {
				List<Employee> employee1 = new ArrayList<>();
				employee1 = employeeService.getEmployees();
				Iterator<Employee> it = employee1.iterator();
				while(it.hasNext()){
					
					 employee = it.next();
					 System.out.println("Employee ID: "+employee.getId());
					 System.out.println("Employee Name: "+employee.getName());
					 System.out.println("Employee Salary: "+employee.getSalary());
					 System.out.println();
				}
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
				break;
			case 6:
				System.out.println("Good Bye");
				System.exit(0);
		
		
		
		}
		//Add Employee UI	
		//GetEmployee UI
		//UpdateEmployee UI
		//removeEmployee UI
	}
	
	public static void main(String[] args) throws EmployeeException{
		EMS_UI app = new EMS_UI();
		
		app.startApp();
		
	}
}
