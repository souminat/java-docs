package com.capgemini.core.ems.util;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;


//Singleton

public class DBUtil//factory class
{
	private static Connection connection;
	public static Connection getConnection() throws SQLException{
			
			if(connection == null){
				OracleDataSource ods = new OracleDataSource();
				
				ods.setUser("system");
				ods.setPassword("sam");
				ods.setDriverType("thin");
				ods.setNetworkProtocol("tcp");
				ods.setURL("jdbc:oracle:thin:@DESKTOP-0O3KG4K:1521:XE");
				connection = ods.getConnection();
			}

				return connection;
			
	}
	public static void main(String[] args) throws SQLException {
			Connection connection = DBUtil.getConnection();
			if(connection!=null){
				System.out.println(connection.getMetaData().getDatabaseProductName());
			}
			else{
				System.out.println("Connection not successfull");
			}
			//System.out.println(connection.getMetaData().getDatabaseProductName());
	}	
}

