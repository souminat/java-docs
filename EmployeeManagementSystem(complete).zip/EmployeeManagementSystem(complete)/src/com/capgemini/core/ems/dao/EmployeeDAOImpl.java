package com.capgemini.core.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.dto.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO {
	
	/*String driver = "oracle.jdbc.OracleDriver";
	String url = "jdbc:oracle:thin:@PUNHWD11917.corp.capgemini.com:1521:ORCL";
	String userName = "lab1ftrg36";
	String password = "lab1foracle";*/
	ResultSet rs=null;
	Statement stmt=null;
	Connection connect=null;
	Scanner in = new Scanner(System.in);

	@Override
	public void addEmployee(Employee employee) throws EmployeeException {
		Connection con = null;
		
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement("insert into employee_details_100906 values(?,?,?)");
			
			pstmt.setInt(1, employee.getId());
			pstmt.setString(2, employee.getName());
			pstmt.setFloat(3, employee.getSalary());
			
			pstmt.execute();
			
		} catch (SQLException e) {
			//throw new EmployeeException();
			e.printStackTrace();
		}finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		
		Connection con = null;
		Employee employee=null;
		try{
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement("select * from employee_details_100906 where id=?"+id);
			pstmt.setInt(1, id);
			ResultSet res = pstmt.executeQuery();
			while(res.next()){
				employee = new Employee();
				employee.setId(res.getInt("id"));
				employee.setName(res.getString("name"));
				employee.setSalary(res.getFloat("salary"));
			}
			
			
		}catch(Exception e){
			
		}finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		if(employee == null){
			throw new EmployeeException("Employee not found");
		}
		
		return employee;
	}

	@Override
	public Employee updateDateEmployee(int id)throws EmployeeException {
		Connection con = null;
		PreparedStatement pstmt=null;
		Employee employee=null;
		ResultSet res=null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from employee_details_100906 where id=?"+id);
			pstmt.setInt(1, id);
			 res = pstmt.executeQuery();
			//employee = getEmployee(id);
			if(res == null){
				throw new EmployeeException("Employee ID "+id+"not found");
			}
			System.out.println("Enter new name");
			String name = in.next();
			System.out.println("Enter new salary");
			float salary = in.nextFloat();
			
			
			//String sql = ;
			pstmt = con.prepareStatement("update employee_details_100906 set name=?,salary =? where id=?"+id);

			pstmt.setString(1,name);
			pstmt.setFloat(2,salary);
			pstmt.setInt(3,id);
			
			int count = pstmt.executeUpdate();
			if(count>0){
				pstmt = con.prepareStatement("select * from employee_details_100906 where id=?"+id);
				pstmt.setInt(1, id);
				res = pstmt.executeQuery();
				while(res.next()){
				employee = new Employee();
				employee.setId(res.getInt("id"));
				employee.setName(res.getString("name"));
				employee.setSalary(res.getFloat("salary"));
				}
				//return employee;
			}
			
			//ResultSet res = 
			
			System.out.println("No.of rows updated: "+count);
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return employee;
	}

	@Override
	public Employee removeEmployee(int id) {
		Connection con=null;
		PreparedStatement pstmt = null;
		ResultSet res = null;
		Employee employee=null;
		try {
			con=DBUtil.getConnection();
			//Employee employee = getEmployee(id);
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from employee_details_100906 where id=?"+id);
			pstmt.setInt(1, id);
			 res = pstmt.executeQuery();
			//employee = getEmployee(id);
			if(res == null){
				throw new EmployeeException("Employee ID "+id+"not found");
			}
			 while(res.next()){
					employee = new Employee();
					employee.setId(res.getInt("id"));
					employee.setName(res.getString("name"));
					employee.setSalary(res.getFloat("salary"));
					}
			pstmt = con.prepareStatement("delete from employee_details_100906 where id=?"+id);
			pstmt.setInt(1, id);
			int count = pstmt.executeUpdate();
			if(count>0){
				System.out.println("No. of rows updated: "+count);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return employee;
	}

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		
		List<Employee> employee = new ArrayList<>();
		Connection con = null;
		
		try {
			con = DBUtil.getConnection();
			Statement stmt = con.createStatement();
			
			ResultSet res = stmt.executeQuery("select * from employee_details_100906");
			
			while(res.next()){
				Employee emp  =new Employee();
				
				emp.setId(res.getInt("id"));
				emp.setName(res.getString("name"));
				emp.setSalary(res.getFloat("salary"));
				
				employee.add(emp);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException();
		}finally{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		if(employee.isEmpty()){
			System.out.println("No employee in the database");
		}
	
		return employee;
		
	}
	
	
}
