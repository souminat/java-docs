package com.capgemini.core.ems.dao;

import java.util.List;

import com.capgemini.core.ems.dto.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;

public interface IEmployeeDAO {
	public void addEmployee(Employee employee)throws EmployeeException; 
	
	public Employee getEmployee(int id)throws EmployeeException;
	
	public Employee updateDateEmployee(int id)throws EmployeeException;
	
	public Employee removeEmployee(int id);
	
	public List<Employee>getEmployees()throws EmployeeException;
}
