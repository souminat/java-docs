package com.capgemini.core.ems.services;

import java.util.List;

import com.capgemini.core.ems.dao.EmployeeDAOImpl;
import com.capgemini.core.ems.dao.IEmployeeDAO;
import com.capgemini.core.ems.dto.Employee;
import com.capgemini.core.ems.exceptions.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	
	//loose coupling
	IEmployeeDAO employeeDAO = new EmployeeDAOImpl();
	
	@Override
	public void addEmployee(Employee employee) throws EmployeeException {
		employeeDAO.addEmployee(employee);
		
	}

	@Override
	public Employee getEmployee(int id)throws EmployeeException {
		return employeeDAO.getEmployee(id);
	}

	@Override
	public Employee updateDateEmployee(int id)throws EmployeeException {
		// TODO Auto-generated method stub
		Employee employee = employeeDAO.updateDateEmployee(id);
		return employee;
	}

	@Override
	public Employee removeEmployee(int id) {
		
		return employeeDAO.removeEmployee(id);
	}

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		return employeeDAO.getEmployees();
	}

}
