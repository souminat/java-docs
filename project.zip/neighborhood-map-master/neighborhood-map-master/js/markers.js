var myLocations = [
    {
        title: 'Discovery Docks Apartments',
        lat: 51.501409,
        lng:  -0.018823,
        type: 'Living Quarters'
    },
    {
        title: 'Nandos Restaurant',
        lat: 51.5023146,
        lng: -0.0187593,
        type: 'Restaurant'
    },
    {
        title: 'Canary Wharf Tube Station',
        lat: 51.5034898,
        lng: -0.0185944,
        type:  'Transit'
    },
    {
        title: 'One Canada Square',
        lat: 51.5049494,
        lng: -0.0194997,
        type:  'Shopping'
    },
    {
        title: 'The O2',
        lat: 51.503039,
        lng: 0.003154,
        type: 'Entertainment'
    },
    {
        title: 'Tesco Express',
        lat: 51.500575,
        lng: -0.017354,
        type: 'Shopping'
    },
    {
        title: 'Firezza Pizza',
        lat: 51.496268,
        lng: -0.015511,
        type: 'Restaurant'
    },
    {
        title: 'The Breakfast Club',
        lat: 51.506066,
        lng: -0.017345,
        type: 'Restaurant'
    },
    {
        title: 'Shake Shack',
        lat: 51.504905,
        lng: -0.018967,
        type: 'Restaurant'
    },
    {
        title: 'Asda Superstore',
        lat: 51.494206,
        lng: -0.012714,
        type: 'Shopping'
    },
    {
        title: 'Pizza Express',
        lat: 51.505233,
        lng: -0.021716,
        type: 'Restaurant'
    }
]