angular.module("mainApp",['ui.router','ngResource','appService','employeeController']);

angular.module("mainApp")
	.config(function($stateProvider,$httpProvider){
		$httpProvider.defaults.useXDomain = true;
		
		$stateProvider
			.state('employees',{
				url:'/employees',
				templateUrl:'viewall.html',
				controller:'viewController',
				resolve:{
					employeeData:function(EmployeeService){
						var EmployeeData = EmployeeService.query();
						return EmployeeData.$promise;
					}
				}
			})
			.state('viewEmployee',{
				url:'data/employees/:id/view',
				templateUrl:'view.html',
				controller:'viewController'
			});
	}).run(function($state){
   $state.go('employees');
});