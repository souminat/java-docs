var app = angular.module("appService",[]);
app.factory('EmployeeService', function($resource) {
		return $resource('data/employees-test.json');
    });