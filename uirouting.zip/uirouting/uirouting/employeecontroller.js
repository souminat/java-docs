angular.module("employeeController",[])
	.controller("viewController",function($scope,$stateParams,employeeData){
	$scope.employees = employeeData;
	//$scope.employee = EmployeeService.get({id:$stateParams.id});
	});