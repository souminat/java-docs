package com.cg.core.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.jboss.resteasy.spi.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.core.dao.ProductRepositoryImpl;
import com.cg.core.dto.Product;
import com.cg.core.exception.ProductException;
import com.cg.core.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	private IProductService productService;
	
	private static Logger logg = Logger.getLogger(ProductController.class);

	@RequestMapping("/add")
	public String add(Model model){
		model.addAttribute("product", new Product());
		return "home";
		
	}
	
	@RequestMapping("/addProduct")
	public String addProduct(@ModelAttribute("product")@Valid Product product,BindingResult res,Model model){
		
	
	if(res.hasErrors()){
			return "home";
		}else{
			//System.out.println("hello1");
			product  = productService.addProduct(product);
			//System.out.println("hello2");
			logg.info("In Controller");
			logg.info("Record Inserted :"+product);
			model.addAttribute("product",product);
			return "display";
		}
	}
	
	@RequestMapping("/showAll")
	public String showAllProducts(Model model){
		List<Product>productList = productService.showAllProducts();
		try {
			if(productList.isEmpty()){
				throw new DataAccessException("Product List is Empty") {
				};
			}else{
			    model.addAttribute("productList",productList);
			}
		} catch (DataAccessException e) {
				model.addAttribute("msg", e.getMessage());
				return "error";
		}
		return "showAll";
	}
	
	@RequestMapping("/update")
	public String update(@RequestParam("id")Long productId,Model model){
		Product product = productService.findProduct(productId);
		
		try {
			if(product == null){
				throw new DataAccessException("Product does not exist"){
						};
			}
		} catch (DataAccessException e) {
			model.addAttribute("msg", e.getMessage());
			return "error";
		}
		model.addAttribute("product", product);
		return "updateForm";
	}
	
	@RequestMapping("/updateProduct")
	public String updateProduct(@ModelAttribute("product")@Valid Product product,BindingResult res,Model model){
	
		
		if(res.hasErrors()){
			return "updateForm";
		}else{
			product = productService.updateProduct(product);
			model.addAttribute("product", product);
		}
		return "updated";
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam("id")Long id,Model model){
			Product product = productService.deleteProduct(id);
			
			try {
				if(product == null){
					throw new DataAccessException("Product does not exist") {
					};
				}
			} catch (DataAccessException e1) {
				model.addAttribute("msg", e1.getMessage());
				return "error";
			}
			
			List<Product>productList = productService.showAllProducts();
			try {
				if(productList.isEmpty()){
					throw new DataAccessException("Product List is Empty") {
					};
				}else{
				    model.addAttribute("productList",productList);
				}
			} catch (DataAccessException e) {
					model.addAttribute("msg", e.getMessage());
					return "error";
			}
			
			return "showAll";
	}
}
