package com.cg.core.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "productId")
	@SequenceGenerator(name="productId",sequenceName="product_sequence",initialValue=1000)
	//@SequenceGenerator(name="emp_generator",sequenceName="seq_emps",allocationSize=1,initialValue=1)
	private Long productId;
	@NotEmpty(message="Name should not be empty")
	@Pattern(regexp = "^[A-Z][a-z]*", message = "Must contain characters only begining with a capital letter")
	private String productName;
	@NotNull(message="Field cannot be empty")
	//@Size(min = 1,message = "Price should not be less than/equal to zero")
	private Double price;
	@NotNull(message="Field cannot be empty")
	//@Size(min = 1,message = "Quantity cannot be zero")
	private Integer quantity;
	private String stock;
	private String category;
	
	
	public Product() {
		super();
	}

	


	public Product(String productName, Double price, Integer quantity,
			String stock, String category) {
		super();
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
		this.stock = stock;
		this.category = category;
	}




	public Long getProductId() {
		return productId;
	}



	public void setProductId(Long productId) {
		this.productId = productId;
	}



	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public String getStock() {
		return stock;
	}


	public void setStock(String stock) {
		this.stock = stock;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}



	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", price=" + price + ", quantity=" + quantity
				+ ", stock=" + stock + ", category=" + category + "]";
	}

	
	


	


	
	
	
}
