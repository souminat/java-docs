package com.cg.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.core.dto.Product;

public interface IProductRepository {
	public Product addProduct(Product product);
	public List<Product> showAllProducts();
	public Product findProduct(Long id);
	public Product updateProduct(Product product);
	public Product deleteProduct(Long id);
}
