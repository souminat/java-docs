package com.cg.core.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.core.dto.Product;
import com.cg.core.exception.ProductException;

@Repository
public class ProductRepositoryImpl implements IProductRepository{

	@PersistenceContext
	private EntityManager manager;
	
	private static Logger logg = Logger.getLogger(ProductRepositoryImpl.class);
	@Override
	public Product addProduct(Product product) {
		
		manager.persist(product);
		//product = manager.find(Product.class, product.getProductId());
		logg.info("Record Inserted :"+product);
		return product;
	}

	@Override
	public List<Product> showAllProducts() {
		TypedQuery<Product> queryList = manager.createQuery("SELECT a FROM Product a", Product.class);
		try {
			if(queryList.equals(null)){
				throw new ProductException();
			}
		} catch (ProductException e) {
			return null;
		}
		return queryList.getResultList();
	}

	@Override
	public Product findProduct(Long id) {
		Product product = manager.find(Product.class,id);
		
		try {
			if(product == null){
				throw new ProductException();
			}
		} catch (ProductException e) {
			return null;
		}
		
		return product;
	}

	@Override
	public Product updateProduct(Product product) {
		
		Product product1 = manager.find(Product.class, product.getProductId());
		product1.setProductId(product.getProductId());
		product1.setProductName(product.getProductName());
		product1.setPrice(product.getPrice());
		product1.setQuantity(product.getQuantity());
		product1.setStock(product.getStock());
		product1.setCategory(product.getCategory());
		
		
		return product1;
	}

	@Override
	public Product deleteProduct(Long id) {
		Product product = manager.find(Product.class, id);
		Product product1 = product;
		try {
			if(product == null){
				throw new ProductException();
			}
		} catch (ProductException e) {
				return null;
		}
		manager.remove(product);
		return product1;
		
	}
		
	

}
