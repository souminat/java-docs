package com.cg.core.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.core.dto.Product;

public interface IProductService {
	
	public Product addProduct(Product product);
	public List<Product> showAllProducts();
	public Product findProduct(Long id);
	public Product updateProduct(Product product);
	public Product deleteProduct(Long id);
}
