package com.cg.core.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.core.dao.IProductRepository;
import com.cg.core.dao.ProductRepositoryImpl;
import com.cg.core.dto.Product;

@Service
@Transactional
public class ProductServiceImpl implements IProductService{

	@Autowired
	private IProductRepository productDao;
	
	@Override
	public Product addProduct(Product product) {
		return productDao.addProduct(product);
	}

	@Override
	public List<Product> showAllProducts() {
		return productDao.showAllProducts();
	}

	@Override
	public Product findProduct(Long id) {
		return productDao.findProduct(id);
	}

	@Override
	public Product updateProduct(Product product) {
		return productDao.updateProduct(product);
	}

	@Override
	public Product deleteProduct(Long id) {
		return productDao.deleteProduct(id);
	}
	
	
}
